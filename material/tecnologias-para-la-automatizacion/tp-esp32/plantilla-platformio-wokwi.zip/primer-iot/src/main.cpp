#include <Arduino.h> // librerías integradas con ARDUINO + de 3ros + propias

//sentencias de precompilacion
//***definiciones globales***
//definición de prototipos de funciones
//clases
const short PIN_LED = 26;


void setup() { // 1 sola vez al inicio del run
    Serial.begin(9600); //velocidad para transmitir y recibir datos por Puerto Serie
    pinMode(PIN_LED, OUTPUT);
    Serial.println("Primer proyecto IoT iniciado");
}

void loop() {
    digitalWrite(PIN_LED, HIGH);
    delay(500);
    digitalWrite(PIN_LED, LOW);
    delay(500);
}


//Cuerpo las funciones declaradas en la sección global