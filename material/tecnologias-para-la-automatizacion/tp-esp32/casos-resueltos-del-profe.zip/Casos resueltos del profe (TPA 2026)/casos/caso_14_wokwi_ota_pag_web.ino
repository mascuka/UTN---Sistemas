
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ================== CONFIGURACION ==================

// WiFi gratuito de Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Servidor ThingSpeak
const char* server = "http://api.thingspeak.com/update";

// Escribir aqui la Write API Key de tu canal
String apiKey = "TU_API_KEY";

// Sensor DHT22
#define DHTPIN 33
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

// Enviar datos cada 20 segundos
unsigned long previousMillis = 0;
const unsigned long interval = 20000;

// ==================== SETUP ====================

void setup() {

  Serial.begin(115200);

  // Inicializar sensor
  dht.begin();

  Serial.println("Iniciando ESP32 en Wokwi");

  // Conectar a WiFi de Wokwi
  WiFi.begin(ssid, password, 6);

  Serial.print("Conectando a WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado");

  Serial.print("IP local: ");
  Serial.println(WiFi.localIP());

  Serial.println("Sensor DHT22 iniciado");
  Serial.println("Envio a ThingSpeak cada 20 segundos");

  Serial.println("-----------------------------");
}

// ==================== LOOP ====================

void loop() {

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {

    previousMillis = currentMillis;

    enviarAThingSpeak();
  }

  delay(10);
}

// ==================== ENVIO A THINGSPEAK ====================

void enviarAThingSpeak() {

  // Leer temperatura y humedad
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  // Verificar sensor
  if (isnan(t) || isnan(h)) {
    Serial.println("Error al leer del sensor DHT22");
    return;
  }

  // Mostrar valores en monitor serie
  Serial.println();
  Serial.println("===== DATOS DEL SENSOR =====");

  Serial.print("Temperatura: ");
  Serial.print(t);
  Serial.println(" C");

  Serial.print("Humedad: ");
  Serial.print(h);
  Serial.println(" %");

  // Verificar WiFi
  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    // Construir URL de envio
    String url = String(server) +
                 "?api_key=" + apiKey +
                 "&field1=" + String(t) +
                 "&field2=" + String(h);

    Serial.println("Enviando datos a ThingSpeak...");

    // Iniciar solicitud HTTP
    http.begin(url);

    // Limitar tiempo de espera
    http.setTimeout(10000);

    // Medir tiempo de envio
    unsigned long inicioHTTP = millis();

    int httpCode = http.GET();

    unsigned long tiempoHTTP = millis() - inicioHTTP;

    // Mostrar codigo HTTP
    Serial.print("HTTP Code: ");
    Serial.println(httpCode);

    Serial.print("Tiempo HTTP: ");
    Serial.print(tiempoHTTP);
    Serial.println(" ms");

    if (httpCode == 200) {

      String respuesta = http.getString();
      respuesta.trim();

      if (respuesta != "0" &&
          respuesta.length() > 0) {

        Serial.println("Datos enviados correctamente");

        Serial.print("Numero de entrada: ");
        Serial.println(respuesta);

      } else {

        Serial.println("ThingSpeak rechazo los datos");
      }

    } else {

      Serial.print("Error al enviar: ");
      Serial.println(http.errorToString(httpCode));
    }

    http.end();

  } else {

    Serial.println("WiFi desconectado");
    WiFi.reconnect();
  }

  Serial.println("============================");
}
