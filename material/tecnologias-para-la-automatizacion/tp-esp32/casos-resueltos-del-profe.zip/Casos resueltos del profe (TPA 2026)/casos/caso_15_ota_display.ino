#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <ArduinoJson.h>

// ================== CONFIGURACIÓN ==================
//const char* ssid = "TU_RED_WIFI";
//const char* password = "";

// Datos del canal de ThingSpeak
const char* channelID = "";  // numero de canal
const char* readAPIKey = "TU_API_KEY";  // read api key o  puede ser "" si el canal es público

const char* server = "http://api.thingspeak.com";

// ================== OLED ==================
Adafruit_SH1106G display = Adafruit_SH1106G(128, 64, &Wire, -1);

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);

  // Iniciar pantalla OLED
  //Inicializar pantalla OLED
display.begin(0x3c, true); //Dirección por defecto: 0x3C
display.setTextSize(1);
display.setTextColor(SH110X_WHITE);
updateOLEDMod("OLED Module ON!");

  // Conectar a WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi conectado");

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("WiFi conectado");
  display.display();
  delay(1000);
}

// ================== LOOP ==================
void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    // URL de lectura del canal
    String url = String(server) + "/channels/" + channelID + "/feeds.json?results=1";
    if (strlen(readAPIKey) > 0) {
      url += "&api_key=" + String(readAPIKey);
    }

    http.begin(url);
    int httpCode = http.GET();

    if (httpCode == 200) {
      String payload = http.getString();
      Serial.println(payload);

      const size_t capacity = JSON_ARRAY_SIZE(1) + JSON_OBJECT_SIZE(2) + JSON_OBJECT_SIZE(1) + 200;
DynamicJsonDocument doc(capacity);

deserializeJson(doc, payload);
float tempValue = doc["feeds"][0]["field1"].as<float>();
float humValue = doc["feeds"][0]["field2"].as<float>();

      // Mostrar en OLED
      display.clearDisplay();
      display.setCursor(0, 0);
      display.println("Datos desde ThingSpeak");
      display.println("-----------------------");
      display.print("Temp: ");
      display.print(tempValue);
      display.println(" °C");
      display.print("Hum:  ");
      display.print(humValue);
      display.println(" %");
      display.display();
    } else {
      Serial.print("Error al obtener datos: ");
      Serial.println(httpCode);
    }
    http.end();
  }

  delay(20000); // Esperar 20 segundos
}
void updateOLEDMod(String txt){

display.clearDisplay();
display.setCursor(0,0);
display.println(txt);
display.display();
}
