#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
const int LED1 = 23;

//Credenciales red Wifi
const char *ssid = "TU_RED_WIFI";
const char *password = "";

//Telegram BOT Token
const String botToken = "";
//const unsigned long tiempo = 1000; //tiempo medio entre mensajes de escaneo
const unsigned long botMTBS = 1000; //mean time between scan messages
unsigned long botLastScan;
uint8_t ledstatus = 0;

//objects
WiFiClientSecure secured_client;
UniversalTelegramBot bot(botToken, secured_client);
void setup() {
  // put your setup code here, to run once:
Serial.begin(115200);
Serial.println();
pinMode(LED1,OUTPUT);
delay(30);
Serial.print ("Conectar a la red Wifi ");
Serial.print(ssid);
WiFi.begin(ssid,password);
secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT); 

while (WiFi.status() != WL_CONNECTED)
{
  Serial.print("·");
  delay(500);
}
Serial.print ("\nWifi conectado ");
//Serial.print ("\nWifi conectado. Direccion IP: ");
//Serial.println (WiFi.localIP());
}

// Funciones de ayuda
void handleNewMessages(int numNewMessages)
{
  Serial.print ("handleNewMessages ");
  Serial.println(numNewMessages);
   for (int i = 0; i < numNewMessages; i++)
   {
     String chat_id = bot.messages[i].chat_id;
     String text = bot.messages[i].text;
     String from_name = bot.messages[i].from_name;
     if (from_name == "")
         from_name = "Guest";

         if (text == "/led+")
         {
           // aumenta el brillo
           for(int ciclo = 0; ciclo <= 255; ciclo++){
           analogWrite(LED1, ciclo);
           delay(5);
           //digitalWrite(LED1, HIGH); // turn the LED on (HIGH is the voltage level)
           //ledstatus = 1;
           }
           bot.sendMessage(chat_id, "Led mas", "");
         }
            

         if (text == "/led-")
         {
           // disminuye el brillo
           for(int ciclo = 255; ciclo >= 0; ciclo--){
           analogWrite(LED1, ciclo);
           delay(5);
           }
           //delay(1000);
           //ledstatus = 0;
           //digitalWrite(LED1, LOW); // turn the LED off (LOW is the voltage level )
           bot.sendMessage(chat_id, "Led menos", "");
          }
          //if (text == "/status")
          //{
          //  if (ledstatus)
          //  {
          //    bot.sendMessage(chat_id, "Led ON", "");
          //   }
          //   else
          //   {
          //     bot.sendMessage(chat_id, "Led OFF", "");
          //   }
          //}
          if (text == "/start")
          {
            String welcome = "Welcome to Universal Arduino Telegram Bot library, " ;//+ from_name + "
            welcome += "This is flash Led Bot example.\n\n";
            welcome += "/led+ : aumenta brillo led \n";
            welcome += "/led- : disminuye brillo led \n";
            bot.sendMessage(chat_id, welcome, "Markdown");
          }
   }
}

void loop() {
  // put your main code here, to run repeatedly:
if (millis() - botLastScan > botMTBS)
{
  int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  while (numNewMessages)
{
  Serial.println("Respuesta obtenida");
  handleNewMessages(numNewMessages);
  numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  
}
botLastScan = millis();
}
}
