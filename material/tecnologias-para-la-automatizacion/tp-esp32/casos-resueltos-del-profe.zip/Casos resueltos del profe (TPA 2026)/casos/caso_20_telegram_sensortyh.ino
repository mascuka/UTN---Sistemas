#include "DHT.h"
#include <Adafruit_Sensor.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>

#define DHTTYPE DHT22   // DHT 22
#define DHTPIN 33
DHT dht(DHTPIN, DHTTYPE);
//Credenciales red Wifi
//const char *ssid = "TU_RED_WIFI";
//const char *password = "";

//Telegram BOT Token
const String botToken = "TU_TOKEN_DEL_BOT";
//const unsigned long tiempo = 1000; //tiempo medio entre mensajes de escaneo
const unsigned long botMTBS = 1000; //mean time between scan messages
unsigned long botLastScan;

//objects
WiFiClientSecure secured_client;
UniversalTelegramBot bot(botToken, secured_client);

void setup() {
  dht.begin();
  Serial.begin(115200);
  Serial.print("Connecting to WiFi");
  //WiFi.begin("Wokwi-GUEST", "", 6);
  WiFi.begin(ssid,password);
  secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT); 
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }
  Serial.println(" Connected!");
}

// Funciones de ayuda
String floatToString( float n, int l, int d, boolean z){
 char c[l+1];
 String s;

 dtostrf(n,l,d,c);
 s=String(c);

 if(z){
 s.replace(" ","0");
 }
 return s;
}

void handleNewMessages(int numNewMessages)
{
  Serial.print ("handleNewMessages ");
  Serial.println(numNewMessages);
   for (int i = 0; i < numNewMessages; i++)
   {
     String chat_id = bot.messages[i].chat_id;
     String text = bot.messages[i].text;
     String from_name = bot.messages[i].from_name;
     if (from_name == "")
         from_name = "Guest";

         
         if (text == "/temperatura")
         {
           
           float t = dht.readTemperature();
           String tstr = floatToString(t,2,2,false);
           bot.sendMessage(chat_id, "Temperatura: ");
           bot.sendMessage(chat_id, tstr);
           bot.sendMessage(chat_id, "grados");
           
         }
         if (text == "/humedad")
         {
           float h = dht.readHumidity();
           String hstr = floatToString(h,2,2,false);
           bot.sendMessage(chat_id, "Humedad: ");
           bot.sendMessage(chat_id, hstr);
           bot.sendMessage(chat_id, " %");
         }
         
          if (text == "/start")
          {
            String welcome = "Welcome to Universal Arduino Telegram Bot library, " ;//+ from_name + "
            welcome += "This is flash temperature humidity Bot example.\n\n";
            welcome += "/temperatura : lectura temperatura\n";
            welcome += "/humedad : lectura humedad\n";
            bot.sendMessage(chat_id, welcome, "Markdown");
          }
   }
}

void loop() {
  // put your main code here, to run repeatedly:
if (millis() - botLastScan > botMTBS)
{
  int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  while (numNewMessages)
{
  Serial.println("Respuesta obtenida");
  handleNewMessages(numNewMessages);
  numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  
}
botLastScan = millis();
}
}


