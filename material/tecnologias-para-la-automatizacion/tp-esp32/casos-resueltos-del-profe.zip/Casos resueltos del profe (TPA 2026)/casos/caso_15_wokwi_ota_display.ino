
#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <ArduinoJson.h>

// ================== CONFIGURACION ==================

// WiFi gratuito de Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Datos del canal ThingSpeak
const char* channelID = "0000000";
const char* readAPIKey = "TU_API_KEY";

// Servidor ThingSpeak
const char* server = "http://api.thingspeak.com";

// ================== OLED SH1106 ==================

#define SDA_PIN 21
#define SCL_PIN 22

Adafruit_SH1106G display =
  Adafruit_SH1106G(128, 64, &Wire, -1);

// ================== TEMPORIZACION ==================

unsigned long previousMillis = 0;
const unsigned long interval = 20000;

// ================== FUNCION OLED ==================

void updateOLEDMod(String txt) {

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println(txt);
  display.display();
}

// ================== LECTURA THINGSPEAK ==================

void leerThingSpeak() {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("WiFi desconectado");
    updateOLEDMod("WiFi desconectado");
    WiFi.reconnect();
    return;
  }

  HTTPClient http;

  // Leer el ultimo registro del canal
  String url = String(server) +
               "/channels/" +
               String(channelID) +
               "/feeds/last.json";

  if (strlen(readAPIKey) > 0) {
    url += "?api_key=" + String(readAPIKey);
  }

  Serial.println();
  Serial.println("Consultando ThingSpeak...");

  http.begin(url);
  http.setTimeout(5000);

  unsigned long inicioHTTP = millis();

  int httpCode = http.GET();

  unsigned long tiempoHTTP = millis() - inicioHTTP;

  Serial.print("HTTP Code: ");
  Serial.println(httpCode);

  Serial.print("Tiempo HTTP: ");
  Serial.print(tiempoHTTP);
  Serial.println(" ms");

  if (httpCode == 200) {

    String payload = http.getString();

    Serial.println("Respuesta:");
    Serial.println(payload);

    DynamicJsonDocument doc(2048);

    DeserializationError error =
      deserializeJson(doc, payload);

    if (error) {

      Serial.println("Error al interpretar JSON");
      updateOLEDMod("Error JSON");

      http.end();
      return;
    }

    if (doc["field1"].isNull() ||
        doc["field2"].isNull()) {

      Serial.println("Campos sin datos");
      updateOLEDMod("Campos sin datos");

      http.end();
      return;
    }

    float tempValue = doc["field1"].as<float>();
    float humValue = doc["field2"].as<float>();

    Serial.print("Temperatura: ");
    Serial.println(tempValue);

    Serial.print("Humedad: ");
    Serial.println(humValue);

    // Mostrar en pantalla OLED
    display.clearDisplay();
    display.setCursor(0, 0);

    display.println("Datos desde ThingSpeak");
    display.println("--------------------");

    display.print("Temp: ");
    display.print(tempValue, 1);
    display.println(" C");

    display.print("Hum: ");
    display.print(humValue, 1);
    display.println(" %");

    display.display();

  } else {

    Serial.print("Error al obtener datos: ");
    Serial.println(httpCode);

    updateOLEDMod("Error ThingSpeak");
  }

  http.end();
}

// ================== SETUP ==================

void setup() {

  Serial.begin(115200);

  // Inicializar bus I2C
  Wire.begin(SDA_PIN, SCL_PIN);

  // Inicializar OLED SH1106
  if (!display.begin(0x3C, true)) {

    Serial.println("Error al iniciar OLED");

    while (true) {
      delay(100);
    }
  }

  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);

  updateOLEDMod("OLED Module ON!");

  delay(1000);

  // Conectar a WiFi de Wokwi
  Serial.println("Conectando a Wokwi-GUEST");

  WiFi.begin(ssid, password, 6);

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado");

  Serial.print("Direccion IP: ");
  Serial.println(WiFi.localIP());

  updateOLEDMod("WiFi conectado");

  delay(1000);

  // Primera consulta
  leerThingSpeak();

  previousMillis = millis();
}

// ================== LOOP ==================

void loop() {

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {

    leerThingSpeak();

    previousMillis = millis();
  }

  delay(10);
}

