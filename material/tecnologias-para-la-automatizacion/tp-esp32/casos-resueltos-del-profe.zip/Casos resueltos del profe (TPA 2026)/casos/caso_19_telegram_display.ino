#include <Adafruit_SH110X.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>

Adafruit_SH1106G display = Adafruit_SH1106G(128, 64, &Wire, -1);
//Credenciales red Wifi
const char *ssid = "TU_RED_WIFI";
const char *password = "";

//Telegram BOT Token
const String botToken = "TU_TOKEN_DEL_BOT";
//const unsigned long tiempo = 1000; //tiempo medio entre mensajes de escaneo
const unsigned long botMTBS = 1000; //mean time between scan messages
unsigned long botLastScan;
//objects
WiFiClientSecure secured_client;
UniversalTelegramBot bot(botToken, secured_client);

void setup() {
  // put your setup code here, to run once:
   
 //Inicializar pantalla OLED
  display.begin(0x3c, true); //Dirección por defecto: 0x3C
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);

  Serial.begin(115200);
Serial.println();
Serial.print ("Conectar a la red Wifi ");
Serial.print(ssid);
WiFi.begin(ssid,password);
secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT); 

while (WiFi.status() != WL_CONNECTED)
{
  Serial.print("·");
  delay(500);
}
Serial.print ("\nWifi conectado. Direccion IP: ");
Serial.println (WiFi.localIP());
}

void handleNewMessages(int numNewMessages)
{
  Serial.print ("handleNewMessages ");
  Serial.println(numNewMessages);
   for (int i = 0; i < numNewMessages; i++)
   {
     String chat_id = bot.messages[i].chat_id;
     String text = bot.messages[i].text;
     String from_name = bot.messages[i].from_name;
     if (from_name == "")
         from_name = "Guest";

         if (text == "/mensaje 1")
         {
          display.clearDisplay();  
          display.setCursor(0,0);
          //printf permite imprimir una cadena formateada:
          display.print("Mensaje 1");
          display.display();
         }
            
         if (text == "/mensaje 2")
         {
          display.clearDisplay();  
          display.setCursor(0,0);
          //printf permite imprimir una cadena formateada:
          display.print("Mensaje 2");
          display.display();
                   }
          if (text == "/start")
          {
            String welcome = "Welcome to Universal Arduino Telegram Bot library, " ;//+ from_name + "
            welcome += "This is flash Message Bot example.\n\n";
            welcome += "/mensaje 1\n";
            welcome += "/mensaje 2\n";
            bot.sendMessage(chat_id, welcome, "Markdown");
          }
   }
}
void loop() {
  // put your main code here, to run repeatedly:
if (millis() - botLastScan > botMTBS)
{
  int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  while (numNewMessages)
{
  Serial.println("Respuesta obtenida");
  handleNewMessages(numNewMessages);
  numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  
}
botLastScan = millis();
}
}
