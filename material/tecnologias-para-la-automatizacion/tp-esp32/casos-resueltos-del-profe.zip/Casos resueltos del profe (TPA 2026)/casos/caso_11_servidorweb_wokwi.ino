#include <WiFi.h>
 
const short GREEN_LED = 23;
const char* ssid = "Wokwi-GUEST";
const char* password = "";
WiFiServer server(80);
String header = "";
 
String pagina =
  "<!DOCTYPE html>"
  "<html><head><meta charset='utf-8' />"
  "<title>Servidor Web ESP32</title></head>"
  "<body><center><h1>Servidor Web ESP32</h1>"
  "<p><a href='/on'><button>ON</button></a></p>"
  "<p><a href='/off'><button>OFF</button></a></p>"
  "</center></body></html>";
 
void setup() {
  Serial.begin(115200);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(GREEN_LED, LOW);
  WiFi.begin(ssid, password, 6);
  Serial.print("Conectando a WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi conectado");
  Serial.println(WiFi.localIP());
  server.begin();
  Serial.println("Servidor HTTP iniciado");
  Serial.println("Escriba ON para encender el LED");
  Serial.println("Escriba OFF para apagar el LED");
}
 
void loop() {
  // Control local por monitor serie
  if (Serial.available() > 0) {
    String comando = Serial.readStringUntil('\n');
    comando.trim();
    if (comando == "ON") {
      digitalWrite(GREEN_LED, HIGH);
      Serial.println("LED ENCENDIDO");
    } else if (comando == "OFF") {
      digitalWrite(GREEN_LED, LOW);
      Serial.println("LED APAGADO");
    }
  }
 
  // Control previsto para solicitudes HTTP
  WiFiClient client = server.available();
  if (client) {
    String currentLine = "";
    header = "";
    unsigned long inicio = millis();
    while (client.connected() && millis() - inicio < 5000) {
      if (client.available()) {
        char c = client.read();
        header += c;
        inicio = millis();
        if (c == '\n') {
          if (currentLine.length() == 0) {
            if (header.indexOf("GET /on ") >= 0) {
              digitalWrite(GREEN_LED, HIGH);
              Serial.println("LED ENCENDIDO POR WEB");
            } else if (header.indexOf("GET /off ") >= 0) {
              digitalWrite(GREEN_LED, LOW);
              Serial.println("LED APAGADO POR WEB");
            }
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type: text/html; charset=utf-8");
            client.println("Connection: close");
            client.println();
            client.print(pagina);
            break;
          } else {
            currentLine = "";
          }
        } else if (c != '\r') {
          currentLine += c;
        }
      }
    }
    header = "";
    client.stop();
  }
}
