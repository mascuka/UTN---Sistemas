#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <WebServer.h>
#include <ArduinoOTA.h>

// ================== CONFIGURACIÓN ==================
//const char* ssid = "TU_RED_WIFI";
//const char* password = "";

const char* server = "http://api.thingspeak.com/update";
String apiKey = "TU_API_KEY"; // write apikey

#define DHTPIN 33
#define DHTTYPE DHT22  // O DHT11
DHT dht(DHTPIN, DHTTYPE);

WebServer serverWeb(80);

unsigned long previousMillis = 0;
const long interval = 20000;

bool modoSimulacion = false;
float tempSimulada = 25.0;
float humSimulada = 50.0;

// ================== FUNCIONES OTA ==================
void configurarOTA() {
  ArduinoOTA.setHostname("ESP32_Sensor");

  ArduinoOTA.onStart([]() {
    Serial.println("Inicio OTA");
  });
  ArduinoOTA.onEnd([]() {
    Serial.println("\nFin OTA");
  });
  ArduinoOTA.onError([](ota_error_t error) {
    Serial.printf("Error OTA [%u]: ", error);
  });

  ArduinoOTA.begin();
}

// ================== ENVÍO A THINGSPEAK ==================
void enviarAThingSpeak() {
  float t = modoSimulacion ? tempSimulada : dht.readTemperature();
  float h = modoSimulacion ? humSimulada : dht.readHumidity();

  if (!modoSimulacion && (isnan(t) || isnan(h))) {
    Serial.println("Error al leer del sensor");
    return;
  }

  Serial.print("Enviando -> Temp: "); Serial.print(t);
  Serial.print(" °C, Hum: "); Serial.println(h);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    String url = String(server) + "?api_key=" + apiKey + "&field1=" + String(t) + "&field2=" + String(h);
    http.begin(url);
    int httpCode = http.GET();
    http.end();

    Serial.print("HTTP Code: "); Serial.println(httpCode);
  }
}

// ================== HTML ==================
void mostrarFormulario() {
  String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>ESP32 Web</title></head><body>";
  html += "<h1>Modo: " + String(modoSimulacion ? "Simulación" : "Normal") + "</h1>";

  float t = modoSimulacion ? tempSimulada : dht.readTemperature();
  float h = modoSimulacion ? humSimulada : dht.readHumidity();

  html += "<p>Temperatura actual: " + String(t) + " °C</p>";
  html += "<p>Humedad actual: " + String(h) + " %</p>";

  html += "<p><a href=\"/simOn\"><button>Activar Simulación</button></a> ";
  html += "<a href=\"/simOff\"><button>Desactivar Simulación</button></a></p>";

  if (modoSimulacion) {
    html += "<form action=\"/setSim\" method=\"POST\">";
    html += "<p><label>Temperatura: <input type=\"number\" step=\"0.1\" name=\"temp\" value=\"" + String(tempSimulada) + "\"></label></p>";
    html += "<p><label>Humedad: <input type=\"number\" step=\"0.1\" name=\"hum\" value=\"" + String(humSimulada) + "\"></label></p>";
    html += "<p><input type=\"submit\" value=\"Actualizar Valores Simulados\"></p>";
    html += "</form>";
  }

  html += "</body></html>";
  serverWeb.send(200, "text/html", html);
}

// ================== HANDLERS ==================
void handleRoot() {
  mostrarFormulario();
}

void handleSimOn() {
  modoSimulacion = true;
  serverWeb.sendHeader("Location", "/", true);
  serverWeb.send(302, "text/plain", "");
}

void handleSimOff() {
  modoSimulacion = false;
  serverWeb.sendHeader("Location", "/", true);
  serverWeb.send(302, "text/plain", "");
}

void handleSetSim() {
  if (serverWeb.hasArg("temp") && serverWeb.hasArg("hum")) {
    tempSimulada = serverWeb.arg("temp").toFloat();
    humSimulada = serverWeb.arg("hum").toFloat();
    Serial.print("Nuevos valores simulados -> Temp: ");
    Serial.print(tempSimulada);
    Serial.print(" °C, Hum: ");
    Serial.println(humSimulada);
  }
  serverWeb.sendHeader("Location", "/", true);
  serverWeb.send(302, "text/plain", "");
}

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  dht.begin();

  WiFi.begin(ssid, password);
  Serial.print("Conectando a WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi conectado. IP: " + WiFi.localIP().toString());

  configurarOTA();

  serverWeb.on("/", handleRoot);
  serverWeb.on("/simOn", handleSimOn);
  serverWeb.on("/simOff", handleSimOff);
  serverWeb.on("/setSim", HTTP_POST, handleSetSim);
  serverWeb.begin();
  Serial.println("Servidor Web iniciado");
}

// ================== LOOP ==================
void loop() {
  ArduinoOTA.handle();
  serverWeb.handleClient();

  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    enviarAThingSpeak();
  }
}
