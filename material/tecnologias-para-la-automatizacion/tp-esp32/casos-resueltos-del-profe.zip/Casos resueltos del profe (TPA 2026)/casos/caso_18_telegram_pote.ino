const int potePin = 32;  //Pin del potenciometro
volatile int estadopote;
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>

//Credenciales red Wifi
//const char *ssid = "TU_RED_WIFI";
//const char *password = "";

const char *ssid = "TU_RED_WIFI";
const char *password = "TU_CLAVE_WIFI";

//Telegram BOT Token
const String botToken = "TU_TOKEN_DEL_BOT";
//const unsigned long tiempo = 1000; //tiempo medio entre mensajes de escaneo
const unsigned long botMTBS = 1000; //mean time between scan messages
unsigned long botLastScan;

//objects
WiFiClientSecure secured_client;
UniversalTelegramBot bot(botToken, secured_client);

void setup() {
  // put your setup code here, to run once:
Serial.begin(115200);
Serial.println();
delay(30);
Serial.print ("Conectar a la red Wifi ");
Serial.print(ssid);
WiFi.begin(ssid,password);
secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT); 
pinMode(potePin, INPUT);
while (WiFi.status() != WL_CONNECTED)
{
  Serial.print("·");
  delay(500);
}
//Serial.print ("\nWifi conectado. Direccion IP: ");
//Serial.println (WiFi.localIP());
}
// Funciones de ayuda
String floatToString( float n, int l, int d, boolean z){
 char c[l+1];
 String s;

 dtostrf(n,l,d,c);
 s=String(c);

 if(z){
 s.replace(" ","0");
 }

 return s;
}

void handleNewMessages(int numNewMessages)
{
  Serial.print ("handleNewMessages ");
  Serial.println(numNewMessages);
   for (int i = 0; i < numNewMessages; i++)
   {
     String chat_id = bot.messages[i].chat_id;
     String text = bot.messages[i].text;
     String from_name = bot.messages[i].from_name;
     if (from_name == "")
         from_name = "Guest";

        if (text == "/poten")
         {
           estadopote=analogRead(potePin);
           String pstr = floatToString(estadopote,2,2,false);
           bot.sendMessage(chat_id, "Potenciometro: ");
           bot.sendMessage(chat_id, pstr);
           //bot.sendMessage(chat_id, "");
           
         }
                  
          if (text == "/start")
          {
            String welcome = "Welcome to Universal Arduino Telegram Bot library, " ;//+ from_name + "
            welcome += "This is Bot example.\n\n";
            welcome += "/poten : para lectura pote\n";
            bot.sendMessage(chat_id, welcome, "Markdown");
          }
   }
}

void loop() {
  // put your main code here, to run repeatedly:
if (millis() - botLastScan > botMTBS)
{
  int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  while (numNewMessages)
{
  Serial.println("Respuesta obtenida");
  handleNewMessages(numNewMessages);
  numNewMessages = bot.getUpdates(bot.last_message_received + 1);
  
}
botLastScan = millis();
}
}
