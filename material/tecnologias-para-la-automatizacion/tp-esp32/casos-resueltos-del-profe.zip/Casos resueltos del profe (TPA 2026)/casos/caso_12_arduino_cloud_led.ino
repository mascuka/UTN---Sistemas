#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>


// ----------------------------------------------------
// DATOS DEL DISPOSITIVO Y WIFI
// ----------------------------------------------------
const char DEVICE_LOGIN_NAME[] = "TU_DEVICE_ID";


const char SSID[] = "TU_RED_WIFI";
const char PASS[] = "TU_CLAVE_WIFI";


const char DEVICE_KEY[] = "TU_DEVICE_KEY";


// ----------------------------------------------------
// VARIABLE DE ARDUINO CLOUD
// ----------------------------------------------------
bool led;


// ----------------------------------------------------
// LED FÍSICO
// ----------------------------------------------------
const int pinLED = 23;


// Prototipo de la función callback
void onLedChange();


// ----------------------------------------------------
// PROPIEDADES DE ARDUINO CLOUD
// ----------------------------------------------------
void initProperties() {


  ArduinoCloud.setBoardId(DEVICE_LOGIN_NAME);


  ArduinoCloud.setSecretDeviceKey(DEVICE_KEY);


  ArduinoCloud.addProperty(
    led,
    READWRITE,
    ON_CHANGE,
    onLedChange
  );
}


// ----------------------------------------------------
// CONEXIÓN WIFI
// ----------------------------------------------------
WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);


// ----------------------------------------------------
// SETUP
// ----------------------------------------------------
void setup() {


  pinMode(pinLED, OUTPUT);


  digitalWrite(pinLED, LOW);


  Serial.begin(9600);


  delay(1500);


  initProperties();


  ArduinoCloud.begin(ArduinoIoTPreferredConnection);


  setDebugMessageLevel(2);


  ArduinoCloud.printDebugInfo();
}


// ----------------------------------------------------
// LOOP
// ----------------------------------------------------
void loop() {


  ArduinoCloud.update();
}


void onLedChange() {


  if (led == true) {


    digitalWrite(pinLED, HIGH);


  } else {


    digitalWrite(pinLED, LOW);
  }
}

