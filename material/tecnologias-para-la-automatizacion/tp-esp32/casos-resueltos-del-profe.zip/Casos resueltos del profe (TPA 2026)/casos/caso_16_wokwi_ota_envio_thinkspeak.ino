
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ================== CONFIGURACION ==================

const char* server = "http://api.thingspeak.com/update";

// Reemplazar por la Write API Key del canal
String apiKey = "TU_API_KEY";

#define DHTPIN 33
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

// Envio cada 20 segundos
unsigned long previousMillis = 0;
const unsigned long interval = 20000;

// Variables de simulacion
bool modoSimulacion = false;
float tempSimulada = 25.0;
float humSimulada = 50.0;

// ================== MOSTRAR ESTADO ==================

void mostrarEstado() {
  Serial.println();
  Serial.println("===== ESTADO ACTUAL =====");

  if (modoSimulacion) {
    Serial.println("Modo: SIMULACION");
    Serial.print("Temperatura: ");
    Serial.println(tempSimulada);
    Serial.print("Humedad: ");
    Serial.println(humSimulada);
  } else {
    Serial.println("Modo: NORMAL - DHT22");
  }

  Serial.println("=========================");
}

// ================== COMANDOS SERIE ==================

void procesarComando(String comando) {

  comando.trim();
  comando.toUpperCase();

  if (comando == "SIMON") {

    modoSimulacion = true;
    Serial.println("Simulacion ACTIVADA");
    mostrarEstado();

  } else if (comando == "SIMOFF") {

    modoSimulacion = false;
    Serial.println("Simulacion DESACTIVADA");
    mostrarEstado();

  } else if (comando.startsWith("TEMP=")) {

    String valor = comando.substring(5);
    valor.trim();

    if (valor.length() == 0) {
      Serial.println("Falta el valor de temperatura");
      return;
    }

    tempSimulada = valor.toFloat();

    Serial.print("Nueva temperatura simulada: ");
    Serial.println(tempSimulada);

  } else if (comando.startsWith("HUM=")) {

    String valor = comando.substring(4);
    valor.trim();

    if (valor.length() == 0) {
      Serial.println("Falta el valor de humedad");
      return;
    }

    float nuevaHumedad = valor.toFloat();

    if (nuevaHumedad < 0 || nuevaHumedad > 100) {
      Serial.println("La humedad debe estar entre 0 y 100");
      return;
    }

    humSimulada = nuevaHumedad;

    Serial.print("Nueva humedad simulada: ");
    Serial.println(humSimulada);

  } else if (comando == "ESTADO") {

    mostrarEstado();

  } else {

    Serial.println("Comando no reconocido");
    Serial.println("Comandos disponibles:");
    Serial.println("SIMON");
    Serial.println("SIMOFF");
    Serial.println("TEMP=30");
    Serial.println("HUM=65");
    Serial.println("ESTADO");
  }
}

// ================== ENVIO A THINGSPEAK ==================

void enviarAThingSpeak() {

  float t;
  float h;

  if (modoSimulacion) {

    t = tempSimulada;
    h = humSimulada;

  } else {

    t = dht.readTemperature();
    h = dht.readHumidity();

    if (isnan(t) || isnan(h)) {
      Serial.println("Error al leer el DHT22");
      return;
    }
  }

  Serial.println();
  Serial.println("===== ENVIO A THINGSPEAK =====");

  Serial.print("Modo: ");
  Serial.println(modoSimulacion ? "SIMULACION" : "NORMAL");

  Serial.print("Temperatura: ");
  Serial.print(t);
  Serial.println(" C");

  Serial.print("Humedad: ");
  Serial.print(h);
  Serial.println(" %");

  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    String url = String(server) +
                 "?api_key=" + apiKey +
                 "&field1=" + String(t) +
                 "&field2=" + String(h);

    http.begin(url);

   unsigned long inicioHTTP = millis();

  int httpCode = http.GET();

  unsigned long duracionHTTP = millis() - inicioHTTP;

Serial.print("Duracion HTTP: ");
Serial.print(duracionHTTP);
Serial.println(" ms");
    Serial.print("HTTP Code: ");
    Serial.println(httpCode);

    if (httpCode == 200) {

      String respuesta = http.getString();

      if (respuesta != "0" && respuesta.length() > 0) {
        Serial.println("Datos enviados correctamente");
        Serial.print("Numero de entrada: ");
        Serial.println(respuesta);
      } else {
        Serial.println("ThingSpeak no acepto los datos");
      }

    } else {
      Serial.println("Error en la comunicacion HTTP");
    }

    http.end();

  } else {

    Serial.println("WiFi desconectado");

  }

  Serial.println("============================");
}

// ================== SETUP ==================

void setup() {

  Serial.begin(115200);
  Serial.setTimeout(50);

  dht.begin();

  Serial.println("Iniciando ESP32 en Wokwi");

  WiFi.begin("Wokwi-GUEST", "", 6);

  Serial.print("Conectando a WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado");

  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  Serial.println();
  Serial.println("COMANDOS DISPONIBLES");
  Serial.println("SIMON  - Activar simulacion");
  Serial.println("SIMOFF - Desactivar simulacion");
  Serial.println("TEMP=30 - Cambiar temperatura");
  Serial.println("HUM=65 - Cambiar humedad");
  Serial.println("ESTADO - Mostrar estado actual");

  mostrarEstado();
}

// ================== LOOP ==================

void loop() {

  // Leer comandos desde monitor serie
  if (Serial.available() > 0) {

    String comando = Serial.readStringUntil('\n');

    procesarComando(comando);
  }

  // Enviar datos cada 20 segundos
  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {

    previousMillis = currentMillis;

    enviarAThingSpeak();
  }
  delay(10);
}
