#include <WiFi.h>
#include <WiFiClient.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Update.h>
#include "ThingSpeak.h"
#include "secrets.h"

const char* ssid = SECRET_SSID;
const char* password = SECRET_PASS;

unsigned long channel = 0000000;
const char * writeAPIKey = "TU_API_KEY"; 

//variables to blink without delay:
const int led = 2;
unsigned long previousMillis = 0;
const long interval = 1000;
int ledState = LOW;

WebServer server(80);
const char* host = "esp32";

#include "OTA.h"

//Objeto WIFI Client
WiFiClient client;

void setup(void) {
  Serial.begin(115200);

  //Code to blink without delay:
  pinMode(led, OUTPUT);

  // Connect to WiFi network
  WiFi.begin(ssid, password);
  Serial.println("");

  // Wait for connection
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("Connected to ");
  Serial.println(ssid);
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  
  iniciaOTA();

  ThingSpeak.begin(client);
}

void loop(void) {
  server.handleClient();
  delay(1);

  unsigned long currentMillis = millis();

  /*if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    ledState = not(ledState);

    digitalWrite(led, ledState);
  }  */

  int rand = random(1,100);
  Serial.printf("Enviando valor: %d  ", rand);
  int x = ThingSpeak.writeField(channel, 1, rand, writeAPIKey);
  if(x == 200){
    Serial.println("Canal escrito correctamente.");
  }
  else{
    Serial.println("Problemas al actualizar el canal. HTTP error code " + String(x));
  }
  delay(7000); 

}
