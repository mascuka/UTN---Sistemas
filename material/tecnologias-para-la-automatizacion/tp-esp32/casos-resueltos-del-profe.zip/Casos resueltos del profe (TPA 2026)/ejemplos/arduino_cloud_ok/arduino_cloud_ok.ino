#include <WiFi.h>
#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>

// ====== CONFIGURAR ======
const char SSID[] = "TU_RED_WIFI";             // TODO: tu SSID (2.4 GHz)
const char PASS[] = "TU_CLAVE_WIFI";           // TODO: tu clave

const char DEVICE_LOGIN_NAME[] = "TU_DEVICE_ID"; // IoT Cloud -> Devices
const char DEVICE_KEY[]        = "TU_DEVICE_KEY"; // IoT Cloud -> Devices

//#define USE_EXISTING_THING_ID
#ifdef USE_EXISTING_THING_ID
const char THING_ID[] = "ESP32_project_2025"; // opcional
#endif

#define LED_PIN 23              // 23=LED placa UTN; 2=LED on-board
#define CLOUD_STATUS_LED 2      // LED de estado (on-board)

// ====== GLOBALES ======
WiFiServer server(80);
String header;

bool led = false;
void onLedChangeCloud();

// Handler que usará el Cloud (también sirve para reconexiones automáticas)
WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);

// Página simple para /on y /off
String pagina =
  "<!DOCTYPE html><html><head><meta charset='utf-8'/>"
  "<title>Servidor Web ESP32</title></head><body><center>"
  "<h1>Servidor Web ESP32</h1>"
  "<p><a href='/on'><button style='height:50px;width:100px;color:green'>ON</button></a></p>"
  "<p><a href='/off'><button style='height:50px;width:100px;color:red'>OFF</button></a></p>"
  "</center></body></html>";

void initCloud() {
  ArduinoCloud.setBoardId(DEVICE_LOGIN_NAME);
  ArduinoCloud.setSecretDeviceKey(DEVICE_KEY);
#ifdef USE_EXISTING_THING_ID
  ArduinoCloud.setThingId(THING_ID);
#endif
  ArduinoCloud.addProperty(led, READWRITE, ON_CHANGE, onLedChangeCloud);
}

bool wifiConnect(uint32_t timeout_ms = 20000) {
  Serial.print("WiFi: conectando a '"); Serial.print(SSID); Serial.println("' ...");
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true, true);  // limpia estado previo
  delay(500);
  WiFi.begin(SSID, PASS);

  uint32_t t0 = millis();
  wl_status_t last = WL_NO_SHIELD;
  while (millis() - t0 < timeout_ms) {
    wl_status_t st = WiFi.status();
    if (st != last) { last = st; Serial.print("Estado WiFi: "); Serial.println((int)st); }
    if (st == WL_CONNECTED) {
      Serial.print("WiFi OK - IP: "); Serial.println(WiFi.localIP());
      return true;
    }
    delay(250);
  }
  Serial.println("ERROR: no se pudo conectar a WiFi (timeout).");
  return false;
}

void setup() {
  pinMode(LED_PIN, OUTPUT);           digitalWrite(LED_PIN, LOW);
  pinMode(CLOUD_STATUS_LED, OUTPUT);  digitalWrite(CLOUD_STATUS_LED, LOW);

  Serial.begin(115200);
  delay(1200);
  Serial.println("\nBoot…");

  // 1) Conectar Wi-Fi primero (con logs)
  if (!wifiConnect()) {
    Serial.println("Revisá SSID/clave, 2.4 GHz, MAC filter del router.");
    // Podés seguir intentando en loop con wifiConnect(); si preferís:
    // while (!wifiConnect()) delay(3000);
  }

  // (opcional) sincronizar hora para TLS (el Cloud también lo hace, pero ayuda)
  configTime(0, 0, "pool.ntp.org", "time.google.com");

  // 2) Iniciar IoT Cloud
  initCloud();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
  setDebugMessageLevel(3);
  ArduinoCloud.printDebugInfo();  // banner + datos

  // 3) Servidor web local
  server.begin();
}

void loop() {
  ArduinoCloud.update();

  // LED de estado del Cloud (parpadea si conectado)
  static bool cloudBlink = false;
  static uint32_t lastBlink = 0;
  if (ArduinoCloud.connected()) {
    if (millis() - lastBlink > 500) {
      lastBlink = millis();
      cloudBlink = !cloudBlink;
      digitalWrite(CLOUD_STATUS_LED, cloudBlink ? HIGH : LOW);
    }
  } else {
    digitalWrite(CLOUD_STATUS_LED, LOW);
  }

  // HTTP /on /off
  WiFiClient client = server.available();
  if (client) {
    uint32_t t0 = millis();
    header = "";
    while (client.connected() && (millis() - t0 < 2000)) {
      if (client.available()) {
        char c = client.read();
        header += c;
        if (c == '\n' && header.endsWith("\r\n\r\n")) {
          if (header.indexOf("GET /on") >= 0) { led = true;  digitalWrite(LED_PIN, HIGH);  Serial.println("HTTP -> led=ON"); }
          if (header.indexOf("GET /off")>= 0) { led = false; digitalWrite(LED_PIN, LOW);   Serial.println("HTTP -> led=OFF"); }

          client.println("HTTP/1.1 200 OK");
          client.println("Content-type:text/html");
          client.println("Connection: close");
          client.println();
          client.println(pagina);
          break;
        }
      }
    }
    client.stop();
  }
}

void onLedChangeCloud() {
  Serial.print("CLOUD -> led="); Serial.println(led ? "ON" : "OFF");
  digitalWrite(LED_PIN, led ? HIGH : LOW);
}
