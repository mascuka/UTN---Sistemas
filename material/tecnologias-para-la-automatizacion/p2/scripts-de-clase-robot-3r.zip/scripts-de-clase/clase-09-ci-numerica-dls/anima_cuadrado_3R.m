% ============================================================
% ANIMACION DEL ROBOT 3R RECORRIENDO EL CUADRADO
% ============================================================

figure

for i = 1:size(Q,1)

    % Angulos correspondientes al punto i del cuadrado

    q1 = Q(i,1);
    q2 = Q(i,2);
    q3 = Q(i,3);

    % Dibujar el robot en esa configuracion

    dibujar_robot_3R(q1,q2,q3);

    % Mantener dibujada la trayectoria cartesiana recorrida

    hold on

    plot3(P(1:i,1), ...
          P(1:i,2), ...
          P(1:i,3), ...
          'o-');

    drawnow

    pause(0.1)

end