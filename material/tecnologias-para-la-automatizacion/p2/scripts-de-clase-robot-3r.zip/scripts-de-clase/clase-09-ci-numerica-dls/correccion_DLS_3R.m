function delta_q = correccion_DLS_3R(J,e,lambda)

% Correccion articular mediante Damped Least Squares
%
% Entradas:
% J       = Jacobiano 3x3
% e       = error cartesiano [ex; ey; ez]
% lambda  = factor de amortiguamiento
%
% Salida:
% delta_q = correccion [dq1; dq2; dq3] en grados

I = eye(3);

delta_q = J' * ((J*J' + lambda^2*I) \ e);

end