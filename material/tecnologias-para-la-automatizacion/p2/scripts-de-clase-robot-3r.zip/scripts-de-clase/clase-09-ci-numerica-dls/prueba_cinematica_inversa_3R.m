clc
clear

% ============================================================
% POSTURA CONOCIDA DEL ROBOT
% ============================================================

q1_real = 30;
q2_real = 30;
q3_real = 30;

%% ============================================================
% CALCULAR EL PUNTO CARTESIANO
% ============================================================

[xd,yd,zd] = cinematica_directa_3R_DH(q1_real,q2_real,q3_real);

Pd = [xd;
      yd;
      zd];

disp('Punto cartesiano deseado:')
disp(Pd)

%% ============================================================
% SEMILLA PARA LA CINEMATICA INVERSA
% ponemos qualquier valor en los qs para ver si llegamos a 
%los mismos valores de x,y,z que proponemos en el
%punto cartesiano deseado


q0 = [0;
      10;
      10];

%% ============================================================
% CINEMATICA INVERSA NUMERICA
%
% tratar� de encontrar los q1,q2,q3 que llegan al x,y,z
% deseado
[q,success,iter] = cinematica_inversa_3R_numerica(Pd,q0);


% MOSTRAR RESULTADOS
% ============================================================

disp('Angulos obtenidos:')
disp(q)

disp('Convergencia:')
disp(success)

disp('Numero de iteraciones:')
disp(iter)

%% ============================================================
% VERIFICACION MEDIANTE CINEMATICA DIRECTA
% ============================================================

[xv,yv,zv] = cinematica_directa_3R_DH(q(1),q(2),q(3));

Pverificado = [xv;
               yv;
               zv];

disp('Punto obtenido con los angulos calculados:')
disp(Pverificado)

disp('Error final:')
disp(Pd-Pverificado)