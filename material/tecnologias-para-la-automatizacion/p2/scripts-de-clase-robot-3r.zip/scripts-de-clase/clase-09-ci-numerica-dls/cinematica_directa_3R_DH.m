function [x,y,z] = cinematica_directa_3R_DH(q1,q2,q3)

% Cinematica directa del robot 3R mediante Denavit-Hartenberg
% q1, q2 y q3 se ingresan en grados
% x, y, z se obtienen en metros

% Longitudes
l1 = 0.50;
l2 = 0.30;
l3 = 0.20;

% Matrices DH
A01 = matrizDenavitHartenberg(q1, l1, 0,  90);
A12 = matrizDenavitHartenberg(q2, 0,  l2, 0);
A23 = matrizDenavitHartenberg(q3, 0,  l3, 0);

% Transformacion total
T03 = A01*A12*A23;

% Posicion del efector final
x = T03(1,4);
y = T03(2,4);
z = T03(3,4);

end