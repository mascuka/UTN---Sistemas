% ============================================================
% CINEMATICA INVERSA NUMERICA PARA TODOS LOS PUNTOS DE P
% ============================================================

% Cantidad de puntos cartesianos

n = size(P,1);

% Matriz donde guardaremos Q1, Q2 y Q3

Q = zeros(n,3);

% ============================================================
% SEMILLA PARA EL PRIMER PUNTO
% ============================================================

q0 = [0;
      20;
      20];

% ============================================================
% RECORRER TODOS LOS PUNTOS DEL CUADRADO
% ============================================================

for i = 1:n

    % Punto cartesiano deseado

    Pd = P(i,:)';

    % Cinematica inversa numerica

    [q,success,iter] = ...
        cinematica_inversa_3R_numerica(Pd,q0);

    % Comprobar convergencia

    if success == 0

        fprintf('No converge el punto %d\n',i)
        break

    end

    % Guardar los angulos obtenidos

    Q(i,:) = q';

    % La solucion actual sera la semilla
    % para el siguiente punto

    q0 = q;

end

% ============================================================
% MOSTRAR RESULTADOS
% ============================================================

disp('Matriz Q obtenida:')
disp(Q)