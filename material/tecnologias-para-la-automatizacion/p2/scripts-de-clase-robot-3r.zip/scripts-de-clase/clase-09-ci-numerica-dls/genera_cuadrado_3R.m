clc
clear
close all

% ============================================================
% GENERACION DE UN CUADRADO EN EL ESPACIO CARTESIANO
% ============================================================

% Centro del cuadrado
xc = 0.25;
yc = 0.00;
zc = 0.65;

% Lado del cuadrado
L = 0.20;

% Cantidad de puntos por lado
N = 10;

% ============================================================
% VERTICES
% ============================================================

P1 = [xc-L/2, yc-L/2, zc];
P2 = [xc+L/2, yc-L/2, zc];
P3 = [xc+L/2, yc+L/2, zc];
P4 = [xc-L/2, yc+L/2, zc];

% ============================================================
% GENERACION DE LOS CUATRO LADOS
% ============================================================

t = linspace(0,1,N);

lado1 = P1 + t'.*(P2-P1);
lado2 = P2 + t'.*(P3-P2);
lado3 = P3 + t'.*(P4-P3);
lado4 = P4 + t'.*(P1-P4);

% ============================================================
% MATRIZ DE PUNTOS CARTESIANOS
% ============================================================

P = [lado1;
     lado2(2:end,:);
     lado3(2:end,:);
     lado4(2:end,:)];

% ============================================================
% DIBUJO
% ============================================================

figure

plot3(P(:,1),P(:,2),P(:,3),'o-')

grid on
axis equal

xlabel('X [m]')
ylabel('Y [m]')
zlabel('Z [m]')

title('Cuadrado cartesiano para el robot 3R')

view(45,25)