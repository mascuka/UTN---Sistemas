function [q,success,iter] = cinematica_inversa_3R_numerica(Pd,q0)

% Cinematica inversa numerica del robot 3R
% Metodo: Jacobiano + Damped Least Squares
%
% Entradas:
% Pd = posicion deseada [xd; yd; zd] en metros
% q0 = postura inicial [q1; q2; q3] en grados
%
% Salidas:
% q       = solucion [q1; q2; q3] en grados
% success = 1 si converge, 0 si no converge
% iter    = numero de iteraciones realizadas

% Parametros del metodo

lambda   = 0.01;
tol_pos  = 1e-5;
max_iter = 200;
alpha    = 1.0;

% Semilla inicial

q = q0;

success = 0;

% Proceso iterativo

for iter = 1:max_iter

    % ---------------------------------------------------------
    % 1. Cinematica directa
    % ---------------------------------------------------------

    [x,y,z] = cinematica_directa_3R_DH(q(1),q(2),q(3));

    Pactual = [x;
               y;
               z];

    % ---------------------------------------------------------
    % 2. Error cartesiano
    % ---------------------------------------------------------

    e = Pd - Pactual;

    % ---------------------------------------------------------
    % 3. Comprobar si llegamos
    % ---------------------------------------------------------

    if norm(e) < tol_pos

        success = 1;
        return

    end

    % ---------------------------------------------------------
    % 4. Jacobiano
    % ---------------------------------------------------------

    J = jacobiano_3R(q(1),q(2),q(3));

    % ---------------------------------------------------------
    % 5. Correccion DLS
    % ---------------------------------------------------------

    delta_q = correccion_DLS_3R(J,e,lambda);

    % ---------------------------------------------------------
    % 6. Nueva postura
    % ---------------------------------------------------------

    q = q + alpha*delta_q;

end

end