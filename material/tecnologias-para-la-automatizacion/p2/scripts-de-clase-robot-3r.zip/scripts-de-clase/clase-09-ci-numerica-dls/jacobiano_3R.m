function J = jacobiano_3R(q1,q2,q3)

% Jacobiano de posicion del robot 3R
% Angulos q1, q2, q3 en grados
%
% J relaciona:
%
%       delta_P = J * delta_q
%
% donde delta_q esta expresado en grados

l2 = 0.30;
l3 = 0.20;

% Expresiones auxiliares

A = l2*cosd(q2) + l3*cosd(q2+q3);

B = l2*sind(q2) + l3*sind(q2+q3);

% Jacobiano calculado respecto de angulos en radianes

Jrad = [ -A*sind(q1), ...
         -B*cosd(q1), ...
         -l3*sind(q2+q3)*cosd(q1);

          A*cosd(q1), ...
         -B*sind(q1), ...
         -l3*sind(q2+q3)*sind(q1);

          0, ...
          A, ...
          l3*cosd(q2+q3) ];

% Conversion para trabajar con incrementos angulares en grados

J = (pi/180)*Jrad;

end