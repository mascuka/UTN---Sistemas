%% ===============================================================
% FK 2R - Animaci�n entre estado inicial y final
% ---------------------------------------------------------------
% Mantiene nombres del script anterior:
%   - l1, l2: longitudes [m]
%   - q1, q2: �ngulos articulares en GRADOS
%   - x, y  : posici�n de la punta en el plano XY
% ===============================================================

close all; clear; clc;
format bank

%% ---------- Par�metros geom�tricos ----------
l1 = 0.70       % [m]
l2 = 0.30       % [m]

%% ---------- ESTADO INICIAL ----------
q1_i = 0;       % [grados]
q2_i = 0;       % [grados]

%% ---------- ESTADO FINAL ----------
q1_f = 0;     % [grados]
q2_f = 360;     % [grados]

%% ---------- Par�metros de animaci�n ----------
Nsteps  = 60;
t_total = 2.0;
dt = t_total / Nsteps;

%% ---------- Trayectoria ----------
traj = zeros(2, Nsteps+1);

%% ---------- Figura ----------
figure('Name','FK 2R - Animaci�n');
axis equal;
grid on;
hold on;

xlabel('X [m]');
ylabel('Y [m]');

R = l1 + l2;
m = 0.1;

xlim([-R-m, R+m]);
ylim([-R-m, R+m]);

scatter(0,0,60,[1 0 1],'filled','Marker','p','DisplayName','Origen (0,0)');
legend('Location','best');

title('Brazo 2R - Animaci�n');

%% ---------- Estado inicial ----------
q1 = q1_i;
q2 = q2_i;

[x, y, P1, P2] = fk2R_xy(l1, l2, q1, q2);

traj(:,1) = [x; y];

h_links = plot([0 P1(1) P2(1)], [0 P1(2) P2(2)], '-o', ...
    'LineWidth', 2, 'MarkerFaceColor', [0.9 0.4 0.1], ...
    'MarkerSize', 7, 'Color', [0 0.45 0.74]);

h_codo = scatter(P1(1), P1(2), 45, [0.2 0.6 0.2], ...
    'filled', 'MarkerEdgeColor','k');

h_tip = scatter(x, y, 45, [0.85 0.33 0.1], ...
    'filled', 'MarkerEdgeColor','k');

h_traj = plot(traj(1,1), traj(2,1), '-', ...
    'LineWidth', 1.5, 'Color', [0.8 0 0]);

txt_codo = text(P1(1), P1(2), '  Codo');
txt_tip  = text(x, y, '  Punta');

%% ---------- Animaci�n ----------
for k = 1:Nsteps

    alpha = k / Nsteps;

    % Interpolaci�n de los �ngulos en grados
    q1 = (1-alpha)*q1_i + alpha*q1_f;
    q2 = (1-alpha)*q2_i + alpha*q2_f;

    % Cinem�tica directa
    [x, y, P1, P2] = fk2R_xy(l1, l2, q1, q2);

    traj(:,k+1) = [x; y];

    set(h_links, 'XData', [0 P1(1) P2(1)], ...
                 'YData', [0 P1(2) P2(2)]);

    set(h_codo, 'XData', P1(1), 'YData', P1(2));

    set(h_tip, 'XData', x, 'YData', y);

    set(h_traj, 'XData', traj(1,1:k+1), ...
                'YData', traj(2,1:k+1));

    set(txt_codo, 'Position', [P1(1) P1(2) 0]);
    set(txt_tip,  'Position', [x y 0]);

    title(sprintf('Brazo 2R - q1 = %.1f�   q2 = %.1f�', q1, q2));

    drawnow;
    pause(dt);
end

%% ---------- Reporte final ----------
fprintf('--- Estados ---\n');

fprintf('Inicial: q1 = %.2f grados   q2 = %.2f grados\n', ...
        q1_i, q2_i);

fprintf('Final:   q1 = %.2f grados   q2 = %.2f grados\n', ...
        q1_f, q2_f);

fprintf('Punta final: x = %.2f m, y = %.2f m\n', x, y);


%% ===============================================================
% ================== FUNCION AUXILIAR ============================
% ===============================================================

function [x, y, P1, P2] = fk2R_xy(l1, l2, q1, q2)

x1 = l1*cosd(q1);
y1 = l1*sind(q1);

x = x1 + l2*cosd(q1 + q2);
y = y1 + l2*sind(q1 + q2);

P1 = [x1; y1];
P2 = [x; y];

end