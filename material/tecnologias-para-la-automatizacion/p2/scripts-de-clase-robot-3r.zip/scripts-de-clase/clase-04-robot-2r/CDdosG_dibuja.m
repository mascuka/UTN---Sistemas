% FK 2R (cinem�tica directa de un manipulador planar de 2 eslabones)
% ---------------------------------------------------------------
% Modelo:
%  - Eslab�n 1: longitud l1
%  - Eslab�n 2: longitud l2
%  - Articulaciones: q1 (hombro), q2 (codo), en GRADOS
%  - Punta (end-effector) en el plano XY: (x, y)
%
% Ecuaciones:
%   x = l1*cos(q1) + l2*cos(q1 + q2)
%   y = l1*sin(q1) + l2*sin(q1 + q2)
%
% Sugerencia docente:
%  - Prob� distintos q1, q2 para ver c�mo cambia (x,y).
%  - Como los �ngulos est�n en grados se usan sind() y cosd().
% ===============================================================

close all; clear; clc;
format bank     % Muestra con 2 decimales

%% Par�metros geom�tricos (metros)
l1 = 0.70
l2 = 0.30

%% �ngulos articulares (GRADOS)
% Cambi� estos valores para probar.
q1 =   45       % por ej.: q1 = 45;
q2 = 180        % por ej.: q2 = -30;

%% Cinem�tica directa (FK)
x = l1*cosd(q1) + l2*cosd(q1 + q2)
y = l1*sind(q1) + l2*sind(q1 + q2)

%% Mostrar resultados num�ricos
disp('--- FK 2R (planar) ---'); % Forward Kinematics
fprintf('q1 = %.2f grados, q2 = %.2f grados\n', q1, q2);
fprintf('x  = %.2f m,       y  = %.2f m\n', x, y);

%% (Opcional) Dibujo del brazo para visualizar

% Puntos clave
O  = [0; 0];                                  % origen
P1 = [l1*cosd(q1); l1*sind(q1)];              % codo
P2 = [x; y];                                   % punta

figure('Name','FK 2R - Visualizaci�n');

plot([O(1) P1(1) P2(1)], ...
     [O(2) P1(2) P2(2)], '-o', ...
     'LineWidth', 2, ...
     'MarkerFaceColor', [0.9 0.4 0.1], ...
     'MarkerSize', 7);

grid on;
axis equal;
hold on;

xlabel('X [m]');
ylabel('Y [m]');
title('Brazo 2R en el plano XY (FK)');

% Marcas y etiquetas
scatter(0,0,60,[1 0 1],'filled','Marker','p','DisplayName','Origen (0,0)');

text(P1(1), P1(2), '  Codo');
text(P2(1), P2(2), '  EFinal');

% L�mites de la vista
R = l1 + l2;
m = 0.1;

xlim([-R-m, R+m]);
ylim([-R-m, R+m]);

legend({'Eslabones + Juntas'},'Location','best');