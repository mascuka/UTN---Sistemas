%% CINEM�TICA INVERSA ROBOT PLANAR 2R
% M�todo basado en la deducci�n geom�trica de la hoja
% Todos los �ngulos se calculan en grados

close all; clear all; clc;
format bank

%% Longitudes de los eslabones
l1 = 0.70;
l2 = 0.30;

%% Punto objetivo
p = [0.90; 0.10];

Px = p(1);
Py = p(2);

%% C�lculo de cos(theta2)

cos_theta2 = (Px^2 + Py^2 - l1^2 - l2^2) / (2*l1*l2);

%% Dos valores posibles de sen(theta2)

sen_theta2_1 = -sqrt(1 - cos_theta2^2);
sen_theta2_2 =  sqrt(1 - cos_theta2^2);

%% Dos soluciones para theta2

theta2_1 = atan2d(sen_theta2_1, cos_theta2);
theta2_2 = atan2d(sen_theta2_2, cos_theta2);

%% C�lculo de beta

beta = atan2d(Py, Px);

%% C�lculo de alfa para cada soluci�n

alfa_1 = atan2d(l2*sen_theta2_1, ...
                l1 + l2*cos_theta2);

alfa_2 = atan2d(l2*sen_theta2_2, ...
                l1 + l2*cos_theta2);

%% C�lculo de theta1

theta1_1 = beta - alfa_1;
theta1_2 = beta - alfa_2;

%% Soluciones

q = [theta1_1 theta2_1;
     theta1_2 theta2_2];

disp('Soluciones [theta1  theta2] en grados:');
disp(q);

%% =========================================================
%% DIBUJO DE LAS DOS POSES DEL ROBOT
%% =========================================================

% -------- Soluci�n 1 --------

x1_1 = l1*cosd(theta1_1);
y1_1 = l1*sind(theta1_1);

x2_1 = x1_1 + l2*cosd(theta1_1 + theta2_1);
y2_1 = y1_1 + l2*sind(theta1_1 + theta2_1);


% -------- Soluci�n 2 --------

x1_2 = l1*cosd(theta1_2);
y1_2 = l1*sind(theta1_2);

x2_2 = x1_2 + l2*cosd(theta1_2 + theta2_2);
y2_2 = y1_2 + l2*sind(theta1_2 + theta2_2);


%% Gr�fico

figure;
hold on;
grid on;
axis equal;

title('Robot 2R - Dos soluciones de cinem�tica inversa');
xlabel('X [m]');
ylabel('Y [m]');

% Soluci�n 1
plot([0 x1_1 x2_1], ...
     [0 y1_1 y2_1], ...
     'b-o', ...
     'LineWidth',3, ...
     'MarkerSize',8);

% Soluci�n 2
plot([0 x1_2 x2_2], ...
     [0 y1_2 y2_2], ...
     'r-o', ...
     'LineWidth',3, ...
     'MarkerSize',8);

% Punto objetivo
plot(Px,Py,'ko', ...
    'MarkerSize',10, ...
    'MarkerFaceColor','y');

% Base
plot(0,0,'ks', ...
    'MarkerSize',10, ...
    'MarkerFaceColor','k');

% Etiquetas
text(x1_1,y1_1,'  Codo 1');
text(x1_2,y1_2,'  Codo 2');
text(Px,Py,'  Punto objetivo');

legend('Soluci�n 1', ...
       'Soluci�n 2', ...
       'Punto objetivo', ...
       'Base', ...
       'Location','best');

% L�mites del gr�fico
R = l1 + l2;
m = 0.1;

xlim([-R-m R+m]);
ylim([-R-m R+m]);

hold off;