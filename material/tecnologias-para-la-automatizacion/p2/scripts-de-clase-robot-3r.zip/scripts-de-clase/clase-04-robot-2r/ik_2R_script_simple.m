%% CINEM�TICA INVERSA ROBOT PLANAR 2R
% M�todo basado en la deducci�n geom�trica de la hoja

close all; clear all; clc;
format bank

%% Longitudes de los eslabones
l1 = 0.70;
l2 = 0.30;

%% Punto objetivo
p = [0.60; 0.20];

Px = p(1);
Py = p(2);

%% C�lculo de cos(theta2)

cos_theta2 = (Px^2 + Py^2 - l1^2 - l2^2) / (2*l1*l2);

%% Dos valores posibles de sen(theta2)

sen_theta2_1 = -sqrt(1 - cos_theta2^2);
sen_theta2_2 =  sqrt(1 - cos_theta2^2);

%% Dos soluciones para theta2

theta2_1 = atan2d(sen_theta2_1, cos_theta2)
theta2_2 = atan2d(sen_theta2_2, cos_theta2)


%% C�lculo de beta

beta = atan2d(Py, Px);

%% C�lculo de alfa para cada soluci�n

alfa_1 = atan2d(l2*sen_theta2_1, ...
                l1 + l2*cos_theta2);

alfa_2 = atan2d(l2*sen_theta2_2, ...
                l1 + l2*cos_theta2);

%% C�lculo de theta1

theta1_1 = beta - alfa_1;
theta1_2 = beta - alfa_2;

%% Soluciones

q = [theta1_1 theta2_1;
     theta1_2 theta2_2];

disp('Soluciones [theta1  theta2] en grados:');
disp(q);

