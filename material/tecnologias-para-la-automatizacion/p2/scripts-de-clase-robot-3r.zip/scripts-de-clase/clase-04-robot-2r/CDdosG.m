close all
clear all
clc

format bank   % Muestra los resultados num�ricos con dos decimales

%% Longitudes de los eslabones
l1 = 0.70;    % Longitud del primer eslab�n [m]
l2 = 0.30;    % Longitud del segundo eslab�n [m]

%% �ngulos articulares
q1 = 180;      % �ngulo de la primera articulaci�n [grados]
q2 = 90;      % �ngulo de la segunda articulaci�n [grados]

%% Cinem�tica directa
% Se calcula la posici�n del extremo del robot en el plano XY.
% Como los �ngulos est�n expresados en grados se utilizan
% las funciones cosd() y sind().

X = l1*cosd(q1) + l2*cosd(q1 + q2)

Y = l1*sind(q1) + l2*sind(q1 + q2)

