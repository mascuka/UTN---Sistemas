clear;
clc;
close all;
%  y = 2*x + 1
%  z = x + 2


% Valores de x
x = 0:0.1:5;

% Ecuaciones de la recta en 3D
y = 2*x + 1;
z = x + 2;

% Dibujar la recta
plot3(x,y,z,'o-');

grid on;
axis equal;

xlabel('X');
ylabel('Y');
zlabel('Z');

title('Recta en 3D');