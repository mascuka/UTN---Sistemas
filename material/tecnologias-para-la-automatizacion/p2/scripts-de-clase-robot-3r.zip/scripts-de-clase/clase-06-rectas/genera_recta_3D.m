for i = 1:length(x)

    % Punto cartesiano de la trayectoria
    px = x(i);
    py = y(i);
    pz = z(i);

    % Cinematica inversa
    [q1,q2,q3] = cinematica_inversa_3R(px,py,pz);

    % Dibujar el robot en esa configuracion
    dibujar_robot_3R(q1,q2,q3);

    % Mantener el dibujo actual
    hold on;

    % Dibujar todos los puntos recorridos hasta ahora
    plot3(x(1:i), y(1:i), z(1:i), 'o');

    grid on;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');

    drawnow;

end