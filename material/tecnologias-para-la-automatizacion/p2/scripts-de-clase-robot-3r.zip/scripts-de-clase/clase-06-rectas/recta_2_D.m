clear;
clc;
close all;

% Ecuacion de la recta y=mx+b
m = 2;      % Pendiente
b = 1;      % Ordenada al origen

% Parametro
t = 0:0.1:5;

% Parametrizacion de la recta
x = t;
y = m*t + b;

% Dibujar la recta
plot(x,y,'o-');

grid on;
xlabel('X');
ylabel('Y');
title('Recta parametrizada: y = m x + b');