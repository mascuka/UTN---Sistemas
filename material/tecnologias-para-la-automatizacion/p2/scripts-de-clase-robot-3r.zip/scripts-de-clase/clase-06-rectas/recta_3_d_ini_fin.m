clear;
clc;
close all;

% Puntos extremos del segmento
P1 = [0.20  0.20  0.60];
P2 = [0.35  0.25  0.70];

% Parametro
t = 0:0.01:1;

% Ecuaciones parametricas
x = 0.20 + 0.15*t;
y = 0.20 + 0.05*t;
z = 0.60 + 0.10*t;

% Graficar el segmento en 3D
plot3(x,y,z,'o-');

grid on;
axis equal;

xlabel('X (m)');
ylabel('Y (m)');
zlabel('Z (m)');

title('Segmento de recta en 3D');