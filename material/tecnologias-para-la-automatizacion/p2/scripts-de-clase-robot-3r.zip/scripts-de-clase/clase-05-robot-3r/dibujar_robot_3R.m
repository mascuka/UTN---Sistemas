function dibujar_robot_3R(q1, q2, q3)

% ===============================================================
% Dibuja una pose del robot 3R
%
% Entradas:
% q1, q2, q3 : �ngulos articulares en grados
%
% Convenci�n:
% q1 se mide alrededor de Z desde X
% q2 se mide desde la direcci�n radial hacia L2
% q3 = 0 cuando L3 es prolongaci�n de L2
% ===============================================================

%% Par�metros del robot [m]

l1 = 0.50;
l2 = 0.30;
l3 = 0.20;

%% Puntos del robot

O = [0; 0; 0];

A = [0; 0; l1];

% Extremo del eslab�n L2
B = [ (l2*cosd(q2))*cosd(q1); ...
      (l2*cosd(q2))*sind(q1); ...
       l1 + l2*sind(q2) ];

% Distancia radial del efector final
r = l2*cosd(q2) + l3*cosd(q2 + q3);

% Extremo del eslab�n L3
C = [ r*cosd(q1); ...
      r*sind(q1); ...
      l1 + l2*sind(q2) + l3*sind(q2 + q3) ];

%% Dibujar robot

clf;

hold on;
grid on;
axis equal;

% Eslab�n 1
plot3([O(1) A(1)], ...
      [O(2) A(2)], ...
      [O(3) A(3)], ...
      'LineWidth',4);

% Eslab�n 2
plot3([A(1) B(1)], ...
      [A(2) B(2)], ...
      [A(3) B(3)], ...
      'LineWidth',4);

% Eslab�n 3
plot3([B(1) C(1)], ...
      [B(2) C(2)], ...
      [B(3) C(3)], ...
      'LineWidth',4);

%% Articulaciones

plot3(O(1),O(2),O(3),'o','MarkerSize',8,'MarkerFaceColor','k');
plot3(A(1),A(2),A(3),'o','MarkerSize',8,'MarkerFaceColor','k');
plot3(B(1),B(2),B(3),'o','MarkerSize',8,'MarkerFaceColor','k');
plot3(C(1),C(2),C(3),'o','MarkerSize',8,'MarkerFaceColor','k');

%% Ejes

xlabel('X [m]');
ylabel('Y [m]');
zlabel('Z [m]');

xlim([-0.6 0.6]);
ylim([-0.6 0.6]);
zlim([0 1.1]);

view(3);

title(sprintf('q1 = %.1f�   q2 = %.1f�   q3 = %.1f�', ...
              q1,q2,q3));

drawnow;

end