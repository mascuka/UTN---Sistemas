%% ===============================================================
% Generaci�n de poses articulares para robot 3R
% Las tres articulaciones comienzan y terminan simult�neamente
% Todos los �ngulos est�n expresados en grados
% ===============================================================

clear;
clc;

%% Posiciones iniciales

q1_inicial = input('Ingrese q1 inicial [grados]: ');
q2_inicial = input('Ingrese q2 inicial [grados]: ');
q3_inicial = input('Ingrese q3 inicial [grados]: ');

%% Posiciones finales

q1_final = input('Ingrese q1 final [grados]: ');
q2_final = input('Ingrese q2 final [grados]: ');
q3_final = input('Ingrese q3 final [grados]: ');

%% Paso angular m�ximo deseado

paso = input('Ingrese el paso angular m�ximo [grados]: ');

%% Desplazamiento de cada articulaci�n

Dq1 = q1_final - q1_inicial
Dq2 = q2_final - q2_inicial
Dq3 = q3_final - q3_inicial

%% Determinar cu�l articulaci�n debe recorrer mayor �ngulo

Dq_max = max(abs([Dq1 Dq2 Dq3]))

%% Cantidad de intervalos necesarios

N_intervalos = ceil(Dq_max / paso)

%% Cantidad de poses

N = N_intervalos + 1;

%% Paso real de cada articulaci�n

paso_q1 = Dq1 / N_intervalos;
paso_q2 = Dq2 / N_intervalos;
paso_q3 = Dq3 / N_intervalos;

%% Crear matriz Q

Q = zeros(N,3);

%% Generaci�n de las poses

for i = 1:N

    Q(i,1) = q1_inicial + (i-1)*paso_q1;
    Q(i,2) = q2_inicial + (i-1)*paso_q2;
    Q(i,3) = q3_inicial + (i-1)*paso_q3;
    
    

end

%% Mostrar matriz de poses
Q
