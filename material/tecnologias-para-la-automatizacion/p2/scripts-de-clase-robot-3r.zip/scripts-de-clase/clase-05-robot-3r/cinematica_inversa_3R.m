function [q1, q2, q3] = cinematica_inversa_3R(x, y, z)

% ===============================================================
% CINEMATICA INVERSA - ROBOT 3R
%
% Entradas:
%   x, y, z = posicion deseada del efector final [m]
%
% Salidas:
%   q1, q2, q3 = angulos articulares [grados]
%
% Convencion:
%   q1 gira alrededor del eje Z
%   q2 se mide desde la direccion radial hacia L2
%   q3 = 0 cuando L3 es prolongacion de L2
%   q3 positivo hace subir L3 respecto de la prolongacion de L2
% ===============================================================

%% Parametros geometricos del robot [m]

l1 = 0.50;
l2 = 0.30;
l3 = 0.20;

%% Eleccion de la solucion
%
% "up"   = q3 positivo
% "down" = q3 negativo

use_elbow = "up";

%% Calculo de q1

q1 = atan2d(y, x);

%% Proyeccion del punto en el plano vertical del brazo

xp = hypot(x, y);
zp = z - l1;

%% Verificacion de alcance

L = hypot(xp, zp);

if L > (l2 + l3) || L < abs(l2 - l3)
    error('El punto esta fuera del alcance del robot');
end

%% Ley del coseno para calcular q3

D = (xp^2 + zp^2 - l2^2 - l3^2) / (2*l2*l3);

D = max(min(D,1),-1);

%% Dos soluciones posibles para q3

q3_up   =  atan2d(sqrt(1 - D^2), D);
q3_down = -atan2d(sqrt(1 - D^2), D);

%% Calculo de q2 para cada solucion

q2_up = atan2d(zp, xp) - ...
        atan2d(l3*sind(q3_up), ...
               l2 + l3*cosd(q3_up));

q2_down = atan2d(zp, xp) - ...
          atan2d(l3*sind(q3_down), ...
                 l2 + l3*cosd(q3_down));

%% Seleccion de la solucion

switch use_elbow

    case "up"
        q2 = q2_up;
        q3 = q3_up;

    case "down"
        q2 = q2_down;
        q3 = q3_down;

    otherwise
        error('use_elbow debe ser "up" o "down"');

end

end