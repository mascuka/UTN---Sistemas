%% ===============================================================
% Generaci�n de poses articulares para robot 3R
% Las tres articulaciones comienzan y terminan simultáneamente
% Todos los �gulos est�n expresados en grados
%
% Convenci�n geom�trica:
% q1 gira alrededor del eje Z
% q2 se mide desde la direcci�n radial hacia L2
% q3 = 0 cuando L3 es prolongaci�n de L2
% ===============================================================

clear;
clc;
close all;

%% Posiciones iniciales

q1_inicial = input('Ingrese q1 inicial [grados]: ');
q2_inicial = input('Ingrese q2 inicial [grados]: ');
q3_inicial = input('Ingrese q3 inicial [grados]: ');

%% Posiciones finales

q1_final = input('Ingrese q1 final [grados]: ');
q2_final = input('Ingrese q2 final [grados]: ');
q3_final = input('Ingrese q3 final [grados]: ');

%% Paso angular m�ximo

paso = input('Ingrese el paso angular m�ximo [grados]: ');

%% Desplazamiento de cada articulaci�n

Dq1 = q1_final - q1_inicial;
Dq2 = q2_final - q2_inicial;
Dq3 = q3_final - q3_inicial;

%% Buscar la articulaci�nn que más debe moverse

Dq_max = max(abs([Dq1 Dq2 Dq3]));

%% Caso especial: no hay movimiento

if Dq_max == 0

    N_intervalos = 0;
    N = 1;

    Q = [q1_inicial q2_inicial q3_inicial];

    dibujar_robot_3R(Q(1,1), Q(1,2), Q(1,3));

else

    %% Cantidad de intervalos

    N_intervalos = ceil(Dq_max / paso);

    %% Cantidad de poses

    N = N_intervalos + 1;

    %% Paso real de cada articulación
    % Las tres articulaciones tienen la misma cantidad de intervalos,
    % por lo tanto comienzan y terminan al mismo tiempo.

    paso_q1 = Dq1 / N_intervalos;
    paso_q2 = Dq2 / N_intervalos;
    paso_q3 = Dq3 / N_intervalos;

    %% Crear matriz Q
    % Cada fila de Q representa una pose:
    % Q(i,:) = [q1 q2 q3]

    Q = zeros(N,3);

    %% Generación de las poses y dibujo

    for i = 1:N

        % Cargar una nueva pose en la fila i de Q

        Q(i,1) = q1_inicial + (i-1)*paso_q1;
        Q(i,2) = q2_inicial + (i-1)*paso_q2;
        Q(i,3) = q3_inicial + (i-1)*paso_q3;

        % Dibujar la pose correspondiente a esta fila de Q

        dibujar_robot_3R(Q(i,1), Q(i,2), Q(i,3));

        % Pausa para observar el movimiento

        pause(0.1);

    end

end

%% Mostrar la matriz completa

Q
