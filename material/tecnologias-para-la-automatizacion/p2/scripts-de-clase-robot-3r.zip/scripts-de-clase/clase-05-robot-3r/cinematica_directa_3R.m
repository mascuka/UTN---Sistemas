function [x, y, z] = cinematica_directa_3R(q1, q2, q3)

% ===============================================================
% CINEMATICA DIRECTA - ROBOT 3R
%
% Entradas:
%   q1 = �ngulo de la articulaci�n 1 [grados]
%   q2 = �ngulo de la articulaci�n 2 [grados]
%   q3 = �ngulo de la articulaci�n 3 [grados]
%
% Salidas:
%   x, y, z = posici�n del efector final [m]
%
% Convenci�n:
%   q1 se mide alrededor del eje Z desde X
%   q2 se mide desde el eje radial r hacia L2
%   q3 = 0 cuando L3 es prolongaci�n de L2
% ===============================================================

%% Par�metros geom�tricos [m]

l1 = 0.50;
l2 = 0.30;
l3 = 0.20;

%% Cinem�tica directa

% Distancia radial respecto del eje Z
r = l2*cosd(q2) + l3*cosd(q2 + q3);

% Altura del efector
z = l1 + l2*sind(q2) + l3*sind(q2 + q3);

% Proyecci�n de r sobre los ejes X e Y
x = r*cosd(q1);
y = r*sind(q1);

end