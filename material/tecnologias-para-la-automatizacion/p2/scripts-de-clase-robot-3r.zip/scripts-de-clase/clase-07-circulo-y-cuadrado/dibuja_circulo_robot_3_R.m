%% ===============================================================
% DIBUJAR UN CIRCULO CON EL ROBOT 3R
%
% Este programa supone que previamente ya se corrio
% el programa que genera el circulo.
%
% Por lo tanto ya deben existir:
%
%       x, y, z
%
% y opcionalmente:
%
%       P = [x' y' z']
%
% Para cada punto del circulo:
%   1) toma x, y, z
%   2) calcula la cinematica inversa
%   3) guarda q1, q2, q3
%   4) dibuja el robot
%   5) deja marcada la trayectoria recorrida
%
% ===============================================================

%% Crear matriz P

P = [x' y' z'];

%% Cantidad de puntos del circulo

N = size(P,1);

%% Matriz para guardar configuraciones articulares

Q = zeros(N,3);

%% Recorrer todos los puntos del circulo

for i = 1:N

    % Punto cartesiano actual

    px = P(i,1);
    py = P(i,2);
    pz = P(i,3);

    % Cinematica inversa

    [q1,q2,q3] = cinematica_inversa_3R(px,py,pz);

    % Guardar los angulos articulares

    Q(i,1) = q1;
    Q(i,2) = q2;
    Q(i,3) = q3;

    % Dibujar el robot

    dibujar_robot_3R(q1,q2,q3);

    % Mantener el dibujo

    hold on;

    %% Dibujar los puntos del circulo recorridos hasta ahora

    plot3(P(1:i,1), ...
          P(1:i,2), ...
          P(1:i,3), ...
          'o-');

    %% Ejes

    grid on;

    xlabel('X [m]');
    ylabel('Y [m]');
    zlabel('Z [m]');

    xlim([-0.30 0.80]);
    ylim([-0.30 0.80]);
    zlim([0 1.20]);

    view(45,25);

    %% Actualizar dibujo

    drawnow;

    %% Pausa para observar el movimiento

    pause(0.1);

end

%% Mostrar matriz articular completa

Q