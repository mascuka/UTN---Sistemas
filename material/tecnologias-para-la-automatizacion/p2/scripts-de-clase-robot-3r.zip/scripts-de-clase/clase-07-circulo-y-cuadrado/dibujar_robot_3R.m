function dibujar_robot_3R(q1, q2, q3)

% ===============================================================
% DIBUJO DEL ROBOT 3R SIN PARPADEO
%
% El robot se dibuja una sola vez.
% Luego se actualiza su posicion sin borrar la figura.
% ===============================================================

%% Parametros del robot [m]

l1 = 0.50;
l2 = 0.30;
l3 = 0.20;

%% Puntos del robot

O = [0; 0; 0];

A = [0; 0; l1];

B = [ (l2*cosd(q2))*cosd(q1); ...
      (l2*cosd(q2))*sind(q1); ...
       l1 + l2*sind(q2) ];

r = l2*cosd(q2) + l3*cosd(q2 + q3);

C = [ r*cosd(q1); ...
      r*sind(q1); ...
      l1 + l2*sind(q2) + l3*sind(q2 + q3) ];

%% Objetos graficos persistentes

persistent h1 h2 h3 hO hA hB hC

%% Primera vez: crear el robot

if isempty(h1) || ~isgraphics(h1)

    hold on;
    grid on;

    h1 = plot3([O(1) A(1)], ...
               [O(2) A(2)], ...
               [O(3) A(3)], ...
               'LineWidth',4);

    h2 = plot3([A(1) B(1)], ...
               [A(2) B(2)], ...
               [A(3) B(3)], ...
               'LineWidth',4);

    h3 = plot3([B(1) C(1)], ...
               [B(2) C(2)], ...
               [B(3) C(3)], ...
               'LineWidth',4);

    hO = plot3(O(1),O(2),O(3), ...
               'o','MarkerSize',8,'MarkerFaceColor','k');

    hA = plot3(A(1),A(2),A(3), ...
               'o','MarkerSize',8,'MarkerFaceColor','k');

    hB = plot3(B(1),B(2),B(3), ...
               'o','MarkerSize',8,'MarkerFaceColor','k');

    hC = plot3(C(1),C(2),C(3), ...
               'o','MarkerSize',8,'MarkerFaceColor','k');

    xlabel('X [m]');
    ylabel('Y [m]');
    zlabel('Z [m]');

    xlim([-0.30 0.80]);
    ylim([-0.30 0.80]);
    zlim([0 1.20]);

    view(45,25);

else

    %% Actualizar eslabon 1

    set(h1, ...
        'XData',[O(1) A(1)], ...
        'YData',[O(2) A(2)], ...
        'ZData',[O(3) A(3)]);

    %% Actualizar eslabon 2

    set(h2, ...
        'XData',[A(1) B(1)], ...
        'YData',[A(2) B(2)], ...
        'ZData',[A(3) B(3)]);

    %% Actualizar eslabon 3

    set(h3, ...
        'XData',[B(1) C(1)], ...
        'YData',[B(2) C(2)], ...
        'ZData',[B(3) C(3)]);

    %% Actualizar articulaciones

    set(hB, ...
        'XData',B(1), ...
        'YData',B(2), ...
        'ZData',B(3));

    set(hC, ...
        'XData',C(1), ...
        'YData',C(2), ...
        'ZData',C(3));

end

drawnow;

end