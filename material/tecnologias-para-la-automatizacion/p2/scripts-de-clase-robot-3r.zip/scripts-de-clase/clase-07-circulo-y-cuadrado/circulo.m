%% ===============================================================
% GENERACION DE UN CIRCULO EN EL PLANO XZ
%
% El circulo esta contenido en el plano XZ.
% Por lo tanto:
%
%       x varia
%       y permanece constante
%       z varia
%
% Cada fila de P contiene un punto:
%
%       P(i,:) = [x  y  z]
%
% ===============================================================

clear;
clc;
close all;

%% Datos del circulo [m]

R = 0.10;          % Radio

x_c = 0.30;        % Centro en X
y_c = 0.10;        % Centro en Y
z_c = 0.65;        % Centro en Z

%% Paso angular [grados]

paso = 5;

w = 0:paso:360;

%% Ecuaciones parametricas del circulo

x = x_c + R*cosd(w);

y = y_c + zeros(size(w));

z = z_c + R*sind(w);

%% Matriz de puntos cartesianos
%
% Cada fila representa un punto:
%
% P(i,:) = [x y z]

P = [x' y' z'];

%% Dibujar el circulo

figure('Units','normalized',...
       'OuterPosition',[0 0 1 1]);

plot3(x,y,z,'o-','LineWidth',1.5);

hold on;
grid on;

%% Dibujar el centro del circulo

plot3(x_c,y_c,z_c,'o',...
      'MarkerSize',8,...
      'MarkerFaceColor','k');

%% Ejes

xlabel('X [m]');
ylabel('Y [m]');
zlabel('Z [m]');

title('Circulo en el plano XZ');

