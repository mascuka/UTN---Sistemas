%% ===============================================================
% GENERACION DE UN CUADRADO EN EL PLANO XY
%
% El programa genera los puntos de los cuatro lados del cuadrado.
% El valor de Z permanece constante.
%
% Cada fila de la matriz P contiene un punto:
%
%       P(i,:) = [x  y  z]
%
% ===============================================================

clear;
clc;
close all;

%% Vertices del cuadrado [m]

P1 = [0.15  0.10  0.60];
P2 = [0.35  0.10  0.60];
P3 = [0.35  0.30  0.60];
P4 = [0.15  0.30  0.60];

%% Parametro

t = 0:0.05:1;

%% Lado 1: P1 --> P2

x1 = P1(1) + (P2(1)-P1(1))*t;
y1 = P1(2) + (P2(2)-P1(2))*t;
z1 = P1(3) + (P2(3)-P1(3))*t;

%% Lado 2: P2 --> P3

x2 = P2(1) + (P3(1)-P2(1))*t;
y2 = P2(2) + (P3(2)-P2(2))*t;
z2 = P2(3) + (P3(3)-P2(3))*t;

%% Lado 3: P3 --> P4

x3 = P3(1) + (P4(1)-P3(1))*t;
y3 = P3(2) + (P4(2)-P3(2))*t;
z3 = P3(3) + (P4(3)-P3(3))*t;

%% Lado 4: P4 --> P1

x4 = P4(1) + (P1(1)-P4(1))*t;
y4 = P4(2) + (P1(2)-P4(2))*t;
z4 = P4(3) + (P1(3)-P4(3))*t;

%% Unir los cuatro lados

x = [x1 x2 x3 x4];
y = [y1 y2 y3 y4];
z = [z1 z2 z3 z4];

%% Matriz de puntos cartesianos
%
% Cada fila corresponde a un punto:
%
%       P(i,:) = [x y z]

P = [x' y' z'];

%% Crear una ventana grande

figure('Units','normalized',...
       'OuterPosition',[0 0 1 1]);

%% Dibujar el cuadrado

plot3(x,y,z,'o-','LineWidth',1.5);

hold on;
grid on;

xlabel('X [m]');
ylabel('Y [m]');
zlabel('Z [m]');

title('Cuadrado en el plano XY');

%% Limites del espacio cartesiano
%

