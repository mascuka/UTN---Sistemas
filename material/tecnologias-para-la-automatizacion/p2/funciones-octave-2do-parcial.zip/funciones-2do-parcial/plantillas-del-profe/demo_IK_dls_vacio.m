%% Inicializacion
q0=[]; %semilla
tipo =''; %tipo
d_offset=[ ]; %desplazamientos d en DH
a=[ ]; %desplazamientos a en DH
alpha=[]; %angulos alpha
unidad='deg'
q_offset=[]; % si hubiera angulos fijos rotando en z
%% Corrida con posicion deseada
pd=[ ]; %posicion deseada
options.verbose=0  % 1 para que muestre resultados intermedios
options.use_analitico=false;
[q_sol,theta,d, success, info] = cinematica_inversa(pd, q0, tipo, q_offset, d_offset, a, alpha, unidad,options);
Q= q_sol
%% verificacion por DH 
[T, origins, Tsist] = cinematica_directa(theta',d', a, alpha, unidad);
Pos=T(1:3,4)
% dibujarSistemasDeEjesCoordenadosDeRobot('Robot',Tsist(:,:, 1),Tsist(:,: ,2),Tsist(:,:, 3))