%%
clear all
close all
clc
%% definir trayectoria
x0 =  ,y0 = , z0 = , R = ;
w = 0 : paso : 360 ; x = x0 +  ; 
y = y0 +  ;
z = z0 +  ; P = [x; y; z] 


%% Inicializacion parametros
q0=[]; %semilla
tipo =''; %tipo
d_offset=[]; %desplazamientos d en DH
a=[ ]; %desplazamientos a en DH
alpha=[]; %angulos alpha
unidad='deg'
q_offset=[]; % si hubiera angulos fijos rotando en z
%% Corrida con posiciones deseadas y verificacion por DH
Q=[]
Pos=[]

for i=1:numel(x)
    pd=P(:,i); %posicion deseada
    options.verbose=0  % 1 para que muestre resultados intermedios
    options.use_analitico=false;
    [q_sol,theta,d, success, info] = cinematica_inversa(pd, q0, tipo, q_offset, d_offset, a, alpha, unidad,options);
    Q= [Q q_sol];
    [T, origins, Tsist] = cinematica_directa(theta',d', a, alpha, unidad);
Pos=[Pos T(1:3,4)]

end
figure
hold on
plot3(x,y,z,'r')
plot3(Pos(1,:),Pos(2,:),Pos(3,:))
grid on
axis equal



%% Generacion trayectorias
wmax = []; %velocidades maximas
h= ; % paso temporal
Q_total  = [];
DQ_total = [];
T_total  = [];
t_acumulado = 0;
for i=1:numel(x)-1
    
    qi=Q(:,i); %posicion deseada
    qf=Q(:,i+1);
    [q_sub, Dq_sub, t_sub] = generacion_de_trayectorias(qi, qf, wmax, h);
    
    % Ajustar el vector de tiempo local para que sea continuo en el tiempo global
    t_sub_global = t_sub + t_acumulado;
    t_acumulado  = t_sub_global(end); % Actualizar offset para el siguiente tramo
    
    % Descartar el primer punto a partir del segundo tramo para NO duplicar
    % el punto de empalme (donde qi del tramo actual es igual al qf del tramo anterior)
    if i > 1
        q_sub        = q_sub(2:end, :);
        Dq_sub       = Dq_sub(2:end, :);
        t_sub_global = t_sub_global(2:end);
    end
    
    % Concatenar con la trayectoria global
    Q_total  = [Q_total; q_sub];
    DQ_total = [DQ_total; Dq_sub];
    T_total  = [T_total; t_sub_global];
end

 %% animacion
 d=d_offset+q_offset
dh_params = [a(:), alpha(:), d(:)];
animar_trayectoria(T_total, Q_total,dh_params,tipo);

%% En el tiempo
Dibujar_Temporal( T_total,Q_total,DQ_total )