%% EJERCICIO 1 - CI geometrica robot RRR (antropomorfo)
clc; clear; format short g
l1 = 0.45; l2 = 0.35; l3 = 0.25;          % [m]
P  = [0.30 0.25 0.60];                     % punto deseado [m]
x = P(1); y = P(2); z = P(3);

q1 = atan2d(y, x)                          % paso 1: giro de la base
r  = hypot(x, y)                           % paso 2: bajo al plano del brazo
s  = z - l1
L  = hypot(r, s)                           % alcance: |l2-l3| <= L <= l2+l3
D  = (r^2 + s^2 - l2^2 - l3^2) / (2*l2*l3) % paso 3: ley del coseno = cos(q3)
q3_arriba = atan2d(-sqrt(1-D^2), D)        % codo arriba
q3_abajo  = atan2d( sqrt(1-D^2), D)        % codo abajo
q2_arriba = atan2d(s, r) - atan2d(l3*sind(q3_arriba), l2 + l3*cosd(q3_arriba))
q2_abajo  = atan2d(s, r) - atan2d(l3*sind(q3_abajo),  l2 + l3*cosd(q3_abajo))

% verificacion con la CD del profe (tabla DH del 3R)
a = [0 l2 l3]; d = [l1 0 0]; alpha = [90 0 0];
T1 = cinematica_directa([q1 q2_arriba q3_arriba], d, a, alpha, 'deg'); P1 = T1(1:3,4)'
T2 = cinematica_directa([q1 q2_abajo  q3_abajo ], d, a, alpha, 'deg'); P2 = T2(1:3,4)'
% codo del brazo (origen 2) para saber cual esta arriba
[~, o1] = cinematica_directa([q1 q2_arriba q3_arriba], d, a, alpha, 'deg'); codo_arriba = o1(:,3)'
[~, o2] = cinematica_directa([q1 q2_abajo  q3_abajo ], d, a, alpha, 'deg'); codo_abajo  = o2(:,3)'
