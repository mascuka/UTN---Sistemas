%% EJERCICIO 2 - CI numerica (DLS) robot cilindrico 4 GdL (R P P R)
clc; clear; format short g
l1 = 400; l4 = 100;                 % [mm]
tipo     = 'RPPR';
q_offset = [0; 90; 0; 0];           % theta fijos (las P) u offset (las R)  [deg]
d_offset = [l1; 0; 0; l4];          % d fijos (las R) u offset (las P)      [mm]
a        = [0; 0; 0; 0];
alpha    = [0; 90; 0; 0];
pd = [300; 250; 650];               % punto deseado [mm]
q0 = [0; 100; 100; 0];              % semilla: [q1 deg; d2 mm; d3 mm; q4 deg]

% ---- iteracion 1 "a mano" (lo que hace la funcion por dentro) ----
theta0 = q_offset + [q0(1); 0; 0; q0(4)];
d0     = d_offset + [0; q0(2); q0(3); 0];
T0 = cinematica_directa(theta0, d0, a, alpha, 'deg');
p0 = T0(1:3,4)
e0 = pd - p0
norm_e0 = norm(e0)
J  = jacobiano_analitico(q0, tipo, q_offset, d_offset, a, alpha, 'deg');
Jp = J(1:3,:)
dq = Jp' * ((Jp*Jp' + 0.05^2*eye(3)) \ e0)
q1_iter = q0 + dq

% ---- la funcion completa del profe ----
[q_sol, theta, d, success, info] = cinematica_inversa(pd, q0, tipo, q_offset, d_offset, a, alpha, 'deg');
q_sol
success
info
% verificacion
th = q_offset + [q_sol(1); 0; 0; q_sol(4)];
dd = d_offset + [0; q_sol(2); q_sol(3); 0];
T  = cinematica_directa(th, dd, a, alpha, 'deg');
p_final = T(1:3,4)
error_final = norm(pd - p_final)
% verificacion analitica (geometrica)
q1_geo = atan2d(pd(2), pd(1))
d2_geo = pd(3) - l1
d3_geo = hypot(pd(1), pd(2)) - l4
