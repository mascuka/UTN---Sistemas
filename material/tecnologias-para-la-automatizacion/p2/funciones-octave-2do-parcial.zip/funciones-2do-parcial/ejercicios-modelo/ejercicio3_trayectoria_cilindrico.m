%% EJERCICIO 3 - Generacion de trayectoria (robot cilindrico 4 GdL)
clc; clear; format short g
l1 = 400; l4 = 100;
tipo = 'RPPR'; q_offset = [0;90;0;0]; d_offset = [l1;0;0;l4];
a = [0;0;0;0]; alpha = [0;90;0;0];
PA = [300; 250; 650];   PB = [-200; 350; 500];      % [mm]

% 1) CI de los dos puntos (la semilla de B es la solucion de A)
[qA, ~, ~, okA] = cinematica_inversa(PA, [0;100;100;0], tipo, q_offset, d_offset, a, alpha, 'deg');
[qB, ~, ~, okB] = cinematica_inversa(PB, qA,            tipo, q_offset, d_offset, a, alpha, 'deg');
qA = qA', qB = qB'

% 2) trayectoria articular sincronizada
wmax = [30 50 50 30];         % [deg/s  mm/s  mm/s  deg/s]
h    = 0.1;                   % [s]
[q, Dq, t] = generacion_de_trayectorias(qA, qB, wmax, h);
T_total  = t(end)
N_puntos = size(q,1)
paso_real = t(2) - t(1)
velocidades = Dq(1,:)
q_mitad = q(round(end/2),:)
t_mitad = t(round(end/2))

% 3) CD de cada muestra -> camino del TCP
P = zeros(3, N_puntos);
for k = 1:N_puntos
  th = q_offset + [q(k,1); 0; 0; q(k,4)];
  dd = d_offset + [0; q(k,2); q(k,3); 0];
  Tk = cinematica_directa(th, dd, a, alpha, 'deg');
  P(:,k) = Tk(1:3,4);
end
P_inicio = P(:,1)', P_fin = P(:,end)'

% 4) graficos y animacion
Dibujar_Temporal(t, q, Dq);
qr = q;  qr(:,[1 4]) = deg2rad(q(:,[1 4]));      % las R en radianes
dh = [0 0 l1; 0 pi/2 pi/2; 0 0 0; 0 0 l4];        % [a  alpha  fijo]
animar_trayectoria(t, qr, dh, 'RPPR');
