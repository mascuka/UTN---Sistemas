format short g
l1 = 770; l2 = 420; l3 = 400; l4 = 250;            % [mm]
tipo     = 'RRRPRR';
q_offset = [0; 0; 0; 0; 0; 0];                      % theta fijos / offsets [deg]
d_offset = [l1; 0; 0; l3; 0; l4];                   % d fijos / offsets  [mm]
a        = [0; l2; 0; 0; 0; 0];
alpha    = [-90; 0; 90; -90; 90; 0];
% Congelamos d4 = 0, q5 = 0 y q6 = 0 con limites iguales
opts.q_min = [-360; -360; -360; 0; 0; 0];
opts.q_max = [ 360;  360;  360; 0; 0; 0];
P = [-87.59 -17.50 1221.98; -127.12 -115.63 1024.95; -268.98 -117.69 1249.07];
for i = 1:size(P,1)
  q1g = atan2d(P(i,2), P(i,1));                     % semilla: q1 hacia el punto
  [qA,~,~,okA] = cinematica_inversa(P(i,:)', [q1g; 20; -45; 0; 0; 0],  tipo, q_offset, d_offset, a, alpha, 'deg', opts);
  [qB,~,~,okB] = cinematica_inversa(P(i,:)', [q1g; -170; -135; 0; 0; 0], tipo, q_offset, d_offset, a, alpha, 'deg', opts);
  printf('Punto %d  A: %8.2f %8.2f %8.2f (ok %d) | B: %8.2f %8.2f %8.2f (ok %d)\n', i, qA(1:3), okA, qB(1:3), okB);
end
