%% 2do Parcial - Ejercicio 4: circulo con el robot cilindrico RPPR
clc; clear; close all;
l1 = 600; l4 = 200;                               % [mm]
tipo     = 'RPPR';
q_offset = [0; 90; 0; 0];                         % columna theta (variables -> 0)
d_offset = [l1; 0; 0; l4];                        % columna d (variables -> 0)
a        = [0; 0; 0; 0];
alpha    = [0; 90; 0; 0];

% 1) Circulo en el plano XZ (y = 700 constante)
x0 = 0; y0 = 700; z0 = 1100; R = 150;
w = 0:15:360;
x = x0 + R*cosd(w);  y = y0 + zeros(size(w));  z = z0 + R*sind(w);
P = [x; y; z];                                    % 3 x N, cada columna un punto

% 2) Cinematica inversa en cada punto (la semilla es la solucion anterior)
N = size(P,2);
Q = zeros(N,4);
q = [90; 500; 500; 0];                            % q_start
for k = 1:N
  [q,~,~,ok] = cinematica_inversa(P(:,k), q, tipo, q_offset, d_offset, a, alpha, 'deg');
  if ~ok, warning('No convergio en el punto %d', k); end
  Q(k,:) = q';
end

% 3) Encadenar generacion_de_trayectorias entre puntos consecutivos
wmax = [60 200 200 60];                           % [deg/s mm/s mm/s deg/s]
h = 0.05;                                         % [s]
Qt = []; DQt = []; Tt = [];
for k = 1:N-1
  [qk, dqk, tk] = generacion_de_trayectorias(Q(k,:), Q(k+1,:), wmax, h);
  if k > 1                                        % no repetir el punto de union
    qk = qk(2:end,:); dqk = dqk(2:end,:); tk = tk(2:end);
  end
  t0 = 0; if ~isempty(Tt), t0 = Tt(end); end
  Qt = [Qt; qk]; DQt = [DQt; dqk]; Tt = [Tt; t0 + tk];
end
printf('Puntos del circulo: %d | muestras: %d | tiempo total: %.2f s\n', N, size(Qt,1), Tt(end));

% 4) Perfiles q(t) y dq(t)
Dibujar_Temporal(Tt, Qt, DQt);

% 5) Animacion (q1 y q4 en radianes; alpha y theta fijos en radianes)
Qr = Qt;  Qr(:,[1 4]) = deg2rad(Qt(:,[1 4]));
dh = [0 0 l1; 0 pi/2 pi/2; 0 0 0; 0 0 l4];        % [a  alpha  fijo]
animar_trayectoria(Tt, Qr, dh, 'RPPR');
