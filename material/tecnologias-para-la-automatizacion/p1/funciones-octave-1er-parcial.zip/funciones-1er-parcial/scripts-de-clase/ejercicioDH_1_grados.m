%% Ejercicios de DH
%Denavit Hartember_ejer.doc   de dos grados de libertad pantografo
close all; clear all; clc
syms q1 q2 real 

% Parmetros de DH del archivo de word
q=[q1 q2]
d=[0 0]
a=[3 1.5]
alfa=[0 0]

%%

i=1;
A01=[cosd(q(i)) -cosd(alfa(i))*sind(q(i))  sind(alfa(i))*sind(q(i)) a(i)*cosd(q(i));...
   sind(q(i))  cosd(alfa(i))*cosd(q(i)) -sind(alfa(i))*cosd(q(i)) a(i)*sind(q(i));...
   0          sind(alfa(i))            cosd(alfa(i))           d(i);...
   0 0 0 1]
%%

i=2;
A12=[cosd(q(i)) -cosd(alfa(i))*sind(q(i))  sind(alfa(i))*sind(q(i)) a(i)*cosd(q(i));...
   sind(q(i))  cosd(alfa(i))*cosd(q(i)) -sind(alfa(i))*cosd(q(i)) a(i)*sind(q(i));...
   0          sind(alfa(i))            cosd(alfa(i))           d(i);...
   0 0 0 1]

%%

T=A01*A12

%%

q1=90;q2=90
eval(T)




