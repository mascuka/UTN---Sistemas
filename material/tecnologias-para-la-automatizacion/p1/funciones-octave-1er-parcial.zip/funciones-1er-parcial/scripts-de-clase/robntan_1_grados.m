%% Ejercicios de DH
% Denavit-Hartenberg del robot no tan elemental, primer ejemplo del apunte
% Versión trabajando con ángulos en grados
close all; clear all; clc
syms q1 L p real

format bank

q = [90 + q1  0]      % theta de los parámetros DH, en grados
d = [0  L + p]        % p va desde 0 hasta 0.30 m
a = [0  0]
alfa = [90  0]        % alpha de los parámetros DH, en grados

L = 0.7               % longitud fija; p es prismático y varía entre 0 y 0.30 m

%%
i = 1;
A01 = [cosd(q(i))  -cosd(alfa(i))*sind(q(i))   sind(alfa(i))*sind(q(i))   a(i)*cosd(q(i)); ...
       sind(q(i))   cosd(alfa(i))*cosd(q(i))  -sind(alfa(i))*cosd(q(i))   a(i)*sind(q(i)); ...
       0            sind(alfa(i))               cosd(alfa(i))              d(i); ...
       0            0                            0                           1]

%%
i = 2;
A12 = [cosd(q(i))  -cosd(alfa(i))*sind(q(i))   sind(alfa(i))*sind(q(i))   a(i)*cosd(q(i)); ...
       sind(q(i))   cosd(alfa(i))*cosd(q(i))  -sind(alfa(i))*cosd(q(i))   a(i)*sind(q(i)); ...
       0            sind(alfa(i))               cosd(alfa(i))              d(i); ...
       0            0                            0                           1]

%%
A01

%%
A12

%%
T = A01*A12

%%
q1 = 90;             % q1 ahora está expresado en grados
p = 0.3;               % eslabón prismático entre 0 y 0.30 m
eval(T)

%%
