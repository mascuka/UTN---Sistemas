%% MATRIZ DE TRASLACI�N 

% Definimos la variable simb�lica para el desplazamiento en x (dx)
syms dx

% Limpiamos el espacio de trabajo, cerramos todas las ventanas y limpiamos la consola
close all; clear all; clc

% Definimos desplazamientos simb�licos en los tres ejes
syms dx dy dz real 

% Creamos la matriz de traslaci�n en el espacio
tras = [1 0 0 dx; ... % Desplazamiento en el eje X
        0 1 0 0; ...  % No hay desplazamiento en Y
        0 0 1 0; ...  % No hay desplazamiento en Z
        0 0 0 1]     % Parte homog�nea de la matriz

%% Asignamos un valor a dx = 3
dx = 3;

% Evaluamos la matriz de traslaci�n con dx = 3
eval(tras)

%% Definimos una nueva matriz de traslaci�n tras1
tras1 = [1 0 0 1; ...   % Desplazamiento en X = 1
         0 1 0 -6; ...  % Desplazamiento en Y = -6
         0 0 1 -7; ...  % Desplazamiento en Z = -7
         0 0 0 1]
    

%% Definimos un punto en el espacio en coordenadas homog�neas
p = [2 3 4 1]'  % Punto P en el espacio (2, 3, 4) m�s el 1 de la coordenada homog�nea

%% Aplicamos la traslaci�n al punto P
p1 = tras1 * p

%% MATRICES DE ROTACI�N

% Limpiamos nuevamente el espacio de trabajo
close all; clear all; clc

% ROTACI�N EN EL EJE Z
syms gama   % �ngulo de rotaci�n en el eje Z

% Definimos la matriz de rotaci�n en el eje Z
rotz = [cos(gama) -sin(gama) 0 0; ...  % Rotaci�n en el plano X-Y
        sin(gama)  cos(gama)  0 0; ...
        0         0          1 0; ...  % Sin rotaci�n en el eje Z
        0         0          0 1]

%% Asignamos un valor a gama = pi (180 grados)
gama = -pi/2;

% Evaluamos la matriz de rotaci�n con gama = pi/2
rotzz = eval(rotz)

%% Definimos un nuevo punto
p = [3 0 0 1]'  % Punto P en (3, 0, 0)
%%
% Aplicamos la rotaci�n en Z al punto P
pp = rotzz * p

%% Otra rotaci�n en Z pero con gama = -pi/2
close all; clear all; clc

gama = -pi/2;  % �ngulo de rotaci�n negativo (hacia el sentido contrario)
rotz = [cos(gama) -sin(gama) 0 0; ...
        sin(gama)  cos(gama)  0 0; ...
        0         0          1 0; ...
        0         0          0 1]

p = [3 0 0 1]';  % Definimos el punto P de nuevo

%% Aplicamos la rotaci�n
pp = rotz * p

%% ROTACI�N EN EL EJE Y

close all; clear all; clc

syms beta  % �ngulo de rotaci�n en el eje Y

% Definimos la matriz de rotaci�n en el eje Y
roty = [cos(beta)  0 sin(beta) 0; ...  % Efecto de rotaci�n en el plano Z-X
        0          1 0         0; ...
       -sin(beta)  0 cos(beta) 0; ...
        0          0 0         1]

%% Definimos el punto a rotar

p = [3 0 0 1]'

%% definimos el angulo beta: 
beta= pi/2

%% evaluamos la matriz de rotaci�n en el eje y

rotyy= eval(roty)


%% Aplicamos la rotaci�n en Y
pp = rotyy * p

%% ROTACI�N EN EL EJE X

close all; clear all; clc

syms alfa  % �ngulo de rotaci�n en el eje X

% Definimos la matriz de rotaci�n en el eje X
rotx = [1 0         0          0; ...
        0 cos(alfa) -sin(alfa) 0; ...
        0 sin(alfa)  cos(alfa) 0; ...
        0 0         0          1]
%%
    
p = [0 0 3 1]'  % Definimos el punto P en el espacio

%% definimos el �ngulo alfa 
alfa = pi/2

%% evaluamos la matriz de rotaci�n con alfa 

rotxx= eval (rotx) 

%% Aplicamos la rotaci�n en el eje X
pp = rotxx * p

%% Combinaci�n de rotaciones //////////////////////////////////////////

% Rotaci�n en el eje Z
syms gama
gama = pi/2;

rotz = [cos(gama) -sin(gama) 0 0; ...
        sin(gama)  cos(gama) 0 0; ...
        0         0         1 0; ...
        0         0         0 1]

%% Rotaci�n en el eje X
syms alfa
alfa = pi/2;

rotx = [1 0         0          0; ...
        0 cos(alfa) -sin(alfa) 0; ...
        0 sin(alfa)  cos(alfa) 0; ...
        0 0         0          1]

%% Definimos el punto
p = [3 0 0 1]';

%% Aplicamos ambas rotaciones (X luego Z)
%PP = rotx * rotz * p

%%
pa= rotz * p

%%
pb= rotx *pa

%% y si cambiamos el orden ??
PPP = rotz * rotx * p

