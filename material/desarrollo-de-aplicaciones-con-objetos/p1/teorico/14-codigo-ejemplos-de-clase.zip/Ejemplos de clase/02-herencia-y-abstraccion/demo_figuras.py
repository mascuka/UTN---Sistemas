# Prueba de Abstraccion_figuras.py (el ejemplo de la cátedra solo define las clases)
from Abstraccion_figuras import FiguraGeometrica, Cuadrado, Circulo

print("Área del cuadrado de lado 3:", Cuadrado(3).calcular_area())
print("Área del círculo de radio 2:", Circulo(2).calcular_area())
try:
    FiguraGeometrica()          # una clase abstracta no se puede instanciar
except TypeError as error:
    print("No se puede crear una FiguraGeometrica:", error)
