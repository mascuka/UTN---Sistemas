import math
import random
from functools import reduce

random.seed(2026)        # para que la salida sea siempre la misma (sacarlo para que cambie)

es_par = lambda x: x % 2 == 0
promedio = lambda lista: sum(lista) / len(lista) if lista else 0

numeros = [random.randint(-1_000_000, 1_000_000) for _ in range(1000)]   # comprensión en vez de un for

print("Menor de todos:", reduce(lambda a, b: a if a < b else b, numeros))
print("Cantidad de pares:", len(list(filter(es_par, numeros))))
impares = list(filter(lambda x: not es_par(x), numeros))
print(f"Promedio de los impares: {promedio(impares):.2f}")
cuadrados = list(map(lambda x: x ** 2, filter(lambda x: 10 < x < 100, numeros)))
print("Cuadrados de los que están entre 10 y 100:", cuadrados)
print("Múltiplos de 3 de esos cuadrados:", list(filter(lambda x: x % 3 == 0, cuadrados)))
multiplos_7 = sorted(filter(lambda x: x % 7 == 0, numeros), reverse=True)
print(f"Múltiplos de 7 (de mayor a menor), {len(multiplos_7)}:", multiplos_7[:10], "…")
print(f"Promedio de los impares negativos: {promedio(list(filter(lambda x: x < 0, impares))):.2f}")
media = promedio(numeros)
desvio = math.sqrt(sum(map(lambda x: (x - media) ** 2, numeros)) / (len(numeros) - 1))
print(f"Desviación estándar: {desvio:.2f}")
print("¿Hay algún múltiplo de 127?", "Sí" if any(map(lambda x: x % 127 == 0, numeros)) else "No")
terminan_2_o_3 = list(filter(lambda x: abs(x) % 10 in (2, 3), numeros))
print(f"Terminan en 2 o 3: {len(terminan_2_o_3)} números, por ejemplo", terminan_2_o_3[:8])
