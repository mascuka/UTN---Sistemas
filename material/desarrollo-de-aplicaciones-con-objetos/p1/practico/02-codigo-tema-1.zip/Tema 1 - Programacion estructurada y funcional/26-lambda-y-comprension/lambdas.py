# lambda argumentos: expresión  (una función sin nombre, de una sola expresión)
cuadrado = lambda x: x ** 2
print(cuadrado(3))

cuadrado_mayor_a_diez = lambda x: x ** 2 > 10
print([cuadrado_mayor_a_diez(n) for n in (2, 3, 4, 5)])

# Las funciones son valores: se pueden guardar en variables y pasar como argumento
imprimir = print
imprimir("Hola desde una variable que guarda una función")
print(sorted(["Bermuda", "Aruba", "Key Largo"], key=lambda s: len(s)))
