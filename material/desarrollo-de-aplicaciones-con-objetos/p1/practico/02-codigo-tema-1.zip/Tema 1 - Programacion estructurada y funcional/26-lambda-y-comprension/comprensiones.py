numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Forma tradicional: un for que va armando la lista
pares = []
for n in numeros:
    if n % 2 == 0:
        pares.append(n)
print("Pares (con for):", pares)

# Por comprensión: [expresión for elemento in iterable if condición]
print("Pares (comprensión):", [n for n in numeros if n % 2 == 0])
print("Siguiente de cada par:", [n + 1 for n in numeros if n % 2 == 0])
print("Cuadrados de los múltiplos de 3:", [n ** 2 for n in numeros if n % 3 == 0])

# Comprensión de diccionarios: {clave: valor for ...}
personas = [
    {"nombre": "Alice", "edad": 30, "puesto": "Data Scientist"},
    {"nombre": "Bob", "edad": 35, "puesto": "Data Engineer"},
    {"nombre": "Chris", "edad": 33, "puesto": "Machine Learning Engineer"},
]
print("Puestos con 'Data':", {p["nombre"]: p["puesto"] for p in personas if "Data" in p["puesto"]})
