from functools import reduce

lista = [1, 2, 3, 4, 5]

# map: aplica la función a cada elemento
print("Cuadrados:", list(map(lambda x: x ** 2, lista)))

# filter: se queda con los elementos para los que la función da True
numeros = list(range(-10, 11))
print("Negativos pares o positivos:", list(filter(lambda x: (x <= 0 and x % 2 == 0) or x > 0, numeros)))

# reduce: acumula de a dos, de izquierda a derecha, hasta dejar un solo valor
print("Suma:", reduce(lambda acumulado, x: acumulado + x, lista))       # ((((1+2)+3)+4)+5)
print("Producto:", reduce(lambda acumulado, x: acumulado * x, lista))
