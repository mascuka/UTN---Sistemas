import random
from functools import reduce

random.seed(2026)        # así la salida es siempre la misma (sacalo para que cambie)

lst = ["Aruba", "Jamaica", "Bermuda", "Bahama", "Key Largo", "Montigo"]

# 01. Primer carácter de cada palabra (comprensión)
iniciales = [p[0] for p in lst]
print("01.", iniciales)

# 02. Longitud de cada palabra (comprensión)
longitudes = [len(p) for p in lst]
print("02.", longitudes)

# 03. Cantidad total de caracteres (reduce)
print("03.", reduce(lambda a, b: a + b, longitudes))

# Actividad: 50 enteros al azar entre 1 y 100 (comprensión)
numeros = [random.randint(1, 100) for _ in range(50)]
print("Números:", numeros)

# Filter: mayores a 50 y menores o iguales a 50
mayores = list(filter(lambda x: x > 50, numeros))
menores = list(filter(lambda x: x <= 50, numeros))
print("Mayores a 50:", mayores)
print("Menores o iguales a 50:", menores)

# Map: solo los impares, con el signo invertido (filter elige los impares, map los niega)
impares_negativos = list(map(lambda x: -x, filter(lambda x: x % 2 != 0, numeros)))
print("Impares con signo invertido:", impares_negativos)

# Reduce: sumatoria de la lista anterior
print("Sumatoria:", reduce(lambda a, b: a + b, impares_negativos))
