# Cada opción del menú es una función guardada en un diccionario
operaciones = {
    "1": ("Sumar", lambda a, b: a + b),
    "2": ("Restar", lambda a, b: a - b),
    "3": ("Multiplicar", lambda a, b: a * b),
    "4": ("Dividir", lambda a, b: a / b if b != 0 else float("inf")),
}


def main():
    print("Calculadora básica")
    for clave, (nombre, _) in operaciones.items():
        print(f"{clave}- {nombre}")
    print("0- Salir")

    opcion = input("Opción: ")
    while opcion != "0":
        if opcion in operaciones:
            a = float(input("Primer operando: "))
            b = float(input("Segundo operando: "))
            nombre, funcion = operaciones[opcion]
            print(f"{nombre}: {funcion(a, b)}")
        else:
            print("Opción no válida")                 # la de la cátedra se rompía con una opción fuera de rango
        opcion = input("Opción: ")
    print("Gracias")


if __name__ == "__main__":
    main()
