import json


def leer_codigos(nombre_archivo):
    """El JSON es una lista de diccionarios: json.load la devuelve lista para usar."""
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return json.load(archivo)


def main():
    codigos = leer_codigos("cp.json")
    buscado = input("Código a buscar (vacío para terminar): ")
    while buscado:
        # en el JSON el código es un número: hay que comparar con int, no con el texto
        encontrados = [c for c in codigos if c["codigo_postal"] == int(buscado)]
        for c in encontrados:
            print(f"   {c['codigo_provincia']}: {c['nombre_localidad']}")
        if not encontrados:
            print("   No se encontró ninguna localidad")
        buscado = input("Código a buscar (vacío para terminar): ")


if __name__ == "__main__":
    main()
