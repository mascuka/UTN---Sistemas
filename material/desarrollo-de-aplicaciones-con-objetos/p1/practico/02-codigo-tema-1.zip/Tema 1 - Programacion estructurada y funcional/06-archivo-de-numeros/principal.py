def leer_numeros(nombre_archivo):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return [int(linea) for linea in archivo if linea.strip()]


def main():
    numeros = leer_numeros("numeros.txt")
    promedio = sum(numeros) / len(numeros)
    pares = [n for n in numeros if n % 2 == 0]
    print("Números leídos:", len(numeros))
    print(f"Promedio: {promedio:.2f}")
    print("Mayores al promedio:", len([n for n in numeros if n > promedio]))
    print(f"Pares ({len(pares)}):", pares)


if __name__ == "__main__":
    main()
