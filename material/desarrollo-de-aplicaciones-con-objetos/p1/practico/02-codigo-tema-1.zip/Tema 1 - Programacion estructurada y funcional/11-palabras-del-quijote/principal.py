import re


def palabras_de(nombre_archivo):
    """Todas las palabras del texto, en minúscula y sin signos de puntuación."""
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return re.findall(r"[a-záéíóúüñ]+", archivo.read().lower())


def leer_diccionario(nombre_archivo):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return {linea.strip() for linea in archivo if linea.strip()}


def main():
    libro = set(palabras_de("quijote.txt"))          # el texto es la traducción al inglés
    diccionario = leer_diccionario("words_alpha.txt")
    no_existen = libro - diccionario                  # diferencia de conjuntos

    print("Palabras únicas del libro:", len(libro))
    print("Palabras del diccionario:", len(diccionario))
    print("Palabras del libro que no están en el diccionario:", len(no_existen))
    print("Listado ordenado:")
    for palabra in sorted(no_existen):
        print("  ", palabra)


if __name__ == "__main__":
    main()
