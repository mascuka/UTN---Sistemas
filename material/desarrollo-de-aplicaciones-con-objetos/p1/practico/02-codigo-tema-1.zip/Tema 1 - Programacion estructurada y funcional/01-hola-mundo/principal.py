from saludos import *

saludar()

