def leer_codigos(nombre_archivo):
    """Una tupla (provincia, código, localidad) por línea."""
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return [tuple(linea.strip().split(";")) for linea in archivo if linea.strip()]


def buscar(codigos, buscado):
    return [c for c in codigos if c[1] == buscado]


def main():
    codigos = leer_codigos("cp.csv")
    buscado = input("Código a buscar (vacío para terminar): ")
    while buscado:
        encontrados = buscar(codigos, buscado)
        for provincia, codigo, localidad in encontrados:
            print(f"   {provincia}: {localidad}")
        if not encontrados:
            print("   No se encontró ninguna localidad")
        buscado = input("Código a buscar (vacío para terminar): ")


if __name__ == "__main__":
    main()
