import random

random.seed(7)       # para que la salida sea siempre la misma (sacarlo para que cambie)

numeros = [random.randint(1, 20) for _ in range(10)]
conjunto = set(numeros)              # el conjunto no guarda repetidos

print("Lista original:", numeros)
print("Conjunto:", conjunto)
print("Elementos originales:", len(numeros), "· sin repetidos:", len(conjunto))
