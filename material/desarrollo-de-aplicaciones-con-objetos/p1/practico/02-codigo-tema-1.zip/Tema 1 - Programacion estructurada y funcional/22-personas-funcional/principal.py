import csv


def cargar(nombre_archivo):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return {d: {"nombre": n, "apellido": a, "edad": int(e)} for d, n, a, e in csv.reader(archivo)}


def mostrar(documento, p):
    print(f"   {documento}: {p['apellido']}, {p['nombre']} ({p['edad']} años)")


def por_documento(datos):
    documento = input("Documento: ")
    persona = datos.get(documento)
    mostrar(documento, persona) if persona else print("   Persona no encontrada")


def por_apellido(datos):
    apellido = input("Apellido: ").upper()
    encontrados = list(filter(lambda item: item[1]["apellido"] == apellido, datos.items()))
    list(map(lambda item: mostrar(*item), encontrados))
    print(f"   {len(encontrados)} persona(s)")


def promedio_edades(datos):
    edades = list(map(lambda p: p["edad"], datos.values()))
    print(f"   Promedio de edades: {sum(edades) / len(edades):.2f}")


# El menú es un diccionario: opción -> (texto, función)
MENU = {"1": ("Búsqueda por documento", por_documento),
        "2": ("Búsqueda por apellido", por_apellido),
        "3": ("Promedio de edades", promedio_edades)}


def main():
    datos = cargar("personas.csv")
    opcion = ""
    while opcion != "4":
        print(" · ".join(f"{k}. {texto}" for k, (texto, _) in MENU.items()) + " · 4. Salir")
        opcion = input("Opción: ")
        if opcion in MENU:
            MENU[opcion][1](datos)
        elif opcion != "4":                       # en la de la cátedra, "Salir" mostraba "opción no válida"
            print("   Opción no válida")


if __name__ == "__main__":
    main()
