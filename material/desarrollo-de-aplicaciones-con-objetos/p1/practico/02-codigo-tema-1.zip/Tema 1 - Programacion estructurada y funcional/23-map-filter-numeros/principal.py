from functools import reduce

numeros = list(range(-5, 11))            # de -5 a 10, ambos incluidos

print("Números:", numeros)
print("Cuadrados:", list(map(lambda x: x ** 2, numeros)))
print("Negativos:", list(filter(lambda x: x < 0, numeros)))
print("Sumatoria:", reduce(lambda a, b: a + b, numeros))
