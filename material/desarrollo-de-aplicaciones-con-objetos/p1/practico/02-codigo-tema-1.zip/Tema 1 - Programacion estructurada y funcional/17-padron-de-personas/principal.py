def leer_padron(nombre_archivo):
    """documento,nombre,apellido,edad -> diccionario indexado por documento."""
    padron = {}
    with open(nombre_archivo, encoding="utf-8") as archivo:
        for linea in archivo:
            if linea.strip():
                documento, nombre, apellido, edad = linea.strip().split(",")
                padron[documento] = {"nombre": nombre, "apellido": apellido, "edad": int(edad)}
    return padron


def mostrar(documento, persona):
    print(f"   {documento}: {persona['apellido']}, {persona['nombre']} ({persona['edad']} años)")


def main():
    padron = leer_padron("personas.csv")
    opcion = ""
    while opcion != "0":
        print("1. Buscar por documento  2. Buscar por apellido  3. Promedio de edades  0. Salir")
        opcion = input("Opción: ")
        if opcion == "1":
            documento = input("Documento: ")
            if documento in padron:                       # búsqueda directa por clave
                mostrar(documento, padron[documento])
            else:
                print("   No hay ninguna persona con ese documento")
        elif opcion == "2":
            apellido = input("Apellido: ").upper()
            encontrados = {d: p for d, p in padron.items() if p["apellido"] == apellido}
            for documento, persona in encontrados.items():
                mostrar(documento, persona)
            print(f"   {len(encontrados)} persona(s) con apellido {apellido}")
        elif opcion == "3":
            promedio = sum(p["edad"] for p in padron.values()) / len(padron)
            print(f"   Promedio de edades: {promedio:.2f}")


if __name__ == "__main__":
    main()
