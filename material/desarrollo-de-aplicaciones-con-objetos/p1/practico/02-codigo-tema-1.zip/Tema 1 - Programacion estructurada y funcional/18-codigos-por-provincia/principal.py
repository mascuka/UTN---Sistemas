NOMBRES = {"X": "Córdoba", "H": "Chubut", "K": "Catamarca"}


def main():
    cantidad = {}                                   # diccionario de contadores: provincia -> cantidad
    with open("cp.csv", encoding="utf-8") as archivo:
        for linea in archivo:
            if linea.strip():
                provincia = linea.split(";")[0]
                cantidad[provincia] = cantidad.get(provincia, 0) + 1    # .get: sirve aunque la provincia sea nueva
    for provincia, cant in sorted(cantidad.items()):
        print(f"Códigos de {NOMBRES.get(provincia, provincia)}: {cant}")


if __name__ == "__main__":
    main()
