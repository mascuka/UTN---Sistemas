TIPOS = {1: "Nafta Super", 2: "Nafta Especial", 3: "Gas Oil"}
SURTIDORES = 10


def ingresar_entero(mensaje, minimo, maximo=None):
    """Pide un entero hasta que esté en el rango [minimo, maximo]."""
    valor = int(input(mensaje))
    while valor < minimo or (maximo is not None and valor > maximo):
        print("Valor inválido")
        valor = int(input(mensaje))
    return valor


def main():
    litros_por_tipo = {1: 0, 2: 0, 3: 0}
    menor_litros = None
    surtidor_menor = None
    total = 0

    for _ in range(SURTIDORES):
        numero = ingresar_entero("Número de surtidor (1 a 30): ", 1, 30)
        litros = ingresar_entero("Litros vendidos: ", 0)
        tipo = ingresar_entero("Tipo de combustible (1 a 3): ", 1, 3)
        litros_por_tipo[tipo] += litros
        total += litros
        if menor_litros is None or litros < menor_litros:      # "is None": un surtidor con 0 litros también cuenta
            menor_litros, surtidor_menor = litros, numero

    for tipo, nombre in TIPOS.items():
        print(f"Litros de {nombre}: {litros_por_tipo[tipo]}")
    print(f"Surtidor que menos vendió: {surtidor_menor} ({menor_litros} litros)")
    print(f"Promedio por surtidor: {total / SURTIDORES:.2f} litros")


if __name__ == "__main__":
    main()
