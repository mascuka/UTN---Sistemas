import random

random.seed(3)       # para que la salida sea siempre la misma (sacarlo para que cambie)
LADO = 400           # el plano va de 0 a 400 en x y en y

# Cada movimiento es una función que recibe la posición y devuelve la nueva
movimientos = {
    "N": lambda x, y: (x, y + 10),
    "S": lambda x, y: (x, y - 20),
    "E": lambda x, y: (x + 10, y),
    "O": lambda x, y: (x - 20, y),        # al oeste x disminuye (en la de la cátedra sumaba)
}


def dentro_del_plano(x, y):
    """Si un movimiento lo saca del plano, queda en el borde."""
    return min(max(x, 0), LADO), min(max(y, 0), LADO)


def main():
    x, y = random.randint(0, LADO), random.randint(0, LADO)
    print(f"Posición inicial: ({x}, {y})")
    print("N- Norte (10) · S- Sur (20) · E- Este (10) · O- Oeste (20) · F- Finalizar")
    orden = input("Movimientos: ").upper()
    while orden != "F":
        for letra in orden:                         # acepta varios movimientos juntos, ej. "NNEO"
            if letra in movimientos:
                x, y = dentro_del_plano(*movimientos[letra](x, y))
                print(f"   {letra} -> ({x}, {y})")
        orden = input("Movimientos: ").upper()
    print("Gracias")


if __name__ == "__main__":
    main()
