from validacion import ingresar_numero_entre

FIN = 50


def cargar_temperaturas():
    temperaturas = []
    print("Temperaturas entre -20 y 49 (50 para terminar)")
    t = ingresar_numero_entre("Temperatura: ", -20, FIN)
    while t != FIN:
        temperaturas.append(t)
        t = ingresar_numero_entre("Temperatura: ", -20, FIN)
    return temperaturas


def promedio(lista):
    return sum(lista) / len(lista) if lista else 0


def main():
    temps = cargar_temperaturas()
    if not temps:
        print("No se cargaron temperaturas")
        return
    prom = promedio(temps)
    calidos = [t for t in temps if t > 20]
    no_calidos = [t for t in temps if t <= 20]

    print("Días bajo cero:", len([t for t in temps if t < 0]))
    print(f"Promedio: {prom:.2f}")
    print(f"Promedio de los días cálidos: {promedio(calidos):.2f}" if calidos else "No hubo días cálidos")
    print("¿Hubo días de más de 40 grados?", "Sí" if any(t > 40 for t in temps) else "No")
    # "is not None"/lista vacía: si la mayor no cálida es 0 grados también hay que mostrarla
    print(f"Mayor de los días no cálidos: {max(no_calidos)}" if no_calidos else "Todos los días fueron cálidos")
    print("Días por debajo del promedio:", len([t for t in temps if t < prom]))


if __name__ == "__main__":
    main()
