def leer_numeros(nombre_archivo):
    """Un número entero por línea -> conjunto (los repetidos quedan una sola vez)."""
    with open(nombre_archivo, encoding="utf-8") as archivo:
        return {int(linea) for linea in archivo if linea.strip()}


def main():
    numeros = leer_numeros("numeros.txt")
    pares = [n for n in numeros if n % 2 == 0]
    print("Cantidad de números no repetidos:", len(numeros))
    print("Suma de todos los números:", sum(numeros))
    print("Cantidad de impares:", len([n for n in numeros if n % 2 != 0]))
    print(f"Promedio de los pares: {sum(pares) / len(pares):.2f}" if pares else "No hay pares")


if __name__ == "__main__":
    main()
