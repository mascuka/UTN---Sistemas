from functools import reduce

palabras = ["Aruba", "Jamaica", "Bermuda", "Bahama", "Key Largo", "Montigo"]

print("Iniciales:", list(map(lambda p: p[0], palabras)))
longitudes = list(map(len, palabras))
print("Longitudes:", longitudes)
print("Total de letras:", reduce(lambda a, b: a + b, longitudes))
print("Total sin contar espacios:", reduce(lambda a, p: a + len(p.replace(" ", "")), palabras, 0))
