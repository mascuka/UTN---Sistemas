def palabras_unicas(cadena):
    """Conjunto con las palabras de la cadena, sin repetir."""
    return set(cadena.lower().split())


def palabras_comunes(texto1, texto2):
    """Palabras que aparecen en los dos textos (intersección)."""
    return palabras_unicas(texto1) & palabras_unicas(texto2)


def elementos_unicos(lista1, lista2):
    """Elementos que están en una sola de las dos listas (diferencia simétrica)."""
    return set(lista1) ^ set(lista2)


def main():
    print(palabras_unicas("el perro y el gato y el loro"))
    print(palabras_comunes("me gusta programar en Python", "en Python todo es un objeto"))
    print(elementos_unicos([1, 2, 3, 4, 5], [4, 5, 6, 7]))


if __name__ == "__main__":
    main()
