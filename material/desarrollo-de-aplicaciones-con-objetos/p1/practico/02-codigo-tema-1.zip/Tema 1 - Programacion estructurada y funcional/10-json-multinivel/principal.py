import json


def main():
    with open("resultset.json", encoding="utf-8") as archivo:
        datos = json.load(archivo)                     # diccionarios y listas anidados

    print("Todo el contenido:")
    print(json.dumps(datos, indent=2, ensure_ascii=False))
    print("\nLa rama ResultSet tiene las claves:", list(datos["ResultSet"].keys()))
    segundo = datos["ResultSet"]["Result"][1]          # las listas empiezan en 0
    print("FileSize del segundo resultado:", segundo["FileSize"])
    print("Url del Thumbnail de ese resultado:", segundo["Thumbnail"]["Url"])


if __name__ == "__main__":
    main()
