def main():
    apellido = input("Apellido a buscar: ").upper()        # el archivo está en mayúsculas
    encontrados = 0
    with open("personas.csv", encoding="utf-8") as archivo:
        for linea in archivo:                               # se procesa línea por línea, sin guardar nada
            documento, nombre, ape, edad = linea.strip().split(",")
            if ape == apellido:
                print(f"   {nombre}: {edad} años")
                encontrados += 1
    print(f"{encontrados} persona(s) con apellido {apellido}")


if __name__ == "__main__":
    main()
