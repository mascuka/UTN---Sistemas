import csv

DIAS = {"Juev": "jueves", "Vie": "viernes", "Sab": "sábado", "Dom": "domingo"}


def main():
    por_sexo = {"Hombre": 0.0, "Mujer": 0.0}
    por_dia = {dia: 0.0 for dia in DIAS}
    total_propinas, cantidad = 0.0, 0
    mayor = None                                   # la fila con la orden más grande

    with open("tips.csv", encoding="utf-8") as archivo:
        for fila in csv.DictReader(archivo):       # la primera línea tiene los títulos
            propina = float(fila["tip"])
            por_sexo[fila["sex"]] += propina
            por_dia[fila["day"]] += propina
            total_propinas += propina
            cantidad += 1
            if mayor is None or float(fila["total_bill"]) > float(mayor["total_bill"]):
                mayor = fila

    print(f"Propinas de hombres: {por_sexo['Hombre']:.2f} · de mujeres: {por_sexo['Mujer']:.2f}")
    print("Pagan más propinas:", "los hombres" if por_sexo["Hombre"] > por_sexo["Mujer"] else "las mujeres")
    lento = min(por_dia, key=por_dia.get)
    print(f"Día más lento: {DIAS[lento]} ({por_dia[lento]:.2f} de propinas)")
    print(f"Propina promedio: {total_propinas / cantidad:.2f}")
    print(f"Orden más grande: {mayor['total_bill']} el {DIAS[mayor['day']]}, turno {mayor['time'].lower()}")


if __name__ == "__main__":
    main()
