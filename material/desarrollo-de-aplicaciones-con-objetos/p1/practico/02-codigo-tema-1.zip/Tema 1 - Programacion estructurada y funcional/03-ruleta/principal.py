import random

random.seed(2026)        # para que la salida sea siempre la misma (sacarlo para que cambie)
TIRADAS = 1000


def reducir(numero):
    """Suma los dígitos hasta que quede uno solo (ej.: 29 -> 11 -> 2)."""
    while numero >= 10:
        numero = sum(int(d) for d in str(numero))
    return numero


def color(numero):
    """V (verde) el 0; N (negro) el 10, el 28 y los que se reducen a par; R (rojo) el resto."""
    if numero == 0:
        return "V"
    if numero in (10, 28) or reducir(numero) % 2 == 0:
        return "N"
    return "R"


def main():
    tiradas = [random.randint(0, 36) for _ in range(TIRADAS)]
    sin_cero = [t for t in tiradas if t != 0]            # el 0 no es par, ni impar, ni de ninguna docena
    pares = len([t for t in sin_cero if t % 2 == 0])
    docenas = [0, 0, 0]
    for t in sin_cero:
        docenas[(t - 1) // 12] += 1                      # 1-12 -> 0, 13-24 -> 1, 25-36 -> 2
    colores = [color(t) for t in tiradas]

    print(f"Pares: {pares} · Impares: {len(sin_cero) - pares}")
    for i, cantidad in enumerate(docenas):
        print(f"{i + 1}ª docena ({i * 12 + 1} a {i * 12 + 12}): {cantidad}")
    print(f"Ceros: {tiradas.count(0) / TIRADAS * 100:.1f} % de las tiradas")
    print(f"Rojos: {colores.count('R')} · Negros: {colores.count('N')}")


if __name__ == "__main__":
    main()
