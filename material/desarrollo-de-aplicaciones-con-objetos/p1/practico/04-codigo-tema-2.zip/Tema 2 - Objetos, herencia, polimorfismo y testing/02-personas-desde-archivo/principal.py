from persona import Persona

VOCALES = "AEIOUÁÉÍÓÚ"


def leer_personas(nombre_archivo):
    """Devuelve un diccionario {documento: Persona} con todas las líneas del archivo."""
    personas = {}
    with open(nombre_archivo, encoding="utf-8") as archivo:
        for linea in archivo:
            linea = linea.strip()
            if linea:
                documento, nombre, apellido, edad = linea.split(",")
                personas[int(documento)] = Persona(int(documento), nombre, apellido, int(edad))
    return personas


def main():
    personas = leer_personas("personas.csv")

    print("Cantidad de personas cargadas:", len(personas))

    mayores = len([p for p in personas.values() if p.edad >= 18])
    print("Cantidad de mayores de edad:", mayores)

    print("Apellido que empieza con vocal:")
    for p in personas.values():
        if p.apellido[0] in VOCALES:
            print(f"   {p.nombre} {p.apellido}")

    por_apellido = {}
    for p in personas.values():
        por_apellido[p.apellido] = por_apellido.get(p.apellido, 0) + 1
    print("Cantidad de personas por apellido:")
    for apellido in sorted(por_apellido):
        print(f"   {apellido}: {por_apellido[apellido]}")


if __name__ == "__main__":
    main()
