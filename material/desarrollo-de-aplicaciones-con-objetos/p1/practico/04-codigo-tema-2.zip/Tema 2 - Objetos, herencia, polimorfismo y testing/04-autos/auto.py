class Auto:
    KM_POR_LITRO = 11
    CAPACIDAD = 49          # litros del tanque
    RESERVA = 5             # litros de reserva

    def __init__(self, combustible=0):
        self._combustible = min(combustible, self.CAPACIDAD + self.RESERVA)

    @property
    def combustible(self):
        return self._combustible

    def conducir(self, km):
        """Si alcanza el combustible, lo descuenta y devuelve True; si no, devuelve False."""
        litros = km / self.KM_POR_LITRO
        if litros > self._combustible:
            return False
        self._combustible -= litros
        return True

    def cargar_combustible(self, litros):
        """Carga hasta llenar tanque + reserva y devuelve los litros derramados (0 si no sobró)."""
        lugar = self.CAPACIDAD + self.RESERVA - self._combustible
        cargados = min(litros, lugar)
        self._combustible += cargados
        return litros - cargados

    def __str__(self):
        return f"Auto con {self._combustible:.2f} litros"
