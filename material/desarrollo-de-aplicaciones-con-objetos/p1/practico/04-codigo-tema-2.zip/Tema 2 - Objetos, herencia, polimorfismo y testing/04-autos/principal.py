from auto import Auto


def main():
    auto = Auto()
    print(auto)

    derramados = auto.cargar_combustible(40)
    print(f"Carga 40 litros -> derramados: {derramados}. {auto}")

    for km in (300, 200):
        if auto.conducir(km):
            print(f"Recorre {km} km. {auto}")
        else:
            print(f"No hay combustible suficiente para {km} km. {auto}")

    derramados = auto.cargar_combustible(60)
    print(f"Carga 60 litros -> derramados: {derramados:.2f}. {auto}")


if __name__ == "__main__":
    main()
