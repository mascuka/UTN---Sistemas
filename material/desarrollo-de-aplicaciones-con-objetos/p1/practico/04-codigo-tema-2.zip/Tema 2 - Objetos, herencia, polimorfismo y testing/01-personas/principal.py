from persona import Persona


def main():
    menor = None          # solo se recuerda la de menor edad: no se guardan en una estructura
    documento = int(input("Documento (0 para terminar): "))
    while documento != 0:
        nombre = input("Nombre: ")
        apellido = input("Apellido: ")
        edad = int(input("Edad: "))
        persona = Persona(documento, nombre, apellido, edad)
        print("Cargada:", persona)
        if menor is None or persona.edad < menor.edad:
            menor = persona
        documento = int(input("Documento (0 para terminar): "))

    if menor is None:
        print("No se cargó ninguna persona")
    else:
        print("La persona de menor edad es:", menor)


if __name__ == "__main__":
    main()
