from hospital import Hospital
from medica import Medica
from farmacia import Farmacia
from paciente import Paciente
from atencion import EFECTIVO, TARJETA


def main():
    h = Hospital("Hospital Privado")
    h.add_atencion(Medica(1, EFECTIVO, Paciente("Juan", 3, False), 10000))
    h.add_atencion(Medica(2, TARJETA, Paciente("Ana", 1, True), 10000))
    h.add_atencion(Farmacia(3, EFECTIVO, 8000, 1000))
    h.add_atencion(Farmacia(4, TARJETA, 5000))
    h.add_atencion(Medica(5, EFECTIVO, Paciente("Luis", 2, True), 20000))

    for a in h.atenciones:
        print(a)
    print(f"\nTotal de consultas médicas: ${h.importe_total_atencion_consulta():,.2f}")
    print(f"Promedio de las médicas que cobran entre $5.000 y $10.000: ${h.importe_promedio_atenciones(5000, 10000):,.2f}")
    print("Primera atención médica de un paciente habitual:", h.codigo_primera_atencion_habitual())


if __name__ == "__main__":
    main()
