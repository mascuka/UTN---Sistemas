from atencion import Atencion, TARJETA


class Medica(Atencion):
    def __init__(self, codigo, tipo_cobro, paciente, importe):
        super().__init__(codigo, tipo_cobro)
        self.paciente = paciente
        self.importe = importe                  # importe de la consulta

    def importe_a_cobrar(self):
        importe = self.importe
        if self.paciente.habitual:
            importe *= 0.75                     # 25 % de descuento
        return importe * (1.20 if self.tipo_cobro == TARJETA else 0.90)
