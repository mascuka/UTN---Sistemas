from abc import ABC, abstractmethod

EFECTIVO, TARJETA = 1, 2


class Atencion(ABC):
    def __init__(self, codigo, tipo_cobro):
        self.codigo = codigo
        self.tipo_cobro = tipo_cobro            # 1: efectivo, 2: tarjeta de crédito

    @abstractmethod
    def importe_a_cobrar(self):
        """Cada tipo de atención calcula su importe."""

    def __str__(self):
        cobro = "efectivo" if self.tipo_cobro == EFECTIVO else "tarjeta"
        return f"{type(self).__name__} {self.codigo} ({cobro}) -> ${self.importe_a_cobrar():,.2f}"
