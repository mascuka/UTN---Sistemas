from atencion import Atencion, TARJETA


class Farmacia(Atencion):
    def __init__(self, codigo, tipo_cobro, importe_medicamentos, cupon_descuento=0):
        super().__init__(codigo, tipo_cobro)
        if cupon_descuento < 0:
            raise ValueError("El cupón de descuento debe ser 0 o positivo")
        self.importe_medicamentos = importe_medicamentos
        self.cupon_descuento = cupon_descuento

    def importe_a_cobrar(self):
        importe = self.importe_medicamentos - self.cupon_descuento
        return importe * (1.30 if self.tipo_cobro == TARJETA else 0.95)   # faltaba el return
