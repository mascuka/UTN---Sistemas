from medica import Medica


class Hospital:
    def __init__(self, razon_social):
        self.razon_social = razon_social
        self.atenciones = []

    def add_atencion(self, atencion):
        self.atenciones.append(atencion)

    def _medicas(self):
        return [a for a in self.atenciones if isinstance(a, Medica)]

    def importe_total_atencion_consulta(self):
        return sum(a.importe for a in self._medicas())

    def importe_promedio_atenciones(self, desde, hasta):
        importes = [a.importe_a_cobrar() for a in self._medicas() if desde < a.importe_a_cobrar() < hasta]
        return sum(importes) / len(importes) if importes else 0

    def codigo_primera_atencion_habitual(self):
        for a in self._medicas():
            if a.paciente.habitual:
                return a.codigo
        return 0
