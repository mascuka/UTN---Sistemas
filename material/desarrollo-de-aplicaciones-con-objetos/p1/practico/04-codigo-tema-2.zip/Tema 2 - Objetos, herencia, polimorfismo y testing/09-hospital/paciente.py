SINTOMAS = {1: "corazón", 2: "pulmón", 3: "otras"}


class Paciente:
    def __init__(self, nombre, sintoma, habitual):
        self.nombre = nombre
        self.sintoma = sintoma                  # 1, 2 o 3
        self.habitual = habitual                # True / False

    def __str__(self):
        return f"{self.nombre} ({SINTOMAS[self.sintoma]}{', habitual' if self.habitual else ''})"
