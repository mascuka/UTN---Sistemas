class Equipo:
    def __init__(self, nombre):
        self.nombre = nombre
        self.jugados = 0
        self.de_local = 0
        self.de_visitante = 0
        self.goles_a_favor = 0
        self.goles_en_contra = 0
        self.ganados = 0
        self.empatados = 0
        self.perdidos = 0

    @property
    def diferencia_goles(self):          # calculado, no almacenado
        return self.goles_a_favor - self.goles_en_contra

    @property
    def puntos(self):                    # 3 por partido ganado, 1 por empate
        return self.ganados * 3 + self.empatados

    def registrar_partido(self, partido):
        if self is partido.local:
            self.de_local += 1
            a_favor, en_contra = partido.goles_local, partido.goles_visitante
        elif self is partido.visitante:
            self.de_visitante += 1
            a_favor, en_contra = partido.goles_visitante, partido.goles_local
        else:
            raise ValueError(f"{self.nombre} no jugó ese partido")
        self.jugados += 1
        self.goles_a_favor += a_favor
        self.goles_en_contra += en_contra
        ganador = partido.ganador()
        if ganador is None:
            self.empatados += 1
        elif ganador is self:
            self.ganados += 1
        else:
            self.perdidos += 1

    def __str__(self):
        return (f"{self.nombre}: PJ {self.jugados} (L {self.de_local} / V {self.de_visitante}) · "
                f"G {self.ganados} E {self.empatados} P {self.perdidos} · "
                f"GF {self.goles_a_favor} GC {self.goles_en_contra} Dif {self.diferencia_goles:+d} · {self.puntos} pts")
