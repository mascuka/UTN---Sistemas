from equipo import Equipo
from partido import Partido


def main():
    belgrano, talleres, instituto = Equipo("Belgrano"), Equipo("Talleres"), Equipo("Instituto")
    partidos = [
        Partido(belgrano, talleres, 2, 1),
        Partido(talleres, instituto, 0, 0),
        Partido(instituto, belgrano, 3, 1),
        Partido(talleres, belgrano, 2, 2),
    ]
    for p in partidos:
        print(p)
        p.local.registrar_partido(p)
        p.visitante.registrar_partido(p)

    print("\nTabla:")
    for e in sorted([belgrano, talleres, instituto], key=lambda e: (e.puntos, e.diferencia_goles), reverse=True):
        print("  ", e)


if __name__ == "__main__":
    main()
