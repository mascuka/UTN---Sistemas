class Partido:
    def __init__(self, local, visitante, goles_local, goles_visitante):
        self.local = local              # referencias a dos objetos Equipo
        self.visitante = visitante
        self.goles_local = goles_local
        self.goles_visitante = goles_visitante

    def ganador(self):
        """Devuelve el equipo ganador, o None si fue empate."""
        if self.goles_local > self.goles_visitante:
            return self.local
        if self.goles_visitante > self.goles_local:
            return self.visitante
        return None

    def __str__(self):
        g = self.ganador()
        resultado = f"ganó {g.nombre}" if g else "empate"
        return f"{self.local.nombre} {self.goles_local} - {self.goles_visitante} {self.visitante.nombre} ({resultado})"
