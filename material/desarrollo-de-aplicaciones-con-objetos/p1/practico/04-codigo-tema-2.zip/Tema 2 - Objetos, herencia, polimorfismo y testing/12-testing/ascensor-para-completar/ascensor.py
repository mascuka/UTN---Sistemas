class Ascensor:
    pass