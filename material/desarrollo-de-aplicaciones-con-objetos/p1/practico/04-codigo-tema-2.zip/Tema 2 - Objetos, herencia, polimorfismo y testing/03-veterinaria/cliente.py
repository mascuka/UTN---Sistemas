class Cliente:
    def __init__(self, numero, nombre, antiguedad, mascota):
        self._numero = numero
        self._nombre = nombre
        self._antiguedad = antiguedad
        self._mascota = mascota        # composición: el cliente TIENE UNA mascota

    @property
    def numero(self):
        return self._numero

    @property
    def nombre(self):
        return self._nombre

    @property
    def antiguedad(self):
        return self._antiguedad

    @antiguedad.setter
    def antiguedad(self, valor):
        self._antiguedad = valor       # en la solución de la cátedra este setter pisaba el número

    @property
    def mascota(self):
        return self._mascota

    def __str__(self):
        return f"Cliente {self._numero}: {self._nombre} - {self._antiguedad} años de cliente - Mascota: {self._mascota}"
