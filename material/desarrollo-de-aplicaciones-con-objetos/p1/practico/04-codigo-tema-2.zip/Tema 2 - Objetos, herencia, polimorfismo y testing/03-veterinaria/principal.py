from cliente import Cliente
from mascota import Mascota


def main():
    clientes = []
    numero = int(input("Número de cliente (0 para terminar): "))
    while numero != 0:
        nombre = input("Nombre del cliente: ")
        antiguedad = int(input("Antigüedad (años): "))
        nombre_mascota = input("Nombre de la mascota: ")
        edad_mascota = int(input("Edad de la mascota: "))
        clientes.append(Cliente(numero, nombre, antiguedad, Mascota(nombre_mascota, edad_mascota)))
        numero = int(input("Número de cliente (0 para terminar): "))

    if not clientes:
        print("No se cargó ningún cliente")
        return

    print("\nCantidad de clientes:", len(clientes))
    promedio = sum(c.mascota.edad for c in clientes) / len(clientes)
    print(f"Promedio de edad de las mascotas: {promedio:.2f}")
    antiguos = len([c for c in clientes if c.antiguedad >= 5])     # "mayor o igual a 5"
    print("Clientes con 5 años o más de antigüedad:", antiguos)
    print("Clientes cuya mascota tiene más de 5 años:")
    for c in clientes:
        if c.mascota.edad > 5:
            print("  ", c)


if __name__ == "__main__":
    main()
