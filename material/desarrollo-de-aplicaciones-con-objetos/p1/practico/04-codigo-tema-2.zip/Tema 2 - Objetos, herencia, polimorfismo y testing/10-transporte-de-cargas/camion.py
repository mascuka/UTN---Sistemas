DISPONIBLE, EN_REPARACION, EN_VIAJE = "DISPONIBLE", "EN REPARACIÓN", "EN VIAJE"


class Camion:
    def __init__(self, patente, carga_maxima):
        self.patente = patente
        self.carga_maxima = carga_maxima      # kg
        self.estado = DISPONIBLE
        self._cargas = []                      # composición: el camión tiene cero o más cargas

    @property
    def cantidad_cargas(self):
        return len(self._cargas)

    @property
    def peso_cargas(self):
        return sum(c.peso() for c in self._cargas)    # polimorfismo: cada carga sabe su peso

    def subir_carga(self, carga):
        if self.estado != DISPONIBLE:
            raise ValueError(f"No se puede cargar: el camión está {self.estado}")
        if self.peso_cargas + carga.peso() > self.carga_maxima:
            raise ValueError(f"No entra {carga}: quedan {self.carga_maxima - self.peso_cargas:.2f} kg libres")
        self._cargas.append(carga)

    def bajar_carga(self, carga):
        if self.estado != DISPONIBLE:
            raise ValueError(f"No se puede descargar: el camión está {self.estado}")
        if carga not in self._cargas:
            raise ValueError("Esa carga no está en el camión")
        self._cargas.remove(carga)

    def listo_para_partir(self):
        return self.estado == DISPONIBLE and self.peso_cargas >= 0.75 * self.carga_maxima

    # Cambios de estado
    def entrar_a_reparacion(self):
        self._cambiar(DISPONIBLE, EN_REPARACION)

    def salir_de_reparacion(self):
        self._cambiar(EN_REPARACION, DISPONIBLE)

    def salir_de_viaje(self):
        self._cambiar(DISPONIBLE, EN_VIAJE)

    def volver_de_viaje(self):
        self._cambiar(EN_VIAJE, DISPONIBLE)

    def _cambiar(self, desde, hasta):
        if self.estado != desde:
            raise ValueError(f"El camión está {self.estado}: no puede pasar a {hasta}")
        self.estado = hasta

    def listado_cargas(self):
        lineas = [f"Camión {self.patente} · {self.estado} · {self.cantidad_cargas} cargas · "
                  f"{self.peso_cargas:.2f} de {self.carga_maxima} kg"]
        lineas += [f"   {c}" for c in self._cargas]
        return "\n".join(lineas)
