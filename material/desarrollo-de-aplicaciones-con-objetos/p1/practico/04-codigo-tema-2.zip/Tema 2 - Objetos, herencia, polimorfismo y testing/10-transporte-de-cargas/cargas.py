from abc import ABC, abstractmethod


class Carga(ABC):
    def __init__(self, contenido):
        self.contenido = contenido

    @abstractmethod
    def peso(self):
        """Peso en kg: cada tipo de carga lo calcula distinto."""

    def __str__(self):
        return f"{type(self).__name__}: {self.contenido} ({self.peso():.2f} kg)"


class Caja(Carga):
    def __init__(self, contenido, peso):
        super().__init__(contenido)
        self._peso = peso

    def peso(self):
        return self._peso


class Packing(Carga):
    def __init__(self, contenido, peso_caja, cantidad, peso_estructura):
        super().__init__(contenido)
        self.peso_caja = peso_caja
        self.cantidad = cantidad
        self.peso_estructura = peso_estructura

    def peso(self):
        return self.peso_caja * self.cantidad + self.peso_estructura


class Bidon(Carga):
    def __init__(self, contenido, capacidad, densidad):
        super().__init__(contenido)
        self.capacidad = capacidad          # litros (siempre lleno)
        self.densidad = densidad            # kg por litro

    def peso(self):
        return self.capacidad * self.densidad
