import csv
from cargas import Caja, Packing, Bidon
from camion import Camion


def leer_cargas():
    """Lee las tres planillas y devuelve todas las cargas (en el orden de los archivos)."""
    cargas = []
    with open("Cajas.csv", encoding="utf-8") as f:
        for fila in csv.DictReader(f):
            cargas.append(Caja(fila["producto"], float(fila["peso"])))
    with open("Packing.csv", encoding="utf-8") as f:
        for fila in csv.DictReader(f):
            cargas.append(Packing(fila["producto"], float(fila["peso"]), int(fila["cantidad"]), float(fila["estructura"])))
    with open("Bidones.csv", encoding="utf-8") as f:
        for fila in csv.DictReader(f):
            cargas.append(Bidon(fila["producto"], float(fila["capacidad"]), float(fila["densidad"])))
    return cargas


def main():
    camion = Camion("KMS851", 200)
    subidas, rechazadas = [], []
    for carga in leer_cargas():
        try:
            camion.subir_carga(carga)
            subidas.append(carga)
        except ValueError as e:          # el camión no deja pasarse del peso máximo
            rechazadas.append(e)
    print(f"Subieron {len(subidas)} cargas y no entraron {len(rechazadas)}. Por ejemplo:")
    print("  ", rechazadas[0])

    print(camion.listado_cargas())
    print("¿Listo para partir?", "Sí" if camion.listo_para_partir() else "No")

    camion.salir_de_viaje()
    try:
        camion.bajar_carga(subidas[0])
    except ValueError as e:
        print("Intento de bajar una carga en viaje ->", e)
    camion.volver_de_viaje()
    print("Volvió:", camion.estado)


if __name__ == "__main__":
    main()
