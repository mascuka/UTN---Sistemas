from empresa import Empresa


def main():
    empresa = Empresa()
    empresa.leer_archivo("empleados.csv")
    print("Empleados leídos:", empresa.cantidad_empleados())
    print(f"Total a pagar de sueldos: ${empresa.total_sueldos():,.2f}")
    obreros, administrativos, vendedores = empresa.cantidad_por_tipo()
    print(f"Obreros: {obreros} · Administrativos: {administrativos} · Vendedores: {vendedores}")

    legajo = int(input("Legajo a buscar: "))
    empleado = empresa.buscar(legajo)
    print(empleado if empleado else "No existe ningún empleado con ese legajo")


if __name__ == "__main__":
    main()
