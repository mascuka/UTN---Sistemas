from abc import ABC, abstractmethod


class Empleado(ABC):
    def __init__(self, legajo, nombre, apellido, basico):
        self.legajo = legajo
        self.nombre = nombre
        self.apellido = apellido
        self.basico = basico

    @property
    @abstractmethod
    def neto(self):
        """Sueldo a cobrar: cada tipo de empleado lo calcula distinto."""

    @property
    @abstractmethod
    def tipo(self):
        """1: obrero, 2: administrativo, 3: vendedor"""

    def __str__(self):
        return f"{self.legajo} {self.nombre} {self.apellido} ({type(self).__name__}) - cobra ${self.neto:,.2f}"
