from empleado import Empleado


class Vendedor(Empleado):
    def __init__(self, legajo, nombre, apellido, basico, ventas):
        super().__init__(legajo, nombre, apellido, basico)
        self.ventas = ventas

    @property
    def neto(self):
        return self.basico + self.ventas * 0.01

    @property
    def tipo(self):
        return 3
