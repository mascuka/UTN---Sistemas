from empleado import Empleado


class Administrativo(Empleado):
    def __init__(self, legajo, nombre, apellido, basico, presentismo):
        super().__init__(legajo, nombre, apellido, basico)
        self.presentismo = presentismo

    @property
    def neto(self):
        return self.basico * 1.13 if self.presentismo else self.basico

    @property
    def tipo(self):
        return 2
