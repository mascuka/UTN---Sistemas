from obrero import Obrero
from administrativo import Administrativo
from vendedor import Vendedor


def empleado_desde_linea(linea):
    """tipo;legajo;nombre;apellido;básico;dato del tipo"""
    tipo, legajo, nombre, apellido, basico, extra = linea.strip().split(";")
    legajo, basico = int(legajo), float(basico)
    if tipo == "1":
        return Obrero(legajo, nombre, apellido, basico, int(extra))
    if tipo == "2":
        return Administrativo(legajo, nombre, apellido, basico, extra == "true")
    return Vendedor(legajo, nombre, apellido, basico, float(extra))


class Empresa:
    def __init__(self):
        self._plantel = {}                       # legajo -> empleado

    def leer_archivo(self, nombre_archivo):
        with open(nombre_archivo, encoding="utf-8") as archivo:
            for linea in archivo:
                if linea.strip():
                    e = empleado_desde_linea(linea)
                    self._plantel[e.legajo] = e

    def cantidad_empleados(self):
        return len(self._plantel)

    def total_sueldos(self):
        return sum(e.neto for e in self._plantel.values())      # polimorfismo: cada uno su neto

    def cantidad_por_tipo(self):
        cant = [0, 0, 0]
        for e in self._plantel.values():
            cant[e.tipo - 1] += 1
        return cant

    def buscar(self, legajo):
        return self._plantel.get(legajo)
