from empleado import Empleado


class Obrero(Empleado):
    DIAS_DEL_MES = 20        # el básico corresponde a 20 días (la solución de la cátedra usaba 22)

    def __init__(self, legajo, nombre, apellido, basico, dias):
        super().__init__(legajo, nombre, apellido, basico)
        self.dias = dias

    @property
    def neto(self):
        return self.basico / self.DIAS_DEL_MES * self.dias

    @property
    def tipo(self):
        return 1
