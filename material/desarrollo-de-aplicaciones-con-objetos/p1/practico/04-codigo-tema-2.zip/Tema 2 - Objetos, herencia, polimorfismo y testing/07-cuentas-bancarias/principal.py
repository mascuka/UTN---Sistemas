from cuentas import CajaAhorro, CuentaCorriente


def cargar_cuentas():
    cuentas = []
    tipo = int(input("Tipo de cuenta (1: caja de ahorro, 2: cuenta corriente, 0: terminar): "))
    while tipo != 0:
        numero = int(input("Número: "))
        nombre = input("Titular: ")
        saldo = float(input("Saldo inicial: "))
        if tipo == 1:
            cuentas.append(CajaAhorro(numero, nombre, saldo))
        else:
            acuerdo = float(input("Acuerdo (saldo negativo máximo): "))
            cuentas.append(CuentaCorriente(numero, nombre, saldo, acuerdo))
        tipo = int(input("Tipo de cuenta (1: caja de ahorro, 2: cuenta corriente, 0: terminar): "))
    return cuentas


def buscar(cuentas, numero):
    for c in cuentas:
        if c.numero == numero:
            return c
    return None


def operar(cuentas):
    numero = int(input("Cuenta a operar (0 para terminar): "))
    while numero != 0:
        cuenta = buscar(cuentas, numero)
        if cuenta is None:
            print("No existe esa cuenta")
        else:
            operacion = input("D: depositar / E: extraer: ").upper()
            monto = float(input("Monto: "))
            if operacion == "D":
                cuenta.depositar(monto)
            elif not cuenta.extraer(monto):      # polimorfismo: cada cuenta extrae a su manera
                print("No se puede extraer: saldo insuficiente")
        numero = int(input("Cuenta a operar (0 para terminar): "))


def main():
    cuentas = cargar_cuentas()
    operar(cuentas)
    print("\nSaldos finales:")
    for c in cuentas:
        print("  ", c)


if __name__ == "__main__":
    main()
