from abc import ABC, abstractmethod


class Cuenta(ABC):
    def __init__(self, numero, nombre, saldo=0):
        self.numero = numero
        self.nombre = nombre
        self.saldo = saldo

    def depositar(self, monto):
        self.saldo += monto

    @abstractmethod
    def extraer(self, monto):
        """Cada tipo de cuenta decide si puede extraer. Devuelve True si se hizo."""

    def __str__(self):
        return f"{type(self).__name__} {self.numero} - {self.nombre} - saldo ${self.saldo:,.2f}"


class CajaAhorro(Cuenta):
    def extraer(self, monto):
        if monto > self.saldo:           # no permite quedar en negativo
            return False
        self.saldo -= monto
        return True


class CuentaCorriente(Cuenta):
    def __init__(self, numero, nombre, saldo=0, acuerdo=0):
        super().__init__(numero, nombre, saldo)
        self.acuerdo = acuerdo            # máximo saldo negativo admitido

    def extraer(self, monto):
        if self.saldo - monto < -self.acuerdo:
            return False
        self.saldo -= monto
        return True
