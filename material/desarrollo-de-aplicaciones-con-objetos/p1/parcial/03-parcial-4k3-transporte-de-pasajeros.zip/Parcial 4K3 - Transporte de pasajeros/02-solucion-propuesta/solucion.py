import csv
from abc import ABC, abstractmethod


class Viaje(ABC):
    def __init__(self, codigo, conductor, destino, pasajeros, precio_base):
        self.codigo = codigo
        self.conductor = conductor
        self.destino = destino
        self.pasajeros = pasajeros
        self.precio_base = precio_base

    @abstractmethod
    def importe_recaudado(self):
        """Cada tipo de viaje calcula su importe (polimorfismo)."""

    def __str__(self):
        return (f"{type(self).__name__} {self.codigo} a {self.destino} · {self.conductor} · "
                f"{self.pasajeros} pasajeros · ${self.importe_recaudado():,.2f}")


class ViajeUrbano(Viaje):
    def importe_recaudado(self):
        return self.pasajeros * self.precio_base


class ViajeInterurbano(Viaje):
    def importe_recaudado(self):
        return self.pasajeros * self.precio_base * 1.10      # el mismo importe + 10 %


class Empresa:
    """Guarda los viajes y responde lo que pide el enunciado (no se hace en el main)."""

    def __init__(self):
        self.viajes = []

    def agregar(self, viaje):
        self.viajes.append(viaje)

    def recaudacion_total(self):
        return sum(v.importe_recaudado() for v in self.viajes)

    def pasajeros_por_destino(self):
        conteo = {}
        for v in self.viajes:
            conteo[v.destino] = conteo.get(v.destino, 0) + v.pasajeros
        return conteo

    def viaje_con_mas_pasajeros(self):
        return max(self.viajes, key=lambda v: v.pasajeros, default=None)


def leer_viajes(nombre_archivo, empresa):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        for fila in csv.DictReader(archivo):                 # la primera línea son los títulos
            clase = ViajeUrbano if fila["tipo"] == "1" else ViajeInterurbano   # el tipo solo elige la clase
            empresa.agregar(clase(int(fila["codigo"]), fila["conductor"], fila["destino"],
                                  int(fila["pasajeros"]), float(fila["precio_base"])))


def main():
    empresa = Empresa()
    leer_viajes("viajes.csv", empresa)
    print("Viajes leídos:", len(empresa.viajes))
    print(f"Recaudación total: ${empresa.recaudacion_total():,.2f}")
    print("Pasajeros por destino:")
    for destino, cantidad in sorted(empresa.pasajeros_por_destino().items()):
        print(f"   {destino}: {cantidad}")
    print("Viaje con más pasajeros:", empresa.viaje_con_mas_pasajeros())


if __name__ == "__main__":
    main()
