# Imports
from Carga import Carga
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Packing"]


class Packing(Carga):
    def __init__(
        self,
        contenido: str,
        peso_por_caja: float,
        cantidad: int,
        peso_estructura: float,
    ) -> None:
        super().__init__(contenido)
        self._peso_por_caja: float = Validador.esFlotantePositivo(peso_por_caja)
        self._cantidad: int = Validador.esEnteroPositivo(cantidad)
        self._peso_estructura: float = Validador.esFlotantePositivo(peso_estructura)

    @property
    def peso_por_caja(self) -> float:
        return self._peso_por_caja

    @peso_por_caja.setter
    def peso_por_caja(self, peso_por_caja: float) -> None:
        self._peso_por_caja = Validador.esFlotantePositivo(peso_por_caja)

    @property
    def cantidad(self) -> int:
        return self._cantidad

    @cantidad.setter
    def cantidad(self, cantidad: int) -> None:
        self._cantidad = Validador.esEnteroPositivo(cantidad)

    @property
    def peso_estructura(self) -> float:
        return self._peso_estructura

    @peso_estructura.setter
    def peso_estructura(self, peso_estructura: float) -> None:
        self._peso_estructura = Validador.esFlotantePositivo(peso_estructura)

    def peso(self) -> float:
        return (self.peso_por_caja * self.cantidad) + self.peso_estructura

    def __str__(self) -> str:
        return (
            f"Packing de {self.contenido} - {self.cantidad} cajas de "
            f"{self.peso_por_caja:.2f} kg c/u - "
            f"Estructura: {self.peso_estructura:.2f} kg - "
            f"Peso: {self.peso():.2f} kg"
        )


if __name__ == "__main__":
    pass
