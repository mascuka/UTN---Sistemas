# Ejercicio tipo parcial

## Empresa de transporte de cargas

Una empresa de transporte de cargas necesita un software que la ayude a organizarse con la carga de los camiones que maneja. La empresa puede recibir packings, cajas sueltas y bidones que transportan líquido.

- Un packing es una estructura de madera que arriba tiene un montón de cajas; se envuelve todo con plástico para que no se desbanden las cajas. Todas las cajas tienen el mismo peso.
  - El peso de un packing es (peso de cada caja × cantidad de cajas) + peso de la estructura de madera que va abajo.
  - Para cada packing se informa qué llevan las cajas, p. ej. Material de construcción.
- De cada caja suelta se informa el peso individualmente, son todas distintas.
- El peso de un bidón es su capacidad en litros por la densidad (o sea, cuántos kg pesa un litro) del líquido que se le carga. Los bidones van siempre llenos hasta el tope.

Cada camión puede llevar hasta una carga máxima medida en kg. Además, cada camión puede: estar disponible para la carga (en cuyo caso ya puede tener cosas cargadas), estar en reparación, o estar de viaje.

Algunos requerimientos:

- Subir una carga al camión, donde la carga puede ser un packing, una caja suelta, o un bidón.
  - Considerar que no se puede saturar un camión con más peso de lo que su carga máxima permite.
- Bajar una carga del camión.
  - Siempre que el camión se encuentre disponible con cargas y que a su vez la carga se encuentre presente dentro de él.
- Conocer el total de cargas de un camión en todo momento y su peso.
- Permitir modificar el estado de un camión, sea porque:
  - Entró en reparación,
  - Salió de reparación,
  - Está en viaje, o
  - De regreso.
- Obtener el listado de cargas contenidas, como string, para imprimir por pantalla.
- Saber si un camión está listo para partir, que es:
  - Si está disponible para la carga,
  - Y el peso total de lo que tiene cargado es de al menos 75% de su carga máxima.

## Importante

- Los valores de los objetos que deben ser instanciados se encuentran en la carpeta `data/`

## Modelo esperado

```mermaid
classDiagram
    class Camion {
        -patente
        -estado
        -carga_maxima
        -cargas
        +__init__()
        +__str__()
        +cantidad_cargas() int
        +subir_carga(carga: Carga)
        +bajar_carga(carga: Carga)
        +peso_cargas() float
        +a_reparacion()
        +sale_reparado()
        +en_viaje()
        +de_regreso()
        +listo_para_salir() bool
        +cargas_en_orden() str
    }
    class Carga {
        <<abstract>>
        -contenido
        +__init__()
        +__str__()
        +peso()* float
    }
    class Caja {
        -peso
        +__init__()
        +__str__()
        +peso() float
    }
    class Packing {
        -peso_por_caja
        -cantidad
        -peso_estructura
        +__init__()
        +__str__()
        +peso() float
    }
    class Bidon {
        -capacidad
        -densidad
        +__init__()
        +__str__()
        +peso() float
    }

    Camion "1" --> "0..*" Carga : Tiene cero o más
    Carga <|-- Caja : Es una
    Carga <|-- Packing : Es una
    Carga <|-- Bidon : Es una
```
