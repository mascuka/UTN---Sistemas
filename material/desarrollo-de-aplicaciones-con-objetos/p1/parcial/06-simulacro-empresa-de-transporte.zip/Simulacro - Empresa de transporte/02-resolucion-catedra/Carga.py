# Imports
from abc import ABC, abstractmethod

from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Carga"]


class Carga(ABC):
    def __init__(self, contenido: str) -> None:
        self._contenido: str = Validador.esCadenaNoVacia(contenido)

    @property
    def contenido(self) -> str:
        return self._contenido

    @contenido.setter
    def contenido(self, contenido: str) -> None:
        self._contenido = Validador.esCadenaNoVacia(contenido)

    @abstractmethod
    def peso(self) -> float:
        pass

    def __str__(self) -> str:
        return f"Carga de {self.contenido} - Peso: {self.peso():.2f} kg"


if __name__ == "__main__":
    pass
