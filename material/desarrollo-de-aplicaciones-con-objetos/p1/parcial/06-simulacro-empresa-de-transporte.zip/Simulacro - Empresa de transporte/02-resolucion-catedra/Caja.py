# Imports
from Carga import Carga
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Caja"]


class Caja(Carga):
    def __init__(self, contenido: str, peso: float) -> None:
        super().__init__(contenido)
        self._peso: float = Validador.esFlotantePositivo(peso)

    def peso(self) -> float:
        return self._peso

    def __str__(self) -> str:
        return f"Caja de {self.contenido} - Peso: {self.peso():.2f} kg"


if __name__ == "__main__":
    pass
