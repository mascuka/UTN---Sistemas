# El chequeo de carga en subir_carga es defensivo en tiempo de ejecucion
# aunque el parametro ya este tipado como Carga; por eso pyright lo marca
# como redundante.
# pyright: reportUnnecessaryIsInstance=false
# ruff: noqa: RUF012

# Imports
from Carga import Carga
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Camion"]


class Camion:
    # Estados del enunciado: 1 disponible, 2 en reparacion, 3 de viaje
    ESTADOS: dict[int, str] = {1: "disponible", 2: "en reparacion", 3: "de viaje"}
    DISPONIBLE, REPARACION, VIAJE = 1, 2, 3

    PORCENTAJE_LISTO_PARA_SALIR: float = 0.75

    def __init__(self, patente: str, carga_maxima: float) -> None:
        self._patente: str = Validador.esCadenaNoVacia(patente)
        self._carga_maxima: float = Validador.esFlotantePositivo(carga_maxima)
        self._estado: int = Camion.DISPONIBLE
        self._cargas: list[Carga] = []

    @property
    def patente(self) -> str:
        return self._patente

    @patente.setter
    def patente(self, patente: str) -> None:
        self._patente = Validador.esCadenaNoVacia(patente)

    @property
    def carga_maxima(self) -> float:
        return self._carga_maxima

    @carga_maxima.setter
    def carga_maxima(self, carga_maxima: float) -> None:
        self._carga_maxima = Validador.esFlotantePositivo(carga_maxima)

    @property
    def estado(self) -> int:
        return self._estado

    @property
    def cargas(self) -> list[Carga]:
        return self._cargas

    def cantidad_cargas(self) -> int:
        return len(self.cargas)

    def peso_cargas(self) -> float:
        return sum(carga.peso() for carga in self.cargas)

    def subir_carga(self, carga: Carga) -> None:
        if not isinstance(carga, Carga):
            raise TypeError("Error el valor ingresado no corresponde a una carga")
        if self.peso_cargas() + carga.peso() > self.carga_maxima:
            raise ValueError("Error no se puede superar la carga maxima del camion")
        self._cargas.append(carga)

    def bajar_carga(self, carga: Carga) -> None:
        if self.estado != Camion.DISPONIBLE or carga not in self.cargas:
            raise ValueError("Error no se puede bajar la carga del camion")
        self._cargas.remove(carga)

    def a_reparacion(self) -> None:
        self._estado = Camion.REPARACION

    def sale_reparado(self) -> None:
        self._estado = Camion.DISPONIBLE

    def en_viaje(self) -> None:
        self._estado = Camion.VIAJE

    def de_regreso(self) -> None:
        self._estado = Camion.DISPONIBLE

    def listo_para_salir(self) -> bool:
        return (
            self.estado == Camion.DISPONIBLE
            and self.peso_cargas()
            >= Camion.PORCENTAJE_LISTO_PARA_SALIR * self.carga_maxima
        )

    def cargas_en_orden(self) -> str:
        return "\n".join(str(carga) for carga in self.cargas)

    def __str__(self) -> str:
        return (
            f"Camion {self.patente} - Estado: {Camion.ESTADOS[self.estado]} - "
            f"Cargas: {self.cantidad_cargas()} - "
            f"Peso: {self.peso_cargas():.2f}/{self.carga_maxima:.2f} kg"
        )


if __name__ == "__main__":
    pass
