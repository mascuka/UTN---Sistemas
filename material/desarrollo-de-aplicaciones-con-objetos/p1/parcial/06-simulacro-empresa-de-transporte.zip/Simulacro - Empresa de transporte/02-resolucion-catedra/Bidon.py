# Imports
from Carga import Carga
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Bidon"]


class Bidon(Carga):
    def __init__(self, contenido: str, capacidad: float, densidad: float) -> None:
        super().__init__(contenido)
        self._capacidad: float = Validador.esFlotantePositivo(capacidad)
        self._densidad: float = Validador.esFlotantePositivo(densidad)

    @property
    def capacidad(self) -> float:
        return self._capacidad

    @capacidad.setter
    def capacidad(self, capacidad: float) -> None:
        self._capacidad = Validador.esFlotantePositivo(capacidad)

    @property
    def densidad(self) -> float:
        return self._densidad

    @densidad.setter
    def densidad(self, densidad: float) -> None:
        self._densidad = Validador.esFlotantePositivo(densidad)

    def peso(self) -> float:
        return self.capacidad * self.densidad

    def __str__(self) -> str:
        return (
            f"Bidon de {self.contenido} - Capacidad: {self.capacidad:.2f} L - "
            f"Densidad: {self.densidad:.2f} kg/L - Peso: {self.peso():.2f} kg"
        )


if __name__ == "__main__":
    pass
