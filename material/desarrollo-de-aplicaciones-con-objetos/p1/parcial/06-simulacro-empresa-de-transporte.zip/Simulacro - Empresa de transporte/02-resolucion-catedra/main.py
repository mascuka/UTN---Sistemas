"""Carga los packings, cajas y bidones desde los archivos CSV de data/."""

import csv
from pathlib import Path

from Bidon import Bidon
from Caja import Caja
from Camion import Camion
from Carga import Carga
from Packing import Packing

DIRECTORIO_DATOS: Path = Path(__file__).parent / "data"
ARCHIVO_BIDONES: Path = DIRECTORIO_DATOS / "bidones.csv"
ARCHIVO_CAJAS: Path = DIRECTORIO_DATOS / "cajas.csv"
ARCHIVO_PACKING: Path = DIRECTORIO_DATOS / "packing.csv"

CARGA_MAXIMA_CAMION: float = 200.0


def leer_csv(ruta: Path) -> list[dict[str, str]]:
    with open(ruta, newline="", encoding="utf-8") as archivo:
        return list(csv.DictReader(archivo))


def cargar_bidones(ruta: Path = ARCHIVO_BIDONES) -> list[Bidon]:
    return [
        Bidon(
            contenido=fila["producto"],
            capacidad=float(fila["capacidad"]),
            densidad=float(fila["densidad"]),
        )
        for fila in leer_csv(ruta)
    ]


def cargar_cajas(ruta: Path = ARCHIVO_CAJAS) -> list[Caja]:
    return [
        Caja(contenido=fila["producto"], peso=float(fila["peso"]))
        for fila in leer_csv(ruta)
    ]


def cargar_packings(ruta: Path = ARCHIVO_PACKING) -> list[Packing]:
    return [
        Packing(
            contenido=fila["producto"],
            peso_por_caja=float(fila["peso"]),
            cantidad=int(fila["cantidad"]),
            peso_estructura=float(fila["estructura"]),
        )
        for fila in leer_csv(ruta)
    ]


def cargar_todas_las_cargas() -> list[Carga]:
    cargas: list[Carga] = []
    cargas.extend(cargar_bidones())
    cargas.extend(cargar_cajas())
    cargas.extend(cargar_packings())
    return cargas


def crear_camiones() -> list[Camion]:
    return [
        Camion("AA001AA", CARGA_MAXIMA_CAMION),
        Camion("BB002BB", CARGA_MAXIMA_CAMION),
        Camion("CC003CC", CARGA_MAXIMA_CAMION),
    ]


def distribuir_cargas(camiones: list[Camion], cargas: list[Carga]) -> None:
    """Sube cada carga al primer camion de la lista donde todavia entre."""
    for carga in cargas:
        for camion in camiones:
            if camion.peso_cargas() + carga.peso() <= camion.carga_maxima:
                camion.subir_carga(carga)
                break


def main() -> None:
    camiones: list[Camion] = crear_camiones()
    cargas: list[Carga] = cargar_todas_las_cargas()
    distribuir_cargas(camiones, cargas)

    print(f"Cargas a distribuir: {len(cargas)}")
    print()

    for camion in camiones:
        print(camion)
        print(f"  Listo para salir: {'si' if camion.listo_para_salir() else 'no'}")
    print()

    primer_camion: Camion = camiones[0]
    print(f"Detalle de cargas de {primer_camion.patente}:")
    print(primer_camion.cargas_en_orden())
    print()

    if primer_camion.cargas:
        primera_carga: Carga = primer_camion.cargas[0]
        primer_camion.bajar_carga(primera_carga)
        print(
            f"Se bajo una carga de {primer_camion.patente}. "
            f"Cargas restantes: {primer_camion.cantidad_cargas()}"
        )
    print()

    primer_camion.a_reparacion()
    print(
        f"{primer_camion.patente} entro en reparacion - Estado: {primer_camion.estado}"
    )
    primer_camion.sale_reparado()
    print(
        f"{primer_camion.patente} salio de reparacion - Estado: {primer_camion.estado}"
    )

    segundo_camion: Camion = camiones[1]
    segundo_camion.en_viaje()
    print(f"{segundo_camion.patente} esta en viaje - Estado: {segundo_camion.estado}")
    segundo_camion.de_regreso()
    print(f"{segundo_camion.patente} esta de regreso - Estado: {segundo_camion.estado}")


if __name__ == "__main__":
    main()
