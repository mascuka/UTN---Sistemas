from sucursal import Sucursal


class Mini(Sucursal):
    def __init__(self, numero, superficie, facturacion, alquiler):
        super().__init__(numero, superficie, facturacion)
        self.alquiler = alquiler                # lo que paga al consorcio

    def resultado_comercial(self):
        return self.facturacion - self.alquiler

    def indice_minimo(self):
        return 35

    def tipo(self):
        return 3
