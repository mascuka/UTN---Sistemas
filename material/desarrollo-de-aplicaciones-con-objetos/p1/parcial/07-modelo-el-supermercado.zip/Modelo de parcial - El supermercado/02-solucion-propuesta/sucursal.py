from abc import ABC, abstractmethod


class Sucursal(ABC):
    def __init__(self, numero, superficie, facturacion):
        self.numero = numero
        self.superficie = superficie
        self.facturacion = facturacion

    @abstractmethod
    def resultado_comercial(self):
        """Cada formato lo calcula distinto."""

    @abstractmethod
    def indice_minimo(self):
        """El índice que tiene que superar para ser rentable."""

    @abstractmethod
    def tipo(self):
        """1: hiper, 2: super, 3: mini"""

    def indice_rentabilidad(self):
        return self.resultado_comercial() / self.superficie

    def es_rentable(self):
        return self.indice_rentabilidad() > self.indice_minimo()

    def __str__(self):
        return f"{self.numero} {self.tipo()}"          # número y tipo, como pide el test
