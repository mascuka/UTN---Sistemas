class Empresa:
    def __init__(self):
        self.sucursales = []

    def agregar_sucursal(self, sucursal):
        self.sucursales.append(sucursal)

    def suma_ganancia(self):
        return sum(s.resultado_comercial() for s in self.sucursales)

    def cantidad_no_rentables(self):
        return len([s for s in self.sucursales if not s.es_rentable()])

    def local_mas_rentable(self):
        return max(self.sucursales, key=lambda s: s.indice_rentabilidad(), default=None)
