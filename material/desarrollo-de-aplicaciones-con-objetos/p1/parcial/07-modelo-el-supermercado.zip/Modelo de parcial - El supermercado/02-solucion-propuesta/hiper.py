from sucursal import Sucursal


class Hiper(Sucursal):
    def __init__(self, numero, superficie, facturacion, alquileres):
        super().__init__(numero, superficie, facturacion)
        self.alquileres = alquileres            # lo que cobra por los boxes

    def resultado_comercial(self):
        return self.facturacion + self.alquileres

    def indice_minimo(self):
        return 50

    def tipo(self):
        return 1
