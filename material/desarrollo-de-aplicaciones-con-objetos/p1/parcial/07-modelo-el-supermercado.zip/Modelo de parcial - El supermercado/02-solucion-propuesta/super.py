from sucursal import Sucursal


class Super(Sucursal):
    def __init__(self, numero, superficie, facturacion, mayorista):
        super().__init__(numero, superficie, facturacion)
        self.mayorista = mayorista

    def resultado_comercial(self):
        return self.facturacion

    def indice_minimo(self):
        return 45 if self.mayorista else 40

    def tipo(self):
        return 2
