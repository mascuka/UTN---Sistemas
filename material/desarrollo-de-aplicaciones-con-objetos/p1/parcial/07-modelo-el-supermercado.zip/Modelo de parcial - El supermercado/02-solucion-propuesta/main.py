from empresa import Empresa
from hiper import Hiper
from mini import Mini
from super import Super

TIPOS = {1: "hiper", 2: "super", 3: "mini"}


def leer_sucursales(nombre_archivo, empresa):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        for linea in archivo:
            if not linea.strip():
                continue
            tipo, numero, superficie, facturacion, extra = linea.strip().split(",")
            numero, superficie, facturacion = int(numero), int(superficie), float(facturacion)
            if tipo == "1":
                empresa.agregar_sucursal(Hiper(numero, superficie, facturacion, float(extra)))
            elif tipo == "2":
                empresa.agregar_sucursal(Super(numero, superficie, facturacion, extra == "1"))
            else:
                empresa.agregar_sucursal(Mini(numero, superficie, facturacion, float(extra)))


def main():
    empresa = Empresa()
    leer_sucursales("sucursales.csv", empresa)
    print("Sucursales leídas:", len(empresa.sucursales))
    print(f"Suma de ganancia: {empresa.suma_ganancia():,.2f} (miles de pesos)")
    print("Locales no rentables:", empresa.cantidad_no_rentables())
    local = empresa.local_mas_rentable()
    print(f"Local más rentable: número {local.numero}, tipo {local.tipo()} ({TIPOS[local.tipo()]}), "
          f"índice {local.indice_rentabilidad():.2f}")


if __name__ == "__main__":
    main()
