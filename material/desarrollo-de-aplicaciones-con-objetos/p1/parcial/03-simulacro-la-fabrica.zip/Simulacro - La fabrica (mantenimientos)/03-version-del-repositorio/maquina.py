from correctivo import Correctivo


class Maquina:
    def __init__(self):
        self.mantenimientos = []

    def agregar_mantenimiento(self, mantenimiento):
        self.mantenimientos.append(mantenimiento)

    def suma_gastos(self):
        return sum(m.gasto_total() for m in self.mantenimientos)

    def cantidad_mantenimientos_caros(self):
        return len([m for m in self.mantenimientos if m.gasto_total() > 10000])     # más de $10.000

    def rotura_mas_larga(self):
        correctivos = [m for m in self.mantenimientos if isinstance(m, Correctivo)]
        if not correctivos:
            return None
        mayor = max(correctivos, key=lambda m: m.horas_parada)
        return f"{mayor.fecha} {mayor.operario}"
