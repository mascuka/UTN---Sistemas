from mantenimiento import Mantenimiento


class Preventivo(Mantenimiento):
    def __init__(self, fecha, operario, repuestos, resultado, insumos):
        super().__init__(fecha, operario, repuestos)
        self.resultado = resultado          # 1 funciona, 2 revisión del fabricante, 3 rotura
        self.insumos = insumos

    def gasto_total(self):
        return self.repuestos + self.insumos
