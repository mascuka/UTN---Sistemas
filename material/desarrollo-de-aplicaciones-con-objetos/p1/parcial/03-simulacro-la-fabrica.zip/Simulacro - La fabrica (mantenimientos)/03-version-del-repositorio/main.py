from correctivo import Correctivo
from maquina import Maquina
from preventivo import Preventivo


def leer_mantenimientos(nombre_archivo, maquina):
    with open(nombre_archivo, encoding="utf-8") as archivo:
        for linea in archivo:
            if not linea.strip():
                continue
            tipo, fecha, operario, repuestos, dato5, dato6 = linea.strip().split(",")
            if tipo == "1":
                maquina.agregar_mantenimiento(Preventivo(fecha, operario, float(repuestos), int(dato5), float(dato6)))
            else:
                maquina.agregar_mantenimiento(Correctivo(fecha, operario, float(repuestos), int(dato5), float(dato6)))


def main():
    maquina = Maquina()
    leer_mantenimientos("mantenimientos.csv", maquina)
    print("Mantenimientos leídos:", len(maquina.mantenimientos))
    print(f"Suma de gastos: ${maquina.suma_gastos():,.2f}")
    print("Mantenimientos caros (más de $10.000):", maquina.cantidad_mantenimientos_caros())
    print("Rotura más larga:", maquina.rotura_mas_larga())


if __name__ == "__main__":
    main()
