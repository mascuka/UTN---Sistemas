from abc import ABC, abstractmethod


class Mantenimiento(ABC):
    def __init__(self, fecha, operario, repuestos):
        self.fecha = fecha
        self.operario = operario
        self.repuestos = repuestos

    @abstractmethod
    def gasto_total(self):
        """Repuestos más lo propio de cada tipo."""

    def __str__(self):
        return f"{type(self).__name__} del {self.fecha} · {self.operario} · ${self.gasto_total():,.2f}"
