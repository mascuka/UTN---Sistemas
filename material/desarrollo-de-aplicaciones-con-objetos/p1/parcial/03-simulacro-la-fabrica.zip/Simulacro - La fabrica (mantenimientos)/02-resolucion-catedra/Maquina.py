# pyright: reportUnnecessaryIsInstance=false

# Imports
from Correctivo import Correctivo
from Mantenimiento import Mantenimiento
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Maquina"]

GASTO_CARO: float = 10000.0


class Maquina:
    def __init__(self, nombre: str) -> None:
        self._nombre: str = Validador.esCadenaNoVacia(nombre)
        self._mantenimientos: list[Mantenimiento] = []

    @property
    def nombre(self) -> str:
        return self._nombre

    @nombre.setter
    def nombre(self, nombre: str) -> None:
        self._nombre = Validador.esCadenaNoVacia(nombre)

    @property
    def mantenimientos(self) -> list[Mantenimiento]:
        return self._mantenimientos

    @mantenimientos.setter
    def mantenimientos(self, mantenimientos: list[Mantenimiento]) -> None:
        if not isinstance(mantenimientos, list) or not all(
            isinstance(mantenimiento, Mantenimiento) for mantenimiento in mantenimientos
        ):
            raise TypeError("Error debe ser una lista de mantenimientos")
        self._mantenimientos = mantenimientos

    def add_mantenimiento(self, mantenimiento: Mantenimiento) -> None:
        if not isinstance(mantenimiento, Mantenimiento):
            raise TypeError(
                "Error el valor ingresado no corresponde a un mantenimiento"
            )
        self._mantenimientos.append(mantenimiento)

    def mantenimientos_correctivos(self) -> list[Correctivo]:
        return [
            mantenimiento
            for mantenimiento in self.mantenimientos
            if isinstance(mantenimiento, Correctivo)
        ]

    def suma_gastos(self) -> float:
        """Total abonado por todo concepto en todos los mantenimientos registrados."""
        return sum(mantenimiento.gasto_total() for mantenimiento in self.mantenimientos)

    def cantidad_mantenimientos_caros(self) -> int:
        """Cantidad de mantenimientos con un gasto total mayor a $10.000."""
        return len(
            [
                mantenimiento
                for mantenimiento in self.mantenimientos
                if mantenimiento.gasto_total() > GASTO_CARO
            ]
        )

    def rotura_mas_larga(self) -> Correctivo | None:
        """Mantenimiento correctivo de mayor duracion (mas horas de parada), o None."""
        correctivos: list[Correctivo] = self.mantenimientos_correctivos()
        if not correctivos:
            return None
        return max(correctivos, key=lambda mantenimiento: mantenimiento.horas_parada)

    def __str__(self) -> str:
        cadena: str = f"Maquina: {self.nombre}\n"
        for mantenimiento in self.mantenimientos:
            cadena += f"  {mantenimiento}\n"
        return cadena


if __name__ == "__main__":
    pass
