# Imports
from abc import ABC, abstractmethod

from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Mantenimiento"]


class Mantenimiento(ABC):
    def __init__(self, operario: str, fecha: str, importe_repuestos: float) -> None:
        self._operario: str = Validador.esCadenaNoVacia(operario)
        self._fecha: str = Validador.esCadenaNoVacia(fecha)
        self._importe_repuestos: float = Validador.esFlotantePositivo(importe_repuestos)

    @property
    def operario(self) -> str:
        return self._operario

    @operario.setter
    def operario(self, operario: str) -> None:
        self._operario = Validador.esCadenaNoVacia(operario)

    @property
    def fecha(self) -> str:
        return self._fecha

    @fecha.setter
    def fecha(self, fecha: str) -> None:
        self._fecha = Validador.esCadenaNoVacia(fecha)

    @property
    def importe_repuestos(self) -> float:
        return self._importe_repuestos

    @importe_repuestos.setter
    def importe_repuestos(self, importe_repuestos: float) -> None:
        self._importe_repuestos = Validador.esFlotantePositivo(importe_repuestos)

    @abstractmethod
    def gasto_total(self) -> float:
        pass

    def __str__(self) -> str:
        return (
            f"Mantenimiento del {self.fecha} - Operario: {self.operario} - "
            f"Repuestos: ${self.importe_repuestos:.2f} - "
            f"Gasto total: ${self.gasto_total():.2f}"
        )


if __name__ == "__main__":
    pass
