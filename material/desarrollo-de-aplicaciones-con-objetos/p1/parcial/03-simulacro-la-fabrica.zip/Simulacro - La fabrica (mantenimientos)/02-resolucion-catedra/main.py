"""Carga los mantenimientos de la maquina desde el archivo CSV de data/."""

import csv
from pathlib import Path

from Correctivo import Correctivo
from Mantenimiento import Mantenimiento
from Maquina import Maquina
from Preventivo import Preventivo

DIRECTORIO_DATOS: Path = Path(__file__).parent / "data"
ARCHIVO_MANTENIMIENTOS: Path = DIRECTORIO_DATOS / "mantenimientos.csv"

PREVENTIVO = 1
CORRECTIVO = 2


def leer_csv(ruta: Path) -> list[list[str]]:
    with open(ruta, newline="", encoding="utf-8") as archivo:
        return [fila for fila in csv.reader(archivo) if fila]


def crear_mantenimiento(fila: list[str]) -> Mantenimiento:
    tipo = int(fila[0])
    fecha: str = fila[1]
    operario: str = fila[2]
    importe_repuestos = float(fila[3])

    if tipo == PREVENTIVO:
        resultado = int(fila[4])
        importe_insumos = float(fila[5])
        return Preventivo(
            operario, fecha, importe_repuestos, importe_insumos, resultado
        )

    if tipo == CORRECTIVO:
        horas_parada = int(fila[4])
        importe_tecnico = float(fila[5])
        return Correctivo(
            operario, fecha, importe_repuestos, horas_parada, importe_tecnico
        )

    raise ValueError(
        f"Error el tipo de mantenimiento debe ser {PREVENTIVO} o {CORRECTIVO}"
    )


def cargar_mantenimientos(ruta: Path = ARCHIVO_MANTENIMIENTOS) -> list[Mantenimiento]:
    return [crear_mantenimiento(fila) for fila in leer_csv(ruta)]


def cargar_maquina(nombre: str = "Maquina Manufacturera") -> Maquina:
    maquina = Maquina(nombre)
    for mantenimiento in cargar_mantenimientos():
        maquina.add_mantenimiento(mantenimiento)
    return maquina


def main() -> None:
    maquina: Maquina = cargar_maquina()
    correctivos: list[Correctivo] = maquina.mantenimientos_correctivos()

    print(f"Maquina: {maquina.nombre}")
    print(f"Mantenimientos registrados: {len(maquina.mantenimientos)}")
    print(f"  Preventivos: {len(maquina.mantenimientos) - len(correctivos)}")
    print(f"  Correctivos: {len(correctivos)}")
    print()

    print(f"Suma de gastos: ${maquina.suma_gastos():.2f}")
    print(
        f"Cantidad de mantenimientos caros: {maquina.cantidad_mantenimientos_caros()}"
    )

    rotura: Correctivo | None = maquina.rotura_mas_larga()
    if rotura is not None:
        print(
            "Rotura mas larga: "
            f"fecha {rotura.fecha} - operario {rotura.operario} - "
            f"{rotura.horas_parada} horas de parada"
        )
    else:
        print("Rotura mas larga: no hay mantenimientos correctivos registrados")
    print()

    print("Detalle de los primeros 5 mantenimientos de cada tipo:")
    for mantenimiento in maquina.mantenimientos[:5]:
        print(f"  {mantenimiento}")
    for mantenimiento in correctivos[:5]:
        print(f"  {mantenimiento}")


if __name__ == "__main__":
    main()
