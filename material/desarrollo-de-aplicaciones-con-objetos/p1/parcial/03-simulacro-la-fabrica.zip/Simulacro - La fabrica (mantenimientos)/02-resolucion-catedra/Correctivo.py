# Imports
from Mantenimiento import Mantenimiento
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Correctivo"]


class Correctivo(Mantenimiento):
    def __init__(
        self,
        operario: str,
        fecha: str,
        importe_repuestos: float,
        horas_parada: int,
        importe_tecnico: float,
    ) -> None:
        super().__init__(operario, fecha, importe_repuestos)
        self._horas_parada: int = Validador.esEnteroPositivo(horas_parada)
        self._importe_tecnico: float = Validador.esFlotantePositivo(importe_tecnico)

    @property
    def horas_parada(self) -> int:
        return self._horas_parada

    @horas_parada.setter
    def horas_parada(self, horas_parada: int) -> None:
        self._horas_parada = Validador.esEnteroPositivo(horas_parada)

    @property
    def importe_tecnico(self) -> float:
        return self._importe_tecnico

    @importe_tecnico.setter
    def importe_tecnico(self, importe_tecnico: float) -> None:
        self._importe_tecnico = Validador.esFlotantePositivo(importe_tecnico)

    def gasto_total(self) -> float:
        return self.importe_repuestos + self.importe_tecnico

    def __str__(self) -> str:
        return (
            f"Correctivo del {self.fecha} - Operario: {self.operario} - "
            f"Repuestos: ${self.importe_repuestos:.2f} - "
            f"Horas de parada: {self.horas_parada} - "
            f"Tecnico: ${self.importe_tecnico:.2f} - "
            f"Gasto total: ${self.gasto_total():.2f}"
        )


if __name__ == "__main__":
    pass
