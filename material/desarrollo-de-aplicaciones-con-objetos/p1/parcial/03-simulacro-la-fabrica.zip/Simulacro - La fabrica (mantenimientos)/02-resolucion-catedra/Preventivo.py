# ruff: noqa: RUF012

# Imports
from Mantenimiento import Mantenimiento
from utilities.Validador import Validador

# Exports
__all__: list[str] = ["Preventivo"]


class Preventivo(Mantenimiento):
    # Resultados del enunciado: 1 funciona correctamente, 2 revision recomendada, 3 rotura
    RESULTADOS: dict[int, str] = {
        1: "funciona correctamente",
        2: "revision recomendada",
        3: "rotura detectada",
    }

    def __init__(
        self,
        operario: str,
        fecha: str,
        importe_repuestos: float,
        importe_insumos: float,
        resultado: int,
    ) -> None:
        super().__init__(operario, fecha, importe_repuestos)
        self._importe_insumos: float = Validador.esFlotantePositivo(importe_insumos)
        self._resultado: int = self._validar_resultado(resultado)

    @staticmethod
    def _validar_resultado(resultado: int) -> int:
        if Validador.esEntero(resultado) not in Preventivo.RESULTADOS:
            raise ValueError("Error el resultado debe ser 1, 2 o 3")
        return resultado

    @property
    def importe_insumos(self) -> float:
        return self._importe_insumos

    @importe_insumos.setter
    def importe_insumos(self, importe_insumos: float) -> None:
        self._importe_insumos = Validador.esFlotantePositivo(importe_insumos)

    @property
    def resultado(self) -> int:
        return self._resultado

    @resultado.setter
    def resultado(self, resultado: int) -> None:
        self._resultado = self._validar_resultado(resultado)

    def gasto_total(self) -> float:
        return self.importe_repuestos + self.importe_insumos

    def __str__(self) -> str:
        return (
            f"Preventivo del {self.fecha} - Operario: {self.operario} - "
            f"Repuestos: ${self.importe_repuestos:.2f} - "
            f"Insumos: ${self.importe_insumos:.2f} - "
            f"Resultado: {self.RESULTADOS[self.resultado]} - "
            f"Gasto total: ${self.gasto_total():.2f}"
        )


if __name__ == "__main__":
    pass
