"""Ejercicio 2 — Formulario de inicio de sesión con eventos de teclado (Tkinter)."""
import tkinter as tk
from tkinter import messagebox, ttk


class FormularioLogin(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Iniciar sesión")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Iniciar sesión", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 10))
        ttk.Label(marco, text="Nombre de usuario").grid(row=1, column=0, sticky="w")
        self.usuario = ttk.Entry(marco, width=30)
        self.usuario.grid(row=2, column=0, sticky="ew", pady=(2, 0))
        # Aviso debajo del campo: vacío hasta que el usuario se va del campo sin escribir nada
        self.aviso = ttk.Label(marco, text="", foreground="#c0392b")
        self.aviso.grid(row=3, column=0, sticky="w", pady=(2, 6))
        ttk.Label(marco, text="Contraseña").grid(row=4, column=0, sticky="w")
        self.clave = ttk.Entry(marco, width=30, show="*")    # la contraseña no se ve
        self.clave.grid(row=5, column=0, sticky="ew", pady=(2, 10))
        ttk.Button(marco, text="Iniciar sesión", command=self.iniciar_sesion).grid(row=6, column=0, sticky="ew")

        self.usuario.bind("<FocusOut>", self.revisar_usuario)       # al perder el foco
        self.bind("<Return>", lambda evento: self.iniciar_sesion())  # Enter en cualquier campo

    def revisar_usuario(self, evento=None):
        vacio = not self.usuario.get().strip()
        self.aviso.config(text="⚠ El nombre de usuario no puede quedar vacío." if vacio else "")
        return not vacio

    def iniciar_sesion(self):
        if not self.revisar_usuario() or not self.clave.get():
            messagebox.showwarning("Iniciar sesión", "Completá el usuario y la contraseña.")
            return
        messagebox.showinfo("Iniciar sesión", f"Sesión iniciada como {self.usuario.get().strip()}.")


if __name__ == "__main__":
    FormularioLogin().mainloop()
