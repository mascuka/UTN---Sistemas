"""Ejercicio 3 — Formulario de datos personales con validación de edad (Tkinter)."""
import tkinter as tk
from tkinter import messagebox, ttk

PAISES = ["Argentina", "Bolivia", "Brasil", "Chile", "Paraguay", "Uruguay", "Otro"]
GENEROS = ["Femenino", "Masculino", "Otro"]


def edad_valida(texto):
    """Edad: un número entero de 18 o más."""
    return texto.isdigit() and int(texto) >= 18


def validar_datos(nombre, edad, pais, genero):
    errores = []
    if not nombre:
        errores.append("Falta el nombre completo.")
    if not edad:
        errores.append("Falta la edad.")
    elif not edad_valida(edad):
        errores.append("La edad tiene que ser un número de 18 o más.")
    if not pais:
        errores.append("Falta elegir el país.")
    if not genero:
        errores.append("Falta elegir el género.")
    return errores


class FormularioDatos(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Datos personales")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Datos personales", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        ttk.Label(marco, text="Nombre completo").grid(row=1, column=0, sticky="w", pady=4)
        self.nombre = ttk.Entry(marco, width=28)
        self.nombre.grid(row=1, column=1, pady=4)
        ttk.Label(marco, text="Edad").grid(row=2, column=0, sticky="w", pady=4)
        self.edad = ttk.Entry(marco, width=28)
        self.edad.grid(row=2, column=1, pady=4)
        self.aviso_edad = ttk.Label(marco, text="", foreground="#c0392b")
        self.aviso_edad.grid(row=3, column=1, sticky="w")
        ttk.Label(marco, text="País").grid(row=4, column=0, sticky="w", pady=4)
        self.pais = ttk.Combobox(marco, values=PAISES, state="readonly", width=26)
        self.pais.grid(row=4, column=1, pady=4)
        ttk.Label(marco, text="Género").grid(row=5, column=0, sticky="w", pady=4)
        self.genero = tk.StringVar(value="")
        radios = ttk.Frame(marco)
        radios.grid(row=5, column=1, sticky="w")
        for g in GENEROS:
            ttk.Radiobutton(radios, text=g, value=g, variable=self.genero).pack(side="left", padx=(0, 8))
        ttk.Button(marco, text="Enviar", command=self.enviar).grid(row=6, column=0, columnspan=2, sticky="ew", pady=(12, 0))

        # Evento: cada vez que se escribe en la edad (o se sale del campo) se revisa
        self.edad.bind("<KeyRelease>", self.revisar_edad)
        self.edad.bind("<FocusOut>", self.revisar_edad)

    def revisar_edad(self, evento=None):
        texto = self.edad.get().strip()
        if texto and not texto.isdigit():
            self.aviso_edad.config(text="⚠ La edad tiene que ser un número.")
        elif texto and int(texto) < 18:
            self.aviso_edad.config(text="⚠ Tiene que ser 18 o más.")
        else:
            self.aviso_edad.config(text="")

    def enviar(self):
        datos = (self.nombre.get().strip(), self.edad.get().strip(), self.pais.get(), self.genero.get())
        errores = validar_datos(*datos)
        if errores:
            messagebox.showwarning("Datos personales", "\n".join(errores))
            return
        nombre, edad, pais, genero = datos
        messagebox.showinfo("Datos personales", f"Nombre: {nombre}\nEdad: {edad}\nPaís: {pais}\nGénero: {genero}")


if __name__ == "__main__":
    FormularioDatos().mainloop()
