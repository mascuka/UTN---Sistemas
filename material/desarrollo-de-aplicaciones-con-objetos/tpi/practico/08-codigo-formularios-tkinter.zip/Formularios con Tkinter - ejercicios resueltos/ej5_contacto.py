"""Ejercicio 5 — Formulario de contacto con eventos dinámicos (Tkinter)."""
import re
import tkinter as tk
from tkinter import messagebox, ttk

PATRON_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+")


def email_valido(texto):
    return bool(PATRON_EMAIL.fullmatch(texto))


def formulario_completo(nombre, email, mensaje):
    return bool(nombre.strip()) and email_valido(email.strip()) and bool(mensaje.strip())


class FormularioContacto(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Contacto")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Contacto", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.nombre = tk.StringVar()
        self.email = tk.StringVar()
        ttk.Label(marco, text="Nombre").grid(row=1, column=0, sticky="w")
        ttk.Entry(marco, textvariable=self.nombre, width=40).grid(row=2, column=0, sticky="ew", pady=(2, 8))
        ttk.Label(marco, text="Correo electrónico").grid(row=3, column=0, sticky="w")
        ttk.Entry(marco, textvariable=self.email, width=40).grid(row=4, column=0, sticky="ew", pady=(2, 0))
        self.aviso = tk.Label(marco, text="", fg="red")           # advertencia en rojo debajo del campo
        self.aviso.grid(row=5, column=0, sticky="w", pady=(0, 6))
        ttk.Label(marco, text="Mensaje").grid(row=6, column=0, sticky="w")
        self.mensaje = tk.Text(marco, width=40, height=5, relief="solid", borderwidth=1)
        self.mensaje.grid(row=7, column=0, sticky="ew", pady=(2, 10))
        self.boton = ttk.Button(marco, text="Enviar", command=self.enviar, state="disabled")
        self.boton.grid(row=8, column=0, sticky="ew")

        # Validación en tiempo real: trace sobre las variables y KeyRelease sobre el Text
        self.nombre.trace_add("write", self.actualizar)
        self.email.trace_add("write", self.actualizar)
        self.mensaje.bind("<KeyRelease>", self.actualizar)

    def actualizar(self, *args):
        texto = self.email.get().strip()
        self.aviso.config(text="El correo no tiene un formato válido." if texto and not email_valido(texto) else "")
        listo = formulario_completo(self.nombre.get(), self.email.get(), self.mensaje.get("1.0", "end"))
        self.boton.config(state="normal" if listo else "disabled")    # solo se habilita si todo está bien

    def enviar(self):
        messagebox.showinfo("Contacto", f"¡Gracias, {self.nombre.get().strip()}! Tu mensaje fue enviado.")


if __name__ == "__main__":
    FormularioContacto().mainloop()
