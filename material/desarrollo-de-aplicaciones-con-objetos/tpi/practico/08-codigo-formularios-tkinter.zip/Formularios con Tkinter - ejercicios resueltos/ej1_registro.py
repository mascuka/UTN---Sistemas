"""Ejercicio 1 — Formulario de registro de usuario con validaciones (Tkinter)."""
import re
import tkinter as tk
from tkinter import messagebox, ttk

PATRON_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+")


def validar_registro(usuario, email, clave, confirmacion):
    """Devuelve la lista de errores (vacía si todo está bien). No depende de la ventana."""
    errores = []
    if not usuario.isalnum():                       # solo letras y números, sin espacios
        errores.append("El nombre de usuario debe tener solo letras y números (sin espacios).")
    if not PATRON_EMAIL.fullmatch(email):
        errores.append("El correo no tiene un formato válido (ej.: nombre@dominio.com).")
    if len(clave) < 8 or not any(c.isalpha() for c in clave) or not any(c.isdigit() for c in clave):
        errores.append("La contraseña debe tener al menos 8 caracteres, con letras y números.")
    if clave != confirmacion:
        errores.append("La contraseña y la confirmación no coinciden.")
    return errores


class FormularioRegistro(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Registro de usuario")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Crear cuenta", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        self.usuario = self._campo(marco, "Nombre de usuario", 1)
        self.email = self._campo(marco, "Correo electrónico", 2)
        self.clave = self._campo(marco, "Contraseña", 3, oculto=True)
        self.confirmacion = self._campo(marco, "Confirmar contraseña", 4, oculto=True)
        ttk.Button(marco, text="Registrar", command=self.registrar).grid(row=5, column=0, columnspan=2, pady=(12, 0), sticky="ew")

    def _campo(self, marco, texto, fila, oculto=False):
        ttk.Label(marco, text=texto).grid(row=fila, column=0, sticky="w", padx=(0, 10), pady=4)
        entrada = ttk.Entry(marco, width=28, show="*" if oculto else "")
        entrada.grid(row=fila, column=1, pady=4)
        return entrada

    def registrar(self):
        errores = validar_registro(self.usuario.get().strip(), self.email.get().strip(),
                                   self.clave.get(), self.confirmacion.get())
        if errores:
            messagebox.showerror("Registro", "Hay errores:\n\n• " + "\n• ".join(errores))
        else:
            messagebox.showinfo("Registro", f"¡Registro exitoso, {self.usuario.get().strip()}!")


if __name__ == "__main__":
    FormularioRegistro().mainloop()
