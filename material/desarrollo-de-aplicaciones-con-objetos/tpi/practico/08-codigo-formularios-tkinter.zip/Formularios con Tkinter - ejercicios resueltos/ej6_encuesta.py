"""Ejercicio 6 — Formulario de encuesta con selección múltiple y validación (Tkinter)."""
import tkinter as tk
from tkinter import messagebox, ttk

GENEROS = ["Femenino", "Masculino", "Otro"]
OPCIONES = ["Opción 1", "Opción 2", "Opción 3"]
ROJO, NORMAL = "#e74c3c", "#c8c8c8"


def campos_faltantes(nombre, genero, elegidas):
    """Devuelve los nombres de los campos que faltan completar."""
    faltan = []
    if not nombre.strip():
        faltan.append("nombre")
    if not genero:
        faltan.append("genero")
    if not elegidas:
        faltan.append("opciones")
    return faltan


class FormularioEncuesta(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Encuesta")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Encuesta", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 10))
        ttk.Label(marco, text="Nombre").grid(row=1, column=0, sticky="w")
        # tk.Entry (no ttk) porque permite pintar el borde con highlightbackground
        self.nombre = tk.Entry(marco, width=34, highlightthickness=2, highlightbackground=NORMAL, relief="flat")
        self.nombre.grid(row=2, column=0, sticky="w", pady=(2, 10))
        # Los grupos van dentro de un Frame con borde, para poder marcarlos en rojo
        self.genero = tk.StringVar(value="")
        self.marco_genero = self._grupo(marco, "Género", 3)
        for g in GENEROS:
            ttk.Radiobutton(self.marco_genero, text=g, value=g, variable=self.genero).pack(side="left", padx=6, pady=4)
        self.marco_opciones = self._grupo(marco, "Opciones de preferencia", 5)
        self.opciones = {o: tk.BooleanVar() for o in OPCIONES}
        for o, var in self.opciones.items():
            ttk.Checkbutton(self.marco_opciones, text=o, variable=var).pack(side="left", padx=6, pady=4)
        ttk.Button(marco, text="Enviar", command=self.enviar).grid(row=7, column=0, sticky="ew", pady=(12, 0))

    def _grupo(self, marco, titulo, fila):
        ttk.Label(marco, text=titulo).grid(row=fila, column=0, sticky="w")
        grupo = tk.Frame(marco, highlightthickness=2, highlightbackground=NORMAL)
        grupo.grid(row=fila + 1, column=0, sticky="ew", pady=(2, 10))
        return grupo

    def enviar(self):
        elegidas = [o for o, var in self.opciones.items() if var.get()]
        faltan = campos_faltantes(self.nombre.get(), self.genero.get(), elegidas)
        # Borde rojo en lo que falta y normal en lo demás
        for campo, widget in (("nombre", self.nombre), ("genero", self.marco_genero), ("opciones", self.marco_opciones)):
            widget.config(highlightbackground=ROJO if campo in faltan else NORMAL)
        if faltan:
            messagebox.showwarning("Encuesta", "Completá los campos marcados en rojo (elegí al menos una opción).")
            return
        messagebox.showinfo("Encuesta", f"Nombre: {self.nombre.get().strip()}\nGénero: {self.genero.get()}\n"
                                        f"Opciones: {', '.join(elegidas)}")


if __name__ == "__main__":
    FormularioEncuesta().mainloop()
