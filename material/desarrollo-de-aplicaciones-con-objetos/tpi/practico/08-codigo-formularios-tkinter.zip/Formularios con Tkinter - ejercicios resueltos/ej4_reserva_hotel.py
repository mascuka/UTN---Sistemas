"""Ejercicio 4 — Formulario de reserva de hotel con validación de fechas (Tkinter)."""
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

FORMATO = "%d/%m/%Y"


def leer_fecha(texto):
    """Devuelve la fecha si tiene el formato dd/mm/aaaa y existe; si no, None."""
    try:
        return datetime.strptime(texto, FORMATO).date()
    except ValueError:
        return None


def validar_reserva(nombre, check_in, check_out, personas):
    errores = []
    if not nombre:
        errores.append("Falta el nombre completo.")
    entrada, salida = leer_fecha(check_in), leer_fecha(check_out)
    if entrada is None:
        errores.append("La fecha de check-in debe tener el formato dd/mm/aaaa.")
    if salida is None:
        errores.append("La fecha de check-out debe tener el formato dd/mm/aaaa.")
    if entrada and salida and salida <= entrada:
        errores.append("El check-out tiene que ser posterior al check-in.")
    if not personas.isdigit() or int(personas) <= 0:
        errores.append("El número de personas tiene que ser mayor a 0.")
    return errores


class FormularioReserva(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Reserva de hotel")
        self.resizable(False, False)
        marco = ttk.Frame(self, padding=16)
        marco.pack()
        ttk.Label(marco, text="Reserva de hotel", font=("TkDefaultFont", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        self.nombre = self._campo(marco, "Nombre completo", 1)
        self.check_in = self._campo(marco, "Check-in (dd/mm/aaaa)", 2)
        self.check_out = self._campo(marco, "Check-out (dd/mm/aaaa)", 3)
        ttk.Label(marco, text="Número de personas").grid(row=4, column=0, sticky="w", pady=4)
        self.personas = ttk.Spinbox(marco, from_=0, to=10, width=26)
        self.personas.set(1)
        self.personas.grid(row=4, column=1, pady=4)
        ttk.Button(marco, text="Reservar", command=self.reservar).grid(row=5, column=0, columnspan=2, sticky="ew", pady=(12, 0))

    def _campo(self, marco, texto, fila):
        ttk.Label(marco, text=texto).grid(row=fila, column=0, sticky="w", padx=(0, 10), pady=4)
        entrada = ttk.Entry(marco, width=28)
        entrada.grid(row=fila, column=1, pady=4)
        return entrada

    def reservar(self):
        datos = (self.nombre.get().strip(), self.check_in.get().strip(), self.check_out.get().strip(), self.personas.get().strip())
        errores = validar_reserva(*datos)
        if errores:
            messagebox.showerror("Reserva", "No se pudo reservar:\n\n• " + "\n• ".join(errores))
            return
        noches = (leer_fecha(datos[2]) - leer_fecha(datos[1])).days
        messagebox.showinfo("Reserva", f"Reserva confirmada para {datos[0]}:\n{datos[1]} al {datos[2]} "
                                       f"({noches} {'noche' if noches == 1 else 'noches'}), {datos[3]} persona(s).")


if __name__ == "__main__":
    FormularioReserva().mainloop()
