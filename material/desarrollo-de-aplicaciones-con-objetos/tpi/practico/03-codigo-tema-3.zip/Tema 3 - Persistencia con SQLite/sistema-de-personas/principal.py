import sqlite3

BASE = "personas.sqlite"


def conectar():
    conexion = sqlite3.connect(BASE)
    conexion.row_factory = sqlite3.Row           # las filas se leen por nombre de columna
    return conexion


def mostrar(p):
    print(f"   {p['documento']}: {p['apellido']}, {p['nombre']} ({p['edad']} años)")


def buscar(conexion, documento):
    return conexion.execute("SELECT * FROM Personas WHERE documento = ?", (documento,)).fetchone()


# ---------- Altas, bajas y modificaciones ----------
def agregar(conexion):
    documento = int(input("Documento: "))
    if buscar(conexion, documento):
        print("   Ya existe una persona con ese documento")
        return
    nombre, apellido = input("Nombre: ").upper(), input("Apellido: ").upper()
    edad = int(input("Edad: "))
    with conexion:                                # commit al terminar bien, rollback si hay error
        conexion.execute("INSERT INTO Personas (documento, nombre, apellido, edad) VALUES (?, ?, ?, ?)",
                         (documento, nombre, apellido, edad))
    print("   Persona agregada")


def cumpleanios(conexion):
    documento = int(input("Documento: "))
    with conexion:
        cursor = conexion.execute("UPDATE Personas SET edad = edad + 1 WHERE documento = ?", (documento,))
    if cursor.rowcount == 0:
        print("   No existe esa persona")
    else:
        print("   ¡Feliz cumpleaños!")
        mostrar(buscar(conexion, documento))


def modificar(conexion):
    documento = int(input("Documento: "))
    persona = buscar(conexion, documento)
    if not persona:
        print("   No existe esa persona")
        return
    mostrar(persona)
    print("   (Enter para dejar el dato como está)")
    cambios = {}
    for campo in ("nombre", "apellido", "edad"):
        valor = input(f"{campo.capitalize()} (nuevo): ")
        if valor:
            cambios[campo] = int(valor) if campo == "edad" else valor.upper()
    if not cambios:
        print("   Sin cambios")
        return
    columnas = ", ".join(f"{c} = ?" for c in cambios)           # solo los campos indicados
    with conexion:
        conexion.execute(f"UPDATE Personas SET {columnas} WHERE documento = ?", (*cambios.values(), documento))
    mostrar(buscar(conexion, documento))


def eliminar(conexion):
    documento = int(input("Documento: "))
    persona = buscar(conexion, documento)
    if not persona:
        print("   No existe esa persona")
        return
    mostrar(persona)
    if input("¿Confirma la eliminación? (s/n): ").lower() == "s":
        with conexion:
            conexion.execute("DELETE FROM Personas WHERE documento = ?", (documento,))
        print("   Persona eliminada")
    else:
        print("   No se eliminó")


def consultar(conexion):
    persona = buscar(conexion, int(input("Documento: ")))
    mostrar(persona) if persona else print("   No existe esa persona")


# ---------- Reportes ----------
def listar(conexion, sql, parametros=(), maximo=10):
    filas = conexion.execute(sql, parametros).fetchall()
    for p in filas[:maximo]:
        mostrar(p)
    if len(filas) > maximo:
        print(f"   … y {len(filas) - maximo} más")
    print(f"   Total: {len(filas)}")


def reportes(conexion):
    opciones = {
        "1": ("Todas", lambda: listar(conexion, "SELECT * FROM Personas ORDER BY apellido, nombre")),
        "2": ("Mayores", lambda: listar(conexion, "SELECT * FROM Personas WHERE edad >= 18 ORDER BY apellido")),
        "3": ("Menores", lambda: listar(conexion, "SELECT * FROM Personas WHERE edad < 18 ORDER BY apellido")),
        "4": ("Por rango", lambda: rangos(conexion)),
        "5": ("Extremos", lambda: extremos(conexion)),
        "6": ("Estadísticas", lambda: estadisticas(conexion)),
        "7": ("Por letra", lambda: por_letra(conexion)),
        "8": ("Apellidos repetidos", lambda: apellidos_repetidos(conexion)),
    }
    opcion = ""
    while opcion != "9":
        print("REPORTES: " + " · ".join(f"{k} {t}" for k, (t, _) in opciones.items()) + " · 9 Volver")
        opcion = input("Opción: ")
        if opcion in opciones:
            opciones[opcion][1]()


def rangos(conexion):
    sql = """SELECT CASE WHEN edad < 18 THEN '0 a 17'
                         WHEN edad < 30 THEN '18 a 29'
                         WHEN edad < 50 THEN '30 a 49'
                         WHEN edad < 65 THEN '50 a 64'
                         ELSE '65 o más' END AS rango, COUNT(*) AS cantidad
             FROM Personas GROUP BY rango ORDER BY MIN(edad)"""
    for fila in conexion.execute(sql):
        print(f"   {fila['rango']}: {fila['cantidad']}")


def extremos(conexion):
    print("   Más joven:"); mostrar(conexion.execute("SELECT * FROM Personas ORDER BY edad, apellido LIMIT 1").fetchone())
    print("   Más longeva:"); mostrar(conexion.execute("SELECT * FROM Personas ORDER BY edad DESC, apellido LIMIT 1").fetchone())


def estadisticas(conexion):
    f = conexion.execute("SELECT COUNT(*) AS n, AVG(edad) AS prom, MIN(edad) AS mi, MAX(edad) AS ma FROM Personas").fetchone()
    print(f"   {f['n']} personas · promedio {f['prom']:.2f} · mínima {f['mi']} · máxima {f['ma']}")


def por_letra(conexion):
    letra = input("Letra: ").upper()[:1]
    listar(conexion, "SELECT * FROM Personas WHERE nombre LIKE ? ORDER BY nombre", (letra + "%",))


def apellidos_repetidos(conexion):
    sql = """SELECT apellido, COUNT(*) AS cantidad FROM Personas
             GROUP BY apellido HAVING COUNT(*) > 1 ORDER BY cantidad DESC, apellido"""
    filas = conexion.execute(sql).fetchall()
    for f in filas[:10]:
        print(f"   {f['apellido']}: {f['cantidad']}")
    print(f"   {len(filas)} apellidos se repiten")


def main():
    conexion = conectar()
    menu = {"1": ("Agregar", agregar), "2": ("Cumpleaños", cumpleanios), "3": ("Modificar", modificar),
            "4": ("Eliminar", eliminar), "5": ("Buscar", consultar), "6": ("Reportes", reportes)}
    opcion = ""
    while opcion != "7":
        print("PERSONAS: " + " · ".join(f"{k} {t}" for k, (t, _) in menu.items()) + " · 7 Salir")
        opcion = input("Opción: ")
        if opcion in menu:
            menu[opcion][1](conexion)
    conexion.close()


if __name__ == "__main__":
    main()
