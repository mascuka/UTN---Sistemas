"""TP · Ejercicio 6 — Recorrido inverso de tareas (Iterator)."""


class Tarea:
    def __init__(self, descripcion):
        self.descripcion = descripcion

    def __str__(self):
        return self.descripcion


class IteradorInverso:
    def __init__(self, tareas):
        self.tareas = tareas
        self.posicion = len(tareas) - 1      # arranca por la última

    def __iter__(self):
        return self

    def __next__(self):
        if self.posicion < 0:
            raise StopIteration
        tarea = self.tareas[self.posicion]
        self.posicion -= 1
        return tarea


class ListaTareas:
    def __init__(self):
        self._tareas = []

    def agregar(self, tarea):
        self._tareas.append(tarea)

    def __iter__(self):
        return IteradorInverso(self._tareas)


if __name__ == "__main__":
    lista = ListaTareas()
    for texto in ["Estudiar Python", "Preparar parcial", "Entregar trabajo"]:
        lista.agregar(Tarea(texto))
    for n, tarea in enumerate(lista, 1):
        print(f"{n}. {tarea}")
