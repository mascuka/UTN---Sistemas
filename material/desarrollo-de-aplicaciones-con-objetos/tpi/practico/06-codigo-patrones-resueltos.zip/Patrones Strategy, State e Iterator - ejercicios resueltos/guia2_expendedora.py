"""Guía · Ejercicio 2 — Máquina expendedora (State)."""
from abc import ABC, abstractmethod


class EstadoMaquina(ABC):
    @abstractmethod
    def ingresar_dinero(self, maquina):
        pass

    @abstractmethod
    def comprar(self, maquina):
        pass

    def reponer_stock(self, maquina, cantidad):
        # Reponer se puede en cualquier estado; si estaba sin stock, pasa a esperar dinero
        maquina.stock += cantidad
        print(f"  Repuesto: ahora hay {maquina.stock}")


class SinDinero(EstadoMaquina):
    def ingresar_dinero(self, maquina):
        print("  Dinero ingresado")
        maquina.cambiar_estado(ConDinero())

    def comprar(self, maquina):
        print("  Primero hay que ingresar dinero")

    def __str__(self):
        return "sin dinero"


class ConDinero(EstadoMaquina):
    def ingresar_dinero(self, maquina):
        print("  Ya hay dinero ingresado: comprá o esperá")

    def comprar(self, maquina):
        maquina.stock -= 1
        print(f"  Producto entregado (quedan {maquina.stock})")
        maquina.cambiar_estado(SinStock() if maquina.stock == 0 else SinDinero())

    def __str__(self):
        return "con dinero"


class SinStock(EstadoMaquina):
    def ingresar_dinero(self, maquina):
        print("  No hay stock: no se acepta dinero")

    def comprar(self, maquina):
        print("  No hay stock")

    def reponer_stock(self, maquina, cantidad):
        super().reponer_stock(maquina, cantidad)
        maquina.cambiar_estado(SinDinero())

    def __str__(self):
        return "sin stock"


class MaquinaExpendedora:
    def __init__(self, stock):
        self.stock = stock
        self.estado = SinDinero() if stock > 0 else SinStock()

    def cambiar_estado(self, nuevo_estado):
        self.estado = nuevo_estado

    def ingresar_dinero(self):
        self.estado.ingresar_dinero(self)

    def comprar(self):
        self.estado.comprar(self)

    def reponer_stock(self, cantidad):
        self.estado.reponer_stock(self, cantidad)


if __name__ == "__main__":
    m = MaquinaExpendedora(stock=1)
    pasos = [("comprar", ()), ("ingresar_dinero", ()), ("ingresar_dinero", ()), ("comprar", ()),
             ("ingresar_dinero", ()), ("comprar", ()), ("reponer_stock", (2,)), ("ingresar_dinero", ()), ("comprar", ())]
    for accion, args in pasos:
        print(f"{accion}{args if args else '()'} estando {m.estado}:")
        getattr(m, accion)(*args)
    print("Estado final:", m.estado, "· stock:", m.stock)
