"""Guía · Ejercicio 1 — Costos de envío (Strategy)."""
from abc import ABC, abstractmethod


class EstrategiaEnvio(ABC):
    @abstractmethod
    def calcular_costo(self, peso):
        pass


class EnvioNormal(EstrategiaEnvio):
    def calcular_costo(self, peso):
        return peso * 1_000


class EnvioExpress(EstrategiaEnvio):
    def calcular_costo(self, peso):
        return peso * 1_500 + 2_000


class EnvioEconomico(EstrategiaEnvio):
    def calcular_costo(self, peso):
        return peso * 800


class CalculadoraEnvios:
    def __init__(self, estrategia):
        self.estrategia = estrategia

    def cambiar_estrategia(self, estrategia):
        self.estrategia = estrategia

    def costo(self, peso):
        return self.estrategia.calcular_costo(peso)


def pesos(x):
    # Formato argentino: punto para los miles
    return "$" + f"{x:,.0f}".replace(",", ".")


if __name__ == "__main__":
    calculadora = CalculadoraEnvios(EnvioNormal())
    for estrategia in [EnvioNormal(), EnvioExpress(), EnvioEconomico()]:
        calculadora.cambiar_estrategia(estrategia)
        print(f"{type(estrategia).__name__:<15} paquete de 5 kg: {pesos(calculadora.costo(5))}")
