"""TP · Ejercicio 5 — Alumnos aprobados (Iterator)."""


class Alumno:
    def __init__(self, nombre, nota):
        self.nombre = nombre
        self.nota = nota

    def __str__(self):
        return f"{self.nombre} ({self.nota})"


class IteradorAprobados:
    def __init__(self, alumnos):
        self.alumnos = alumnos
        self.posicion = 0

    def __iter__(self):
        return self

    def __next__(self):
        # Salta los que no aprobaron: el filtro está acá, no en el programa principal
        while self.posicion < len(self.alumnos):
            alumno = self.alumnos[self.posicion]
            self.posicion += 1
            if alumno.nota >= 6:
                return alumno
        raise StopIteration


class Curso:
    def __init__(self):
        self.alumnos = []

    def agregar(self, alumno):
        self.alumnos.append(alumno)

    def __iter__(self):
        return IteradorAprobados(self.alumnos)


if __name__ == "__main__":
    curso = Curso()
    for nombre, nota in [("Ana", 8), ("Luis", 4), ("María", 7), ("Pedro", 3), ("Sofía", 9)]:
        curso.agregar(Alumno(nombre, nota))
    print("Aprobados:")
    for alumno in curso:
        print(" ", alumno)
