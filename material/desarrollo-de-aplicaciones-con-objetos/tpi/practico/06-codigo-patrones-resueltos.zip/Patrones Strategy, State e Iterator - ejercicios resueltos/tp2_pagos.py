"""TP · Ejercicio 2 — Sistema de pagos (Strategy)."""
from abc import ABC, abstractmethod


class MedioPago(ABC):
    @abstractmethod
    def total(self, monto):
        pass


class PagoEfectivo(MedioPago):
    def total(self, monto):
        return monto * 0.90          # 10 % de descuento


class PagoTransferencia(MedioPago):
    def total(self, monto):
        return monto                 # sin cambios


class PagoTarjeta(MedioPago):
    def total(self, monto):
        return monto * 1.15          # 15 % de recargo


class ProcesadorPago:
    def __init__(self, medio):
        self.medio = medio

    def cambiar_medio(self, medio):
        self.medio = medio

    def procesar(self, monto):
        return self.medio.total(monto)


# Se agrega después, sin tocar ProcesadorPago: alcanza con una clase nueva con la misma interfaz
class PagoPromocional(MedioPago):
    def total(self, monto):
        return monto * 0.80          # 20 % de descuento


def pesos(x):
    # Formato argentino: punto para los miles
    return "$" + f"{x:,.0f}".replace(",", ".")


if __name__ == "__main__":
    monto = 10_000
    procesador = ProcesadorPago(PagoEfectivo())
    for medio in [PagoEfectivo(), PagoTransferencia(), PagoTarjeta(), PagoPromocional()]:
        procesador.cambiar_medio(medio)
        print(f"{type(medio).__name__:<18} {pesos(procesador.procesar(monto))}")
