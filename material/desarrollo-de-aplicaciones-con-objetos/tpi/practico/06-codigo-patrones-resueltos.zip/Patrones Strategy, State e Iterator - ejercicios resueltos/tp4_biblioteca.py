"""TP · Ejercicio 4 — Préstamo de biblioteca (State)."""
from abc import ABC, abstractmethod


class EstadoLibro(ABC):
    # Cada estado redefine solo lo que permite; lo demás avisa sin cambiar el estado
    def prestar(self, libro):
        print(f"  No se puede prestar: está {self}")

    def devolver(self, libro):
        print(f"  No se puede devolver: está {self}")

    def enviar_reparacion(self, libro):
        print(f"  No se puede enviar a reparación: está {self}")

    def finalizar_reparacion(self, libro):
        print(f"  No se puede finalizar la reparación: está {self}")

    @abstractmethod
    def __str__(self):
        pass


class Disponible(EstadoLibro):
    def prestar(self, libro):
        print("  Prestado")
        libro.cambiar_estado(Prestado())

    def enviar_reparacion(self, libro):
        print("  Enviado a reparación")
        libro.cambiar_estado(EnReparacion())

    def __str__(self):
        return "disponible"


class Prestado(EstadoLibro):
    def devolver(self, libro):
        print("  Devuelto")
        libro.cambiar_estado(Disponible())

    def __str__(self):
        return "prestado"


class EnReparacion(EstadoLibro):
    def finalizar_reparacion(self, libro):
        print("  Reparación terminada")
        libro.cambiar_estado(Disponible())

    def __str__(self):
        return "en reparación"


class Libro:
    def __init__(self, titulo):
        self.titulo = titulo
        self.estado = Disponible()

    def cambiar_estado(self, nuevo_estado):
        self.estado = nuevo_estado

    def prestar(self):
        self.estado.prestar(self)

    def devolver(self):
        self.estado.devolver(self)

    def enviar_reparacion(self):
        self.estado.enviar_reparacion(self)

    def finalizar_reparacion(self):
        self.estado.finalizar_reparacion(self)


if __name__ == "__main__":
    libro = Libro("Rayuela")
    for accion in ["prestar", "prestar", "enviar_reparacion", "devolver", "enviar_reparacion",
                   "prestar", "finalizar_reparacion", "prestar"]:
        print(f"{accion}() estando {libro.estado}:")
        getattr(libro, accion)()
    print(f"«{libro.titulo}» queda {libro.estado}")
