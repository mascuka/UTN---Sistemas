"""TP · Ejercicio 3 — Reproductor de música (State)."""
from abc import ABC, abstractmethod


class EstadoReproductor(ABC):
    # Por defecto, cada acción no está permitida: avisa y el estado no cambia
    def reproducir(self, reproductor):
        print(f"  No se puede reproducir: está {self}")

    def pausar(self, reproductor):
        print(f"  No se puede pausar: está {self}")

    def detener(self, reproductor):
        print(f"  No se puede detener: está {self}")

    @abstractmethod
    def __str__(self):
        pass


class Detenido(EstadoReproductor):
    def reproducir(self, reproductor):
        print("  Reproduciendo")
        reproductor.cambiar_estado(Reproduciendo())

    def __str__(self):
        return "detenido"


class Reproduciendo(EstadoReproductor):
    def pausar(self, reproductor):
        print("  En pausa")
        reproductor.cambiar_estado(Pausado())

    def detener(self, reproductor):
        print("  Detenido")
        reproductor.cambiar_estado(Detenido())

    def __str__(self):
        return "reproduciendo"


class Pausado(EstadoReproductor):
    def reproducir(self, reproductor):
        print("  Sigue la reproducción")
        reproductor.cambiar_estado(Reproduciendo())

    def detener(self, reproductor):
        print("  Detenido")
        reproductor.cambiar_estado(Detenido())

    def __str__(self):
        return "en pausa"


class Reproductor:
    def __init__(self):
        self.estado = Detenido()

    def cambiar_estado(self, nuevo_estado):
        self.estado = nuevo_estado

    def reproducir(self):
        self.estado.reproducir(self)

    def pausar(self):
        self.estado.pausar(self)

    def detener(self):
        self.estado.detener(self)


if __name__ == "__main__":
    r = Reproductor()
    for accion in ["pausar", "reproducir", "reproducir", "pausar", "pausar", "reproducir", "detener", "detener"]:
        print(f"{accion}() estando {r.estado}:")
        getattr(r, accion)()
    print("Estado final:", r.estado)
