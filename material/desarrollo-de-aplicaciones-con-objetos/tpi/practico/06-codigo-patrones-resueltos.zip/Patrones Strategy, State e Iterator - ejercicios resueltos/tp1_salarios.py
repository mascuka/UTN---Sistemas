"""TP · Ejercicio 1 — Cálculo de salarios (Strategy)."""
from abc import ABC, abstractmethod


class EstrategiaSalario(ABC):
    @abstractmethod
    def calcular(self):
        pass


class SalarioFijo(EstrategiaSalario):
    def __init__(self, monto):
        self.monto = monto

    def calcular(self):
        return self.monto


class SalarioPorHoras(EstrategiaSalario):
    def __init__(self, horas, valor_hora):
        self.horas = horas
        self.valor_hora = valor_hora

    def calcular(self):
        return self.horas * self.valor_hora


class SalarioConComision(EstrategiaSalario):
    def __init__(self, basico, ventas, porcentaje):
        self.basico = basico
        self.ventas = ventas
        self.porcentaje = porcentaje

    def calcular(self):
        return self.basico + self.ventas * self.porcentaje / 100


class CalculadoraSalario:
    def __init__(self, estrategia):
        self.estrategia = estrategia

    def cambiar_estrategia(self, estrategia):
        self.estrategia = estrategia

    def calcular(self):
        # Polimorfismo: no pregunta qué estrategia es, le pide que calcule
        return self.estrategia.calcular()


def pesos(x):
    # Formato argentino: punto para los miles
    return "$" + f"{x:,.0f}".replace(",", ".")


if __name__ == "__main__":
    calculadora = CalculadoraSalario(SalarioFijo(500_000))
    print("Fijo:         ", pesos(calculadora.calcular()))
    calculadora.cambiar_estrategia(SalarioPorHoras(40, 8_000))
    print("Por horas:    ", pesos(calculadora.calcular()))
    calculadora.cambiar_estrategia(SalarioConComision(300_000, 1_000_000, 10))
    print("Con comisión: ", pesos(calculadora.calcular()))
