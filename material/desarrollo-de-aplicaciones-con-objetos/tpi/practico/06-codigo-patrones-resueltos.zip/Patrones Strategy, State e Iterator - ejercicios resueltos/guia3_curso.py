"""Guía · Ejercicio 3 — Curso y alumnos (Iterator), con un segundo iterador de aprobados."""


class Alumno:
    def __init__(self, nombre, nota):
        self.nombre = nombre
        self.nota = nota

    def __str__(self):
        return f"{self.nombre} ({self.nota})"


class IteradorAlumnos:
    def __init__(self, alumnos):
        self.alumnos = alumnos
        self.posicion = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.posicion >= len(self.alumnos):
            raise StopIteration
        alumno = self.alumnos[self.posicion]
        self.posicion += 1
        return alumno


class IteradorAprobados(IteradorAlumnos):
    # Reusa el recorrido y saltea los que tienen menos de 6
    def __next__(self):
        while True:
            alumno = super().__next__()      # al terminar, StopIteration sale de acá
            if alumno.nota >= 6:
                return alumno


class Curso:
    def __init__(self):
        self._alumnos = []

    def agregar(self, alumno):
        self._alumnos.append(alumno)

    def __iter__(self):
        return IteradorAlumnos(self._alumnos)

    def aprobados(self):
        return IteradorAprobados(self._alumnos)


if __name__ == "__main__":
    curso = Curso()
    for nombre, nota in [("Ana", 8), ("Luis", 4), ("María", 7), ("Pedro", 3), ("Sofía", 9)]:
        curso.agregar(Alumno(nombre, nota))
    print("Todos:", ", ".join(str(a) for a in curso))
    print("Aprobados:", ", ".join(str(a) for a in curso.aprobados()))
