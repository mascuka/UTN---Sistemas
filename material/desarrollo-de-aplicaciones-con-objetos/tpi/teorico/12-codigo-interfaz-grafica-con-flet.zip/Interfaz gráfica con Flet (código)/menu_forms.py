"""Menú de opciones en Flet: cada botón carga un formulario distinto al costado del menú."""

from collections.abc import Callable
from typing import Final

import flet as ft

import tema

TIPOS_DOCUMENTO: Final[tuple[str, ...]] = ("DNI", "Pasaporte", "CUIL")

type ConstructorFormulario = Callable[[], list[ft.Control]]
"""Función sin parámetros que devuelve los controles de un formulario."""

# Íconos de los botones del menú, en el mismo orden que los formularios
ICONOS_MENU: Final[tuple[ft.IconData, ...]] = (
    ft.Icons.PERSON_ADD_ALT_1_OUTLINED,
    ft.Icons.SEARCH,
    ft.Icons.EDIT_OUTLINED,
    ft.Icons.DELETE_OUTLINE,
)


def main(page: ft.Page) -> None:
    """Construye el menú lateral y el área donde se muestran los formularios.

    Args:
        page: Página principal que provee Flet al iniciar la aplicación.
    """
    tema.aplicar_tema(page, "Menú de opciones con Flet")

    # Título del formulario actual y área de contenido que se reemplaza en cada selección
    contenido: ft.Text = ft.Text(
        value="Selecciona una opción del menú",
        size=20,
        weight=ft.FontWeight.BOLD,
        color=tema.COLOR_TEXTO,
    )
    area_formulario: ft.Column = tema.columna([contenido])

    def mostrar_formulario(titulo: str, constructor: ConstructorFormulario) -> None:
        """Reemplaza el área de contenido por el formulario elegido.

        A diferencia de ``page.clean()``, el menú permanece visible.

        Args:
            titulo: Título que se muestra arriba del formulario.
            constructor: Función que genera los controles del formulario.
        """
        contenido.value = titulo
        area_formulario.controls = [contenido, *tema.estilizar(constructor())]

    def formulario_registro() -> list[ft.Control]:
        """Genera el formulario de Registro de Alumnos.

        Returns:
            Controles del formulario.
        """
        nombre: ft.TextField = ft.TextField(label="Nombre del Alumno")
        apellido: ft.TextField = ft.TextField(label="Apellido del Alumno")
        tipo_documento: ft.Dropdown = ft.Dropdown(
            label="Tipo de Documento",
            options=[ft.DropdownOption(tipo) for tipo in TIPOS_DOCUMENTO],
        )
        numero_documento: ft.TextField = ft.TextField(label="Número de Documento")
        fecha_nacimiento: ft.TextField = ft.TextField(
            label="Fecha de Nacimiento (AAAA-MM-DD)"
        )
        guardar_btn: ft.Button = ft.Button(
            "Guardar",
            on_click=lambda: print("Alumno registrado"),
        )
        return [
            nombre,
            apellido,
            tipo_documento,
            numero_documento,
            fecha_nacimiento,
            guardar_btn,
        ]

    def formulario_buscar() -> list[ft.Control]:
        """Genera el formulario de Buscar Alumnos.

        Returns:
            Controles del formulario.
        """
        id_alumno: ft.TextField = ft.TextField(label="ID del Alumno")
        buscar_btn: ft.Button = ft.Button(
            "Buscar",
            on_click=lambda: print(f"Buscando Alumno con ID: {id_alumno.value}"),
        )
        return [id_alumno, buscar_btn]

    def formulario_modificar() -> list[ft.Control]:
        """Genera el formulario de Modificar Alumnos.

        Returns:
            Controles del formulario.
        """
        id_alumno: ft.TextField = ft.TextField(label="ID del Alumno a modificar")
        nuevo_nombre: ft.TextField = ft.TextField(label="Nuevo Nombre")
        nuevo_apellido: ft.TextField = ft.TextField(label="Nuevo Apellido")
        modificar_btn: ft.Button = ft.Button(
            "Modificar",
            on_click=lambda: print(f"Modificando Alumno con ID: {id_alumno.value}"),
        )
        return [id_alumno, nuevo_nombre, nuevo_apellido, modificar_btn]

    def formulario_eliminar() -> list[ft.Control]:
        """Genera el formulario de Eliminar Alumnos.

        Returns:
            Controles del formulario.
        """
        id_alumno: ft.TextField = ft.TextField(label="ID del Alumno a eliminar")
        eliminar_btn: ft.Button = ft.Button(
            "Eliminar",
            on_click=lambda: print(f"Eliminando Alumno con ID: {id_alumno.value}"),
        )
        return [id_alumno, eliminar_btn]

    # Cada opción del menú asocia su título con la función que arma el formulario
    formularios: dict[str, ConstructorFormulario] = {
        "Formulario 1: Registro de Alumnos": formulario_registro,
        "Formulario 2: Buscar Alumnos": formulario_buscar,
        "Formulario 3: Modificar Alumnos": formulario_modificar,
        "Formulario 4: Eliminar Alumnos": formulario_eliminar,
    }

    def crear_boton(
        titulo: str, constructor: ConstructorFormulario, icono: ft.IconData
    ) -> ft.Button:
        """Crea el botón del menú que muestra un formulario.

        Args:
            titulo: Texto del botón y título del formulario.
            constructor: Función que genera los controles del formulario.
            icono: Ícono que acompaña al texto del botón.

        Returns:
            El botón configurado.
        """
        return ft.Button(
            titulo,
            icon=icono,
            on_click=lambda: mostrar_formulario(titulo, constructor),
            style=ft.ButtonStyle(
                bgcolor=tema.COLOR_SUPERFICIE_ALTA,
                alignment=ft.Alignment.CENTER_LEFT,
                padding=ft.Padding.all(tema.ESPACIO_MD),
            ),
        )

    # Crear las opciones del menú
    menu: ft.Column = tema.columna(
        [
            tema.etiqueta("Opciones"),
            *[
                crear_boton(titulo, constructor, icono)
                for (titulo, constructor), icono in zip(
                    formularios.items(), ICONOS_MENU, strict=True
                )
            ],
        ],
        tema.ESPACIO_SM + tema.ESPACIO_XS,
    )

    # Diseño de la página principal con el menú a la izquierda
    page.add(
        tema.pantalla(
            tema.encabezado(
                "Gestión de Alumnos",
                "Elegí una opción del menú para cargar su formulario",
                ft.Icons.SCHOOL_OUTLINED,
            ),
            ft.Row(
                [tema.tarjeta(menu, ancho=340), tema.tarjeta(area_formulario)],
                spacing=tema.ESPACIO_LG,
                tight=True,
                vertical_alignment=ft.CrossAxisAlignment.START,
            ),
        )
    )


if __name__ == "__main__":
    ft.run(main)
