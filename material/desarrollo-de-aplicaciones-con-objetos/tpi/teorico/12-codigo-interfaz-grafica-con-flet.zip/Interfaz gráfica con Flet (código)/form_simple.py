"""Formulario simple en Flet: pide un nombre y muestra un saludo."""

import flet as ft

import tema


def main(page: ft.Page) -> None:
    """Construye el formulario con un campo de texto, un botón y un resultado.

    Args:
        page: Página principal que provee Flet al iniciar la aplicación.
    """
    tema.aplicar_tema(page, "Formulario con Flet")

    nombre_input: ft.TextField = ft.TextField(
        label="Ingresa tu nombre", prefix_icon=ft.Icons.PERSON_OUTLINE
    )
    resultado: ft.Text = ft.Text(value="Escribí tu nombre y presioná Enviar.")

    def saludar() -> None:
        """Muestra un saludo con el nombre ingresado o un aviso si está vacío."""
        nombre: str = nombre_input.value.strip()
        resultado.value = (
            f"Hola, {nombre}!" if nombre else "Por favor, ingresa tu nombre."
        )

    # Sin lambda: saludar ya tiene la firma () -> None que acepta on_click
    enviar_boton: ft.Button = ft.Button("Enviar", icon=ft.Icons.SEND, on_click=saludar)

    page.add(
        tema.pantalla(
            tema.encabezado(
                "Formulario simple",
                "Ingresá tu nombre para recibir un saludo",
                ft.Icons.WAVING_HAND_OUTLINED,
            ),
            tema.tarjeta(
                tema.columna(
                    [
                        *tema.estilizar([nombre_input]),
                        enviar_boton,
                        tema.panel_resultado(resultado),
                    ]
                )
            ),
        )
    )


if __name__ == "__main__":
    ft.run(main)
