"""Barra de menús con PopupMenuButton en Flet; cada opción abre un diálogo."""

from typing import Final

import flet as ft

import tema

# Cada menú se define por su título y la lista de opciones que contiene
MENUS: Final[dict[str, tuple[str, ...]]] = {
    "Archivo": ("Nuevo", "Abrir", "Guardar", "Salir"),
    "Editar": ("Deshacer", "Rehacer", "Copiar", "Pegar"),
    "Ayuda": ("Documentación", "Acerca de..."),
}


def main(page: ft.Page) -> None:
    """Construye la barra de menús y la agrega a la página.

    Args:
        page: Página principal que provee Flet al iniciar la aplicación.
    """
    tema.aplicar_tema(page, "Ejemplo de Menú con Flet")

    def mostrar_seleccion(opcion: str) -> None:
        """Abre un diálogo indicando qué opción del menú se eligió.

        Args:
            opcion: Texto de la opción seleccionada.
        """
        page.show_dialog(
            ft.AlertDialog(
                icon=ft.Icon(
                    ft.Icons.CHECK_CIRCLE_OUTLINE, color=tema.COLOR_EXITO, size=36
                ),
                title=f"Seleccionado: {opcion}",
            )
        )

    def crear_item(opcion: str) -> ft.PopupMenuItem:
        """Crea un ítem de menú que, al hacer clic, muestra su propia opción.

        Usar una función fábrica hace que cada lambda capture su ``opcion``
        (evita el error clásico de capturar la variable de un bucle).

        Args:
            opcion: Texto del ítem.

        Returns:
            El ítem de menú configurado.
        """
        return ft.PopupMenuItem(
            content=opcion, on_click=lambda: mostrar_seleccion(opcion)
        )

    def crear_menu(titulo: str, opciones: tuple[str, ...]) -> ft.PopupMenuButton:
        """Crea un menú desplegable con su título como contenido.

        Args:
            titulo: Texto del menú.
            opciones: Opciones que contiene el menú.

        Returns:
            El ``PopupMenuButton`` configurado.
        """
        return ft.PopupMenuButton(
            content=ft.Container(
                ft.Row(
                    [
                        ft.Text(
                            titulo, color=tema.COLOR_TEXTO, weight=ft.FontWeight.W_500
                        ),
                        ft.Icon(
                            ft.Icons.EXPAND_MORE, color=tema.COLOR_SECUNDARIO, size=18
                        ),
                    ],
                    spacing=tema.ESPACIO_XS,
                    tight=True,
                ),
                padding=ft.Padding.symmetric(
                    horizontal=tema.ESPACIO_MD,
                    vertical=tema.ESPACIO_SM + tema.ESPACIO_XS,
                ),
                bgcolor=tema.COLOR_SUPERFICIE_ALTA,
                border_radius=tema.RADIO,
            ),
            items=[crear_item(opcion) for opcion in opciones],
        )

    # Barra de menús: un PopupMenuButton por cada entrada de MENUS
    menu_bar: ft.Row = ft.Row(
        [crear_menu(titulo, opciones) for titulo, opciones in MENUS.items()],
        spacing=tema.ESPACIO_SM,
        alignment=ft.MainAxisAlignment.CENTER,
    )

    # Agregar menú a la página
    page.add(
        tema.pantalla(
            tema.encabezado(
                "Barra de menús",
                "Abrí un menú y elegí una opción para ver el diálogo",
                ft.Icons.MENU_OPEN,
            ),
            tema.tarjeta(
                tema.columna([tema.etiqueta("Menús"), menu_bar], tema.ESPACIO_MD),
                ancho=440,
            ),
        )
    )


if __name__ == "__main__":
    ft.run(main)
