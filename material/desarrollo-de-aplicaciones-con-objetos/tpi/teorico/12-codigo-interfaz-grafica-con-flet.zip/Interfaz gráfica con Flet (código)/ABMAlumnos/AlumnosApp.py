"""Capa de presentación: interfaz Flet del ABM de alumnos."""

from dataclasses import replace

import flet as ft

import tema
from Alumno import Alumno
from BusinessLayer import TIPOS_DOCUMENTO, BusinessLayer


class AlumnosApp:
    """Vista del ABM de alumnos.

    Flujo de uso:
        * **Agregar**: completar los datos (sin legajo) y presionar "Agregar".
        * **Buscar**: ingresar el número de documento y presionar "Buscar";
          se cargan todos los datos del alumno, incluido su legajo.
        * **Modificar**: buscar el alumno, editar los datos y presionar "Modificar".
        * **Eliminar**: buscar el alumno (o escribir su legajo) y presionar "Eliminar".

    Se usa composición (la clase *tiene* una ``ft.Column``) en lugar de heredar de
    un control de Flet: la vista queda desacoplada del ciclo de vida de los controles.
    En Flet 1.0 la página se actualiza sola al terminar cada manejador de evento.
    """

    def __init__(self, business: BusinessLayer | None = None) -> None:
        """Crea los controles de la vista.

        Args:
            business: Capa de negocio a utilizar; si no se indica, se crea una por defecto.
        """
        self.__business: BusinessLayer = (
            business if business is not None else BusinessLayer()
        )

        # Controles de entrada
        self._legajo: ft.TextField = ft.TextField(
            label="Legajo",
            hint_text="Para modificar o eliminar",
            prefix_icon=ft.Icons.TAG,
            keyboard_type=ft.KeyboardType.NUMBER,
        )
        self._tipo_documento: ft.Dropdown = ft.Dropdown(
            label="Tipo de Documento",
            options=[ft.DropdownOption(tipo) for tipo in TIPOS_DOCUMENTO],
        )
        self._numero_documento: ft.TextField = ft.TextField(
            label="Número de Documento", prefix_icon=ft.Icons.BADGE_OUTLINED
        )
        self._apellido: ft.TextField = ft.TextField(label="Apellido")
        self._nombre: ft.TextField = ft.TextField(label="Nombre")
        self._fecha_nacimiento: ft.TextField = ft.TextField(
            label="Fecha de Nacimiento",
            hint_text="AAAA-MM-DD",
            prefix_icon=ft.Icons.CALENDAR_MONTH_OUTLINED,
        )
        self._resultado: ft.Text = ft.Text("Completá el formulario y elegí una acción.")

        self.vista: ft.Column = self.__construir_vista()

    def __construir_vista(self) -> ft.Column:
        """Arma la estructura principal de la interfaz.

        Returns:
            Columna con el título, los campos, los botones y el resultado.
        """
        # Botones para las acciones ABM (on_click acepta métodos sin parámetros)
        agregar: ft.Button = ft.Button(
            "Agregar alumno",
            icon=ft.Icons.PERSON_ADD_ALT_1,
            on_click=self.agregar_alumno,
        )
        acciones: ft.Row = tema.fila(
            [
                ft.OutlinedButton(
                    "Buscar", icon=ft.Icons.SEARCH, on_click=self.buscar_alumno
                ),
                ft.OutlinedButton(
                    "Modificar",
                    icon=ft.Icons.EDIT_OUTLINED,
                    on_click=self.modificar_alumno,
                ),
                ft.OutlinedButton(
                    "Eliminar",
                    icon=ft.Icons.DELETE_OUTLINE,
                    on_click=self.eliminar_alumno,
                    style=ft.ButtonStyle(
                        color=tema.COLOR_ERROR,
                        icon_color=tema.COLOR_ERROR,
                        side=ft.BorderSide(1, tema.COLOR_ERROR),
                    ),
                ),
            ]
        )
        limpiar: ft.TextButton = ft.TextButton(
            "Limpiar formulario",
            icon=ft.Icons.CLEANING_SERVICES_OUTLINED,
            on_click=self.limpiar_formulario,
        )

        # Campos agrupados por sección; los pares van en la misma fila
        identificacion: ft.Row = tema.fila([self._legajo, self._tipo_documento])
        nombre_completo: ft.Row = tema.fila([self._apellido, self._nombre])
        tema.estilizar(
            [
                self._legajo,
                self._tipo_documento,
                self._numero_documento,
                self._apellido,
                self._nombre,
                self._fecha_nacimiento,
            ]
        )

        formulario: ft.Column = tema.columna(
            [
                tema.columna(
                    [
                        tema.etiqueta("Identificación"),
                        identificacion,
                        self._numero_documento,
                    ]
                ),
                tema.columna(
                    [
                        tema.etiqueta("Datos personales"),
                        nombre_completo,
                        self._fecha_nacimiento,
                    ]
                ),
                ft.Divider(color=tema.COLOR_BORDE),
                tema.columna(
                    [tema.etiqueta("Acciones"), agregar, acciones, limpiar],
                    tema.ESPACIO_SM + tema.ESPACIO_XS,
                ),
                tema.panel_resultado(self._resultado),
            ],
            tema.ESPACIO_LG,
        )

        return tema.pantalla(
            tema.encabezado(
                "ABM de Alumnos",
                "Alta, baja, modificación y búsqueda de alumnos",
                ft.Icons.SCHOOL_OUTLINED,
            ),
            tema.tarjeta(formulario, ancho=540),
        )

    def _leer_alumno(self) -> Alumno:
        """Construye un alumno con los valores ingresados en el formulario.

        ``Dropdown.value`` es ``str | None`` (sin selección): se normaliza a ``str``.

        Returns:
            Alumno con los datos del formulario (sin legajo).
        """
        return Alumno(
            tipo_documento=self._tipo_documento.value or "",
            numero_documento=self._numero_documento.value.strip(),
            apellido=self._apellido.value.strip(),
            nombre=self._nombre.value.strip(),
            fecha_nacimiento=self._fecha_nacimiento.value.strip(),
        )

    def _leer_legajo(self) -> int | None:
        """Lee el legajo ingresado.

        Returns:
            El legajo como entero positivo, o ``None`` si está vacío o es inválido.
        """
        texto: str = self._legajo.value.strip()
        return int(texto) if texto.isdigit() and int(texto) > 0 else None

    def _cargar_alumno(self, alumno: Alumno) -> None:
        """Completa el formulario con los datos de un alumno.

        Args:
            alumno: Alumno cuyos datos se muestran.
        """
        self._legajo.value = str(alumno.legajo) if alumno.legajo is not None else ""
        self._tipo_documento.value = alumno.tipo_documento
        self._numero_documento.value = alumno.numero_documento
        self._apellido.value = alumno.apellido
        self._nombre.value = alumno.nombre
        self._fecha_nacimiento.value = alumno.fecha_nacimiento

    def _mostrar(self, mensaje: str) -> None:
        """Muestra un mensaje en el texto de resultado.

        Args:
            mensaje: Texto a mostrar.
        """
        self._resultado.value = mensaje

    def agregar_alumno(self) -> None:
        """Maneja el clic en "Agregar": da de alta un alumno con los datos del formulario."""
        self._mostrar(self.__business.agregar_alumno(self._leer_alumno()))

    def buscar_alumno(self) -> None:
        """Maneja el clic en "Buscar": carga el alumno con el documento ingresado."""
        numero_documento: str = self._numero_documento.value
        alumno: Alumno | None = self.__business.buscar_alumno(numero_documento)
        if alumno is None:
            self._mostrar("No existe un alumno con ese número de documento.")
            return
        self._cargar_alumno(alumno)
        self._resultado.value = f"Alumno encontrado (legajo {alumno.legajo})."

    def modificar_alumno(self) -> None:
        """Maneja el clic en "Modificar": guarda los datos del formulario en el legajo indicado."""
        legajo: int | None = self._leer_legajo()
        if legajo is None:
            self._mostrar(
                "Ingrese un legajo válido (o busque el alumno por documento)."
            )
            return
        # replace() crea una copia del dataclass inmutable con el legajo asignado
        alumno: Alumno = replace(self._leer_alumno(), legajo=legajo)
        self._mostrar(self.__business.modificar_alumno(alumno))

    def eliminar_alumno(self) -> None:
        """Maneja el clic en "Eliminar": borra el alumno del legajo indicado."""
        legajo: int | None = self._leer_legajo()
        if legajo is None:
            self._mostrar(
                "Ingrese un legajo válido (o busque el alumno por documento)."
            )
            return
        mensaje: str = self.__business.eliminar_alumno(legajo)
        self.limpiar_formulario()
        self._mostrar(mensaje)

    def limpiar_formulario(self) -> None:
        """Maneja el clic en "Limpiar": vacía todos los campos del formulario."""
        self._cargar_alumno(Alumno("", "", "", "", ""))
        self._tipo_documento.value = None  # sin opción seleccionada
        self._resultado.value = ""
