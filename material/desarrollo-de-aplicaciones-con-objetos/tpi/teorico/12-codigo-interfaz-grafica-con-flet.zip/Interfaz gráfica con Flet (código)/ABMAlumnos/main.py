"""Punto de entrada del ABM de alumnos: ``python ABMAlumnos/main.py``."""

import flet as ft

import tema
from AlumnosApp import AlumnosApp


def main(page: ft.Page) -> None:
    """Configura la ventana y agrega la vista del ABM.

    Args:
        page: Página principal que provee Flet al iniciar la aplicación.
    """
    tema.aplicar_tema(page, "ABM de Alumnos")  # incluye scroll si la ventana es chica
    page.window.width = 760
    page.window.height = 940
    alumnos_app: AlumnosApp = AlumnosApp()
    page.add(alumnos_app.vista)


if __name__ == "__main__":
    ft.run(main)
