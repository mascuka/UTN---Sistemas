"""Modelo de dominio compartido por las capas de datos, negocio y presentación."""

from dataclasses import dataclass
from typing import Self

# Fila de la tabla alumnos:
# (legajo, tipo_documento, numero_documento, apellido, nombre, fecha_nacimiento)
type FilaAlumno = tuple[int, str, str, str, str, str]


@dataclass(frozen=True, slots=True)
class Alumno:
    """Datos de un alumno.

    Agrupar los campos en una sola clase evita pasar cinco o seis parámetros
    sueltos entre capas (y el riesgo de pasarlos en el orden equivocado).

    Attributes:
        tipo_documento: Tipo de documento (DNI, Pasaporte o CUIL).
        numero_documento: Número de documento, solo dígitos.
        apellido: Apellido del alumno.
        nombre: Nombre del alumno.
        fecha_nacimiento: Fecha de nacimiento con formato AAAA-MM-DD.
        legajo: Identificador en la base; ``None`` si todavía no fue guardado.
    """

    tipo_documento: str
    numero_documento: str
    apellido: str
    nombre: str
    fecha_nacimiento: str
    legajo: int | None = None

    @classmethod
    def desde_fila(cls, fila: FilaAlumno) -> Self:
        """Crea un alumno a partir de una fila de la tabla ``alumnos``.

        Args:
            fila: Tupla en el orden de las columnas de la tabla.

        Returns:
            El alumno equivalente a la fila.
        """
        legajo, tipo_documento, numero_documento, apellido, nombre, fecha_nacimiento = (
            fila
        )
        return cls(
            tipo_documento, numero_documento, apellido, nombre, fecha_nacimiento, legajo
        )
