"""Capa de datos: acceso a la base SQLite de alumnos."""

import sqlite3
from pathlib import Path
from typing import Final

from Alumno import Alumno, FilaAlumno

# La base se ubica junto a este archivo, sin importar desde qué carpeta se ejecute el programa
RUTA_DB: Final[Path] = Path(__file__).with_name("alumnosnew.db")


class DataLayer:
    """Repositorio de alumnos persistido en SQLite."""

    def __init__(self, db_path: Path = RUTA_DB) -> None:
        """Abre la conexión y crea la tabla si todavía no existe.

        Args:
            db_path: Ruta del archivo de base de datos.
        """
        self.__conn: sqlite3.Connection = sqlite3.connect(db_path)
        self._create_tables()

    def _create_tables(self) -> None:
        """Crea la tabla ``alumnos`` si no existe."""
        # "with conn" abre una transacción: hace commit al terminar o rollback si hay error
        with self.__conn:
            self.__conn.execute("""
                CREATE TABLE IF NOT EXISTS alumnos (
                    legajo INTEGER PRIMARY KEY,
                    tipo_documento TEXT NOT NULL,
                    numero_documento TEXT NOT NULL UNIQUE,
                    apellido TEXT NOT NULL,
                    nombre TEXT NOT NULL,
                    fecha_nacimiento TEXT NOT NULL
                )
            """)

    def insert_alumno(self, alumno: Alumno) -> int:
        """Inserta un alumno nuevo.

        El legajo lo asigna SQLite (``INTEGER PRIMARY KEY`` toma el máximo + 1).

        Args:
            alumno: Alumno a insertar; su ``legajo`` se ignora.

        Returns:
            El legajo asignado al alumno.
        """
        with self.__conn:
            cursor: sqlite3.Cursor = self.__conn.execute(
                """
                INSERT INTO alumnos
                    (tipo_documento, numero_documento, apellido, nombre, fecha_nacimiento)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    alumno.tipo_documento,
                    alumno.numero_documento,
                    alumno.apellido,
                    alumno.nombre,
                    alumno.fecha_nacimiento,
                ),
            )
        legajo: int | None = cursor.lastrowid
        if legajo is None:
            msg: str = "SQLite no devolvió el legajo del alumno insertado."
            raise sqlite3.DatabaseError(msg)
        return legajo

    def buscar_alumno(self, numero_documento: str) -> Alumno | None:
        """Busca un alumno por número de documento.

        Args:
            numero_documento: Número de documento a buscar.

        Returns:
            El alumno encontrado, o ``None`` si no existe.
        """
        cursor: sqlite3.Cursor = self.__conn.execute(
            "SELECT * FROM alumnos WHERE numero_documento = ?",
            (numero_documento,),
        )
        fila: FilaAlumno | None = cursor.fetchone()
        return Alumno.desde_fila(fila) if fila is not None else None

    def update_alumno(self, alumno: Alumno) -> bool:
        """Actualiza los datos de un alumno existente según su legajo.

        Args:
            alumno: Alumno con los datos nuevos; debe tener ``legajo``.

        Returns:
            ``True`` si se modificó una fila, ``False`` si el legajo no existe.
        """
        with self.__conn:
            cursor: sqlite3.Cursor = self.__conn.execute(
                """
                UPDATE alumnos
                SET tipo_documento = ?, numero_documento = ?, apellido = ?, nombre = ?,
                    fecha_nacimiento = ?
                WHERE legajo = ?
                """,
                (
                    alumno.tipo_documento,
                    alumno.numero_documento,
                    alumno.apellido,
                    alumno.nombre,
                    alumno.fecha_nacimiento,
                    alumno.legajo,
                ),
            )
        return cursor.rowcount > 0

    def delete_alumno(self, legajo: int) -> bool:
        """Elimina un alumno por legajo.

        Args:
            legajo: Legajo del alumno a eliminar.

        Returns:
            ``True`` si se eliminó una fila, ``False`` si el legajo no existe.
        """
        with self.__conn:
            cursor: sqlite3.Cursor = self.__conn.execute(
                "DELETE FROM alumnos WHERE legajo = ?",
                (legajo,),
            )
        return cursor.rowcount > 0

    def close(self) -> None:
        """Cierra la conexión con la base de datos."""
        self.__conn.close()
