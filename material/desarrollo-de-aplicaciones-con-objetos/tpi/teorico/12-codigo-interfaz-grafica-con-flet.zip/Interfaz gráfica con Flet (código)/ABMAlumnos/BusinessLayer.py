"""Capa de negocio: validaciones y reglas del ABM de alumnos."""

from collections.abc import Callable
from datetime import datetime
from typing import Final

from Alumno import Alumno
from DataLayer import DataLayer

TIPOS_DOCUMENTO: Final[tuple[str, ...]] = ("DNI", "Pasaporte", "CUIL")
LONGITUD_MINIMA_DOCUMENTO: Final[int] = 6
FORMATO_FECHA: Final[str] = "%Y-%m-%d"

type Regla = tuple[Callable[[], bool], str]
"""Par (condición que debe cumplirse, mensaje de error si no se cumple)."""


class BusinessLayer:
    """Reglas de negocio del ABM: valida los datos antes de delegar en la capa de datos."""

    def __init__(self, data: DataLayer | None = None) -> None:
        """Inicializa la capa de negocio.

        Args:
            data: Capa de datos a utilizar. Si no se indica, se crea una por defecto
                (recibirla por parámetro permite usar otra base, por ejemplo en tests).
        """
        self.__data: DataLayer = data if data is not None else DataLayer()

    @staticmethod
    def _es_fecha_valida(texto: str) -> bool:
        """Indica si un texto es una fecha válida con formato AAAA-MM-DD.

        Args:
            texto: Fecha a validar.

        Returns:
            ``True`` si la fecha es válida.
        """
        try:
            datetime.strptime(texto, FORMATO_FECHA)
        except ValueError:
            return False
        return True

    def _documento_en_uso(self, alumno: Alumno) -> bool:
        """Indica si el documento del alumno ya pertenece a *otro* alumno.

        Al modificar, el propio alumno ya figura con ese documento: por eso se
        compara el legajo y no solo la existencia.

        Args:
            alumno: Alumno a verificar.

        Returns:
            ``True`` si otro alumno tiene el mismo número de documento.
        """
        existente: Alumno | None = self.__data.buscar_alumno(alumno.numero_documento)
        return existente is not None and existente.legajo != alumno.legajo

    def validar_datos(self, alumno: Alumno) -> str | None:
        """Valida los datos de un alumno.

        Cada regla es una lambda sin parámetros: se evalúan en orden y de forma
        perezosa, así la consulta a la base solo se hace si las anteriores pasan.

        Args:
            alumno: Alumno a validar.

        Returns:
            El mensaje del primer error encontrado, o ``None`` si los datos son válidos.
        """
        reglas: list[Regla] = [
            (
                lambda: alumno.tipo_documento in TIPOS_DOCUMENTO,
                "Tipo de documento inválido.",
            ),
            (
                lambda: (
                    alumno.numero_documento.isdigit()
                    and len(alumno.numero_documento) >= LONGITUD_MINIMA_DOCUMENTO
                ),
                "Número de documento inválido.",
            ),
            (lambda: bool(alumno.apellido.strip()), "Apellido es obligatorio."),
            (lambda: bool(alumno.nombre.strip()), "Nombre es obligatorio."),
            (
                lambda: self._es_fecha_valida(alumno.fecha_nacimiento),
                "Fecha de nacimiento inválida. Use el formato AAAA-MM-DD.",
            ),
            (
                lambda: not self._documento_en_uso(alumno),
                "Ya existe un alumno con ese número de documento.",
            ),
        ]
        return next((mensaje for cumple, mensaje in reglas if not cumple()), None)

    def buscar_alumno(self, numero_documento: str) -> Alumno | None:
        """Busca un alumno por número de documento.

        Args:
            numero_documento: Número de documento a buscar.

        Returns:
            El alumno encontrado, o ``None`` si no existe.
        """
        return self.__data.buscar_alumno(numero_documento.strip())

    def agregar_alumno(self, alumno: Alumno) -> str:
        """Valida y agrega un alumno nuevo.

        Args:
            alumno: Alumno a agregar.

        Returns:
            Mensaje con el resultado de la operación.
        """
        error: str | None = self.validar_datos(alumno)
        if error is not None:
            return error
        legajo: int = self.__data.insert_alumno(alumno)
        return f"Alumno agregado con éxito (legajo {legajo})."

    def modificar_alumno(self, alumno: Alumno) -> str:
        """Valida y modifica un alumno existente.

        Args:
            alumno: Alumno con los datos nuevos; debe tener ``legajo``.

        Returns:
            Mensaje con el resultado de la operación.
        """
        if alumno.legajo is None:
            return "Debe indicar el legajo del alumno a modificar."
        error: str | None = self.validar_datos(alumno)
        if error is not None:
            return error
        if not self.__data.update_alumno(alumno):
            return "No existe un alumno con ese legajo."
        return "Alumno modificado con éxito."

    def eliminar_alumno(self, legajo: int) -> str:
        """Elimina un alumno por legajo.

        Args:
            legajo: Legajo del alumno a eliminar.

        Returns:
            Mensaje con el resultado de la operación.
        """
        if not self.__data.delete_alumno(legajo):
            return "No existe un alumno con ese legajo."
        return "Alumno eliminado con éxito."
