"""Estilo visual compartido por los ejemplos: colores, espaciados, tema y componentes.

Solo contiene presentación (no hay lógica de los ejemplos). Centralizarlo acá
permite cambiar el aspecto de todas las pantallas desde un único lugar.
"""

from collections.abc import Sequence
from typing import Final

import flet as ft

# ---------------------------------------------------------------------
# Paleta (tema oscuro)
# ---------------------------------------------------------------------
COLOR_PRIMARIO: Final[str] = "#4F46E5"
COLOR_PRIMARIO_SUAVE: Final[str] = "#312E81"
COLOR_SECUNDARIO: Final[str] = "#94A3B8"
COLOR_EXITO: Final[str] = "#10B981"
COLOR_ERROR: Final[str] = "#EF4444"
COLOR_FONDO: Final[str] = "#0F172A"
COLOR_SUPERFICIE: Final[str] = "#1E293B"
COLOR_SUPERFICIE_ALTA: Final[str] = "#273449"
COLOR_BORDE: Final[str] = "#334155"
COLOR_TEXTO: Final[str] = "#F1F5F9"

# ---------------------------------------------------------------------
# Espaciados y medidas
# ---------------------------------------------------------------------
ESPACIO_XS: Final[int] = 4
ESPACIO_SM: Final[int] = 8
ESPACIO_MD: Final[int] = 16
ESPACIO_LG: Final[int] = 24
ESPACIO_XL: Final[int] = 32

RADIO: Final[int] = 8
RADIO_TARJETA: Final[int] = 12
ANCHO_TARJETA: Final[int] = 380
ANCHO_COMPLETO: Final[int] = 10_000


def construir_tema() -> ft.Theme:
    """Crea el tema global: color base, botones, diálogos y menús.

    Returns:
        Tema de Flet listo para asignar a ``page.theme`` y ``page.dark_theme``.
    """
    forma: ft.RoundedRectangleBorder = ft.RoundedRectangleBorder(radius=RADIO)
    relleno: ft.Padding = ft.Padding.symmetric(
        horizontal=ESPACIO_LG, vertical=ESPACIO_MD
    )
    return ft.Theme(
        color_scheme_seed=COLOR_PRIMARIO,
        scaffold_bgcolor=COLOR_FONDO,
        button_theme=ft.ButtonTheme(
            style=ft.ButtonStyle(
                bgcolor=COLOR_PRIMARIO,
                color=ft.Colors.WHITE,
                icon_color=ft.Colors.WHITE,
                shape=forma,
                padding=relleno,
                mouse_cursor=ft.MouseCursor.CLICK,
            )
        ),
        outlined_button_theme=ft.OutlinedButtonTheme(
            style=ft.ButtonStyle(
                color=COLOR_TEXTO,
                side=ft.BorderSide(1, COLOR_BORDE),
                shape=forma,
                padding=relleno,
                mouse_cursor=ft.MouseCursor.CLICK,
            )
        ),
        text_button_theme=ft.TextButtonTheme(
            style=ft.ButtonStyle(shape=forma, mouse_cursor=ft.MouseCursor.CLICK)
        ),
        slider_theme=ft.SliderTheme(
            active_track_color=COLOR_PRIMARIO,
            inactive_track_color=COLOR_BORDE,
            thumb_color=COLOR_PRIMARIO,
            value_indicator_color=COLOR_PRIMARIO,
        ),
        dialog_theme=ft.DialogTheme(
            bgcolor=COLOR_SUPERFICIE,
            shape=ft.RoundedRectangleBorder(radius=RADIO_TARJETA),
        ),
        popup_menu_theme=ft.PopupMenuTheme(
            color=COLOR_SUPERFICIE_ALTA,
            shape=forma,
            menu_position=ft.PopupMenuPosition.UNDER,
            mouse_cursor=ft.MouseCursor.CLICK,
        ),
    )


def aplicar_tema(page: ft.Page, titulo: str) -> None:
    """Configura la página: título, tema oscuro y contenido centrado.

    Args:
        page: Página principal de la aplicación.
        titulo: Título de la ventana.
    """
    page.title = titulo
    page.theme = construir_tema()
    page.dark_theme = construir_tema()
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = COLOR_FONDO
    page.padding = ESPACIO_LG
    page.scroll = ft.ScrollMode.AUTO
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER


def encabezado(titulo: str, subtitulo: str, icono: ft.IconData) -> ft.Column:
    """Crea el encabezado de una pantalla: ícono, título y subtítulo centrados.

    Args:
        titulo: Texto principal.
        subtitulo: Texto descriptivo debajo del título.
        icono: Ícono que acompaña al título.

    Returns:
        Columna con el encabezado.
    """
    return ft.Column(
        [
            ft.Container(
                ft.Icon(icono, color=ft.Colors.WHITE, size=28),
                bgcolor=COLOR_PRIMARIO,
                border_radius=RADIO_TARJETA,
                padding=ESPACIO_MD - ESPACIO_XS,
            ),
            ft.Text(titulo, size=26, weight=ft.FontWeight.BOLD, color=COLOR_TEXTO),
            ft.Text(
                subtitulo,
                size=14,
                color=COLOR_SECUNDARIO,
                text_align=ft.TextAlign.CENTER,
            ),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=ESPACIO_SM,
    )


def pantalla(*controles: ft.Control) -> ft.Column:
    """Agrupa los bloques principales de una pantalla, centrados horizontalmente.

    Args:
        controles: Bloques a mostrar (encabezado, tarjetas, etc.), de arriba a abajo.

    Returns:
        Columna centrada con separación amplia entre bloques.
    """
    return ft.Column(
        list(controles),
        spacing=ESPACIO_LG,
        tight=True,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )


def columna(controles: list[ft.Control], espacio: int = ESPACIO_MD) -> ft.Column:
    """Crea una columna cuyos controles ocupan todo el ancho disponible.

    Args:
        controles: Controles a apilar.
        espacio: Separación vertical entre controles.

    Returns:
        La columna configurada.
    """
    return ft.Column(
        controles,
        spacing=espacio,
        tight=True,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )


def fila(controles: list[ft.Control]) -> ft.Row:
    """Ubica controles uno al lado del otro, repartiendo el ancho en partes iguales.

    Args:
        controles: Controles a ubicar en la fila.

    Returns:
        La fila configurada.
    """
    control: ft.Control
    for control in controles:
        control.expand = True
    return ft.Row(controles, spacing=ESPACIO_MD)


def tarjeta(contenido: ft.Control, ancho: int = ANCHO_TARJETA) -> ft.Container:
    """Envuelve un contenido en una tarjeta con fondo, bordes redondeados y sombra.

    Args:
        contenido: Control que va dentro de la tarjeta.
        ancho: Ancho de la tarjeta en píxeles.

    Returns:
        El contenedor con estilo de tarjeta.
    """
    return ft.Container(
        contenido,
        width=ancho,
        padding=ESPACIO_LG,
        bgcolor=COLOR_SUPERFICIE,
        border_radius=RADIO_TARJETA,
        border=ft.Border.all(1, COLOR_BORDE),
        shadow=ft.BoxShadow(
            blur_radius=24, color=ft.Colors.with_opacity(0.35, "#000000")
        ),
    )


def etiqueta(texto: str) -> ft.Text:
    """Crea un rótulo de sección en mayúsculas y color tenue.

    Args:
        texto: Texto del rótulo.

    Returns:
        El texto con estilo de rótulo.
    """
    return ft.Text(
        texto.upper(),
        size=11,
        weight=ft.FontWeight.W_600,
        color=COLOR_SECUNDARIO,
    )


def panel_resultado(texto: ft.Text) -> ft.Container:
    """Muestra un texto de salida dentro de un recuadro destacado.

    Args:
        texto: Control de texto donde la lógica escribe el resultado.

    Returns:
        El recuadro que contiene al texto.
    """
    texto.color = COLOR_TEXTO
    texto.size = 15
    return ft.Container(
        ft.Row(
            [
                ft.Icon(ft.Icons.INFO_OUTLINE, color=COLOR_PRIMARIO, size=20),
                ft.Container(texto, expand=True),
            ],
            spacing=ESPACIO_SM + ESPACIO_XS,
        ),
        padding=ESPACIO_MD,
        bgcolor=COLOR_SUPERFICIE_ALTA,
        border_radius=RADIO,
        border=ft.Border.only(left=ft.BorderSide(3, COLOR_PRIMARIO)),
    )


def estilizar[T: Sequence[ft.Control]](controles: T) -> T:
    """Aplica el estilo de los campos de entrada (bordes redondeados y colores).

    Los controles que no son campos de entrada se dejan sin cambios.

    Args:
        controles: Controles a estilizar.

    Returns:
        Los mismos controles recibidos, para poder usarla en línea.
    """
    control: ft.Control
    for control in controles:
        if isinstance(control, ft.TextField):
            control.border_radius = RADIO
            control.border_color = COLOR_BORDE
            control.focused_border_color = COLOR_PRIMARIO
        elif isinstance(control, ft.Dropdown):
            control.border_radius = RADIO
            control.border_color = COLOR_BORDE
            control.focused_border_color = COLOR_PRIMARIO
            control.bgcolor = COLOR_SUPERFICIE_ALTA  # fondo del menú desplegado
            if not control.expand:
                # El Dropdown no se estira solo: un ancho mayor al disponible hace que
                # el contenedor lo recorte y termine ocupando todo el ancho
                control.width = ANCHO_COMPLETO
    return controles
