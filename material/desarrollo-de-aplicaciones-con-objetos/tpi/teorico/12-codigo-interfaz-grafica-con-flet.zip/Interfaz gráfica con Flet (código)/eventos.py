"""Ejemplos de manejo de eventos en Flet: click, cambio de texto, dropdown y slider."""

from typing import Final

import flet as ft

import tema

OPCIONES: Final[tuple[str, ...]] = ("Opción 1", "Opción 2", "Opción 3")


def main(page: ft.Page) -> None:
    """Construye la página con un control por cada tipo de evento.

    En Flet 1.0 la página se actualiza sola al terminar cada manejador de evento,
    por eso no hace falta llamar a ``page.update()``.

    Args:
        page: Página principal que provee Flet al iniciar la aplicación.
    """
    tema.aplicar_tema(page, "Ejemplos de Eventos en Flet")

    # Label para mostrar el resultado de los eventos
    output_text: ft.Text = ft.Text(value="Interactuá con algún control...")

    def mostrar(mensaje: str) -> None:
        """Muestra un mensaje en el label de salida.

        Args:
            mensaje: Texto a mostrar.
        """
        output_text.value = mensaje

    # Botón con evento de click (los callbacks de Flet 1.0 aceptan lambdas sin parámetros)
    button: ft.Button = ft.Button(
        "Haz clic aquí",
        icon=ft.Icons.TOUCH_APP,
        on_click=lambda: mostrar("¡Botón clicado!"),
    )

    # Campo de texto con evento de cambio de texto
    text_field: ft.TextField = ft.TextField(
        label="Escribe algo",
        prefix_icon=ft.Icons.EDIT_OUTLINED,
        on_change=lambda: mostrar(f"Texto ingresado: {text_field.value}"),
    )

    # Dropdown (ComboBox) con evento de selección
    dropdown: ft.Dropdown = ft.Dropdown(
        label="Selecciona una opción",
        options=[ft.DropdownOption(opcion) for opcion in OPCIONES],
        on_select=lambda: mostrar(f"Opción seleccionada: {dropdown.value}"),
    )

    # Slider con evento de cambio de valor
    slider: ft.Slider = ft.Slider(
        min=0,
        max=100,
        divisions=10,
        label="{value}",
        on_change=lambda: mostrar(f"Valor del slider: {slider.value}"),
    )

    # Agregar controles a la página: cada control en su sección dentro de una tarjeta
    page.add(
        tema.pantalla(
            tema.encabezado(
                "Eventos en Flet",
                "Cada control dispara un evento que se refleja en el resultado",
                ft.Icons.BOLT,
            ),
            tema.tarjeta(
                tema.columna(
                    [
                        tema.columna([tema.etiqueta("Click"), button], tema.ESPACIO_SM),
                        tema.columna(
                            [
                                tema.etiqueta("Cambio de texto"),
                                *tema.estilizar([text_field]),
                            ],
                            tema.ESPACIO_SM,
                        ),
                        tema.columna(
                            [tema.etiqueta("Selección"), *tema.estilizar([dropdown])],
                            tema.ESPACIO_SM,
                        ),
                        tema.columna(
                            [tema.etiqueta("Slider"), slider], tema.ESPACIO_XS
                        ),
                        ft.Divider(color=tema.COLOR_BORDE),
                        tema.panel_resultado(output_text),
                    ],
                    tema.ESPACIO_LG,
                ),
                ancho=420,
            ),
        )
    )


if __name__ == "__main__":
    ft.run(main)
