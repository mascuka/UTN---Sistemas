from observer import Subject, Observer


class ListaPrecios(Subject):
    def __init__(self):
        super().__init__()


class Cliente(Observer):
    def __init__(self, nombre: str):
        super().__init__()
        self.nombre = nombre

    def update(self):
        print(f"Nombre: {self.nombre}. LISTA DE PRECIOS ACTUALIZADA.")


# Ahora utilizamos el Sujeto
# y el Observador
lista = ListaPrecios()
cliente1 = Cliente("Martin")
cliente2 = Cliente("Ivan")
cliente3 = Cliente("Analia")

lista.attach(cliente1)
lista.attach(cliente2)
lista.attach(cliente3)

lista.notify()
