"""Ejemplos de aplicación del patrón Observer"""

from abc import ABC, abstractmethod


class Subject:
    def __init__(self):
        self._observers = []

    def attach(self, observer):
        self._observers.append(observer)

    def notify(self):
        for observer in self._observers:
            observer.update()


class Observer(ABC):
    @abstractmethod
    def update(self):
        """
        Todas las clases derivadas deben definir este
        método, para poder recibir notificaciones de actualización
        """
        pass


class ConcreteObserver(Observer):
    def update(self):
        print("ConcreteObserver received an update")
