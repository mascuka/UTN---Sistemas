from abc import abstractmethod


# Observer (Suscriptor)
class Observer:
    @abstractmethod
    def update(self, data):
        pass


# Sujeto (Publisher)
class Subject:
    def __init__(self):
        self._observers = []
        self._data = None

    def attach(self, observer):
        self._observers.append(observer)

    def detach(self, observer):
        self._observers.remove(observer)

    def notify(self):
        for observer in self._observers:
            observer.update(self._data)

    def set_data(self, data):
        self._data = data
        self.notify()
