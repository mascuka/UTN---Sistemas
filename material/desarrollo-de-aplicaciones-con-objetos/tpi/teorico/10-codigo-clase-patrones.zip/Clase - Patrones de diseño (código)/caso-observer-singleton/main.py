import dearpygui.dearpygui as dpg
from observer import Subject
from windobserver import WindowObserver


def main():
    server = Subject()

    def button_click(sender, data):
        server.set_data("Click en el boton")

    def input_type(sender, data):
        server.set_data(f"Input: {data}")

    def slider_slide(sender, data):
        server.set_data(f"Slider: {data}")

    w1 = WindowObserver("Ventana 1", subject=server)
    w2 = WindowObserver("Ventana 2", subject=server)
    w3 = WindowObserver("Ventana 3", subject=server)

    dpg.create_context()

    dpg.create_viewport(title="Ventana principal", width=600, height=300)

    with dpg.window(label="Ventana server"):
        dpg.add_text("Hola mundo")
        dpg.add_button(label="Picar botoncito", callback=button_click)
        dpg.add_input_text(
            label="string", default_value="Quick brown fox", callback=input_type
        )
        dpg.add_slider_float(
            label="float", default_value=0.273, max_value=1, callback=slider_slide
        )

    dpg.setup_dearpygui()
    dpg.show_viewport()
    dpg.start_dearpygui()
    dpg.destroy_context()


if __name__ == "__main__":
    dpg.create_context()
    main()
