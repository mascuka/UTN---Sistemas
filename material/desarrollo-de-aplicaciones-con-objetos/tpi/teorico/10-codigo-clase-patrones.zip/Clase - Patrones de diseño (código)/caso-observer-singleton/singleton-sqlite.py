from database import DatabaseSingleton


# Función para crear la tabla de personas e insertar datos iniciales
def initialize_personas_data():
    db = DatabaseSingleton()

    # Crear la tabla si no existe
    create_table_query = """
    CREATE TABLE IF NOT EXISTS personas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        edad INTEGER
    );
    """
    db.execute_query(create_table_query)

    # Insertar datos iniciales
    personas_iniciales = [("Juan", 28), ("María", 22), ("Carlos", 35), ("Ana", 30)]

    insert_person_query = "INSERT INTO personas (nombre, edad) VALUES (?, ?);"

    for persona in personas_iniciales:
        db.execute_query(insert_person_query, persona)

    print("Datos iniciales insertados en la tabla 'personas'")


# Ejemplo de uso
if __name__ == "__main__":
    # Inicializar los datos de la tabla personas
    initialize_personas_data()

    # Verificar los datos insertados
    db = DatabaseSingleton()
    select_query = "SELECT * FROM personas;"
    personas = db.fetch_query(select_query)
    for persona in personas:
        print(persona)

    # Cerrar la conexión
    db.close_connection()

    select_query = "SELECT * FROM personas;"
    personas = db.fetch_query(select_query)
    for persona in personas:
        print(persona)
