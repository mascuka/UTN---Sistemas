import dearpygui.dearpygui as dpg
from observer import Observer
from random import randint


# Custom Window class that acts as an observer
class WindowObserver(Observer):
    def __init__(self, window_title, subject):
        self.subject = subject
        self.window_title = window_title
        self.text_element = None
        self.create_window()
        self.attach_to_subject()

    def create_window(self):
        # Create a new Dear PyGui window for this observer
        with dpg.window(
            label=self.window_title,
            width=300,
            height=200,
            pos=(randint(0, 500), randint(0, 500)),
        ) as window_id:
            self.text_element = dpg.add_text(
                f"{self.window_title}: Waiting for updates..."
            )

    def update(self, data):
        # Update window content when notified
        dpg.set_value(self.text_element, f"{self.window_title}: {data}")

    def attach_to_subject(self):
        self.subject.attach(self)

    def detach_from_subject(self):
        self.subject.detach(self)
