class DBConnection:
    _instance = None
    dbconnection = None

    def __new__(cls, connection_string: str):
        if not cls._instance:
            cls._instance = super(DBConnection, cls).__new__(cls)
            cls.dbconnection = connection_string
        return cls._instance


db = DBConnection("sqlserver:usuario@localhost/DBMAIN")
print(db.dbconnection)

db2 = DBConnection("oracle:otro_usuario@servidor/DATABASE")
print(db2.dbconnection)

db3 = DBConnection("")
print(db3.dbconnection)
