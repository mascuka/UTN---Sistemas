class Ascensor:
    def __init__(self, capacidad, piso_minimo, piso_maximo):
        self._capacidad = capacidad
        self._piso_minimo = piso_minimo
        self._piso_maximo = piso_maximo
        self._piso = 0
        self._personas = 0

    def ir_a(self, piso):
        """Devuelve True si el piso existe (y va hasta ahí), False si no."""
        if self._piso_minimo <= piso <= self._piso_maximo:
            self._piso = piso
            return True
        return False

    def subir(self, cantidad):
        """Devuelve cuántas personas entraron, o -1 si la cantidad no es válida."""
        if cantidad <= 0:
            return -1
        entran = min(cantidad, self._capacidad - self._personas)
        self._personas += entran
        return entran

    def bajar(self, cantidad):
        """Devuelve cuántas personas bajaron, o -1 si la cantidad no es válida."""
        if cantidad <= 0:
            return -1
        salen = min(cantidad, self._personas)
        self._personas -= salen
        return salen

    def __str__(self):          # el "toString" del enunciado
        return f"Piso {self._piso} con {self._personas} persona(s) adentro"
