from ascensor import Ascensor


def main():
    asc = Ascensor(capacidad=8, piso_minimo=-2, piso_maximo=10)
    print(asc)
    print("Subir 5 ->", asc.subir(5), "|", asc)
    print("Subir 6 ->", asc.subir(6), "| solo entran 3 |", asc)
    print("Ir al piso 7 ->", asc.ir_a(7), "|", asc)
    print("Ir al piso 15 ->", asc.ir_a(15), "| no existe |", asc)
    print("Bajar 3 ->", asc.bajar(3), "|", asc)
    print("Bajar 10 ->", asc.bajar(10), "| bajan todos |", asc)
    print("Subir -2 ->", asc.subir(-2), "| cantidad no válida")


if __name__ == "__main__":
    main()
