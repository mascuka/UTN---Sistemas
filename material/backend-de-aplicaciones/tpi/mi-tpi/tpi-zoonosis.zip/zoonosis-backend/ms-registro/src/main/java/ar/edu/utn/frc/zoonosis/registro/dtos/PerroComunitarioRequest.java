package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Body de POST /api/v1/perros/comunitarios (RF07): un perro sin tutor que da de alta el personal.
 * Dónde vive: la calle y un número aproximado (sirven para validar Villa Allende y calcular la zona del mapa)
 * y una referencia en palabras. No se piden coordenadas: solo si esa dirección no se puede ubicar en el mapa,
 * el personal puede indicar latitud y longitud en "ubicacion".
 */
public record PerroComunitarioRequest(

        @NotBlank(message = "Nombre inválido: el nombre es obligatorio (puede ser el apodo del barrio)")
        @Size(max = 60, message = "Nombre inválido: el nombre puede tener hasta 60 caracteres")
        String nombre,

        // Tiene que estar en el listado de Zoonosis (tabla raza): lo controla RazaService (422)
        @NotBlank(message = "Raza inválida: la raza es obligatoria (si es una cruza, Mestizo; si no se sabe, No identificada)")
        @Size(max = 60, message = "Raza inválida: la raza puede tener hasta 60 caracteres")
        String raza,

        @NotNull(message = "Sexo inválido: el sexo es obligatorio (MACHO o HEMBRA)")
        Sexo sexo,

        @NotNull(message = "Fecha de nacimiento inválida: la fecha de nacimiento estimada es obligatoria")
        @PastOrPresent(message = "Fecha de nacimiento inválida: la fecha de nacimiento no puede ser futura")
        LocalDate fechaNacimiento,

        @NotNull(message = "Peso inválido: el peso es obligatorio")
        @Positive(message = "Peso inválido: el peso tiene que ser mayor a 0")
        @Digits(integer = 3, fraction = 2, message = "Peso inválido: el peso puede tener hasta 3 enteros y 2 decimales")
        BigDecimal pesoKg,

        boolean castrado,

        @NotBlank(message = "Calle inválida: la calle donde vive el perro es obligatoria")
        @Size(max = 120, message = "Calle inválida: la calle puede tener hasta 120 caracteres")
        String calle,

        @NotNull(message = "Altura inválida: la altura aproximada es obligatoria")
        @Positive(message = "Altura inválida: la altura tiene que ser mayor a 0")
        Integer altura,

        @NotBlank(message = "Referencia inválida: indicá dónde vive el perro (por ejemplo, plaza frente a la escuela)")
        @Size(max = 200, message = "Referencia inválida: la referencia puede tener hasta 200 caracteres")
        String referenciaUbicacion,

        @Valid
        UbicacionRequest ubicacion
) { }
