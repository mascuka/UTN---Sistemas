package ar.edu.utn.frc.zoonosis.registro.clients;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Habla con la API pública Georef (Gobierno nacional): dice si una calle existe en Villa Allende
 * y cuál es su nombre oficial (RN03 y RN18), y si un punto cae dentro del municipio.
 * Si Georef no responde, tarda demasiado o devuelve algo inesperado, lanza ServicioNoDisponibleException:
 * cada service decide qué hacer (el del tutor guarda el domicilio como SIN_VERIFICAR).
 */
@Component
public class GeorefClient {

    // Id oficial del municipio de Villa Allende en Georef
    private static final String MUNICIPIO_VILLA_ALLENDE = "140175";

    private final RestClient georef;

    // Hay varios RestClient (Georef, OpenStreetMap y sanidad): @Qualifier indica cuál va acá
    public GeorefClient(@Qualifier("georefRestClient") RestClient georef) {
        this.georef = georef;
    }

    /** Busca la calle en Villa Allende. Devuelve su nombre oficial, o vacío si no existe. */
    public Optional<String> buscarCalle(String calle) {
        RespuestaCalles respuesta;
        try {
            respuesta = georef.get()
                    .uri(uri -> uri.path("/calles")
                            .queryParam("nombre", calle)
                            .queryParam("provincia", "cordoba")
                            .queryParam("departamento", "colon")
                            .queryParam("localidad_censal", "villa allende")
                            .queryParam("max", 1)
                            .build())
                    .retrieve()
                    .body(RespuestaCalles.class);
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("Georef no responde", e);
        }
        if (respuesta == null || respuesta.calles() == null) {
            throw new ServicioNoDisponibleException("Georef devolvió una respuesta inesperada");
        }
        return respuesta.calles().stream().findFirst().map(Calle::nombre);
    }

    /**
     * ¿La latitud y longitud caen dentro del municipio de Villa Allende? Usa el límite oficial del municipio
     * (Georef /ubicacion). Solo se llama cuando el personal indica la ubicación a mano.
     */
    public boolean estaEnVillaAllende(BigDecimal latitud, BigDecimal longitud) {
        RespuestaUbicacion respuesta;
        try {
            respuesta = georef.get()
                    .uri(uri -> uri.path("/ubicacion")
                            .queryParam("lat", latitud)
                            .queryParam("lon", longitud)
                            .build())
                    .retrieve()
                    .body(RespuestaUbicacion.class);
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("Georef no responde", e);
        }
        if (respuesta == null || respuesta.ubicacion() == null) {
            throw new ServicioNoDisponibleException("Georef devolvió una respuesta inesperada");
        }
        // Fuera de todo municipio (zona rural) Georef devuelve el municipio con el id vacío
        Municipio municipio = respuesta.ubicacion().municipio();
        return municipio != null && MUNICIPIO_VILLA_ALLENDE.equals(municipio.id());
    }

    // Solo los campos de la respuesta de Georef que usamos (el resto se ignora)
    record RespuestaCalles(Integer cantidad, List<Calle> calles) { }
    record Calle(String nombre) { }
    record RespuestaUbicacion(Lugar ubicacion) { }
    record Lugar(Municipio municipio) { }
    record Municipio(String id, String nombre) { }
}
