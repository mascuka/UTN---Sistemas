package ar.edu.utn.frc.zoonosis.registro.dtos;

import java.math.BigDecimal;

/**
 * Una zona del mapa de calor público (RF12): el centro de la zona y cuántos perros tiene.
 * Nunca lleva domicilios ni coordenadas exactas (RN14).
 */
public record PerrosPorZonaResponse(String zonaId, BigDecimal lat, BigDecimal lon, Long cantidad) { }
