package ar.edu.utn.frc.zoonosis.registro.dtos;

/**
 * Respuesta del alta de un perro comunitario: el código con el que quedó en el padrón.
 */
public record PerroCreadoResponse(String codigo) { }
