package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Respuesta al vecino cuando envía una solicitud: el número, el estado (siempre PENDIENTE), cuándo la mandó,
 * el perro como quedó registrado (con la raza como figura en el listado) y los avisos para él
 * (por ejemplo, antirrábica vencida). Las alertas internas no salen acá.
 */
public record SolicitudCreadaResponse(
        Long id,
        EstadoSolicitud estado,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaCreacion,
        SolicitudResponse.PerroDeclarado perro,
        List<String> avisos  // solo si hay alguno
) {

    public static SolicitudCreadaResponse desde(Solicitud solicitud, List<String> avisos) {
        return new SolicitudCreadaResponse(
                solicitud.getId(),
                solicitud.getEstado(),
                solicitud.getFechaCreacion(),
                SolicitudResponse.PerroDeclarado.de(solicitud),
                avisos.isEmpty() ? null : avisos);  // sin avisos no se manda la lista vacía
    }
}
