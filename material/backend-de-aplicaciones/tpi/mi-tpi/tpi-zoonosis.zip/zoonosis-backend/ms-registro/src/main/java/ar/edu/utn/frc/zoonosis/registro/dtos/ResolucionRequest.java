package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Body de PATCH /api/v1/solicitudes/{id}: APROBADA, OBSERVADA o RECHAZADA (cambia solo el estado de la solicitud).
 * El mensaje es para el vecino; que sea obligatorio al observar o rechazar lo controla SolicitudService.
 * La ubicación es opcional: solo se usa al aprobar, si el domicilio del tutor no se puede ubicar en el mapa.
 */
public record ResolucionRequest(

        @NotNull(message = "Estado inválido: el estado es obligatorio (APROBADA, OBSERVADA o RECHAZADA)")
        EstadoSolicitud estado,

        @Size(max = 500, message = "Mensaje inválido: el mensaje puede tener hasta 500 caracteres")
        String mensaje,

        @Valid // si viene, se validan también la latitud y la longitud de adentro
        UbicacionRequest ubicacion
) { }
