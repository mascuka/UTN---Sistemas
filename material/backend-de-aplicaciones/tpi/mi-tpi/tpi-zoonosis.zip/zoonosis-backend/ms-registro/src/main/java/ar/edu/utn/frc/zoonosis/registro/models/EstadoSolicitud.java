package ar.edu.utn.frc.zoonosis.registro.models;

public enum EstadoSolicitud {
    PENDIENTE,
    OBSERVADA,
    APROBADA,
    RECHAZADA
}
