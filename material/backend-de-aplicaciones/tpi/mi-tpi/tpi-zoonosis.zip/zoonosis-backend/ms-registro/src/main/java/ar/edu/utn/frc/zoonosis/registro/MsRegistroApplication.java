package ar.edu.utn.frc.zoonosis.registro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Busca clases de Spring en este servicio y también en el componente común (el manejador de errores)
@SpringBootApplication(scanBasePackages = {"ar.edu.utn.frc.zoonosis.registro", "ar.edu.utn.frc.zoonosis.commons"})
public class MsRegistroApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsRegistroApplication.class, args);
    }
}
