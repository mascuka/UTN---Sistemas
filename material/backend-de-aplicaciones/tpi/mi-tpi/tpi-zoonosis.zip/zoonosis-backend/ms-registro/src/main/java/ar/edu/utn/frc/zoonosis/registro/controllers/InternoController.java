package ar.edu.utn.frc.zoonosis.registro.controllers;

import ar.edu.utn.frc.zoonosis.registro.dtos.VerificacionPerroResponse;
import ar.edu.utn.frc.zoonosis.registro.services.PerroService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints internos: solo los llama ms-sanidad dentro de la red de Docker.
 * El gateway no tiene ruta hacia /internal/**, y además piden token (el del veterinario, propagado).
 */
@RestController
@RequestMapping("/internal/perros")
public class InternoController {

    private final PerroService perroService;

    public InternoController(PerroService perroService) {
        this.perroService = perroService;
    }

    // P2: antes de registrar una vacuna, sanidad confirma que el perro existe y que el DNI coincide.
    // El dni es opcional porque los comunitarios no tienen tutor
    @GetMapping("/{codigo}/verificacion")
    public ResponseEntity<VerificacionPerroResponse> verificar(@PathVariable String codigo,
                                                               @RequestParam(required = false) String dni) {
        return ResponseEntity.ok(perroService.verificar(codigo, dni));
    }
}
