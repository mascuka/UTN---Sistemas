package ar.edu.utn.frc.zoonosis.registro.controllers;

import ar.edu.utn.frc.zoonosis.registro.config.Roles;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroComunitarioRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroCreadoResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroFichaResponse;
import ar.edu.utn.frc.zoonosis.registro.services.PerroService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

/**
 * Endpoints del padrón de perros. Solo maneja HTTP: la lógica está en PerroService.
 */
@RestController
@RequestMapping("/api/v1/perros")
public class PerroController {

    private final PerroService perroService;

    public PerroController(PerroService perroService) {
        this.perroService = perroService;
    }

    // RF14 (personal): el padrón completo, o los perros de una persona con ?dniTutor=.
    // RF15 (veterinario): con ?dniTutor=, los perros de esa persona, solo con datos de los perros (RN12).
    // RF04 (vecino): sus perros con el estado de la antirrábica. El usuario sale del token (RN04)
    @GetMapping
    public ResponseEntity<List<?>> listar(@RequestParam(required = false) String dniTutor,
                                          @AuthenticationPrincipal Jwt jwt, Authentication usuario) {
        if (Roles.esPersonal(usuario)) {
            return ResponseEntity.ok(perroService.padron(dniTutor));
        }
        if (Roles.esVeterinario(usuario) && dniTutor != null && !dniTutor.isBlank()) {
            return ResponseEntity.ok(perroService.paraVeterinario(dniTutor, jwt.getClaimAsString("preferred_username")));
        }
        // Un veterinario sin DNI cae acá: también es vecino y ve sus propios perros
        return ResponseEntity.ok(perroService.delVecino(jwt.getSubject()));
    }

    // RF08: la ficha. El personal ve cualquier perro; el vecino solo los suyos (403). 404 si no está en el padrón
    @GetMapping("/{codigo}")
    public ResponseEntity<PerroFichaResponse> ficha(@PathVariable String codigo, @AuthenticationPrincipal Jwt jwt,
                                                    Authentication usuario) {
        String soloDe = Roles.esPersonal(usuario) ? null : jwt.getSubject();
        return ResponseEntity.ok(perroService.ficha(codigo, soloDe));
    }

    // RF07 (personal): alta de un perro comunitario. 201 {codigo} · 422 calle fuera de Villa Allende o que no se ubica · 503
    @PostMapping("/comunitarios")
    public ResponseEntity<PerroCreadoResponse> altaComunitario(@Valid @RequestBody PerroComunitarioRequest datos) {
        PerroCreadoResponse creado = perroService.altaComunitario(datos);
        return ResponseEntity.created(URI.create("/api/v1/perros/" + creado.codigo())).body(creado);
    }
}
