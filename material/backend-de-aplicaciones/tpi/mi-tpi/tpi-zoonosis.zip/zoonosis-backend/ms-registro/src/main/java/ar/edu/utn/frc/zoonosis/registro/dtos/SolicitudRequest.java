package ar.edu.utn.frc.zoonosis.registro.dtos;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDate;

/**
 * Body de POST /api/v1/solicitudes. Solo trae los datos del perro:
 * los del tutor ya están cargados (RF01) y salen del token.
 */
public record SolicitudRequest(

        // @Valid hace que también se validen los campos de adentro de "perro"
        @NotNull(message = "Perro inválido: faltan los datos del perro")
        @Valid
        PerroDatosRequest perro,

        // Opcional: si no se sabe o el perro nunca fue vacunado, viene vacía
        @PastOrPresent(message = "Fecha de la antirrábica inválida: la fecha de la antirrábica no puede ser futura")
        LocalDate fechaUltimaAntirrabica
) { }
