package ar.edu.utn.frc.zoonosis.registro.config;

import ar.edu.utn.frc.zoonosis.commons.security.PropagarTokenInterceptor;
import ar.edu.utn.frc.zoonosis.commons.trazabilidad.PropagarIdPedidoInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * Clientes HTTP para hablar con otros sistemas. Cada uno tiene su URL y tiempos máximos de espera,
 * así una API caída no deja al servicio colgado.
 */
@Configuration
public class RestClientConfig {

    // API pública Georef (calles y municipios): 5 segundos para responder
    @Bean
    public RestClient georefRestClient(@Value("${georef.url}") String url) {
        return RestClient.builder()
                .baseUrl(url)
                .requestFactory(tiempos(5000))
                .build();
    }

    // OpenStreetMap (Nominatim): ubica una calle y número en el mapa. 5 segundos para responder.
    // Sus reglas de uso piden que cada aplicación se identifique en el User-Agent (y no más de un pedido por segundo)
    @Bean
    public RestClient openStreetMapRestClient(@Value("${osm.url}") String url) {
        return RestClient.builder()
                .baseUrl(url)
                .defaultHeader("User-Agent", "zoonosis-villa-allende/1.0")
                .requestFactory(tiempos(5000))
                .build();
    }

    // ms-sanidad (endpoints internos). Reenvía el token del usuario que hizo el pedido y el id del pedido.
    // 10 segundos: el primer pedido a un servicio recién arrancado puede tardar varios segundos
    @Bean
    public RestClient sanidadRestClient(@Value("${sanidad.url}") String url) {
        return RestClient.builder()
                .baseUrl(url)
                .requestFactory(tiempos(10000))
                .requestInterceptor(new PropagarTokenInterceptor())
                .requestInterceptor(new PropagarIdPedidoInterceptor())
                .build();
    }

    private SimpleClientHttpRequestFactory tiempos(int milisegundosParaResponder) {
        SimpleClientHttpRequestFactory tiempos = new SimpleClientHttpRequestFactory();
        tiempos.setConnectTimeout(3000); // 3 segundos para conectar
        tiempos.setReadTimeout(milisegundosParaResponder);
        return tiempos;
    }
}
