package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Una solicitud vista por el personal de Zoonosis (RF05 y RF06), agrupada en lo que necesita para resolverla:
 * el perro declarado, quién lo pide y las alertas. Nunca se le devuelve al vecino (para él está MiSolicitudResponse).
 * Los campos que no tienen valor (por ejemplo, el mensaje antes de resolverla) no salen en el JSON.
 */
public record SolicitudResponse(
        Long id,
        EstadoSolicitud estado,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaCreacion,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaResolucion,  // solo si ya se resolvió
        String mensajeZoonosis,  // solo si se observó o rechazó
        String codigoPerro,      // solo si se aprobó: el código del perro en el padrón
        Alertas alertas,         // solo si aplica alguna
        PerroDeclarado perro,
        TutorSolicitante tutor
) {

    // Los datos del perro que declaró el vecino. Lo usan también las respuestas al vecino
    // (SolicitudCreadaResponse y MiSolicitudResponse), así el perro sale igual en todas.
    public record PerroDeclarado(
            String nombre,
            String raza,
            Sexo sexo,
            @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaNacimiento,
            BigDecimal pesoKg,
            boolean castrado,
            @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaUltimaAntirrabica
    ) {
        public static PerroDeclarado de(Solicitud solicitud) {
            return new PerroDeclarado(
                    solicitud.getNombrePerro(),
                    solicitud.getRazaPerro(),
                    solicitud.getSexoPerro(),
                    solicitud.getFechaNacimientoPerro(),
                    solicitud.getPesoKgPerro(),
                    solicitud.isCastradoPerro(),
                    solicitud.getFechaUltimaAntirrabica());
        }
    }

    // Quién lo pide: lo que hace falta para validar la solicitud (el teléfono y el email están en la ficha del perro)
    public record TutorSolicitante(String dni, String nombre, String domicilio) { }

    /**
     * Alertas para el personal. No se guardan: las calcula SolicitudService al mostrar la solicitud.
     * Solo sale en true la que aplica; las demás quedan en null y no aparecen en el JSON.
     * posiblePpp: RN06 · antirrabicaVencida: RN07 · domicilioSinVerificar: RN03 (Georef no respondió al cargarlo)
     */
    public record Alertas(Boolean posiblePpp, Boolean antirrabicaVencida, Boolean domicilioSinVerificar) {

        // Si no aplica ninguna no hay alertas (null): el campo no sale en el JSON
        public static Alertas de(boolean posiblePpp, boolean antirrabicaVencida, boolean domicilioSinVerificar) {
            if (!posiblePpp && !antirrabicaVencida && !domicilioSinVerificar) {
                return null;
            }
            return new Alertas(siAplica(posiblePpp), siAplica(antirrabicaVencida), siAplica(domicilioSinVerificar));
        }

        private static Boolean siAplica(boolean alerta) {
            return alerta ? Boolean.TRUE : null;
        }

        // Para el log: solo los nombres de las que aplican, por ejemplo "posiblePpp, antirrabicaVencida"
        @Override
        public String toString() {
            List<String> nombres = new ArrayList<>();
            if (posiblePpp != null) nombres.add("posiblePpp");
            if (antirrabicaVencida != null) nombres.add("antirrabicaVencida");
            if (domicilioSinVerificar != null) nombres.add("domicilioSinVerificar");
            return String.join(", ", nombres);
        }
    }

    public static SolicitudResponse desde(Solicitud solicitud, Alertas alertas) {
        Tutor tutor = solicitud.getTutor();
        return new SolicitudResponse(
                solicitud.getId(),
                solicitud.getEstado(),
                solicitud.getFechaCreacion(),
                solicitud.getFechaResolucion(),
                solicitud.getMensajeZoonosis(),
                solicitud.getPerro() != null ? solicitud.getPerro().getCodigo() : null,
                alertas,
                PerroDeclarado.de(solicitud),
                new TutorSolicitante(
                        tutor.getDni(),
                        tutor.getNombre() + " " + tutor.getApellido(),
                        tutor.getCalle() + " " + tutor.getAltura()));
    }
}
