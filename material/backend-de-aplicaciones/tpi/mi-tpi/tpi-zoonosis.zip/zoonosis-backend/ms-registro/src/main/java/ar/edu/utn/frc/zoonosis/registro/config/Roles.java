package ar.edu.utn.frc.zoonosis.registro.config;

import org.springframework.security.core.Authentication;

/**
 * Para los endpoints que comparten varios roles (por ejemplo GET /api/v1/solicitudes o GET /api/v1/perros):
 * el personal ve todo, el vecino solo lo suyo y el veterinario, en la lista de perros, solo datos de los perros.
 * El rol ya viene validado por Spring Security.
 */
public final class Roles {

    private Roles() {
    }

    /** ¿El usuario del token es personal de Zoonosis? (también tiene VECINO, que es el rol por defecto) */
    public static boolean esPersonal(Authentication usuario) {
        return tieneRol(usuario, "ROLE_PERSONAL_MUNICIPAL");
    }

    /** ¿El usuario del token es veterinario? (también tiene VECINO, que es el rol por defecto) */
    public static boolean esVeterinario(Authentication usuario) {
        return tieneRol(usuario, "ROLE_VETERINARIO");
    }

    private static boolean tieneRol(Authentication usuario, String rol) {
        return usuario.getAuthorities().stream()
                .anyMatch(autoridad -> autoridad.getAuthority().equals(rol));
    }
}
