package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Datos del perro que declara el vecino en la solicitud.
 * Las anotaciones validan el formato (400). Las reglas de negocio están en SolicitudService.
 */
public record PerroDatosRequest(

        @NotBlank(message = "Nombre inválido: el nombre del perro es obligatorio")
        @Size(max = 60, message = "Nombre inválido: el nombre puede tener hasta 60 caracteres")
        String nombre,

        // Tiene que estar en el listado de Zoonosis (tabla raza): lo controla RazaService (422)
        @NotBlank(message = "Raza inválida: la raza es obligatoria (si es una cruza, Mestizo; si no la sabés, No identificada)")
        @Size(max = 60, message = "Raza inválida: la raza puede tener hasta 60 caracteres")
        String raza,

        @NotNull(message = "Sexo inválido: el sexo es obligatorio (MACHO o HEMBRA)")
        Sexo sexo,

        @NotNull(message = "Fecha de nacimiento inválida: la fecha de nacimiento es obligatoria (puede ser aproximada)")
        @PastOrPresent(message = "Fecha de nacimiento inválida: la fecha de nacimiento no puede ser futura")
        LocalDate fechaNacimiento,

        @NotNull(message = "Peso inválido: el peso es obligatorio")
        @Positive(message = "Peso inválido: el peso tiene que ser mayor a 0")
        @Digits(integer = 3, fraction = 2, message = "Peso inválido: el peso puede tener hasta 3 enteros y 2 decimales")
        BigDecimal pesoKg,

        // Si no viene, queda en false
        boolean castrado
) { }
