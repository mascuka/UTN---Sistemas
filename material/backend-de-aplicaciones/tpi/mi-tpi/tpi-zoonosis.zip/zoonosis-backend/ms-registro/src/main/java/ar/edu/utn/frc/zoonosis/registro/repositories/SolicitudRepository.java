package ar.edu.utn.frc.zoonosis.registro.repositories;

import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Acceso a la tabla solicitud. Spring Data arma el SQL a partir del nombre de cada método.
 */
public interface SolicitudRepository extends JpaRepository<Solicitud, Long> {

    // Las solicitudes de un vecino, de la más nueva a la más vieja (RF03, RN04).
    // "TutorUsuarioId" = solicitud.tutor.usuarioId
    List<Solicitud> findByTutorUsuarioIdOrderByFechaCreacionDesc(String usuarioId);

    // Las solicitudes en un estado, de la más vieja a la más nueva: se atienden por orden de llegada (RF05)
    List<Solicitud> findByEstadoOrderByFechaCreacionAsc(EstadoSolicitud estado);

    // Las solicitudes de un tutor en un estado: para no aceptar dos veces el mismo perro (RN05)
    List<Solicitud> findByTutorAndEstado(Tutor tutor, EstadoSolicitud estado);
}
