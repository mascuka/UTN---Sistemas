package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.EstadoInvalidoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroDatosRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.ResolucionRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudCreadaResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudResponse.Alertas;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoDomicilio;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.SolicitudRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.TutorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas de las reglas de las solicitudes (RN01, RN02, RN03, RN04, RN05, RN06, RN07, RN15 y la aprobación, P1).
 * Los repositorios, RazaService y PadronService son "mocks" de Mockito: no hay base de datos ni red.
 */
@ExtendWith(MockitoExtension.class)
class SolicitudServiceTest {

    private static final String USUARIO = "sub-de-vecino1";

    @Mock SolicitudRepository solicitudRepository;
    @Mock TutorRepository tutorRepository;
    @Mock PerroRepository perroRepository;
    @Mock RazaService razaService;
    @Mock PadronService padronService;
    @InjectMocks SolicitudService solicitudService;

    private Tutor tutor;

    @BeforeEach
    void prepararTutor() {
        tutor = new Tutor();
        tutor.setUsuarioId(USUARIO);
        tutor.setDni("30111222");
        tutor.setCalle("AV RIO DE JANEIRO");
        tutor.setAltura(450);
    }

    // ---------- Enviar una solicitud (RF02) ----------

    @Test
    void sinDatosDeTutorNoSePuedeEnviarUnaSolicitud_RN15() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> solicitudService.crear(USUARIO, solicitud("Toby", "Mestizo", "18", null)))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("datos de tutor");
        verify(solicitudRepository, never()).save(any());
    }

    @Test
    void laSolicitudEntraPendienteYSinAlertas_RN01() {
        prepararCreacion();

        SolicitudCreadaResponse respuesta = solicitudService.crear(USUARIO,
                solicitud("Toby", "Mestizo", "18.5", LocalDate.now().minusMonths(3)));

        assertThat(respuesta.estado()).isEqualTo(EstadoSolicitud.PENDIENTE);
        assertThat(respuesta.fechaCreacion()).isNotNull();           // el vecino ve cuándo la mandó
        assertThat(respuesta.perro().nombre()).isEqualTo("Toby");    // y de qué perro es
        assertThat(respuesta.avisos()).isNull();                     // sin avisos, la lista no sale
        assertThat(solicitudService.alertas(guardada())).isNull();  // sin alertas, tampoco
    }

    @Test
    void razaDelListadoMarcaAlertaPpp_RN06() {
        prepararCreacion();
        when(razaService.nombreOficial("rottweiler")).thenReturn("Rottweiler");
        when(razaService.esPeligrosa("Rottweiler")).thenReturn(true);

        solicitudService.crear(USUARIO, solicitud("Rocco", "rottweiler", "20", null));

        // Solo sale la alerta que aplica, en true; las otras quedan en null y no aparecen en el JSON
        assertThat(solicitudService.alertas(guardada())).isEqualTo(new Alertas(true, null, null));
    }

    @Test
    void laRazaSeGuardaComoFiguraEnElListadoDeZoonosis_RN19() {
        prepararCreacion();
        when(razaService.nombreOficial("ovejero aleman")).thenReturn("Ovejero Alemán");

        solicitudService.crear(USUARIO, solicitud("Luna", "ovejero aleman", "20", null));

        assertThat(guardada().getRazaPerro()).isEqualTo("Ovejero Alemán");
    }

    @Test
    void unaRazaQueNoEstaEnElListadoNoSeGuarda_RN19() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.of(tutor));
        when(razaService.nombreOficial("Perro de raza")).thenThrow(new ReglaNegocioException("Raza inválida"));

        assertThatThrownBy(() -> solicitudService.crear(USUARIO, solicitud("Toby", "Perro de raza", "18", null)))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("Raza inválida");
        verify(solicitudRepository, never()).save(any());
    }

    @Test
    void siElDomicilioDelTutorNoSeVerificoSaleLaAlerta_RN03() {
        tutor.setEstadoDomicilio(EstadoDomicilio.SIN_VERIFICAR);

        assertThat(solicitudService.alertas(solicitudGuardada(EstadoSolicitud.PENDIENTE)))
                .isEqualTo(new Alertas(null, null, true));
    }

    @Test
    void masDe25KgMarcaAlertaPppPeroJusto25No_RN06() {
        prepararCreacion();

        solicitudService.crear(USUARIO, solicitud("Luna", "Ovejero", "25.01", null));
        assertThat(solicitudService.alertas(guardada())).isEqualTo(new Alertas(true, null, null));

        solicitudService.crear(USUARIO, solicitud("Kira", "Mestizo", "25", null));
        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository, org.mockito.Mockito.times(2)).save(captor.capture());
        assertThat(solicitudService.alertas(captor.getAllValues().get(1))).isNull();
    }

    @Test
    void unPerroQueYaEstaEnElPadronNoSeVuelveAMandar_RN05() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.of(tutor));
        Perro toby = new Perro();
        toby.setNombre("Toby");
        when(perroRepository.findByTutor(tutor)).thenReturn(List.of(toby));

        // El mismo nombre sin mayúsculas ni tildes: se rechaza y no se guarda nada
        assertThatThrownBy(() -> solicitudService.crear(USUARIO, solicitud("  TÓBY ", "Mestizo", "8", null)))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("padrón");
        verify(solicitudRepository, never()).save(any());
    }

    @Test
    void siYaHayUnaSolicitudPendienteParaEsePerroLaNuevaNoSeGuarda_RN05() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.of(tutor));
        when(solicitudRepository.findByTutorAndEstado(tutor, EstadoSolicitud.PENDIENTE))
                .thenReturn(List.of(solicitudGuardada(EstadoSolicitud.PENDIENTE)));

        assertThatThrownBy(() -> solicitudService.crear(USUARIO, solicitud("Toby", "Mestizo", "18", null)))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("pendiente");
        verify(solicitudRepository, never()).save(any());
    }

    @Test
    void unVecinoNoPuedeVerLaSolicitudDeOtro_RN04() {
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(solicitudGuardada(EstadoSolicitud.PENDIENTE)));

        assertThatThrownBy(() -> solicitudService.obtenerDelVecino(1L, "sub-de-otro-vecino"))
                .isInstanceOf(PermisoDenegadoException.class);
        assertThat(solicitudService.obtenerDelVecino(1L, USUARIO).perro().nombre()).isEqualTo("Toby");
    }

    @Test
    void antirrabicaDeMasDeUnAnioSeAceptaConAviso_RN07() {
        prepararCreacion();

        SolicitudCreadaResponse respuesta = solicitudService.crear(USUARIO,
                solicitud("Bobi", "Caniche", "6", LocalDate.now().minusYears(1).minusDays(1)));

        assertThat(respuesta.estado()).isEqualTo(EstadoSolicitud.PENDIENTE);
        assertThat(respuesta.avisos()).hasSize(1);
        assertThat(solicitudService.alertas(guardada())).isEqualTo(new Alertas(null, true, null));
    }

    @Test
    void antirrabicaDeHaceJustoUnAnioTodaviaNoEstaVencida_RN07() {
        prepararCreacion();

        SolicitudCreadaResponse respuesta = solicitudService.crear(USUARIO,
                solicitud("Mora", "Beagle", "12", LocalDate.now().minusYears(1)));

        assertThat(respuesta.avisos()).isNull();
    }

    @Test
    void antirrabicaAnteriorAlNacimientoSeRechaza() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.of(tutor));
        SolicitudRequest datos = new SolicitudRequest(
                new PerroDatosRequest("Toby", "Mestizo", Sexo.MACHO, LocalDate.of(2021, 5, 10), new BigDecimal("18"), true),
                LocalDate.of(2020, 1, 1));

        assertThatThrownBy(() -> solicitudService.crear(USUARIO, datos)).isInstanceOf(ReglaNegocioException.class);
        verify(solicitudRepository, never()).save(any());
    }

    // ---------- Resolver una solicitud (RF06) ----------

    @Test
    void soloSeResuelveUnaSolicitudPendiente_RN02() {
        Solicitud observada = solicitudGuardada(EstadoSolicitud.OBSERVADA);
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(observada));

        assertThatThrownBy(() -> solicitudService.resolver(1L, new ResolucionRequest(EstadoSolicitud.APROBADA, null, null)))
                .isInstanceOf(EstadoInvalidoException.class);
        verify(padronService, never()).darDeAlta(any(), any(), any(), any(), any());
    }

    @Test
    void observarSinMensajeSeRechaza() {
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(solicitudGuardada(EstadoSolicitud.PENDIENTE)));

        assertThatThrownBy(() -> solicitudService.resolver(1L, new ResolucionRequest(EstadoSolicitud.OBSERVADA, "  ", null)))
                .isInstanceOf(ReglaNegocioException.class);
    }

    @Test
    void aprobarDaDeAltaElPerroConElDomicilioDelTutorYLaAntirrabicaDeclarada_P1() {
        Solicitud pendiente = solicitudGuardada(EstadoSolicitud.PENDIENTE);
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(pendiente));
        Perro alta = new Perro();
        alta.setCodigo("VA-000001");
        when(padronService.darDeAlta(any(), eq("AV RIO DE JANEIRO"), eq(450), any(),
                eq(pendiente.getFechaUltimaAntirrabica()))).thenReturn(alta);

        var respuesta = solicitudService.resolver(1L, new ResolucionRequest(EstadoSolicitud.APROBADA, null, null));

        assertThat(respuesta.estado()).isEqualTo(EstadoSolicitud.APROBADA);
        assertThat(respuesta.codigoPerro()).isEqualTo("VA-000001");
        assertThat(pendiente.getFechaResolucion()).isNotNull();
    }

    @Test
    void alAprobarUnMensajeParaElVecinoSeDescarta() {
        Solicitud pendiente = solicitudGuardada(EstadoSolicitud.PENDIENTE);
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(pendiente));
        when(padronService.darDeAlta(any(), any(), any(), any(), any())).thenReturn(new Perro());

        solicitudService.resolver(1L, new ResolucionRequest(EstadoSolicitud.APROBADA, "Bienvenido al padrón", null));

        assertThat(pendiente.getMensajeZoonosis()).isNull();
    }

    @Test
    void siSanidadNoRespondeAlAprobarLaSolicitudSigueEnPendiente_P1() {
        Solicitud pendiente = solicitudGuardada(EstadoSolicitud.PENDIENTE);
        when(solicitudRepository.findById(1L)).thenReturn(Optional.of(pendiente));
        when(padronService.darDeAlta(any(), any(), any(), any(), any()))
                .thenThrow(new ServicioNoDisponibleException("ms-sanidad no respondió"));

        assertThatThrownBy(() -> solicitudService.resolver(1L, new ResolucionRequest(EstadoSolicitud.APROBADA, null, null)))
                .isInstanceOf(ServicioNoDisponibleException.class);
        assertThat(pendiente.getEstado()).isEqualTo(EstadoSolicitud.PENDIENTE);
        assertThat(pendiente.getPerro()).isNull();
    }

    // ---------- Ayudas ----------

    private void prepararCreacion() {
        when(tutorRepository.findByUsuarioId(USUARIO)).thenReturn(Optional.of(tutor));
        // La raza que se escribe es la del listado, tal cual (salvo en las pruebas que digan otra cosa).
        // lenient: no todas las pruebas llegan a usarlo
        lenient().when(razaService.nombreOficial(any())).thenAnswer(inv -> inv.getArgument(0));
        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    private Solicitud guardada() {
        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository).save(captor.capture());
        return captor.getValue();
    }

    private SolicitudRequest solicitud(String nombre, String raza, String peso, LocalDate antirrabica) {
        return new SolicitudRequest(
                new PerroDatosRequest(nombre, raza, Sexo.MACHO, LocalDate.of(2020, 1, 1), new BigDecimal(peso), true),
                antirrabica);
    }

    private Solicitud solicitudGuardada(EstadoSolicitud estado) {
        Solicitud s = new Solicitud();
        s.setId(1L);
        s.setTutor(tutor);
        s.setEstado(estado);
        s.setFechaCreacion(LocalDateTime.now());
        s.setNombrePerro("Toby");
        s.setRazaPerro("Mestizo");
        s.setSexoPerro(Sexo.MACHO);
        s.setFechaNacimientoPerro(LocalDate.of(2021, 5, 10));
        s.setPesoKgPerro(new BigDecimal("18.5"));
        s.setFechaUltimaAntirrabica(LocalDate.now().minusMonths(2));
        return s;
    }
}
