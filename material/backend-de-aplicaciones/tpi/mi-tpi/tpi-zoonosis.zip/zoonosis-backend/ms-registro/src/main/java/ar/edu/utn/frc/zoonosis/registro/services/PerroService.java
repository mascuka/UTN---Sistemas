package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.RecursoNoEncontradoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.clients.SanidadClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.MiPerroResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroComunitarioRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroCreadoResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroFichaResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroPadronResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroVeterinarioResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.VerificacionPerroResponse;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Lógica de negocio de los perros del padrón:
 * alta de comunitarios (RF07, P4, RN18), ficha (RF08, P3), los perros del vecino (RF04, P3),
 * el padrón para el personal (RF14), los perros de una persona para el veterinario (RF15)
 * y la verificación que pide ms-sanidad antes de registrar una vacuna (P2, RN08, RN12).
 */
@Service
public class PerroService {

    private static final Logger log = LoggerFactory.getLogger(PerroService.class);

    // Lo que se muestra cuando ms-sanidad no responde (degradación explícita, P3)
    private static final String NO_DISPONIBLE = "NO_DISPONIBLE";

    private final PerroRepository perroRepository;
    private final PadronService padronService;
    private final RazaService razaService;
    private final GeorefClient georefClient;
    private final SanidadClient sanidadClient;

    public PerroService(PerroRepository perroRepository, PadronService padronService, RazaService razaService,
                        GeorefClient georefClient, SanidadClient sanidadClient) {
        this.perroRepository = perroRepository;
        this.padronService = padronService;
        this.razaService = razaService;
        this.georefClient = georefClient;
        this.sanidadClient = sanidadClient;
    }

    /**
     * POST /api/v1/perros/comunitarios (RF07, P4). Sin @Transactional a propósito: la transacción empieza
     * en PadronService, así no se tiene la base ocupada mientras se espera a Georef.
     */
    public PerroCreadoResponse altaComunitario(PerroComunitarioRequest datos) {
        // La raza tiene que estar en el listado de Zoonosis (422 si no); se guarda como figura ahí
        String raza = razaService.nombreOficial(datos.raza());

        // RN18: la calle donde vive tiene que ser de Villa Allende (Georef).
        // Si Georef no responde, la ServicioNoDisponibleException sigue de largo y sale 503:
        // el personal reintenta en vez de guardar algo sin verificar
        String calleOficial = georefClient.buscarCalle(datos.calle().trim())
                .orElseThrow(() -> new ReglaNegocioException("Calle inválida: la calle no existe en Villa Allende"));

        Perro perro = new Perro();
        perro.setNombre(datos.nombre().trim());
        perro.setRaza(raza);
        perro.setSexo(datos.sexo());
        perro.setFechaNacimiento(datos.fechaNacimiento());
        perro.setPesoKg(datos.pesoKg());
        perro.setCastrado(datos.castrado());
        perro.setReferenciaUbicacion(datos.referenciaUbicacion().trim());
        // Sin tutor = comunitario. La calle y el número solo se usan para calcular la zona del mapa
        // (con la ubicación del personal, si viene, por si no se encuentran).
        // Sin antirrábica declarada: la libreta arranca vacía (IRREGULAR)
        Perro guardado = padronService.darDeAlta(perro, calleOficial, datos.altura(), datos.ubicacion(), null);
        log.info("Perro comunitario {} dado de alta", guardado.getCodigo());
        return new PerroCreadoResponse(guardado.getCodigo());
    }

    /**
     * GET /api/v1/perros/{codigo} (RF08, P3): la ficha con el tutor y el estado sanitario.
     * El personal ve cualquier perro (usuarioId null); el vecino, solo los suyos (RN04).
     * Sin @Transactional: no tiene sentido tener la base ocupada mientras se espera a ms-sanidad.
     * El tutor viene en la misma consulta (@ManyToOne se carga junto con el perro).
     */
    public PerroFichaResponse ficha(String codigo, String usuarioId) {
        Perro perro = perroRepository.findByCodigo(codigo)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe el perro " + codigo + " en el padrón"));
        boolean esDeOtro = perro.getTutor() == null || !perro.getTutor().getUsuarioId().equals(usuarioId);
        if (usuarioId != null && esDeOtro) {
            throw new PermisoDenegadoException("Solo podés ver tus propios perros");
        }
        SanidadClient.EstadoLibreta estado = estadoSanitario(codigo);
        return PerroFichaResponse.desde(perro, estado.estadoSanitario(), estado.fechaVencimiento());
    }

    /** GET /api/v1/perros (vecino, RF04, P3): sus perros, con el estado de la antirrábica. */
    public List<MiPerroResponse> delVecino(String usuarioId) {
        return perroRepository.findByTutorUsuarioIdOrderByNombreAsc(usuarioId).stream()
                .map(perro -> {
                    SanidadClient.EstadoLibreta estado = estadoSanitario(perro.getCodigo());
                    return new MiPerroResponse(perro.getCodigo(), perro.getNombre(), perro.getRaza(),
                            estado.estadoSanitario(), estado.fechaVencimiento());
                })
                .toList();
    }

    /**
     * GET /api/v1/perros (personal, RF14): el padrón completo o, si viene el DNI, solo los perros de esa persona
     * (por ejemplo, ante una mordedura cuando no se sabe el código del perro).
     * Sin estado sanitario: no se le pregunta a ms-sanidad por cada perro (está en la ficha y en vencimientos).
     */
    @Transactional(readOnly = true)
    public List<PerroPadronResponse> padron(String dniTutor) {
        List<Perro> perros = dniTutor == null || dniTutor.isBlank()
                ? perroRepository.findAllByOrderByCodigoAsc()
                : perroRepository.findByTutorDniOrderByNombreAsc(dniTutor.trim());
        return perros.stream()
                .map(PerroPadronResponse::desde)
                .toList();
    }

    /**
     * GET /api/v1/perros?dniTutor= (veterinario, RF15): los perros de la persona que tiene adelante,
     * para encontrar el código cuando no lo sabe. El DNI lo escribe el veterinario: se lo da la persona.
     * Solo datos de los perros, nunca del tutor (RN12). Para vacunar sigue mandando el DNI, que se verifica (P2).
     */
    @Transactional(readOnly = true)
    public List<PerroVeterinarioResponse> paraVeterinario(String dniTutor, String veterinario) {
        List<PerroVeterinarioResponse> perros = perroRepository.findByTutorDniOrderByNombreAsc(dniTutor.trim()).stream()
                .map(PerroVeterinarioResponse::desde)
                .toList();
        // Queda en el log quién buscó y cuántos perros encontró; nunca el DNI
        log.info("El veterinario {} buscó los perros de una persona por DNI (perros encontrados: {})", veterinario, perros.size());
        return perros;
    }

    /**
     * GET /internal/perros/{codigo}/verificacion?dni= (lo llama ms-sanidad, P2).
     * RN08: ¿existe en el padrón? RN12: ¿el DNI es el del tutor? Responde solo sí o no.
     */
    @Transactional(readOnly = true)
    public VerificacionPerroResponse verificar(String codigo, String dni) {
        return perroRepository.findByCodigo(codigo)
                .map(perro -> {
                    boolean comunitario = perro.getTutor() == null;
                    boolean dniCoincide = !comunitario && dni != null
                            && perro.getTutor().getDni().equals(dni.trim());
                    // Nunca se escribe el DNI en el log: solo el resultado
                    log.info("Verificación de {} pedida por ms-sanidad: comunitario={}, dniCoincide={}", codigo, comunitario, dniCoincide);
                    return new VerificacionPerroResponse(true, comunitario, dniCoincide, perro.getFechaNacimiento());
                })
                .orElse(new VerificacionPerroResponse(false, false, false, null));
    }

    /** P3: le pregunta a sanidad. Si no responde, NO_DISPONIBLE en vez de fallar todo (es solo una consulta). */
    private SanidadClient.EstadoLibreta estadoSanitario(String codigo) {
        try {
            return sanidadClient.consultarEstado(codigo);
        } catch (ServicioNoDisponibleException e) {
            log.warn("Estado sanitario de {} no disponible: {}", codigo, e.getMessage());
            return new SanidadClient.EstadoLibreta(NO_DISPONIBLE, null);
        }
    }
}
