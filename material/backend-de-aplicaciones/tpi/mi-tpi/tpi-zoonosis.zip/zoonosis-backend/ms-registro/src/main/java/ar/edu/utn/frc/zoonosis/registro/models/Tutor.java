package ar.edu.utn.frc.zoonosis.registro.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "tutor")
@Getter
@Setter
@NoArgsConstructor
public class Tutor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // "sub" del token de Keycloak: vincula al tutor con su cuenta
    @Column(nullable = false, unique = true, length = 36)
    private String usuarioId;

    @Column(nullable = false, unique = true, length = 10)
    private String dni;

    // Nombre, apellido y email salen del token (la cuenta de Keycloak): el vecino no los vuelve a escribir
    @Column(nullable = false, length = 80)
    private String nombre;

    @Column(nullable = false, length = 80)
    private String apellido;

    @Column(length = 120)
    private String email;

    // Nombre oficial de la calle, normalizado por Georef
    @Column(nullable = false, length = 120)
    private String calle;

    // El número de la casa. No se guardan coordenadas: cuando el perro entra al padrón, la zona del mapa
    // se calcula con la calle y el número (OpenStreetMap) y se guarda solo la zona, en el perro
    @Column(nullable = false)
    private Integer altura;

    @Column(nullable = false, length = 20)
    private String telefono;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private EstadoDomicilio estadoDomicilio;

    @Column(nullable = false)
    private LocalDateTime fechaConsentimiento;
}
