package ar.edu.utn.frc.zoonosis.registro.repositories;

import ar.edu.utn.frc.zoonosis.registro.dtos.PerrosPorZonaResponse;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Acceso a la tabla perro (el padrón).
 */
public interface PerroRepository extends JpaRepository<Perro, Long> {

    // ¿El tutor ya tiene algún perro en el padrón? (RN17)
    boolean existsByTutor(Tutor tutor);

    // Los perros del tutor, para buscar posibles duplicados (RN05)
    List<Perro> findByTutor(Tutor tutor);

    // Un perro por su código del padrón (ficha y verificación)
    Optional<Perro> findByCodigo(String codigo);

    // Los perros del vecino, por nombre (RF04). "TutorUsuarioId" = perro.tutor.usuarioId
    List<Perro> findByTutorUsuarioIdOrderByNombreAsc(String usuarioId);

    // El padrón completo, por código (RF14, personal)
    List<Perro> findAllByOrderByCodigoAsc();

    // Los perros de una persona, por su DNI (RF14, personal). "TutorDni" = perro.tutor.dni
    List<Perro> findByTutorDniOrderByNombreAsc(String dni);

    // Próximo número para el código VA-000123. La secuencia se crea en data.sql;
    // la base nunca da dos veces el mismo número, aunque se aprueben dos perros a la vez
    @Query(value = "SELECT nextval('registro.perro_codigo_seq')", nativeQuery = true)
    long siguienteNumeroDeCodigo();

    // Mapa de calor (RF12): cuántos perros hay en cada zona, solo las zonas con al menos "minimo" perros (RN14).
    // "new ...PerrosPorZonaResponse(...)" arma directamente el DTO con cada fila del resultado
    @Query("""
            SELECT new ar.edu.utn.frc.zoonosis.registro.dtos.PerrosPorZonaResponse(
                       p.zonaId, p.zonaLatCentro, p.zonaLonCentro, COUNT(p))
            FROM Perro p
            GROUP BY p.zonaId, p.zonaLatCentro, p.zonaLonCentro
            HAVING COUNT(p) >= :minimo
            ORDER BY p.zonaId
            """)
    List<PerrosPorZonaResponse> contarPorZona(@Param("minimo") long minimo);
}
