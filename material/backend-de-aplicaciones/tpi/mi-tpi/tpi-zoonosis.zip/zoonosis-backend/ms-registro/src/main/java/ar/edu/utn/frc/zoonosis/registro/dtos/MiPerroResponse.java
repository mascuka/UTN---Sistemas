package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

/**
 * Un perro del vecino, con el estado de la antirrábica que informa ms-sanidad (RF04).
 * estadoSanitario: AL_DIA, IRREGULAR o NO_DISPONIBLE (si sanidad no respondió).
 */
public record MiPerroResponse(
        String codigo,
        String nombre,
        String raza,
        String estadoSanitario,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaVencimientoAntirrabica
) { }
