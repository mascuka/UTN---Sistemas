package ar.edu.utn.frc.zoonosis.registro.clients;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Habla con ms-sanidad por sus endpoints internos (/internal/**, no pasan por el gateway).
 * El token del usuario viaja solo, gracias al PropagarTokenInterceptor del RestClient.
 * Si ms-sanidad no responde o devuelve un error, lanza ServicioNoDisponibleException (503):
 * cada service decide si cancela la operación (P1, P4) o si sigue con NO_DISPONIBLE (P3).
 */
@Component
public class SanidadClient {

    private final RestClient sanidad;

    public SanidadClient(@Qualifier("sanidadRestClient") RestClient sanidad) {
        this.sanidad = sanidad;
    }

    /** POST /internal/libretas: abre la libreta del perro (P1 y P4). Si ya existía, sanidad responde 200. */
    public void abrirLibreta(AperturaLibreta datos) {
        try {
            sanidad.post()
                    .uri("/internal/libretas")
                    .body(datos)
                    .retrieve()
                    .toBodilessEntity();
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("ms-sanidad no respondió: no se pudo abrir la libreta del perro", e);
        }
    }

    /** GET /internal/libretas/{codigo}/estado: AL_DIA o IRREGULAR y el vencimiento de la antirrábica (P3). */
    public EstadoLibreta consultarEstado(String codigoPerro) {
        EstadoLibreta estado;
        try {
            estado = sanidad.get()
                    .uri("/internal/libretas/{codigo}/estado", codigoPerro)
                    .retrieve()
                    .body(EstadoLibreta.class);
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("ms-sanidad no respondió el estado sanitario", e);
        }
        if (estado == null) {
            throw new ServicioNoDisponibleException("ms-sanidad devolvió una respuesta vacía");
        }
        return estado;
    }

    // Lo que se le manda a sanidad para abrir la libreta (fechaAntirrabicaDeclarada es null en los comunitarios)
    public record AperturaLibreta(String codigoPerro, LocalDate fechaAntirrabicaDeclarada,
                                  String zonaId, BigDecimal zonaLat, BigDecimal zonaLon) { }

    // Lo que contesta sanidad sobre el estado de la libreta
    public record EstadoLibreta(String estadoSanitario, LocalDate fechaVencimiento) { }
}
