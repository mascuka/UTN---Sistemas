package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoDomicilio;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

/**
 * Lo que se le devuelve al vecino sobre sus datos de tutor.
 * No se devuelve la entidad Tutor directamente: así elegimos qué datos salen (por ejemplo, no sale el usuarioId).
 * El id sirve para consultarlos o cambiarlos después (GET y PATCH /api/v1/tutores/{id}).
 */
public record TutorResponse(
        Long id,
        String dni,
        String nombre,
        String apellido,
        String email,
        String calle,
        Integer altura,
        String telefono,
        EstadoDomicilio estadoDomicilio,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaConsentimiento
) {

    /** Arma la respuesta a partir de la entidad guardada en la base. */
    public static TutorResponse desde(Tutor tutor) {
        return new TutorResponse(
                tutor.getId(),
                tutor.getDni(),
                tutor.getNombre(),
                tutor.getApellido(),
                tutor.getEmail(),
                tutor.getCalle(),
                tutor.getAltura(),
                tutor.getTelefono(),
                tutor.getEstadoDomicilio(),
                tutor.getFechaConsentimiento());
    }
}
