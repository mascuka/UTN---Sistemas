package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.registro.dtos.PerrosPorZonaResponse;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Mapa de calor público, parte de registro: perros por zona (RF12).
 * No llama a ms-sanidad: arma su mitad del mapa solo con sus datos.
 */
@Service
public class EstadisticaService {

    // RN14: las zonas con menos perros que esto no se muestran (privacidad)
    private static final long MINIMO_PERROS_POR_ZONA = 3;

    private final PerroRepository perroRepository;

    public EstadisticaService(PerroRepository perroRepository) {
        this.perroRepository = perroRepository;
    }

    @Transactional(readOnly = true)
    public List<PerrosPorZonaResponse> perrosPorZona() {
        return perroRepository.contarPorZona(MINIMO_PERROS_POR_ZONA);
    }
}
