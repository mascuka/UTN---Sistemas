package ar.edu.utn.frc.zoonosis.registro.models;

public enum Sexo {
    MACHO,
    HEMBRA
}
