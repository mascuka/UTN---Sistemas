package ar.edu.utn.frc.zoonosis.registro.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "solicitud")
@Getter
@Setter
@NoArgsConstructor
public class Solicitud {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // El vecino que la envía, con sus datos de tutor ya cargados
    @ManyToOne(optional = false)
    @JoinColumn(name = "tutor_id", nullable = false)
    private Tutor tutor;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private EstadoSolicitud estado;

    // Obligatorio al observar o rechazar
    @Column(length = 500)
    private String mensajeZoonosis;

    @Column(nullable = false)
    private LocalDateTime fechaCreacion;

    private LocalDateTime fechaResolucion;

    // Datos del perro declarados por el vecino: se copian al Perro al aprobar
    @Column(nullable = false, length = 60)
    private String nombrePerro;

    @Column(nullable = false, length = 60)
    private String razaPerro;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Sexo sexoPerro;

    @Column(nullable = false)
    private LocalDate fechaNacimientoPerro;

    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal pesoKgPerro;

    private boolean castradoPerro;

    // null si el vecino no la sabe o el perro nunca fue vacunado
    private LocalDate fechaUltimaAntirrabica;

    // Las alertas para el personal (posible PPP, antirrábica vencida) no se guardan:
    // se calculan al mostrar la solicitud, a partir de los datos del perro (SolicitudService.alertas)

    // Se completa al aprobar
    @ManyToOne
    @JoinColumn(name = "perro_id")
    private Perro perro;
}
