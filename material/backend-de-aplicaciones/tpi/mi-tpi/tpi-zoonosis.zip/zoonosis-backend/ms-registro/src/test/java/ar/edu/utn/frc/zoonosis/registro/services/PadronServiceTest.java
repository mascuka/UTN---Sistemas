package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.clients.OpenStreetMapClient;
import ar.edu.utn.frc.zoonosis.registro.clients.SanidadClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.UbicacionRequest;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas del alta en el padrón (P1 y P4): ubicación por calle y número, código del perro,
 * cálculo de la zona (sección 6.1) y apertura de la libreta en ms-sanidad.
 */
@ExtendWith(MockitoExtension.class)
class PadronServiceTest {

    @Mock PerroRepository perroRepository;
    @Mock SanidadClient sanidadClient;
    @Mock OpenStreetMapClient openStreetMapClient;
    @Mock GeorefClient georefClient;
    @InjectMocks PadronService padronService;

    @Test
    void ubicarLaDireccionPonerCodigoYZonaYAbrirLaLibretaConEsosDatos() {
        ubicaEn("-31.2946", "-64.2953");
        when(perroRepository.siguienteNumeroDeCodigo()).thenReturn(7L);
        when(perroRepository.save(any(Perro.class))).thenAnswer(inv -> inv.getArgument(0));
        LocalDate antirrabica = LocalDate.now().minusMonths(1);

        Perro perro = padronService.darDeAlta(new Perro(), "AV RIO DE JANEIRO", 450, null, antirrabica);

        assertThat(perro.getCodigo()).isEqualTo("VA-000007");
        assertThat(perro.getZonaId()).isEqualTo("-6259_-12860");
        assertThat(perro.getZonaLatCentro()).isEqualByComparingTo("-31.2925");
        assertThat(perro.getZonaLonCentro()).isEqualByComparingTo("-64.2975");
        assertThat(perro.getFechaAlta()).isNotNull();

        ArgumentCaptor<SanidadClient.AperturaLibreta> pedido = ArgumentCaptor.forClass(SanidadClient.AperturaLibreta.class);
        verify(sanidadClient).abrirLibreta(pedido.capture());
        assertThat(pedido.getValue()).isEqualTo(new SanidadClient.AperturaLibreta("VA-000007", antirrabica,
                "-6259_-12860", perro.getZonaLatCentro(), perro.getZonaLonCentro()));
    }

    @Test
    void unPuntoJustoEnElBordeDeUnaZonaQuedaEnLaZonaDeArriba() {
        // -31.29 / 0.005 = -6258 exacto: con BigDecimal no hay errores de redondeo
        ubicaEn("-31.29", "-64.30");
        when(perroRepository.siguienteNumeroDeCodigo()).thenReturn(1L);
        when(perroRepository.save(any(Perro.class))).thenAnswer(inv -> inv.getArgument(0));

        Perro perro = padronService.darDeAlta(new Perro(), "ALBERDI", 345, null, null);

        assertThat(perro.getZonaId()).isEqualTo("-6258_-12860");
    }

    @Test
    void siLaDireccionNoSePuedeUbicarYNoHayUbicacionDelPersonalNoSeDaDeAlta() {
        when(openStreetMapClient.ubicar("CALLE RARA", 10)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> padronService.darDeAlta(new Perro(), "CALLE RARA", 10, null, null))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("ubicar");
        verify(perroRepository, never()).save(any());
        verify(sanidadClient, never()).abrirLibreta(any());
    }

    @Test
    void siLaDireccionNoSeEncuentraSeUsaLaUbicacionQueIndicoElPersonal() {
        when(openStreetMapClient.ubicar("VELEZ SARSFIELD", 800)).thenReturn(Optional.empty());
        UbicacionRequest ubicacion = new UbicacionRequest(new BigDecimal("-31.2946"), new BigDecimal("-64.2953"));
        when(georefClient.estaEnVillaAllende(ubicacion.latitud(), ubicacion.longitud())).thenReturn(true);
        when(perroRepository.siguienteNumeroDeCodigo()).thenReturn(3L);
        when(perroRepository.save(any(Perro.class))).thenAnswer(inv -> inv.getArgument(0));

        Perro perro = padronService.darDeAlta(new Perro(), "VELEZ SARSFIELD", 800, ubicacion, null);

        assertThat(perro.getZonaId()).isEqualTo("-6259_-12860");
        verify(sanidadClient).abrirLibreta(any());
    }

    @Test
    void laUbicacionDelPersonalTieneQueSerDeVillaAllende() {
        when(openStreetMapClient.ubicar(any(), any())).thenReturn(Optional.empty());
        // Un punto de Córdoba capital
        UbicacionRequest ubicacion = new UbicacionRequest(new BigDecimal("-31.4167"), new BigDecimal("-64.1833"));
        when(georefClient.estaEnVillaAllende(ubicacion.latitud(), ubicacion.longitud())).thenReturn(false);

        assertThatThrownBy(() -> padronService.darDeAlta(new Perro(), "VELEZ SARSFIELD", 800, ubicacion, null))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("Villa Allende");
        verify(perroRepository, never()).save(any());
        verify(sanidadClient, never()).abrirLibreta(any());
    }

    @Test
    void siLaDireccionSeEncuentraNoSeUsaLaUbicacionDelPersonal() {
        ubicaEn("-31.29", "-64.29");
        when(perroRepository.siguienteNumeroDeCodigo()).thenReturn(4L);
        when(perroRepository.save(any(Perro.class))).thenAnswer(inv -> inv.getArgument(0));
        // Un punto de otra zona: no se tiene que usar
        UbicacionRequest otra = new UbicacionRequest(new BigDecimal("-31.2946"), new BigDecimal("-64.2953"));

        Perro perro = padronService.darDeAlta(new Perro(), "ALBERDI", 345, otra, null);

        assertThat(perro.getZonaId()).isEqualTo("-6258_-12858");
        verify(georefClient, never()).estaEnVillaAllende(any(), any());
    }

    @Test
    void siSanidadNoRespondeLaExcepcionSaleParaQueSeDeshagaLaTransaccion() {
        ubicaEn("-31.29", "-64.29");
        when(perroRepository.siguienteNumeroDeCodigo()).thenReturn(2L);
        when(perroRepository.save(any(Perro.class))).thenAnswer(inv -> inv.getArgument(0));
        doThrow(new ServicioNoDisponibleException("ms-sanidad no respondió")).when(sanidadClient).abrirLibreta(any());

        assertThatThrownBy(() -> padronService.darDeAlta(new Perro(), "BALCARCE", 77, null, null))
                .isInstanceOf(ServicioNoDisponibleException.class);
    }

    private void ubicaEn(String latitud, String longitud) {
        when(openStreetMapClient.ubicar(any(), any()))
                .thenReturn(Optional.of(new OpenStreetMapClient.Punto(new BigDecimal(latitud), new BigDecimal(longitud))));
    }
}
