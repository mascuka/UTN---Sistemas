package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

/**
 * Una solicitud vista por el vecino que la envió (RF03), con el perro agrupado igual que en las demás respuestas.
 * A propósito no tiene las alertas internas (posiblePpp, antirrabicaVencida, domicilioSinVerificar): esas son solo para el personal (RN06).
 * Los campos sin valor (por ejemplo, el código antes de aprobarla) no salen en el JSON.
 */
public record MiSolicitudResponse(
        Long id,
        EstadoSolicitud estado,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaCreacion,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaResolucion,  // solo si ya se resolvió
        String mensajeZoonosis,  // solo si se observó o rechazó
        String codigoPerro,      // solo si se aprobó: el código de su perro en el padrón
        SolicitudResponse.PerroDeclarado perro
) {

    public static MiSolicitudResponse desde(Solicitud solicitud) {
        return new MiSolicitudResponse(
                solicitud.getId(),
                solicitud.getEstado(),
                solicitud.getFechaCreacion(),
                solicitud.getFechaResolucion(),
                solicitud.getMensajeZoonosis(),
                solicitud.getPerro() != null ? solicitud.getPerro().getCodigo() : null,
                SolicitudResponse.PerroDeclarado.de(solicitud));
    }
}
