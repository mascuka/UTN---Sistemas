package ar.edu.utn.frc.zoonosis.registro.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Listado de razas que acepta Zoonosis (datos semilla en data.sql). Además de las razas tiene "Mestizo"
// (una cruza) y "No identificada" (no se sabe). peligrosa = true marca las razas de la alerta de perro
// potencialmente peligroso (RN06)
@Entity
@Table(name = "raza")
@Getter
@Setter
@NoArgsConstructor
public class Raza {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 60)
    private String nombre;

    @Column(nullable = false)
    private boolean peligrosa;
}
