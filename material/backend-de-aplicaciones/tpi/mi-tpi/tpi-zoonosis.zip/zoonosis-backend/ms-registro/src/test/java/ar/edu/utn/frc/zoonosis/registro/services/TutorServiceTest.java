package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.EstadoInvalidoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.CuentaUsuario;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorCambiosRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorResponse;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoDomicilio;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.TutorRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas de los datos del tutor (RF01): alta y cambios, RN03 con Georef (y Georef caído), RN04, RN16 y RN17.
 */
@ExtendWith(MockitoExtension.class)
class TutorServiceTest {

    private static final CuentaUsuario ANA = new CuentaUsuario("sub-de-vecino1", "Ana", "Pérez", "vecino1@example.com");

    @Mock TutorRepository tutorRepository;
    @Mock PerroRepository perroRepository;
    @Mock GeorefClient georefClient;
    @InjectMocks TutorService tutorService;

    @Test
    void elAltaGuardaLaCalleOficialYLosDatosDeLaCuenta_RN03() {
        sinDatosPrevios();
        when(georefClient.buscarCalle("Rio de Janeiro")).thenReturn(Optional.of("AV RIO DE JANEIRO"));

        TutorResponse tutor = tutorService.crear(ANA, alta("30111222"));

        assertThat(tutor.calle()).isEqualTo("AV RIO DE JANEIRO");
        assertThat(tutor.estadoDomicilio()).isEqualTo(EstadoDomicilio.VERIFICADO);
        // Nombre, apellido y email no los escribe el vecino: salen de su cuenta (el token)
        assertThat(tutor.nombre()).isEqualTo("Ana");
        assertThat(tutor.email()).isEqualTo("vecino1@example.com");
    }

    @Test
    void unaCalleQueNoExisteEnVillaAllendeSeRechaza_RN03() {
        sinDatosPrevios();
        when(georefClient.buscarCalle("Rio de Janeiro")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> tutorService.crear(ANA, alta("30111222")))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("calle");
        verify(tutorRepository, never()).save(any());
    }

    @Test
    void siGeorefNoRespondeSeGuardaIgualComoSinVerificar_RN03() {
        sinDatosPrevios();
        when(georefClient.buscarCalle("Rio de Janeiro")).thenThrow(new ServicioNoDisponibleException("Georef no responde"));

        TutorResponse tutor = tutorService.crear(ANA, alta("30111222"));

        assertThat(tutor.estadoDomicilio()).isEqualTo(EstadoDomicilio.SIN_VERIFICAR);
        assertThat(tutor.calle()).isEqualTo("Rio de Janeiro");
    }

    @Test
    void losDatosDeTutorSeCarganUnaSolaVez() {
        when(tutorRepository.findByUsuarioId(ANA.usuarioId())).thenReturn(Optional.of(new Tutor()));

        assertThatThrownBy(() -> tutorService.crear(ANA, alta("30111222")))
                .isInstanceOf(EstadoInvalidoException.class);
    }

    @Test
    void unDniDeOtraCuentaSeRechaza_RN16() {
        when(tutorRepository.findByUsuarioId(ANA.usuarioId())).thenReturn(Optional.empty());
        Tutor otro = new Tutor();
        otro.setUsuarioId("otra-cuenta");
        when(tutorRepository.findByDni("30111222")).thenReturn(Optional.of(otro));

        assertThatThrownBy(() -> tutorService.crear(ANA, alta("30111222")))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("otra cuenta");
    }

    @Test
    void unVecinoNoPuedeVerNiCambiarLosDatosDeOtro_RN04() {
        Tutor deOtro = tutorGuardado();
        deOtro.setUsuarioId("otra-cuenta");

        assertThatThrownBy(() -> tutorService.obtener(1L, ANA.usuarioId())).isInstanceOf(PermisoDenegadoException.class);
        assertThatThrownBy(() -> tutorService.modificar(1L, ANA, new TutorCambiosRequest(null, null, null, "3519998877")))
                .isInstanceOf(PermisoDenegadoException.class);
    }

    @Test
    void conPerrosEnElPadronNoSePuedeCambiarElDomicilio_RN17() {
        Tutor tutor = tutorGuardado();
        when(perroRepository.existsByTutor(tutor)).thenReturn(true);

        assertThatThrownBy(() -> tutorService.modificar(1L, ANA, new TutorCambiosRequest(null, null, 999, null)))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("perros en el padrón");
        verify(georefClient, never()).buscarCalle(any());
    }

    @Test
    void conPerrosEnElPadronSiSePuedeCambiarElTelefono_RN17() {
        tutorGuardado();

        TutorResponse tutor = tutorService.modificar(1L, ANA, new TutorCambiosRequest(null, null, null, "3519998877"));

        assertThat(tutor.telefono()).isEqualTo("3519998877");
        assertThat(tutor.altura()).isEqualTo(450); // lo que no vino en el PATCH no cambia
        verify(perroRepository, never()).existsByTutor(any()); // no cambia DNI ni domicilio: RN17 no aplica
    }

    @Test
    void volverAEscribirLaCalleComoLaEscribioElVecinoNoEsUnCambioDeDomicilio_RN17() {
        // Guardada con el nombre oficial de Georef ("AV RIO DE JANEIRO"); el vecino manda "Rio de Janeiro" otra vez
        tutorGuardado();

        TutorResponse tutor = tutorService.modificar(1L, ANA, new TutorCambiosRequest(null, "Rio de Janeiro", null, null));

        assertThat(tutor.calle()).isEqualTo("AV RIO DE JANEIRO");
        verify(perroRepository, never()).existsByTutor(any());
        verify(georefClient, never()).buscarCalle(any());
    }

    // ---------- Ayudas ----------

    private void sinDatosPrevios() {
        when(tutorRepository.findByUsuarioId(ANA.usuarioId())).thenReturn(Optional.empty());
        when(tutorRepository.findByDni(any())).thenReturn(Optional.empty());
        lenient().when(tutorRepository.save(any(Tutor.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    private Tutor tutorGuardado() {
        Tutor tutor = new Tutor();
        tutor.setId(1L);
        tutor.setUsuarioId(ANA.usuarioId());
        tutor.setDni("30111222");
        tutor.setCalle("AV RIO DE JANEIRO");
        tutor.setAltura(450);
        tutor.setTelefono("3511234567");
        tutor.setEstadoDomicilio(EstadoDomicilio.VERIFICADO);
        when(tutorRepository.findById(1L)).thenReturn(Optional.of(tutor));
        return tutor;
    }

    private TutorRequest alta(String dni) {
        return new TutorRequest(dni, "Rio de Janeiro", 450, "3511234567", true);
    }
}
