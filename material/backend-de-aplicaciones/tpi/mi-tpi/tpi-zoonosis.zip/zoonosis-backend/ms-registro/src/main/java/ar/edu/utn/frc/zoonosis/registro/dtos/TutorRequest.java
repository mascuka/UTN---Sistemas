package ar.edu.utn.frc.zoonosis.registro.dtos;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Lo que manda el vecino para cargar sus datos de tutor (POST /api/v1/tutores). Solo lo que él sabe:
 * nombre, apellido y email salen de su cuenta (el token), y la zona del mapa la calcula el sistema.
 * Las anotaciones validan el formato; si algo está mal, la respuesta es 400 con el detalle por campo.
 */
public record TutorRequest(

        @NotBlank(message = "DNI inválido: el DNI es obligatorio")
        @Pattern(regexp = "\\d{7,8}", message = "DNI inválido: el DNI tiene que tener 7 u 8 números, sin puntos")
        String dni,

        @NotBlank(message = "Calle inválida: la calle es obligatoria")
        @Size(max = 120, message = "Calle inválida: la calle puede tener hasta 120 caracteres")
        String calle,

        @NotNull(message = "Altura inválida: la altura es obligatoria")
        @Positive(message = "Altura inválida: la altura tiene que ser mayor a 0")
        Integer altura,

        @NotBlank(message = "Teléfono inválido: el teléfono es obligatorio")
        @Pattern(regexp = "\\d{8,15}", message = "Teléfono inválido: el teléfono tiene que tener entre 8 y 15 números, sin espacios ni guiones")
        String telefono,

        // Si no viene o viene en false, no se aceptan los datos (uso de datos personales)
        @AssertTrue(message = "Consentimiento inválido: hay que aceptar el uso de los datos personales")
        boolean consentimiento
) {
}
