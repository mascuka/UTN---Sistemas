package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.EstadoInvalidoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.RecursoNoEncontradoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.CuentaUsuario;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorCambiosRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorResponse;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoDomicilio;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.TutorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

/**
 * Lógica de negocio de los datos del tutor (RF01).
 * Reglas: RN03 (la calle tiene que ser de Villa Allende, con Georef), RN04 (cada vecino ve solo lo suyo),
 * RN16 (un DNI, una cuenta) y RN17 (con perros en el padrón no se cambian DNI ni domicilio).
 */
@Service
public class TutorService {

    private static final Logger log = LoggerFactory.getLogger(TutorService.class);

    private final TutorRepository tutorRepository;
    private final PerroRepository perroRepository;
    private final GeorefClient georefClient;

    public TutorService(TutorRepository tutorRepository, PerroRepository perroRepository, GeorefClient georefClient) {
        this.tutorRepository = tutorRepository;
        this.perroRepository = perroRepository;
        this.georefClient = georefClient;
    }

    /** GET /api/v1/tutores: los datos de tutor del vecino del token (una lista con uno, o vacía si no los cargó). */
    @Transactional(readOnly = true)
    public List<TutorResponse> listar(String usuarioId) {
        return tutorRepository.findByUsuarioId(usuarioId).stream()
                .map(TutorResponse::desde)
                .toList();
    }

    /** GET /api/v1/tutores/{id}: solo el dueño de esos datos (RN04). */
    @Transactional(readOnly = true)
    public TutorResponse obtener(Long id, String usuarioId) {
        return TutorResponse.desde(buscarDelUsuario(id, usuarioId));
    }

    /** POST /api/v1/tutores: el vecino carga sus datos de tutor, una sola vez. */
    @Transactional
    public TutorResponse crear(CuentaUsuario cuenta, TutorRequest datos) {
        if (tutorRepository.findByUsuarioId(cuenta.usuarioId()).isPresent()) {
            throw new EstadoInvalidoException("Ya cargaste tus datos de tutor: si querés cambiar alguno, modificalo");
        }
        validarDniLibre(datos.dni(), cuenta.usuarioId()); // RN16

        Tutor tutor = new Tutor();
        tutor.setUsuarioId(cuenta.usuarioId());
        tutor.setDni(datos.dni());
        copiarDatosDeLaCuenta(tutor, cuenta);
        tutor.setAltura(datos.altura());
        tutor.setTelefono(datos.telefono());
        validarCalle(tutor, datos.calle()); // RN03
        tutor.setFechaConsentimiento(LocalDateTime.now());

        Tutor guardado = tutorRepository.save(tutor);
        log.info("Datos de tutor cargados (domicilio {})", guardado.getEstadoDomicilio());
        return TutorResponse.desde(guardado);
    }

    /** PATCH /api/v1/tutores/{id}: cambia solo lo que viene en el body. */
    @Transactional
    public TutorResponse modificar(Long id, CuentaUsuario cuenta, TutorCambiosRequest cambios) {
        Tutor tutor = buscarDelUsuario(id, cuenta.usuarioId()); // RN04

        boolean cambiaDni = cambios.dni() != null && !cambios.dni().equals(tutor.getDni());
        boolean cambiaCalle = cambios.calle() != null && !esLaMismaCalle(tutor.getCalle(), cambios.calle());
        boolean cambiaAltura = cambios.altura() != null && !Objects.equals(cambios.altura(), tutor.getAltura());

        // RN17: si ya tiene perros en el padrón, el DNI y el domicilio quedan fijos
        if ((cambiaDni || cambiaCalle || cambiaAltura) && perroRepository.existsByTutor(tutor)) {
            throw new ReglaNegocioException(
                    "Ya tenés perros en el padrón: el DNI y el domicilio solo se cambian con un trámite en Zoonosis");
        }
        if (cambiaDni) {
            validarDniLibre(cambios.dni(), cuenta.usuarioId()); // RN16
            tutor.setDni(cambios.dni());
        }
        if (cambiaAltura) {
            tutor.setAltura(cambios.altura());
        }
        if (cambiaCalle) {
            validarCalle(tutor, cambios.calle()); // RN03
        }
        if (cambios.telefono() != null) {
            tutor.setTelefono(cambios.telefono());
        }
        // Si el vecino cambió su nombre o email en su cuenta, se actualizan solos
        copiarDatosDeLaCuenta(tutor, cuenta);
        // No hace falta save(): el tutor vino de la base dentro de esta transacción
        return TutorResponse.desde(tutor);
    }

    /** RN04: el tutor tiene que existir (404) y ser del usuario del token (403). */
    private Tutor buscarDelUsuario(Long id, String usuarioId) {
        Tutor tutor = tutorRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existen los datos de tutor " + id));
        if (!tutor.getUsuarioId().equals(usuarioId)) {
            throw new PermisoDenegadoException("Solo podés ver y cambiar tus propios datos de tutor");
        }
        return tutor;
    }

    /** RN16: un DNI, una cuenta. */
    private void validarDniLibre(String dni, String usuarioId) {
        tutorRepository.findByDni(dni)
                .filter(otro -> !otro.getUsuarioId().equals(usuarioId))
                .ifPresent(otro -> {
                    throw new ReglaNegocioException("DNI inválido: el DNI ya está asociado a otra cuenta");
                });
    }

    /**
     * RN03 con Georef: la calle tiene que existir en Villa Allende y se guarda con su nombre oficial.
     * Si Georef no responde, no se frena al vecino: se guarda como SIN_VERIFICAR y Zoonosis lo revisa a mano.
     */
    private void validarCalle(Tutor tutor, String calle) {
        try {
            String calleOficial = georefClient.buscarCalle(calle.trim())
                    .orElseThrow(() -> new ReglaNegocioException("Calle inválida: la calle no existe en Villa Allende"));
            tutor.setCalle(calleOficial);
            tutor.setEstadoDomicilio(EstadoDomicilio.VERIFICADO);
        } catch (ServicioNoDisponibleException e) {
            log.warn("Georef no disponible: el domicilio se guarda SIN_VERIFICAR ({})", e.getMessage());
            tutor.setCalle(calle.trim());
            tutor.setEstadoDomicilio(EstadoDomicilio.SIN_VERIFICAR);
        }
    }

    private void copiarDatosDeLaCuenta(Tutor tutor, CuentaUsuario cuenta) {
        tutor.setNombre(cuenta.nombre());
        tutor.setApellido(cuenta.apellido());
        tutor.setEmail(cuenta.email());
    }

    /**
     * Se guarda el nombre oficial de Georef ("AV RIO DE JANEIRO"), pero el vecino puede volver a escribir
     * "Rio de Janeiro". Es la misma calle si, sin tildes ni mayúsculas, el nombre guardado termina con lo que escribió.
     */
    private boolean esLaMismaCalle(String guardada, String escrita) {
        return Textos.normalizar(guardada).endsWith(Textos.normalizar(escrita));
    }
}
