package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.clients.OpenStreetMapClient;
import ar.edu.utn.frc.zoonosis.registro.clients.SanidadClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.UbicacionRequest;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * El único lugar donde un perro entra al padrón. Lo usan:
 * - SolicitudService al aprobar una solicitud (P1)
 * - PerroService al dar de alta un perro comunitario (P4)
 * Está en una clase aparte para que los dos lo llamen a través del proxy de Spring
 * (sin self-invocation) y la transacción funcione siempre.
 */
@Service
public class PadronService {

    private static final Logger log = LoggerFactory.getLogger(PadronService.class);

    // Tamaño de cada zona del mapa: 0,005 grados (unos 500 m)
    private static final BigDecimal TAMANIO_ZONA = new BigDecimal("0.005");
    private static final BigDecimal MEDIA_ZONA = new BigDecimal("0.5");

    private final PerroRepository perroRepository;
    private final SanidadClient sanidadClient;
    private final OpenStreetMapClient openStreetMapClient;
    private final GeorefClient georefClient;

    public PadronService(PerroRepository perroRepository, SanidadClient sanidadClient,
                         OpenStreetMapClient openStreetMapClient, GeorefClient georefClient) {
        this.perroRepository = perroRepository;
        this.sanidadClient = sanidadClient;
        this.openStreetMapClient = openStreetMapClient;
        this.georefClient = georefClient;
    }

    /**
     * Le pone código y zona al perro, lo guarda y le abre la libreta en ms-sanidad.
     * La zona sale de la calle y el número donde vive (el domicilio del tutor, o el lugar del comunitario).
     * ubicacionDelPersonal es opcional: la latitud y longitud que indica el personal por si OpenStreetMap
     * no encuentra la dirección. Si OpenStreetMap la encuentra, no se usa.
     * Si OpenStreetMap, Georef o ms-sanidad no responden, sale ServicioNoDisponibleException: como es una
     * RuntimeException, Spring deshace la transacción (no queda un perro sin libreta ni sin zona) y el cliente recibe 503.
     */
    @Transactional
    public Perro darDeAlta(Perro perro, String calle, Integer altura, UbicacionRequest ubicacionDelPersonal,
                           LocalDate antirrabicaDeclarada) {
        // La ubicación solo se usa para calcular la zona (500 m): las coordenadas no se guardan.
        // Primero se busca la calle y el número; la del personal es solo para cuando no se encuentra
        OpenStreetMapClient.Punto punto = openStreetMapClient.ubicar(calle, altura)
                .orElseGet(() -> usarUbicacionDelPersonal(calle, altura, ubicacionDelPersonal));

        // Código del padrón: VA-000001, VA-000002... El número lo da una secuencia de la base (data.sql)
        perro.setCodigo(String.format("VA-%06d", perroRepository.siguienteNumeroDeCodigo()));
        perro.setFechaAlta(LocalDateTime.now());
        asignarZona(perro, punto.latitud(), punto.longitud());
        Perro guardado = perroRepository.save(perro);
        log.info("Alta en el padrón de {} (zona {}): pidiendo a ms-sanidad que abra la libreta", guardado.getCodigo(), guardado.getZonaId());

        sanidadClient.abrirLibreta(new SanidadClient.AperturaLibreta(
                guardado.getCodigo(), antirrabicaDeclarada,
                guardado.getZonaId(), guardado.getZonaLatCentro(), guardado.getZonaLonCentro()));
        log.info("ms-sanidad abrió la libreta de {}", guardado.getCodigo());
        return guardado;
    }

    /**
     * OpenStreetMap no encontró la dirección. Si el personal indicó latitud y longitud (por ejemplo, desde
     * Google Maps), se usan, siempre que caigan dentro de Villa Allende (límite oficial, Georef).
     * Si no las indicó, 422: no se inventa una zona.
     */
    private OpenStreetMapClient.Punto usarUbicacionDelPersonal(String calle, Integer altura, UbicacionRequest ubicacion) {
        if (ubicacion == null) {
            throw new ReglaNegocioException("No se pudo ubicar en el mapa la dirección " + calle + " " + altura
                    + ": si es correcta, indicá su latitud y longitud en \"ubicacion\" (por ejemplo, desde Google Maps)");
        }
        if (!georefClient.estaEnVillaAllende(ubicacion.latitud(), ubicacion.longitud())) {
            throw new ReglaNegocioException("Ubicación inválida: la latitud y longitud indicadas no son de Villa Allende");
        }
        log.info("No se encontró {} {} en el mapa: se usa la ubicación que indicó el personal", calle, altura);
        return new OpenStreetMapClient.Punto(ubicacion.latitud(), ubicacion.longitud());
    }

    /**
     * Zona de la cuadrícula del mapa (sección 6.1):
     * fila = piso(lat / 0,005), columna = piso(lon / 0,005), zonaId = "fila_columna",
     * centro = (fila + 0,5) * 0,005 y (columna + 0,5) * 0,005.
     * Ejemplo: -31.2946, -64.2953 -> zona "-6259_-12860", centro -31.292500, -64.297500.
     */
    private void asignarZona(Perro perro, BigDecimal latitud, BigDecimal longitud) {
        BigDecimal fila = latitud.divide(TAMANIO_ZONA, 0, RoundingMode.FLOOR);
        BigDecimal columna = longitud.divide(TAMANIO_ZONA, 0, RoundingMode.FLOOR);
        perro.setZonaId(fila.toPlainString() + "_" + columna.toPlainString());
        perro.setZonaLatCentro(fila.add(MEDIA_ZONA).multiply(TAMANIO_ZONA).setScale(6, RoundingMode.HALF_UP));
        perro.setZonaLonCentro(columna.add(MEDIA_ZONA).multiply(TAMANIO_ZONA).setScale(6, RoundingMode.HALF_UP));
    }
}
