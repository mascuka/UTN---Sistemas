package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Ficha del perro para el personal de Zoonosis (RF08): datos del perro, su tutor (o "comunitario")
 * y el estado sanitario que informa ms-sanidad (AL_DIA, IRREGULAR o NO_DISPONIBLE si no respondió).
 */
public record PerroFichaResponse(
        String codigo,
        String nombre,
        String raza,
        Sexo sexo,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaNacimiento,
        BigDecimal pesoKg,
        boolean castrado,
        @JsonFormat(pattern = FormatoFecha.FECHA_Y_HORA) LocalDateTime fechaAlta,
        Boolean comunitario,         // solo comunitarios (true); en los demás no sale
        String referenciaUbicacion,  // solo comunitarios
        TutorFicha tutor,            // solo perros con tutor
        String estadoSanitario,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaVencimientoAntirrabica
) {

    // Quién es el tutor y cómo contactarlo (solo lo ve el personal; por ejemplo, ante una mordedura)
    public record TutorFicha(String dni, String nombre, String domicilio, String telefono, String email) { }

    public static PerroFichaResponse desde(Perro perro, String estadoSanitario, LocalDate vencimiento) {
        Tutor tutor = perro.getTutor();
        TutorFicha datosTutor = tutor == null ? null : new TutorFicha(
                tutor.getDni(),
                tutor.getNombre() + " " + tutor.getApellido(),
                tutor.getCalle() + (tutor.getAltura() != null ? " " + tutor.getAltura() : ""),
                tutor.getTelefono(),
                tutor.getEmail());
        return new PerroFichaResponse(
                perro.getCodigo(),
                perro.getNombre(),
                perro.getRaza(),
                perro.getSexo(),
                perro.getFechaNacimiento(),
                perro.getPesoKg(),
                perro.isCastrado(),
                perro.getFechaAlta(),
                tutor == null ? Boolean.TRUE : null,
                perro.getReferenciaUbicacion(),
                datosTutor,
                estadoSanitario,
                vencimiento);
    }
}
