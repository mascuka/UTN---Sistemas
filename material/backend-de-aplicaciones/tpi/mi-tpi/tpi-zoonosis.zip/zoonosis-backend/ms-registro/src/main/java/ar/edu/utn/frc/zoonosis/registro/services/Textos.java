package ar.edu.utn.frc.zoonosis.registro.services;

import java.text.Normalizer;

/**
 * Ayuda para comparar textos que escribe el vecino (nombres de perros, calles) sin que importen
 * las mayúsculas, las tildes ni los espacios de los costados. La usan SolicitudService (RN05), TutorService (RN17) y RazaService (la raza del listado).
 */
final class Textos {

    private Textos() { }

    /** "  Tóby " -> "toby": saca las tildes, los espacios de los costados y pasa a minúsculas. */
    static String normalizar(String texto) {
        String sinTildes = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return sinTildes.trim().toLowerCase();
    }
}
