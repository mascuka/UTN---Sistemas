package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.registro.clients.GeorefClient;
import ar.edu.utn.frc.zoonosis.registro.clients.SanidadClient;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroComunitarioRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroFichaResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroPadronResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroVeterinarioResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.VerificacionPerroResponse;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.RecordComponent;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas de los perros del padrón: comunitarios (RN18, P4), ficha con sanidad caído (P3),
 * cada vecino ve solo sus perros (RN04), los perros de un DNI para el veterinario (RF15)
 * y la verificación que pide el veterinario (RN12).
 */
@ExtendWith(MockitoExtension.class)
class PerroServiceTest {

    @Mock PerroRepository perroRepository;
    @Mock PadronService padronService;
    @Mock RazaService razaService;
    @Mock GeorefClient georefClient;
    @Mock SanidadClient sanidadClient;
    @InjectMocks PerroService perroService;

    private final PerroComunitarioRequest comunitario = new PerroComunitarioRequest("Negro", "Mestizo", Sexo.MACHO,
            LocalDate.of(2020, 1, 1), new BigDecimal("22"), false, "Bartolome Mitre", 400, "Plaza", null);

    @Test
    void unComunitarioEnUnaCalleQueNoEsDeVillaAllendeSeRechaza_RN18() {
        when(georefClient.buscarCalle("Bartolome Mitre")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> perroService.altaComunitario(comunitario)).isInstanceOf(ReglaNegocioException.class);
        verify(padronService, never()).darDeAlta(any(), any(), any(), any(), any());
    }

    @Test
    void unComunitarioConUnaRazaQueNoEstaEnElListadoSeRechaza_RN19() {
        when(razaService.nombreOficial("Mestizo")).thenThrow(new ReglaNegocioException("Raza inválida"));

        assertThatThrownBy(() -> perroService.altaComunitario(comunitario)).isInstanceOf(ReglaNegocioException.class);
        verify(georefClient, never()).buscarCalle(any());
        verify(padronService, never()).darDeAlta(any(), any(), any(), any(), any());
    }

    @Test
    void siGeorefNoRespondeElAltaDelComunitarioDa503_RN18() {
        when(georefClient.buscarCalle(any())).thenThrow(new ServicioNoDisponibleException("Georef no responde"));

        assertThatThrownBy(() -> perroService.altaComunitario(comunitario)).isInstanceOf(ServicioNoDisponibleException.class);
        verify(padronService, never()).darDeAlta(any(), any(), any(), any(), any());
    }

    @Test
    void elComunitarioSeDaDeAltaSinTutorYSinAntirrabicaConLaCalleOficial_P4() {
        when(razaService.nombreOficial("Mestizo")).thenReturn("Mestizo");
        when(georefClient.buscarCalle("Bartolome Mitre")).thenReturn(Optional.of("BARTOLOME MITRE"));
        Perro alta = new Perro();
        alta.setCodigo("VA-000002");
        when(padronService.darDeAlta(any(), eq("BARTOLOME MITRE"), eq(400), any(), any())).thenAnswer(inv -> {
            Perro p = inv.getArgument(0);
            assertThat(p.getTutor()).isNull();
            assertThat((LocalDate) inv.getArgument(4)).isNull();
            return alta;
        });

        assertThat(perroService.altaComunitario(comunitario).codigo()).isEqualTo("VA-000002");
    }

    @Test
    void siSanidadNoRespondeLaFichaSaleIgualConNoDisponible_P3() {
        when(perroRepository.findByCodigo("VA-000001")).thenReturn(Optional.of(perroConTutor()));
        when(sanidadClient.consultarEstado("VA-000001")).thenThrow(new ServicioNoDisponibleException("ms-sanidad no respondió"));

        PerroFichaResponse ficha = perroService.ficha("VA-000001", null); // null = la pide el personal

        assertThat(ficha.nombre()).isEqualTo("Toby");
        assertThat(ficha.estadoSanitario()).isEqualTo("NO_DISPONIBLE");
    }

    @Test
    void unVecinoSoloVeLaFichaDeSusPerros_RN04() {
        when(perroRepository.findByCodigo("VA-000001")).thenReturn(Optional.of(perroConTutor()));

        assertThatThrownBy(() -> perroService.ficha("VA-000001", "sub-de-otro-vecino"))
                .isInstanceOf(PermisoDenegadoException.class);
        verify(sanidadClient, never()).consultarEstado(any());
    }

    @Test
    void elPersonalVeElPadronOSoloLosPerrosDeUnDniSinPreguntarleASanidad_RF14() {
        Perro sinTutor = perroConTutor();
        sinTutor.setCodigo("VA-000002");
        sinTutor.setTutor(null);
        sinTutor.setReferenciaUbicacion("Plaza");
        when(perroRepository.findAllByOrderByCodigoAsc()).thenReturn(List.of(perroConTutor(), sinTutor));
        when(perroRepository.findByTutorDniOrderByNombreAsc("30111222")).thenReturn(List.of(perroConTutor()));

        List<PerroPadronResponse> todos = perroService.padron(null);
        List<PerroPadronResponse> deUnDni = perroService.padron(" 30111222 ");

        assertThat(todos).extracting(PerroPadronResponse::codigo).containsExactly("VA-000001", "VA-000002");
        assertThat(todos.get(0).tutor().dni()).isEqualTo("30111222");
        assertThat(todos.get(0).comunitario()).isNull();  // solo sale en los comunitarios
        assertThat(todos.get(1).comunitario()).isTrue();
        assertThat(todos.get(1).referenciaUbicacion()).isEqualTo("Plaza");
        assertThat(deUnDni).extracting(PerroPadronResponse::nombre).containsExactly("Toby");
        verify(sanidadClient, never()).consultarEstado(any());
    }

    @Test
    void elVeterinarioVeLosPerrosDeUnDniSoloConDatosDeLosPerros_RF15() {
        when(perroRepository.findByTutorDniOrderByNombreAsc("30111222")).thenReturn(List.of(perroConTutor()));

        List<PerroVeterinarioResponse> perros = perroService.paraVeterinario(" 30111222 ", "vet1");

        assertThat(perros).extracting(PerroVeterinarioResponse::codigo).containsExactly("VA-000001");
        assertThat(perros.get(0).nombre()).isEqualTo("Toby");
        assertThat(perros.get(0).fechaNacimiento()).isEqualTo(LocalDate.of(2021, 5, 10));
        // RN12: la respuesta no tiene ningún campo del tutor (ni DNI, ni nombre, ni domicilio, ni teléfono)
        assertThat(PerroVeterinarioResponse.class.getRecordComponents()).extracting(RecordComponent::getName)
                .containsExactly("codigo", "nombre", "raza", "sexo", "fechaNacimiento");
        verify(sanidadClient, never()).consultarEstado(any());
    }

    @Test
    void siElDniNoTienePerrosElVeterinarioRecibeUnaListaVacia_RF15() {
        when(perroRepository.findByTutorDniOrderByNombreAsc("11111111")).thenReturn(List.of());

        assertThat(perroService.paraVeterinario("11111111", "vet1")).isEmpty();
    }

    @Test
    void laVerificacionSoloDiceSiElDniCoincide_RN12() {
        when(perroRepository.findByCodigo("VA-000001")).thenReturn(Optional.of(perroConTutor()));

        VerificacionPerroResponse bien = perroService.verificar("VA-000001", "30111222");
        VerificacionPerroResponse mal = perroService.verificar("VA-000001", "11111111");

        assertThat(bien.existe()).isTrue();
        assertThat(bien.dniCoincide()).isTrue();
        assertThat(mal.dniCoincide()).isFalse();
    }

    @Test
    void laVerificacionDeUnComunitarioNoPideDni_RN12() {
        Perro sinTutor = perroConTutor();
        sinTutor.setTutor(null);
        when(perroRepository.findByCodigo("VA-000002")).thenReturn(Optional.of(sinTutor));

        VerificacionPerroResponse respuesta = perroService.verificar("VA-000002", null);

        assertThat(respuesta.comunitario()).isTrue();
    }

    @Test
    void laVerificacionDeUnPerroQueNoEstaEnElPadron_RN08() {
        when(perroRepository.findByCodigo("VA-999999")).thenReturn(Optional.empty());

        assertThat(perroService.verificar("VA-999999", "30111222").existe()).isFalse();
    }

    private Perro perroConTutor() {
        Tutor tutor = new Tutor();
        tutor.setUsuarioId("sub-de-vecino1");
        tutor.setDni("30111222");
        tutor.setCalle("AV RIO DE JANEIRO");
        tutor.setAltura(450);
        Perro perro = new Perro();
        perro.setCodigo("VA-000001");
        perro.setNombre("Toby");
        perro.setFechaNacimiento(LocalDate.of(2021, 5, 10));
        perro.setTutor(tutor);
        return perro;
    }
}
