package ar.edu.utn.frc.zoonosis.registro.controllers;

import ar.edu.utn.frc.zoonosis.registro.dtos.PerrosPorZonaResponse;
import ar.edu.utn.frc.zoonosis.registro.services.EstadisticaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Mapa de calor público (sin token): perros por zona (RF12).
 */
@RestController
@RequestMapping("/api/v1/estadisticas")
public class EstadisticaController {

    private final EstadisticaService estadisticaService;

    public EstadisticaController(EstadisticaService estadisticaService) {
        this.estadisticaService = estadisticaService;
    }

    @GetMapping("/perros-por-zona")
    public ResponseEntity<List<PerrosPorZonaResponse>> perrosPorZona() {
        return ResponseEntity.ok(estadisticaService.perrosPorZona());
    }
}
