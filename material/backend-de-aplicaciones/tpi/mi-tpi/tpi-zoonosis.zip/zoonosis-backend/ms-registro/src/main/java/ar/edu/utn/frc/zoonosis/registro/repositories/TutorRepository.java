package ar.edu.utn.frc.zoonosis.registro.repositories;

import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Acceso a la tabla tutor. Spring Data arma el SQL a partir del nombre del método:
 * findByUsuarioId -> SELECT ... FROM tutor WHERE usuario_id = ?
 */
public interface TutorRepository extends JpaRepository<Tutor, Long> {

    Optional<Tutor> findByUsuarioId(String usuarioId);

    Optional<Tutor> findByDni(String dni);
}
