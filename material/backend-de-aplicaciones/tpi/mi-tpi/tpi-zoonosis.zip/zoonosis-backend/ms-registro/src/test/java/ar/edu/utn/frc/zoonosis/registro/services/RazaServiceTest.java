package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.registro.models.Raza;
import ar.edu.utn.frc.zoonosis.registro.repositories.RazaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

/**
 * Pruebas del listado de razas de Zoonosis (RN19): solo se aceptan razas del listado, sin que importen
 * las mayúsculas ni las tildes, y se guardan como figuran ahí.
 */
@ExtendWith(MockitoExtension.class)
class RazaServiceTest {

    @Mock RazaRepository razaRepository;
    @InjectMocks RazaService razaService;

    @Test
    void laRazaSeBuscaSinMayusculasNiTildesYDevuelveElNombreDelListado_RN19() {
        when(razaRepository.findAll()).thenReturn(List.of(raza("Mestizo"), raza("Ovejero Alemán")));

        assertThat(razaService.nombreOficial("  ovejero aleman ")).isEqualTo("Ovejero Alemán");
        assertThat(razaService.nombreOficial("MESTIZO")).isEqualTo("Mestizo");
    }

    @Test
    void unaRazaQueNoEstaEnElListadoSeRechazaYDiceQuePoner_RN19() {
        when(razaRepository.findAll()).thenReturn(List.of(raza("Mestizo"), raza("No identificada")));

        assertThatThrownBy(() -> razaService.nombreOficial("Perro de raza"))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("Raza inválida")
                .hasMessageContaining("Mestizo")
                .hasMessageContaining("No identificada");
    }

    private Raza raza(String nombre) {
        Raza raza = new Raza();
        raza.setNombre(nombre);
        return raza;
    }
}
