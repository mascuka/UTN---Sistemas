package ar.edu.utn.frc.zoonosis.registro.repositories;

import ar.edu.utn.frc.zoonosis.registro.models.Raza;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Acceso al listado de razas de Zoonosis (validación de la raza y alerta de posible PPP, RN06).
 */
public interface RazaRepository extends JpaRepository<Raza, Long> {

    // ¿Es una raza potencialmente peligrosa? Sin distinguir mayúsculas: "rottweiler" = "Rottweiler"
    boolean existsByNombreIgnoreCaseAndPeligrosaTrue(String nombre);
}
