package ar.edu.utn.frc.zoonosis.registro.dtos;

import java.time.LocalDate;

/**
 * Respuesta del endpoint interno que usa ms-sanidad antes de registrar una vacuna (P2, RN08 y RN12).
 * Solo dice sí o no: nunca devuelve el DNI ni otros datos del tutor.
 */
public record VerificacionPerroResponse(
        boolean existe,          // ¿el perro está en el padrón?
        boolean comunitario,     // sin tutor: no hace falta DNI
        boolean dniCoincide,     // ¿el DNI que ingresó el veterinario es el del tutor?
        LocalDate fechaNacimiento // para validar que la vacuna no sea anterior (RN11)
) { }
