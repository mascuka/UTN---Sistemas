package ar.edu.utn.frc.zoonosis.registro.controllers;

import ar.edu.utn.frc.zoonosis.registro.dtos.CuentaUsuario;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorCambiosRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.TutorResponse;
import ar.edu.utn.frc.zoonosis.registro.services.TutorService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

/**
 * Endpoints de los datos del tutor (RF01). Solo maneja HTTP: la lógica está en TutorService.
 * El usuario sale del token (jwt.getSubject() = "sub"). Si se pide un tutor por id, el service controla
 * que sea del usuario del token: un vecino nunca ve ni cambia los datos de otro (RN04).
 */
@RestController
@RequestMapping("/api/v1/tutores")
public class TutorController {

    private final TutorService tutorService;

    public TutorController(TutorService tutorService) {
        this.tutorService = tutorService;
    }

    // Los datos de tutor del vecino del token: una lista con uno, o vacía si todavía no los cargó
    @GetMapping
    public ResponseEntity<List<TutorResponse>> listar(@AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(tutorService.listar(jwt.getSubject()));
    }

    // 200 · 403 si son de otro vecino · 404
    @GetMapping("/{id}")
    public ResponseEntity<TutorResponse> obtener(@PathVariable Long id, @AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(tutorService.obtener(id, jwt.getSubject()));
    }

    // Alta, una sola vez: 201 con la dirección del recurso creado · 400 · 409 si ya los cargó · 422 (RN03, RN16)
    @PostMapping
    public ResponseEntity<TutorResponse> crear(@AuthenticationPrincipal Jwt jwt, @Valid @RequestBody TutorRequest datos) {
        TutorResponse creado = tutorService.crear(CuentaUsuario.desde(jwt), datos);
        return ResponseEntity.created(URI.create("/api/v1/tutores/" + creado.id())).body(creado);
    }

    // Cambio parcial: solo lo que viene en el body. 200 · 400 · 403 · 404 · 422 (RN03, RN16, RN17)
    @PatchMapping("/{id}")
    public ResponseEntity<TutorResponse> modificar(@PathVariable Long id, @AuthenticationPrincipal Jwt jwt,
                                                   @Valid @RequestBody TutorCambiosRequest cambios) {
        return ResponseEntity.ok(tutorService.modificar(id, CuentaUsuario.desde(jwt), cambios));
    }
}
