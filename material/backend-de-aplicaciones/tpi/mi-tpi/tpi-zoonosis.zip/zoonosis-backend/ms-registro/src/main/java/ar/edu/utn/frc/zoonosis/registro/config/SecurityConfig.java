package ar.edu.utn.frc.zoonosis.registro.config;

import ar.edu.utn.frc.zoonosis.commons.security.RolesKeycloakConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Quién puede llamar a cada endpoint de ms-registro.
 * El gateway también controla esto; el servicio lo vuelve a controlar (defensa en profundidad).
 * Las reglas se leen de arriba hacia abajo y gana la primera que coincide.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filtroDeSeguridad(HttpSecurity http) throws Exception {
        // Usa los roles de Keycloak (realm_access.roles) como roles de Spring: VECINO -> ROLE_VECINO
        JwtAuthenticationConverter rolesDelToken = new JwtAuthenticationConverter();
        rolesDelToken.setJwtGrantedAuthoritiesConverter(new RolesKeycloakConverter());

        http
            // API REST con token: no usa sesiones ni formularios, así que no necesita CSRF
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(reglas -> reglas
                // Públicos: estado del servicio, documentación, la página de error de Spring y el mapa de calor
                .requestMatchers("/actuator/health", "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/error").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/v1/estadisticas/**").permitAll()

                // Vecino: sus datos de tutor (RF01) y enviar solicitudes (RF02).
                // Que cada uno vea solo lo suyo lo controla el service con el usuario del token (RN04)
                .requestMatchers("/api/v1/tutores", "/api/v1/tutores/*").hasRole("VECINO")
                .requestMatchers(HttpMethod.POST, "/api/v1/solicitudes").hasRole("VECINO")

                // Vecino o personal: las mismas URLs; el personal ve todo y el vecino solo lo suyo
                // (solicitudes: RF03 y RF05; ficha del perro: RF08)
                .requestMatchers(HttpMethod.GET, "/api/v1/solicitudes", "/api/v1/solicitudes/*", "/api/v1/perros/*")
                        .hasAnyRole("VECINO", "PERSONAL_MUNICIPAL")
                // La lista de perros también la usa el veterinario: con ?dniTutor= ve los perros de una persona,
                // solo con datos de los perros (vecino: RF04; personal: RF14; veterinario: RF15)
                .requestMatchers(HttpMethod.GET, "/api/v1/perros").hasAnyRole("VECINO", "PERSONAL_MUNICIPAL", "VETERINARIO")

                // Personal de Zoonosis: resolver solicitudes (RF06) y dar de alta comunitarios (RF07)
                .requestMatchers(HttpMethod.PATCH, "/api/v1/solicitudes/*").hasRole("PERSONAL_MUNICIPAL")
                .requestMatchers(HttpMethod.POST, "/api/v1/perros/comunitarios").hasRole("PERSONAL_MUNICIPAL")

                // Interno (lo llama ms-sanidad con el token del veterinario): verificación antes de una vacuna (P2)
                .requestMatchers(HttpMethod.GET, "/internal/perros/*/verificacion").hasRole("VETERINARIO")

                // Cualquier otra ruta se rechaza
                .anyRequest().denyAll())
            .oauth2ResourceServer(oauth -> oauth.jwt(jwt -> jwt.jwtAuthenticationConverter(rolesDelToken)));
        return http.build();
    }
}
