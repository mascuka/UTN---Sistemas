package ar.edu.utn.frc.zoonosis.registro.dtos;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Body de PATCH /api/v1/tutores/{id}: se manda solo lo que se quiere cambiar (lo que no viene, no cambia).
 * Si viene, tiene que tener el formato correcto (un campo que no viene no se valida).
 * El DNI y el domicilio no se pueden cambiar si el tutor ya tiene perros en el padrón (RN17).
 */
public record TutorCambiosRequest(

        @Pattern(regexp = "\\d{7,8}", message = "DNI inválido: el DNI tiene que tener 7 u 8 números, sin puntos")
        String dni,

        @Size(min = 1, max = 120, message = "Calle inválida: la calle tiene que tener entre 1 y 120 caracteres")
        String calle,

        @Positive(message = "Altura inválida: la altura tiene que ser mayor a 0")
        Integer altura,

        @Pattern(regexp = "\\d{8,15}", message = "Teléfono inválido: el teléfono tiene que tener entre 8 y 15 números, sin espacios ni guiones")
        String telefono
) {
}
