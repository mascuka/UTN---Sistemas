-- Razas que acepta Zoonosis (listado de ejemplo: el real lo define Zoonosis). Un perro solo se carga con una
-- de estas razas; "Mestizo" es una cruza y "No identificada", cuando no se sabe.
-- peligrosa = true: las razas de la alerta de perro potencialmente peligroso (RN06).
-- ON CONFLICT evita duplicarlas en cada arranque.
INSERT INTO registro.raza (nombre, peligrosa) VALUES
    ('Mestizo', false),
    ('No identificada', false),
    ('Basset Hound', false),
    ('Beagle', false),
    ('Bichón Frisé', false),
    ('Border Collie', false),
    ('Boxer', false),
    ('Boyero de Berna', false),
    ('Bull Terrier', false),
    ('Bulldog Francés', false),
    ('Bulldog Inglés', false),
    ('Caniche', false),
    ('Chihuahua', false),
    ('Chow Chow', false),
    ('Cocker Spaniel', false),
    ('Collie', false),
    ('Dálmata', false),
    ('Doberman', false),
    ('Fox Terrier', false),
    ('Galgo', false),
    ('Golden Retriever', false),
    ('Gran Danés', false),
    ('Husky Siberiano', false),
    ('Jack Russell', false),
    ('Labrador', false),
    ('Lhasa Apso', false),
    ('Maltés', false),
    ('Ovejero Alemán', false),
    ('Pastor Belga', false),
    ('Pekinés', false),
    ('Pinscher', false),
    ('Pomerania', false),
    ('Pug', false),
    ('Salchicha', false),
    ('Samoyedo', false),
    ('San Bernardo', false),
    ('Schnauzer', false),
    ('Setter Irlandés', false),
    ('Shar Pei', false),
    ('Shih Tzu', false),
    ('Weimaraner', false),
    ('West Highland Terrier', false),
    ('Yorkshire Terrier', false),
    ('Pit Bull Terrier', true),
    ('American Staffordshire Terrier', true),
    ('Staffordshire Bull Terrier', true),
    ('Rottweiler', true),
    ('Dogo Argentino', true),
    ('Fila Brasileiro', true),
    ('Tosa Inu', true),
    ('Akita Inu', true)
ON CONFLICT (nombre) DO NOTHING;

-- Numerador del código de los perros (VA-000001, VA-000002...). IF NOT EXISTS: se crea una sola vez.
CREATE SEQUENCE IF NOT EXISTS registro.perro_codigo_seq;

-- ===== Datos de prueba para el mapa de calor (RF12 y RF13) =====
-- Tutores de ejemplo, con domicilios en calles reales de Villa Allende. No tienen cuenta en Keycloak
-- (el usuario_id es inventado): solo existen para que sus perros estén en el padrón y en el mapa.
INSERT INTO registro.tutor (usuario_id, dni, nombre, apellido, calle, altura, telefono, email, estado_domicilio, fecha_consentimiento) VALUES
    ('ejemplo-tutor-01', '20100001', 'María', 'Fernández', 'AV RIO DE JANEIRO', 820, '3515550101', 'maria.fernandez@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-02', '20100002', 'Jorge', 'Sosa', 'ALBERDI', 345, '3515550102', 'jorge.sosa@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-03', '20100003', 'Lucía', 'Romero', 'AV SAN MARTIN', 1210, '3515550103', 'lucia.romero@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-04', '20100004', 'Pablo', 'Herrera', 'BALCARCE', 77, '3515550104', 'pablo.herrera@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-05', '20100005', 'Carla', 'Medina', '25 DE MAYO', 560, '3515550105', 'carla.medina@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-06', '20100006', 'Diego', 'Castro', 'ARENALES', 912, '3515550106', 'diego.castro@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-07', '20100007', 'Sofía', 'Navarro', 'AV DEL CARMEN', 233, '3515550107', 'sofia.navarro@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-08', '20100008', 'Martín', 'Acosta', 'BELLA VISTA', 145, '3515550108', 'martin.acosta@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-09', '20100009', 'Valeria', 'Ríos', 'AV GOYCOECHEA', 1430, '3515550109', 'valeria.rios@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-10', '20100010', 'Nicolás', 'Peralta', 'ALSINA', 618, '3515550110', 'nicolas.peralta@example.com', 'VERIFICADO', NOW()),
    ('ejemplo-tutor-11', '20100011', 'Florencia', 'Ortiz', 'BARTOLOME MITRE', 390, '3515550111', 'florencia.ortiz@example.com', 'VERIFICADO', NOW())
ON CONFLICT (dni) DO NOTHING;

-- Perros de ejemplo en 7 zonas: 6 con 3 perros o más y una con solo 2, que no tiene que aparecer en el mapa (RN14).
-- Códigos VA-9xxxxx para no chocar con los que da la secuencia (VA-000001, VA-000002...).
-- La zona ya va calculada (sección 6.1) y es la misma que tiene su libreta en el schema sanidad.
-- dni_tutor NULL = perro comunitario. El tutor se busca por su DNI (LEFT JOIN: los comunitarios quedan sin tutor).
INSERT INTO registro.perro (codigo, nombre, raza, sexo, fecha_nacimiento, peso_kg, castrado, fecha_alta, tutor_id, zona_id, zona_lat_centro, zona_lon_centro, referencia_ubicacion)
SELECT p.codigo, p.nombre, p.raza, p.sexo, p.nacimiento, p.peso, p.castrado, NOW(), t.id, p.zona, p.lat, p.lon, p.referencia
FROM (VALUES
    ('VA-900001', 'Coco', 'Mestizo', 'MACHO', DATE '2020-03-01', 12.50, true, '20100001', '-6259_-12860', -31.292500, -64.297500, NULL),
    ('VA-900002', 'Nala', 'Labrador', 'HEMBRA', DATE '2019-11-15', 28.00, true, '20100001', '-6259_-12860', -31.292500, -64.297500, NULL),
    ('VA-900003', 'Rocky', 'Boxer', 'MACHO', DATE '2018-06-20', 30.00, false, '20100002', '-6259_-12860', -31.292500, -64.297500, NULL),
    ('VA-900004', 'Frida', 'Caniche', 'HEMBRA', DATE '2021-02-10', 5.50, true, '20100002', '-6259_-12860', -31.292500, -64.297500, NULL),
    ('VA-900005', 'Simón', 'Mestizo', 'MACHO', DATE '2022-01-05', 15.00, true, '20100003', '-6258_-12859', -31.287500, -64.292500, NULL),
    ('VA-900006', 'Kiara', 'Golden Retriever', 'HEMBRA', DATE '2020-08-30', 27.50, true, '20100003', '-6258_-12859', -31.287500, -64.292500, NULL),
    ('VA-900007', 'Thor', 'Rottweiler', 'MACHO', DATE '2019-04-12', 42.00, false, '20100004', '-6258_-12859', -31.287500, -64.292500, NULL),
    ('VA-900008', 'Pupi', 'Mestizo', 'HEMBRA', DATE '2023-03-18', 8.00, false, '20100004', '-6258_-12859', -31.287500, -64.292500, NULL),
    ('VA-900009', 'Manchas', 'Mestizo', 'MACHO', DATE '2021-05-01', 18.00, false, NULL, '-6258_-12859', -31.287500, -64.292500, 'Plaza del barrio, junto a los juegos'),
    ('VA-900010', 'Lola', 'Beagle', 'HEMBRA', DATE '2021-09-09', 11.00, true, '20100005', '-6260_-12861', -31.297500, -64.302500, NULL),
    ('VA-900011', 'Bruno', 'Ovejero Alemán', 'MACHO', DATE '2017-12-01', 35.00, true, '20100005', '-6260_-12861', -31.297500, -64.302500, NULL),
    ('VA-900012', 'Mía', 'Mestizo', 'HEMBRA', DATE '2022-07-07', 9.50, true, '20100006', '-6260_-12861', -31.297500, -64.302500, NULL),
    ('VA-900013', 'Tango', 'Dogo Argentino', 'MACHO', DATE '2020-10-10', 38.00, false, '20100007', '-6257_-12861', -31.282500, -64.302500, NULL),
    ('VA-900014', 'Luz', 'Mestizo', 'HEMBRA', DATE '2019-02-14', 14.00, true, '20100007', '-6257_-12861', -31.282500, -64.302500, NULL),
    ('VA-900015', 'Negrita', 'Mestizo', 'HEMBRA', DATE '2020-01-01', 16.00, false, NULL, '-6257_-12861', -31.282500, -64.302500, 'Frente al dispensario'),
    ('VA-900016', 'Colita', 'Mestizo', 'MACHO', DATE '2022-06-01', 13.00, false, NULL, '-6257_-12861', -31.282500, -64.302500, 'Esquina de la escuela'),
    ('VA-900017', 'Milo', 'Schnauzer', 'MACHO', DATE '2021-04-04', 9.00, true, '20100008', '-6261_-12859', -31.302500, -64.292500, NULL),
    ('VA-900018', 'Olivia', 'Mestizo', 'HEMBRA', DATE '2018-09-21', 20.00, true, '20100008', '-6261_-12859', -31.302500, -64.292500, NULL),
    ('VA-900019', 'Zeus', 'Pit Bull Terrier', 'MACHO', DATE '2020-05-05', 26.00, false, '20100008', '-6261_-12859', -31.302500, -64.292500, NULL),
    ('VA-900020', 'Uma', 'Border Collie', 'HEMBRA', DATE '2022-02-22', 17.00, true, '20100009', '-6258_-12862', -31.287500, -64.307500, NULL),
    ('VA-900021', 'Toto', 'Mestizo', 'MACHO', DATE '2016-08-08', 22.00, true, '20100009', '-6258_-12862', -31.287500, -64.307500, NULL),
    ('VA-900022', 'Bella', 'Cocker Spaniel', 'HEMBRA', DATE '2019-07-17', 13.50, true, '20100010', '-6258_-12862', -31.287500, -64.307500, NULL),
    ('VA-900023', 'Jack', 'Jack Russell', 'MACHO', DATE '2021-11-11', 7.00, false, '20100010', '-6258_-12862', -31.287500, -64.307500, NULL),
    ('VA-900024', 'Canela', 'Mestizo', 'HEMBRA', DATE '2018-03-03', 19.00, true, '20100010', '-6258_-12862', -31.287500, -64.307500, NULL),
    ('VA-900025', 'Rulo', 'Mestizo', 'MACHO', DATE '2021-10-01', 21.00, false, NULL, '-6258_-12862', -31.287500, -64.307500, 'Terminal de ómnibus'),
    ('VA-900026', 'Firulais', 'Mestizo', 'MACHO', DATE '2020-12-24', 16.50, true, '20100011', '-6260_-12858', -31.297500, -64.287500, NULL),
    ('VA-900027', 'Pelusa', 'Caniche', 'HEMBRA', DATE '2017-05-30', 6.00, true, '20100011', '-6260_-12858', -31.297500, -64.287500, NULL)
) AS p(codigo, nombre, raza, sexo, nacimiento, peso, castrado, dni_tutor, zona, lat, lon, referencia)
LEFT JOIN registro.tutor t ON t.dni = p.dni_tutor
ON CONFLICT (codigo) DO NOTHING;
