package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;

/**
 * Un perro del padrón, visto por el personal de Zoonosis (RF14): quién es y de quién es.
 * Sin estado sanitario: eso está en la ficha (un perro) y en vencimientos (los que hay que vacunar),
 * así el listado no le pregunta a ms-sanidad por cada perro.
 * Con tutor sale el tutor; los comunitarios no tienen tutor: salen con comunitario = true y dónde viven.
 */
public record PerroPadronResponse(
        String codigo,
        String nombre,
        String raza,
        Boolean comunitario,         // solo comunitarios (true); en los demás no sale
        String referenciaUbicacion,  // solo comunitarios
        TutorPadron tutor            // solo perros con tutor
) {

    public record TutorPadron(String dni, String nombre) { }

    public static PerroPadronResponse desde(Perro perro) {
        Tutor tutor = perro.getTutor();
        return new PerroPadronResponse(
                perro.getCodigo(),
                perro.getNombre(),
                perro.getRaza(),
                tutor == null ? Boolean.TRUE : null,
                perro.getReferenciaUbicacion(),
                tutor == null ? null : new TutorPadron(tutor.getDni(), tutor.getNombre() + " " + tutor.getApellido()));
    }
}
