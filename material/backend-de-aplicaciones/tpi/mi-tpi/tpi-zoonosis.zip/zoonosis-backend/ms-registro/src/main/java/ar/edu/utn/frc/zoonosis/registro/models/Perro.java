package ar.edu.utn.frc.zoonosis.registro.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "perro")
@Getter
@Setter
@NoArgsConstructor
public class Perro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Código del padrón, por ejemplo VA-000123. Es lo único que conoce ms-sanidad
    @Column(nullable = false, unique = true, length = 12)
    private String codigo;

    @Column(nullable = false, length = 60)
    private String nombre;

    @Column(nullable = false, length = 60)
    private String raza;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Sexo sexo;

    // En los perros comunitarios es una fecha estimada
    @Column(nullable = false)
    private LocalDate fechaNacimiento;

    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal pesoKg;

    private boolean castrado;

    @Column(nullable = false)
    private LocalDateTime fechaAlta;

    // null = perro comunitario (sin tutor)
    @ManyToOne
    @JoinColumn(name = "tutor_id")
    private Tutor tutor;

    // Zona de la cuadrícula del mapa, calculada al dar de alta al perro
    @Column(nullable = false, length = 20)
    private String zonaId;

    @Column(nullable = false, precision = 9, scale = 6)
    private BigDecimal zonaLatCentro;

    @Column(nullable = false, precision = 9, scale = 6)
    private BigDecimal zonaLonCentro;

    // Solo comunitarios: dónde vive, sin coordenadas exactas
    @Column(length = 200)
    private String referenciaUbicacion;
}
