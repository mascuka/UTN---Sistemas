package ar.edu.utn.frc.zoonosis.registro.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Sexo;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

/**
 * Un perro de la persona que tiene adelante el veterinario (RF15): solo datos del perro, para encontrar
 * su código cuando la persona no lo sabe. Nunca datos del tutor: ni DNI, ni nombre, ni domicilio, ni teléfono (RN12).
 * La raza, el sexo y la fecha de nacimiento sirven para distinguir los perros si la persona tiene varios.
 */
public record PerroVeterinarioResponse(
        String codigo,
        String nombre,
        String raza,
        Sexo sexo,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaNacimiento
) {

    public static PerroVeterinarioResponse desde(Perro perro) {
        return new PerroVeterinarioResponse(perro.getCodigo(), perro.getNombre(), perro.getRaza(),
                perro.getSexo(), perro.getFechaNacimiento());
    }
}
