package ar.edu.utn.frc.zoonosis.registro.clients;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Habla con OpenStreetMap (Nominatim, API pública y gratuita) para ubicar en el mapa una calle y número
 * de Villa Allende. Hace falta porque Georef no tiene la numeración de las calles de Villa Allende:
 * valida que la calle exista, pero no sabe dónde queda cada número.
 * Si OpenStreetMap tiene el número, el punto es la casa; si no, es un punto de esa calle (aproximado).
 * Solo se le manda la calle y el número: nunca el nombre ni el DNI del vecino.
 * Si no responde, lanza ServicioNoDisponibleException (503): el que llama decide qué hacer.
 */
@Component
public class OpenStreetMapClient {

    private final RestClient osm;

    public OpenStreetMapClient(@Qualifier("openStreetMapRestClient") RestClient osm) {
        this.osm = osm;
    }

    /** El punto (latitud y longitud) de esa dirección de Villa Allende, o vacío si OpenStreetMap no la encuentra. */
    public Optional<Punto> ubicar(String calle, Integer altura) {
        Lugar[] encontrados;
        try {
            encontrados = osm.get()
                    .uri(uri -> uri.path("/search")
                            .queryParam("street", altura + " " + calle)
                            .queryParam("city", "Villa Allende")
                            .queryParam("state", "Córdoba")
                            .queryParam("country", "Argentina")
                            .queryParam("format", "jsonv2")
                            .queryParam("limit", 1)
                            .build())
                    .retrieve()
                    .body(Lugar[].class);
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("OpenStreetMap no responde", e);
        }
        if (encontrados == null) {
            throw new ServicioNoDisponibleException("OpenStreetMap devolvió una respuesta inesperada");
        }
        if (encontrados.length == 0) {
            return Optional.empty();
        }
        return Optional.of(new Punto(new BigDecimal(encontrados[0].lat()), new BigDecimal(encontrados[0].lon())));
    }

    public record Punto(BigDecimal latitud, BigDecimal longitud) { }

    // Lo único que usamos de cada resultado de OpenStreetMap (vienen como texto)
    record Lugar(String lat, String lon) { }
}
