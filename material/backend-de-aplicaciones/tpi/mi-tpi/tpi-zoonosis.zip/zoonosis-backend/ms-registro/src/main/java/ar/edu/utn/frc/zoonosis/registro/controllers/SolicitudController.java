package ar.edu.utn.frc.zoonosis.registro.controllers;

import ar.edu.utn.frc.zoonosis.registro.config.Roles;
import ar.edu.utn.frc.zoonosis.registro.dtos.ResolucionRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudCreadaResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudResponse;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.services.SolicitudService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

/**
 * Endpoints de las solicitudes de registro. Solo maneja HTTP: la lógica está en SolicitudService.
 * Las mismas URLs sirven al vecino y al personal: el personal ve todas (con las alertas),
 * el vecino solo las suyas (sin las alertas internas). El usuario sale del token (RN04).
 */
@RestController
@RequestMapping("/api/v1/solicitudes")
public class SolicitudController {

    private final SolicitudService solicitudService;

    public SolicitudController(SolicitudService solicitudService) {
        this.solicitudService = solicitudService;
    }

    // RF02 (VECINO): enviar una solicitud. 201 con el número, el estado y los avisos · 422 (RN05, RN15)
    @PostMapping
    public ResponseEntity<SolicitudCreadaResponse> crear(@AuthenticationPrincipal Jwt jwt,
                                                         @Valid @RequestBody SolicitudRequest datos) {
        SolicitudCreadaResponse creada = solicitudService.crear(jwt.getSubject(), datos);
        return ResponseEntity.created(URI.create("/api/v1/solicitudes/" + creada.id())).body(creada);
    }

    // RF05 (personal): todas, por estado (por defecto PENDIENTE), con las alertas.
    // RF03 (vecino): solo las suyas (con ?estado= filtra; sin estado, todas las suyas)
    @GetMapping
    public ResponseEntity<List<?>> listar(@RequestParam(required = false) EstadoSolicitud estado,
                                          @AuthenticationPrincipal Jwt jwt, Authentication usuario) {
        if (Roles.esPersonal(usuario)) {
            return ResponseEntity.ok(solicitudService.listar(estado != null ? estado : EstadoSolicitud.PENDIENTE));
        }
        return ResponseEntity.ok(solicitudService.listarDelVecino(jwt.getSubject(), estado));
    }

    // El personal ve cualquiera; el vecino solo las suyas (403 si es de otro). 404 si no existe
    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id, @AuthenticationPrincipal Jwt jwt, Authentication usuario) {
        if (Roles.esPersonal(usuario)) {
            return ResponseEntity.ok(solicitudService.obtener(id));
        }
        return ResponseEntity.ok(solicitudService.obtenerDelVecino(id, jwt.getSubject()));
    }

    // RF06 (personal): aprobar, observar o rechazar. Cambia solo el estado: PATCH.
    // 200 · 404 · 409 (ya resuelta) · 422 (sin mensaje, dirección que no se puede ubicar) · 503
    @PatchMapping("/{id}")
    public ResponseEntity<SolicitudResponse> resolver(@PathVariable Long id,
                                                      @Valid @RequestBody ResolucionRequest datos) {
        return ResponseEntity.ok(solicitudService.resolver(id, datos));
    }
}
