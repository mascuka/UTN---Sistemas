package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.EstadoInvalidoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.PermisoDenegadoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.RecursoNoEncontradoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.registro.dtos.MiSolicitudResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.PerroDatosRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.ResolucionRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudCreadaResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudRequest;
import ar.edu.utn.frc.zoonosis.registro.dtos.SolicitudResponse;
import ar.edu.utn.frc.zoonosis.registro.dtos.UbicacionRequest;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoDomicilio;
import ar.edu.utn.frc.zoonosis.registro.models.EstadoSolicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Perro;
import ar.edu.utn.frc.zoonosis.registro.models.Solicitud;
import ar.edu.utn.frc.zoonosis.registro.models.Tutor;
import ar.edu.utn.frc.zoonosis.registro.repositories.PerroRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.SolicitudRepository;
import ar.edu.utn.frc.zoonosis.registro.repositories.TutorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Lógica de negocio de las solicitudes de registro.
 * Del vecino (RF02, RF03): RN01, RN04, RN05, RN07, RN15 y la raza del listado de Zoonosis.
 * Del personal (RF05, RF06): RN02, las alertas (RN03, RN06, RN07) y la aprobación con apertura de la libreta (P1).
 */
@Service
public class SolicitudService {

    private static final Logger log = LoggerFactory.getLogger(SolicitudService.class);

    // RN06: desde este peso el perro se marca como posible PPP
    private static final BigDecimal PESO_PPP_KG = new BigDecimal("25");

    private final SolicitudRepository solicitudRepository;
    private final TutorRepository tutorRepository;
    private final PerroRepository perroRepository;
    private final RazaService razaService;
    private final PadronService padronService;

    public SolicitudService(SolicitudRepository solicitudRepository, TutorRepository tutorRepository,
                            PerroRepository perroRepository, RazaService razaService, PadronService padronService) {
        this.solicitudRepository = solicitudRepository;
        this.tutorRepository = tutorRepository;
        this.perroRepository = perroRepository;
        this.razaService = razaService;
        this.padronService = padronService;
    }

    /** POST /api/v1/solicitudes: el vecino pide registrar un perro (RF02). */
    @Transactional
    public SolicitudCreadaResponse crear(String usuarioId, SolicitudRequest datos) {
        // RN15: primero tiene que cargar sus datos de tutor
        Tutor tutor = tutorRepository.findByUsuarioId(usuarioId)
                .orElseThrow(() -> new ReglaNegocioException(
                        "Antes de registrar un perro tenés que cargar tus datos de tutor"));

        PerroDatosRequest perro = datos.perro();
        LocalDate antirrabica = datos.fechaUltimaAntirrabica();

        // RN05: si ya mandó ese perro (pendiente) o ya está en el padrón, la solicitud nueva no se guarda
        validarQueNoEsteRepetido(tutor, perro.nombre());

        // La raza tiene que estar en el listado de Zoonosis (422 si no); se guarda como figura ahí
        String raza = razaService.nombreOficial(perro.raza());

        // La vacuna no puede ser de antes de que naciera el perro (la misma regla que RN11 en sanidad)
        if (antirrabica != null && antirrabica.isBefore(perro.fechaNacimiento())) {
            throw new ReglaNegocioException("Fecha de la antirrábica inválida: la fecha de la antirrábica no puede ser anterior al nacimiento del perro");
        }

        Solicitud solicitud = new Solicitud();
        solicitud.setTutor(tutor);
        solicitud.setEstado(EstadoSolicitud.PENDIENTE); // RN01: toda solicitud entra pendiente
        solicitud.setFechaCreacion(LocalDateTime.now());
        solicitud.setNombrePerro(perro.nombre().trim());
        solicitud.setRazaPerro(raza);
        solicitud.setSexoPerro(perro.sexo());
        solicitud.setFechaNacimientoPerro(perro.fechaNacimiento());
        solicitud.setPesoKgPerro(perro.pesoKg());
        solicitud.setCastradoPerro(perro.castrado());
        solicitud.setFechaUltimaAntirrabica(antirrabica);

        // RN07: antirrábica de hace más de un año -> se acepta igual, pero se le avisa al vecino
        List<String> avisos = new ArrayList<>();
        if (antirrabicaVencida(antirrabica, LocalDate.now())) {
            avisos.add("La antirrábica que declaraste tiene más de un año: está vencida. Vacunalo lo antes posible.");
        }

        Solicitud guardada = solicitudRepository.save(solicitud);
        SolicitudResponse.Alertas alertas = alertas(guardada);
        log.info("Solicitud {} creada (PENDIENTE). Alertas: {}", guardada.getId(), alertas == null ? "ninguna" : alertas);
        return SolicitudCreadaResponse.desde(guardada, avisos);
    }

    /** GET /api/v1/solicitudes (vecino): solo las suyas, sin las alertas internas (RF03, RN04). */
    @Transactional(readOnly = true)
    public List<MiSolicitudResponse> listarDelVecino(String usuarioId, EstadoSolicitud estado) {
        return solicitudRepository.findByTutorUsuarioIdOrderByFechaCreacionDesc(usuarioId).stream()
                .filter(solicitud -> estado == null || solicitud.getEstado() == estado)
                .map(MiSolicitudResponse::desde)
                .toList();
    }

    /** GET /api/v1/solicitudes/{id} (vecino): solo si es suya (RN04). */
    @Transactional(readOnly = true)
    public MiSolicitudResponse obtenerDelVecino(Long id, String usuarioId) {
        Solicitud solicitud = buscar(id);
        if (!solicitud.getTutor().getUsuarioId().equals(usuarioId)) {
            throw new PermisoDenegadoException("Solo podés ver tus propias solicitudes");
        }
        return MiSolicitudResponse.desde(solicitud);
    }

    /** GET /api/v1/solicitudes?estado=PENDIENTE (personal): todas las de ese estado, con sus alertas (RF05). */
    @Transactional(readOnly = true)
    public List<SolicitudResponse> listar(EstadoSolicitud estado) {
        return solicitudRepository.findByEstadoOrderByFechaCreacionAsc(estado).stream()
                .map(solicitud -> SolicitudResponse.desde(solicitud, alertas(solicitud)))
                .toList();
    }

    /** GET /api/v1/solicitudes/{id} (personal): el detalle con los datos del tutor y las alertas. */
    @Transactional(readOnly = true)
    public SolicitudResponse obtener(Long id) {
        Solicitud solicitud = buscar(id);
        return SolicitudResponse.desde(solicitud, alertas(solicitud));
    }

    /**
     * PATCH /api/v1/solicitudes/{id}: el personal aprueba, observa o rechaza (RF06).
     * Al aprobar se da de alta el perro y se le abre la libreta en ms-sanidad (P1).
     * Todo pasa en una sola transacción: si sanidad no responde, no se guarda nada,
     * la solicitud sigue PENDIENTE y se responde 503.
     */
    @Transactional
    public SolicitudResponse resolver(Long id, ResolucionRequest datos) {
        Solicitud solicitud = buscar(id);

        // RN02: solo se resuelve una solicitud pendiente
        if (solicitud.getEstado() != EstadoSolicitud.PENDIENTE) {
            throw new EstadoInvalidoException("La solicitud ya fue resuelta: está " + solicitud.getEstado());
        }

        // El mensaje es para el vecino y solo tiene sentido al observar o rechazar: al aprobar, si viene uno, se descarta
        String mensaje = datos.estado() == EstadoSolicitud.APROBADA || datos.mensaje() == null || datos.mensaje().isBlank()
                ? null : datos.mensaje().trim();
        switch (datos.estado()) {
            case APROBADA -> aprobar(solicitud, datos.ubicacion());
            case OBSERVADA, RECHAZADA -> {
                if (mensaje == null) {
                    throw new ReglaNegocioException("Mensaje inválido: para observar o rechazar hay que escribirle un mensaje al vecino");
                }
            }
            case PENDIENTE -> throw new ReglaNegocioException("Estado inválido: el estado tiene que ser APROBADA, OBSERVADA o RECHAZADA");
        }

        solicitud.setEstado(datos.estado());
        solicitud.setMensajeZoonosis(mensaje);
        solicitud.setFechaResolucion(LocalDateTime.now());
        log.info("Solicitud {} resuelta: {}", id, datos.estado());
        // No hace falta save(): la solicitud vino de la base dentro de esta transacción,
        // así que JPA guarda los cambios solo al terminar el método
        return SolicitudResponse.desde(solicitud, alertas(solicitud));
    }

    /**
     * P1: copia los datos declarados a un Perro nuevo del tutor y lo da de alta en el padrón.
     * ubicacion: la que indicó el personal, solo por si el domicilio no se puede ubicar en el mapa.
     */
    private void aprobar(Solicitud solicitud, UbicacionRequest ubicacion) {
        Tutor tutor = solicitud.getTutor();
        Perro perro = new Perro();
        perro.setNombre(solicitud.getNombrePerro());
        perro.setRaza(solicitud.getRazaPerro());
        perro.setSexo(solicitud.getSexoPerro());
        perro.setFechaNacimiento(solicitud.getFechaNacimientoPerro());
        perro.setPesoKg(solicitud.getPesoKgPerro());
        perro.setCastrado(solicitud.isCastradoPerro());
        perro.setTutor(tutor);
        // La zona sale del domicilio del tutor (calle y número); la antirrábica declarada va a la libreta
        Perro guardado = padronService.darDeAlta(perro, tutor.getCalle(), tutor.getAltura(), ubicacion,
                solicitud.getFechaUltimaAntirrabica());
        solicitud.setPerro(guardado);
    }

    private Solicitud buscar(Long id) {
        return solicitudRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la solicitud " + id));
    }

    /**
     * RN05: un perro se manda una sola vez. Si el vecino ya tiene una solicitud pendiente o un perro en el padrón
     * con el mismo nombre (sin mayúsculas ni tildes), la nueva se rechaza y no se guarda nada.
     */
    private void validarQueNoEsteRepetido(Tutor tutor, String nombre) {
        String buscado = Textos.normalizar(nombre);
        boolean yaPendiente = solicitudRepository.findByTutorAndEstado(tutor, EstadoSolicitud.PENDIENTE).stream()
                .anyMatch(solicitud -> Textos.normalizar(solicitud.getNombrePerro()).equals(buscado));
        if (yaPendiente) {
            throw new ReglaNegocioException("Ya enviaste una solicitud para " + nombre.trim()
                    + " y está pendiente: esperá a que Zoonosis la revise");
        }
        boolean yaEnElPadron = perroRepository.findByTutor(tutor).stream()
                .anyMatch(perro -> Textos.normalizar(perro.getNombre()).equals(buscado));
        if (yaEnElPadron) {
            throw new ReglaNegocioException(nombre.trim() + " ya está registrado en el padrón");
        }
    }

    /**
     * Alertas para el personal. No se guardan: se calculan con los datos de la solicitud cada vez que se muestra.
     * Solo salen las que aplican, en true (si no aplica ninguna, no hay alertas).
     */
    SolicitudResponse.Alertas alertas(Solicitud solicitud) {
        return SolicitudResponse.Alertas.de(
                esPosiblePpp(solicitud.getRazaPerro(), solicitud.getPesoKgPerro()),                                 // RN06
                antirrabicaVencida(solicitud.getFechaUltimaAntirrabica(), solicitud.getFechaCreacion().toLocalDate()), // RN07
                solicitud.getTutor().getEstadoDomicilio() == EstadoDomicilio.SIN_VERIFICAR);                          // RN03
    }

    /** RN06: posible perro potencialmente peligroso, por raza (las marcadas en la tabla raza) o por peso (> 25 kg). */
    private boolean esPosiblePpp(String raza, BigDecimal pesoKg) {
        return razaService.esPeligrosa(raza) || pesoKg.compareTo(PESO_PPP_KG) > 0;
    }

    /** RN07: la antirrábica declarada tiene más de un año a esa fecha (si no declaró ninguna, no hay alerta). */
    private boolean antirrabicaVencida(LocalDate antirrabica, LocalDate fecha) {
        return antirrabica != null && antirrabica.plusYears(1).isBefore(fecha);
    }
}
