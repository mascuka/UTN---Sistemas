package ar.edu.utn.frc.zoonosis.registro.dtos;

import org.springframework.security.oauth2.jwt.Jwt;

/**
 * Los datos de la cuenta del usuario que hace el pedido, sacados del token de Keycloak.
 * Así el vecino no tiene que volver a escribir su nombre, apellido ni email: ya los cargó al crearse la cuenta.
 */
public record CuentaUsuario(String usuarioId, String nombre, String apellido, String email) {

    public static CuentaUsuario desde(Jwt jwt) {
        // "sub" = id único del usuario; given_name, family_name y email son los datos de la cuenta
        String nombre = jwt.getClaimAsString("given_name");
        String apellido = jwt.getClaimAsString("family_name");
        return new CuentaUsuario(
                jwt.getSubject(),
                nombre != null ? nombre : jwt.getClaimAsString("preferred_username"),
                apellido != null ? apellido : "",
                jwt.getClaimAsString("email"));
    }
}
