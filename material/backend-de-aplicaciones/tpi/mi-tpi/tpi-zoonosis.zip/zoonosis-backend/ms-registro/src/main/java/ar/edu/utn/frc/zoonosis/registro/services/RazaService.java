package ar.edu.utn.frc.zoonosis.registro.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.registro.models.Raza;
import ar.edu.utn.frc.zoonosis.registro.repositories.RazaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * El listado de razas de Zoonosis: qué razas se aceptan al cargar un perro y cuáles son
 * potencialmente peligrosas (RN06). Lo usan SolicitudService (la solicitud del vecino)
 * y PerroService (el comunitario que carga el personal).
 */
@Service
public class RazaService {

    private final RazaRepository razaRepository;

    public RazaService(RazaRepository razaRepository) {
        this.razaRepository = razaRepository;
    }

    /**
     * La raza como figura en el listado, sin importar mayúsculas ni tildes: "ovejero aleman" -> "Ovejero Alemán".
     * Si no está en el listado, 422: así no entran razas inventadas ni mal escritas.
     */
    @Transactional(readOnly = true)
    public String nombreOficial(String raza) {
        String buscada = Textos.normalizar(raza);
        return razaRepository.findAll().stream()
                .map(Raza::getNombre)
                .filter(nombre -> Textos.normalizar(nombre).equals(buscada))
                .findFirst()
                .orElseThrow(() -> new ReglaNegocioException("Raza inválida: la raza no está en el listado de Zoonosis. "
                        + "Si es una cruza, poné Mestizo; si no la sabés, No identificada"));
    }

    /** RN06: ¿la raza está marcada como potencialmente peligrosa? */
    @Transactional(readOnly = true)
    public boolean esPeligrosa(String raza) {
        return razaRepository.existsByNombreIgnoreCaseAndPeligrosaTrue(raza.trim());
    }
}
