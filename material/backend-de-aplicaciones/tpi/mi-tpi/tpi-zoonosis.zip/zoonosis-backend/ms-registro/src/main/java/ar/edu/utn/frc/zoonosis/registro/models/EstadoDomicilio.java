package ar.edu.utn.frc.zoonosis.registro.models;

public enum EstadoDomicilio {
    VERIFICADO,
    SIN_VERIFICAR
}
