package ar.edu.utn.frc.zoonosis.registro.dtos;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * Latitud y longitud que indica el personal (por ejemplo, sacadas de Google Maps) SOLO para el caso
 * en que el sistema no puede ubicar en el mapa la calle y el número.
 * Es opcional y va adentro de ResolucionRequest (al aprobar) y de PerroComunitarioRequest.
 * El vecino nunca la manda: no tiene por qué saber sus coordenadas.
 */
public record UbicacionRequest(

        @NotNull(message = "Latitud inválida: falta la latitud")
        @DecimalMin(value = "-90", message = "Latitud inválida: la latitud va de -90 a 90")
        @DecimalMax(value = "90", message = "Latitud inválida: la latitud va de -90 a 90")
        BigDecimal latitud,

        @NotNull(message = "Longitud inválida: falta la longitud")
        @DecimalMin(value = "-180", message = "Longitud inválida: la longitud va de -180 a 180")
        @DecimalMax(value = "180", message = "Longitud inválida: la longitud va de -180 a 180")
        BigDecimal longitud
) { }
