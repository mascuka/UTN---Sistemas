@echo off
rem Muestra los 5 contenedores con su estado y sus puertos (solo el gateway y Keycloak se publican)
docker compose ps --format "table {{.Service}}\t{{.Status}}\t{{.Ports}}"
