package ar.edu.utn.frc.zoonosis.gateway.config;

import ar.edu.utn.frc.zoonosis.commons.security.RolesKeycloakConverter;
import ar.edu.utn.frc.zoonosis.gateway.handlers.RespuestaError;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtAuthenticationConverterAdapter;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
import org.springframework.security.web.server.authorization.ServerAccessDeniedHandler;

/**
 * Security filter del gateway: valida el token de Keycloak y el rol ANTES de reenviar el pedido.
 * Es la versión reactiva (WebFlux) de la SecurityConfig de los microservicios, con las mismas reglas.
 * Los microservicios vuelven a controlar todo (defensa en profundidad).
 * Las reglas se leen de arriba hacia abajo y gana la primera que coincide.
 * Si rechaza el pedido (401 o 403), responde con el mismo formato de error que los servicios.
 */
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain filtroDeSeguridad(ServerHttpSecurity http, RespuestaError respuestaError) {
        // El mismo conversor de roles del commons (realm_access.roles -> ROLE_...),
        // envuelto en un adaptador porque el gateway es reactivo
        JwtAuthenticationConverter rolesDelToken = new JwtAuthenticationConverter();
        rolesDelToken.setJwtGrantedAuthoritiesConverter(new RolesKeycloakConverter());

        // 401: sin token, o con un token vencido o inválido. El header WWW-Authenticate dice qué se espera (un token)
        ServerAuthenticationEntryPoint sinSesion = (exchange, error) -> {
            exchange.getResponse().getHeaders().set(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
            return respuestaError.escribir(exchange, HttpStatus.UNAUTHORIZED,
                    "Sesión inválida: no iniciaste sesión o tu sesión venció");
        };
        // 403: el token es válido, pero el rol no tiene permiso para esa dirección
        ServerAccessDeniedHandler sinPermiso = (exchange, error) -> respuestaError.escribir(exchange,
                HttpStatus.FORBIDDEN, "Permiso denegado: tu usuario no tiene permiso para hacer esto");

        http
            // API con token: sin formularios ni sesiones, así que no hace falta CSRF
            .csrf(csrf -> csrf.disable())
            .authorizeExchange(reglas -> reglas
                // Públicos: estado del gateway, Swagger, la página del mapa y sus datos
                .pathMatchers("/actuator/health", "/swagger-ui.html", "/swagger-ui/**", "/webjars/**",
                        "/v3/api-docs/**", "/registro/v3/api-docs", "/sanidad/v3/api-docs", "/mapa.html").permitAll()
                .pathMatchers(HttpMethod.GET, "/api/v1/estadisticas/**").permitAll()

                // Vecino: sus datos de tutor y mandar solicitudes.
                // Que cada uno vea solo lo suyo lo controla el microservicio con el usuario del token (RN04)
                .pathMatchers("/api/v1/tutores", "/api/v1/tutores/*").hasRole("VECINO")
                .pathMatchers(HttpMethod.POST, "/api/v1/solicitudes").hasRole("VECINO")

                // Vecino o personal: las mismas URLs; el personal ve todo y el vecino solo lo suyo
                .pathMatchers(HttpMethod.GET, "/api/v1/solicitudes", "/api/v1/solicitudes/*", "/api/v1/perros/*")
                        .hasAnyRole("VECINO", "PERSONAL_MUNICIPAL")
                // La lista de perros también la usa el veterinario: con ?dniTutor= ve los perros de una persona
                // (solo datos de los perros, RF15)
                .pathMatchers(HttpMethod.GET, "/api/v1/perros").hasAnyRole("VECINO", "PERSONAL_MUNICIPAL", "VETERINARIO")

                // Personal de Zoonosis
                .pathMatchers(HttpMethod.PATCH, "/api/v1/solicitudes/*").hasRole("PERSONAL_MUNICIPAL")
                .pathMatchers(HttpMethod.POST, "/api/v1/perros/comunitarios").hasRole("PERSONAL_MUNICIPAL")
                .pathMatchers(HttpMethod.GET, "/api/v1/libretas/vencimientos").hasRole("PERSONAL_MUNICIPAL")

                // Personal o veterinario: ver una libreta
                .pathMatchers(HttpMethod.GET, "/api/v1/libretas/*").hasAnyRole("PERSONAL_MUNICIPAL", "VETERINARIO")

                // Veterinario: registrar una vacuna
                .pathMatchers(HttpMethod.POST, "/api/v1/libretas/*/vacunas").hasRole("VETERINARIO")

                // Todo lo demás (incluido /internal/**) se rechaza
                .anyExchange().denyAll())
            .exceptionHandling(errores -> errores.authenticationEntryPoint(sinSesion).accessDeniedHandler(sinPermiso))
            .oauth2ResourceServer(oauth -> oauth
                    .jwt(jwt -> jwt.jwtAuthenticationConverter(new ReactiveJwtAuthenticationConverterAdapter(rolesDelToken)))
                    .authenticationEntryPoint(sinSesion)
                    .accessDeniedHandler(sinPermiso));
        return http.build();
    }
}
