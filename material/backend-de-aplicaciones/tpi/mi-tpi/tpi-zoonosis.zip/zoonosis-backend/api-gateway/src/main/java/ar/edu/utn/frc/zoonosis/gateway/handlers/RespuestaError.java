package ar.edu.utn.frc.zoonosis.gateway.handlers;

import ar.edu.utn.frc.zoonosis.commons.dtos.ErrorResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * Escribe un error del gateway con el mismo formato que los microservicios (ErrorResponse del commons:
 * status, mensaje y timestamp). La usan el security filter (401 y 403) y el filtro del 503.
 * Hace falta porque el gateway es reactivo: no tiene el ManejadorErrores de los servicios.
 */
@Component
public class RespuestaError {

    private final ObjectMapper json;

    public RespuestaError(ObjectMapper json) {
        this.json = json;
    }

    public Mono<Void> escribir(ServerWebExchange exchange, HttpStatus status, String mensaje) {
        byte[] cuerpo;
        try {
            cuerpo = json.writeValueAsBytes(ErrorResponse.crear(status.value(), mensaje, null));
        } catch (JsonProcessingException e) {
            return Mono.error(e);
        }
        ServerHttpResponse respuesta = exchange.getResponse();
        respuesta.setStatusCode(status);
        respuesta.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        return respuesta.writeWith(Mono.just(respuesta.bufferFactory().wrap(cuerpo)));
    }
}
