package ar.edu.utn.frc.zoonosis.gateway.filters;

import ar.edu.utn.frc.zoonosis.commons.dtos.ErrorResponse;
import ar.edu.utn.frc.zoonosis.gateway.handlers.RespuestaError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.support.ServerWebExchangeUtils;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.net.ConnectException;
import java.net.UnknownHostException;

/**
 * Si un microservicio está apagado, el gateway responde 503 con el mismo formato de error que los servicios
 * (ErrorResponse del commons), para cualquier método: GET, POST, PATCH...
 * Sin esto, Spring Cloud Gateway devuelve un 500 genérico.
 */
@Component
public class ServicioNoDisponibleFilter implements GlobalFilter, Ordered {

    private static final Logger log = LoggerFactory.getLogger(ServicioNoDisponibleFilter.class);

    private final RespuestaError respuestaError;

    public ServicioNoDisponibleFilter(RespuestaError respuestaError) {
        this.respuestaError = respuestaError;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        // chain.filter reenvía el pedido al servicio. Si falla porque no se pudo conectar
        // (servicio apagado) o no existe su nombre en la red (contenedor detenido), se responde 503
        return chain.filter(exchange)
                .onErrorResume(error -> error instanceof ConnectException || error instanceof UnknownHostException,
                        error -> responder503(exchange, error));
    }

    private Mono<Void> responder503(ServerWebExchange exchange, Throwable error) {
        Route ruta = exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR);
        String servicio = ruta != null ? ruta.getId() : "El servicio";
        log.warn("{} no responde: {}", servicio, error.getMessage());
        // El nombre del servicio queda solo en el log: el usuario recibe el mismo mensaje general que dan los servicios
        return respuestaError.escribir(exchange, HttpStatus.SERVICE_UNAVAILABLE, ErrorResponse.MENSAJE_NO_DISPONIBLE);
    }

    // Justo después del IdPedidoFilter: así "envuelve" a todos los demás y ve el error de la conexión
    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 1;
    }
}
