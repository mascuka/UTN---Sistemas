package ar.edu.utn.frc.zoonosis.gateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Rutas del gateway: qué camino va a qué microservicio.
 * El cliente solo conoce el gateway (puerto 8080); las direcciones de los servicios salen de la configuración.
 * /internal/** no tiene ruta a propósito: esos endpoints solo se usan entre servicios (trusted zone).
 */
@Configuration
public class RutasConfig {

    @Bean
    public RouteLocator rutas(RouteLocatorBuilder builder,
                              @Value("${servicios.registro.url}") String registroUrl,
                              @Value("${servicios.sanidad.url}") String sanidadUrl) {
        return builder.routes()
                // ms-registro: tutores, solicitudes, perros y su mitad del mapa
                .route("ms-registro", r -> r
                        .path("/api/v1/tutores/**", "/api/v1/solicitudes/**", "/api/v1/perros/**",
                                "/api/v1/estadisticas/perros-por-zona")
                        .uri(registroUrl))
                // ms-sanidad: libretas, vacunas y su mitad del mapa
                .route("ms-sanidad", r -> r
                        .path("/api/v1/libretas/**", "/api/v1/estadisticas/vacunacion-por-zona")
                        .uri(sanidadUrl))
                // Documentación de cada servicio para el Swagger del gateway:
                // /registro/v3/api-docs -> (stripPrefix saca "/registro") -> ms-registro /v3/api-docs
                .route("ms-registro-docs", r -> r
                        .path("/registro/v3/api-docs")
                        .filters(f -> f.stripPrefix(1))
                        .uri(registroUrl))
                .route("ms-sanidad-docs", r -> r
                        .path("/sanidad/v3/api-docs")
                        .filters(f -> f.stripPrefix(1))
                        .uri(sanidadUrl))
                .build();
    }
}
