package ar.edu.utn.frc.zoonosis.gateway.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.UUID;

/**
 * Le pone a cada pedido un identificador (header X-Request-Id) y se lo pasa al microservicio.
 * Los servicios lo escriben en cada línea de log y se lo pasan entre ellos (commons/trazabilidad),
 * así un proceso completo (por ejemplo, aprobar una solicitud) se sigue con: docker compose logs | grep <id>
 * Al terminar deja una línea en el log del gateway con el resultado.
 */
@Component
public class IdPedidoFilter implements GlobalFilter, Ordered {

    private static final Logger log = LoggerFactory.getLogger(IdPedidoFilter.class);
    private static final String HEADER = "X-Request-Id";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String recibido = exchange.getRequest().getHeaders().getFirst(HEADER);
        String id = recibido != null && !recibido.isBlank() ? recibido : UUID.randomUUID().toString().substring(0, 8);

        ServerHttpRequest pedido = exchange.getRequest().mutate().header(HEADER, id).build();
        // El cliente también lo ve en la respuesta. Normalmente ya lo trae la respuesta del servicio;
        // si no (por ejemplo, el 503 del gateway), se agrega justo antes de enviarla, sin duplicarlo
        exchange.getResponse().beforeCommit(() -> {
            if (!exchange.getResponse().getHeaders().containsKey(HEADER)) {
                exchange.getResponse().getHeaders().set(HEADER, id);
            }
            return Mono.empty();
        });

        return chain.filter(exchange.mutate().request(pedido).build())
                .doFinally(fin -> log.info("[{}] {} {} -> {}", id, pedido.getMethod(), pedido.getPath(),
                        exchange.getResponse().getStatusCode()));
    }

    // El primero de todos: así el id ya está cuando corren los demás filtros
    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }
}
