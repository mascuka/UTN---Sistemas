package ar.edu.utn.frc.zoonosis.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// A diferencia de los microservicios, NO escanea el paquete del commons: su ManejadorErrores es para
// aplicaciones servlet y el gateway es reactivo. Del commons solo usa clases sueltas (roles y ErrorResponse)
@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
