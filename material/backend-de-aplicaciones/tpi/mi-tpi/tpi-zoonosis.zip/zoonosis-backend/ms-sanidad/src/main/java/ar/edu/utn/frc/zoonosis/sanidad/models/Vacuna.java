package ar.edu.utn.frc.zoonosis.sanidad.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "vacuna")
@Getter
@Setter
@NoArgsConstructor
public class Vacuna {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "libreta_id", nullable = false)
    private Libreta libreta;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private TipoVacuna tipo;

    // Opcional: qué vacuna es cuando el tipo es OTRA
    @Column(length = 100)
    private String descripcion;

    @Column(nullable = false)
    private LocalDate fechaAplicacion;

    // Antirrábica: aplicación + 1 año (RN09). En las de tipo OTRA queda vacía
    private LocalDate fechaVencimiento;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 25)
    private OrigenVacuna origen;

    // null si la declaró el vecino
    @ManyToOne
    @JoinColumn(name = "veterinario_id")
    private Veterinario veterinario;
}
