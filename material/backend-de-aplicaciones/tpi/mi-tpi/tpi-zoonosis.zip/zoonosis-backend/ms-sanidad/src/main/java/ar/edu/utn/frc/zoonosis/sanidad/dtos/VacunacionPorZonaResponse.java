package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import java.math.BigDecimal;

/**
 * Una zona del mapa de calor público (RF13): cuántos perros hay y cuántos tienen la antirrábica al día.
 * Solo totales por zona, nunca datos de un perro (RN14).
 */
public record VacunacionPorZonaResponse(
        String zonaId,
        BigDecimal lat,
        BigDecimal lon,
        int perros,
        int alDia,
        int irregulares,
        int porcentajeAlDia
) { }
