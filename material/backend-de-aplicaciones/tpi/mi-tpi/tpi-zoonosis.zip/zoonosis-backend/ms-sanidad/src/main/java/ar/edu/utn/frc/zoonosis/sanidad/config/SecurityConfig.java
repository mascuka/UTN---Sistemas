package ar.edu.utn.frc.zoonosis.sanidad.config;

import ar.edu.utn.frc.zoonosis.commons.security.RolesKeycloakConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Quién puede llamar a cada endpoint de ms-sanidad.
 * El gateway también controla esto; el servicio lo vuelve a controlar (defensa en profundidad).
 * Las reglas se leen de arriba hacia abajo y gana la primera que coincide.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filtroDeSeguridad(HttpSecurity http) throws Exception {
        // Usa los roles de Keycloak (realm_access.roles) como roles de Spring: VETERINARIO -> ROLE_VETERINARIO
        JwtAuthenticationConverter rolesDelToken = new JwtAuthenticationConverter();
        rolesDelToken.setJwtGrantedAuthoritiesConverter(new RolesKeycloakConverter());

        http
            // API REST con token: no usa sesiones ni formularios, así que no necesita CSRF
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(reglas -> reglas
                // Públicos: estado del servicio, documentación, la página de error de Spring y el mapa de calor
                .requestMatchers("/actuator/health", "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/error").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/v1/estadisticas/**").permitAll()

                // Personal: vencimientos (RF11). Va antes que "/libretas/*", que si no también la agarraría
                .requestMatchers(HttpMethod.GET, "/api/v1/libretas/vencimientos").hasRole("PERSONAL_MUNICIPAL")
                // Personal o veterinario: ver la libreta de un perro (RF10)
                .requestMatchers(HttpMethod.GET, "/api/v1/libretas/*").hasAnyRole("PERSONAL_MUNICIPAL", "VETERINARIO")
                // Veterinario: registrar una vacuna (RF09)
                .requestMatchers(HttpMethod.POST, "/api/v1/libretas/*/vacunas").hasRole("VETERINARIO")

                // Internos (los llama ms-registro con el token del usuario que inició la operación)
                .requestMatchers(HttpMethod.POST, "/internal/libretas").hasRole("PERSONAL_MUNICIPAL")       // P1 y P4
                .requestMatchers(HttpMethod.GET, "/internal/libretas/*/estado").hasAnyRole("VECINO", "PERSONAL_MUNICIPAL") // P3

                // Cualquier otra ruta se rechaza
                .anyRequest().denyAll())
            .oauth2ResourceServer(oauth -> oauth.jwt(jwt -> jwt.jwtAuthenticationConverter(rolesDelToken)));
        return http.build();
    }
}
