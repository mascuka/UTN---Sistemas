package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

/**
 * Un perro del listado de vencimientos (RF11). fechaVencimiento es null si nunca tuvo antirrábica.
 */
public record VencimientoResponse(
        String codigoPerro,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaVencimiento,
        EstadoSanitario estadoSanitario
) { }
