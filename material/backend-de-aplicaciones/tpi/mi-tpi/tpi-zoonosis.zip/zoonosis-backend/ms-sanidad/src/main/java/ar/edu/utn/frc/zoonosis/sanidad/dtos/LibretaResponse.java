package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;

import java.util.List;

/**
 * La libreta sanitaria de un perro (RF10): el estado (AL_DIA o IRREGULAR) y todas sus vacunas.
 * El vencimiento de la antirrábica está en la vacuna misma (no se repite arriba).
 * No tiene ningún dato del tutor (sanidad no los conoce).
 */
public record LibretaResponse(
        String codigoPerro,
        EstadoSanitario estadoSanitario,
        List<VacunaResponse> vacunas
) { }
