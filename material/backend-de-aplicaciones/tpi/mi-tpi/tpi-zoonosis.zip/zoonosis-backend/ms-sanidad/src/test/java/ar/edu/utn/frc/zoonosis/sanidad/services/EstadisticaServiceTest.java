package ar.edu.utn.frc.zoonosis.sanidad.services;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunacionPorZonaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.LibretaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Pruebas del mapa de vacunación por zona (RF13): totales por zona y RN14 (zonas con menos de 3 perros ocultas).
 */
@ExtendWith(MockitoExtension.class)
class EstadisticaServiceTest {

    @Mock LibretaRepository libretaRepository;

    @Test
    void cuentaAlDiaEIrregularesPorZonaYOcultaLasZonasConMenosDe3Perros_RN14() {
        // EstadisticaService usa la misma regla de estado que la libreta (RN09): LibretaService real, sin mocks
        LibretaService libretaService = new LibretaService(libretaRepository, null, null, null);
        EstadisticaService estadisticaService = new EstadisticaService(libretaRepository, libretaService);
        LocalDate alDia = LocalDate.now().plusMonths(6);
        LocalDate vencida = LocalDate.now().minusMonths(1);
        when(libretaRepository.buscarUltimaAntirrabicaDeCadaPerro(TipoVacuna.ANTIRRABICA)).thenReturn(List.of(
                fila("VA-1", "A", alDia), fila("VA-2", "A", alDia), fila("VA-3", "A", vencida), fila("VA-4", "A", null),
                fila("VA-5", "B", alDia), fila("VA-6", "B", alDia)));   // zona B: solo 2 perros

        List<VacunacionPorZonaResponse> zonas = estadisticaService.vacunacionPorZona();

        assertThat(zonas).hasSize(1);
        VacunacionPorZonaResponse zonaA = zonas.get(0);
        assertThat(zonaA.zonaId()).isEqualTo("A");
        assertThat(zonaA.perros()).isEqualTo(4);
        assertThat(zonaA.alDia()).isEqualTo(2);
        assertThat(zonaA.irregulares()).isEqualTo(2);
        assertThat(zonaA.porcentajeAlDia()).isEqualTo(50);
    }

    private UltimaAntirrabica fila(String codigo, String zona, LocalDate vencimiento) {
        return new UltimaAntirrabica(codigo, zona, new BigDecimal("-31.2925"), new BigDecimal("-64.2975"), vencimiento);
    }
}
