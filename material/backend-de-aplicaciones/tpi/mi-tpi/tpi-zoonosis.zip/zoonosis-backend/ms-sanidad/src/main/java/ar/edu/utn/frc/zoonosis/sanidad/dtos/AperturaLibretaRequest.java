package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Body de POST /internal/libretas: lo manda ms-registro al dar de alta un perro (P1 y P4).
 */
public record AperturaLibretaRequest(

        @NotBlank(message = "Código inválido: el código del perro es obligatorio")
        @Size(max = 12, message = "Código inválido: el código puede tener hasta 12 caracteres")
        String codigoPerro,

        // La antirrábica que declaró el vecino. null en los comunitarios o si no la sabía
        LocalDate fechaAntirrabicaDeclarada,

        @NotBlank(message = "Zona inválida: la zona es obligatoria")
        @Size(max = 20, message = "Zona inválida: la zona puede tener hasta 20 caracteres")
        String zonaId,

        @NotNull(message = "Latitud inválida: la latitud del centro de la zona es obligatoria")
        BigDecimal zonaLat,

        @NotNull(message = "Longitud inválida: la longitud del centro de la zona es obligatoria")
        BigDecimal zonaLon
) { }
