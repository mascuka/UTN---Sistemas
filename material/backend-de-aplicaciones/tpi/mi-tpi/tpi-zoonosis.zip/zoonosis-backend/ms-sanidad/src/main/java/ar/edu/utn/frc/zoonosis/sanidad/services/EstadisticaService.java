package ar.edu.utn.frc.zoonosis.sanidad.services;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunacionPorZonaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.LibretaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Mapa de calor público, parte de sanidad: vacunación por zona (RF13).
 * No llama a ms-registro: usa la zona que recibió al abrir cada libreta.
 */
@Service
public class EstadisticaService {

    // RN14: las zonas con menos perros que esto no se muestran (privacidad)
    private static final int MINIMO_PERROS_POR_ZONA = 3;

    private final LibretaRepository libretaRepository;
    private final LibretaService libretaService;

    public EstadisticaService(LibretaRepository libretaRepository, LibretaService libretaService) {
        this.libretaRepository = libretaRepository;
        this.libretaService = libretaService;
    }

    @Transactional(readOnly = true)
    public List<VacunacionPorZonaResponse> vacunacionPorZona() {
        // Agrupa las libretas por zona. TreeMap: las zonas quedan ordenadas por su id
        Map<String, List<UltimaAntirrabica>> porZona = libretaRepository
                .buscarUltimaAntirrabicaDeCadaPerro(TipoVacuna.ANTIRRABICA).stream()
                .collect(Collectors.groupingBy(UltimaAntirrabica::zonaId, TreeMap::new, Collectors.toList()));

        List<VacunacionPorZonaResponse> zonas = new ArrayList<>();
        for (List<UltimaAntirrabica> perros : porZona.values()) {
            if (perros.size() < MINIMO_PERROS_POR_ZONA) {
                continue; // RN14: zona con 1 o 2 perros -> no se muestra
            }
            // El estado de cada perro se calcula igual que en la libreta (RN09)
            int alDia = (int) perros.stream()
                    .filter(p -> libretaService.estadoSegun(p.fechaVencimiento()) == EstadoSanitario.AL_DIA)
                    .count();
            UltimaAntirrabica zona = perros.get(0);
            zonas.add(new VacunacionPorZonaResponse(zona.zonaId(), zona.zonaLat(), zona.zonaLon(),
                    perros.size(), alDia, perros.size() - alDia, Math.round(alDia * 100f / perros.size())));
        }
        return zonas;
    }
}
