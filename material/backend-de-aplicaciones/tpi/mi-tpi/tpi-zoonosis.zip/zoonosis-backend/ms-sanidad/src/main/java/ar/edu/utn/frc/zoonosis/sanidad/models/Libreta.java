package ar.edu.utn.frc.zoonosis.sanidad.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

// Libreta sanitaria de un perro. Sanidad no guarda datos personales: solo el código del perro y su zona
@Entity
@Table(name = "libreta")
@Getter
@Setter
@NoArgsConstructor
public class Libreta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Referencia lógica a registro.perro.codigo, SIN clave foránea (otro schema, otro servicio).
    // Única: una sola libreta por perro (por eso abrirla dos veces no duplica nada)
    @Column(nullable = false, unique = true, length = 12)
    private String codigoPerro;

    // Zona del mapa, calculada por ms-registro al dar de alta al perro
    @Column(nullable = false, length = 20)
    private String zonaId;

    @Column(nullable = false, precision = 9, scale = 6)
    private BigDecimal zonaLatCentro;

    @Column(nullable = false, precision = 9, scale = 6)
    private BigDecimal zonaLonCentro;

    @Column(nullable = false)
    private LocalDateTime fechaApertura;
}
