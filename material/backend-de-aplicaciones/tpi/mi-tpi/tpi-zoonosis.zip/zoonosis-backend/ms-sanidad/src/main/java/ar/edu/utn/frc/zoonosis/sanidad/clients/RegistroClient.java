package ar.edu.utn.frc.zoonosis.sanidad.clients;

import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Habla con ms-registro por su endpoint interno de verificación (P2).
 * El token del veterinario viaja solo, gracias al PropagarTokenInterceptor del RestClient.
 * Si ms-registro no responde o devuelve un error, lanza ServicioNoDisponibleException (503)
 * y la vacuna no se registra.
 */
@Component
public class RegistroClient {

    private final RestClient registro;

    public RegistroClient(RestClient registroRestClient) {
        this.registro = registroRestClient;
    }

    /** GET /internal/perros/{codigo}/verificacion?dni=: ¿existe el perro? ¿el DNI es el del tutor? */
    public Verificacion verificarPerro(String codigoPerro, String dni) {
        Verificacion verificacion;
        try {
            verificacion = registro.get()
                    .uri(uri -> uri.path("/internal/perros/{codigo}/verificacion")
                            .queryParamIfPresent("dni", Optional.ofNullable(dni)) // sin DNI no se manda el parámetro
                            .build(codigoPerro))
                    .retrieve()
                    .body(Verificacion.class);
        } catch (RestClientException e) {
            throw new ServicioNoDisponibleException("ms-registro no respondió: no se pudo verificar el perro", e);
        }
        if (verificacion == null) {
            throw new ServicioNoDisponibleException("ms-registro devolvió una respuesta vacía");
        }
        return verificacion;
    }

    // Lo que contesta ms-registro (nunca trae datos del tutor, solo sí o no)
    public record Verificacion(boolean existe, boolean comunitario, boolean dniCoincide, LocalDate fechaNacimiento) { }
}
