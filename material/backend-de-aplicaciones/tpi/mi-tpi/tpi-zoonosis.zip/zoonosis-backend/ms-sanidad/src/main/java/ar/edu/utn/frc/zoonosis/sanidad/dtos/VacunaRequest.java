package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

/**
 * Body de POST /api/v1/libretas/{codigo}/vacunas (RF09).
 * La matrícula no viene en el body: sale del veterinario logueado (usuario del token).
 * Que la fecha no sea futura ni anterior al nacimiento (RN11) lo controla LibretaService (422).
 */
public record VacunaRequest(

        // El DNI que le muestra el tutor. Obligatorio salvo en los perros comunitarios (lo controla el service)
        @Size(max = 10, message = "DNI inválido: el DNI puede tener hasta 10 caracteres")
        String dniTutor,

        @NotNull(message = "Tipo de vacuna inválido: el tipo es obligatorio (ANTIRRABICA u OTRA)")
        TipoVacuna tipo,

        @NotNull(message = "Fecha de aplicación inválida: la fecha de aplicación es obligatoria")
        LocalDate fechaAplicacion,

        @Size(max = 100, message = "Descripción inválida: la descripción puede tener hasta 100 caracteres")
        String descripcion
) { }
