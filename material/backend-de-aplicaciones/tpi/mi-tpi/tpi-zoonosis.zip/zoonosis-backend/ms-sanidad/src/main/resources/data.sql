-- Veterinarios matriculados de prueba. El username tiene que ser el mismo que el del usuario de Keycloak.
-- Las matrículas son inventadas. ON CONFLICT evita duplicarlos en cada arranque.
INSERT INTO sanidad.veterinario (username, nombre, matricula) VALUES
    ('vet1', 'Carlos Ruiz', 'MP-4521'),
    ('vet2', 'Marta López', 'MP-4876')
ON CONFLICT (username) DO NOTHING;

-- ===== Datos de prueba para el mapa de calor (RF13) =====
-- Libretas de los perros de ejemplo de ms-registro: mismo código y misma zona que en el schema registro.
INSERT INTO sanidad.libreta (codigo_perro, zona_id, zona_lat_centro, zona_lon_centro, fecha_apertura) VALUES
    ('VA-900001', '-6259_-12860', -31.292500, -64.297500, NOW()),
    ('VA-900002', '-6259_-12860', -31.292500, -64.297500, NOW()),
    ('VA-900003', '-6259_-12860', -31.292500, -64.297500, NOW()),
    ('VA-900004', '-6259_-12860', -31.292500, -64.297500, NOW()),
    ('VA-900005', '-6258_-12859', -31.287500, -64.292500, NOW()),
    ('VA-900006', '-6258_-12859', -31.287500, -64.292500, NOW()),
    ('VA-900007', '-6258_-12859', -31.287500, -64.292500, NOW()),
    ('VA-900008', '-6258_-12859', -31.287500, -64.292500, NOW()),
    ('VA-900009', '-6258_-12859', -31.287500, -64.292500, NOW()),
    ('VA-900010', '-6260_-12861', -31.297500, -64.302500, NOW()),
    ('VA-900011', '-6260_-12861', -31.297500, -64.302500, NOW()),
    ('VA-900012', '-6260_-12861', -31.297500, -64.302500, NOW()),
    ('VA-900013', '-6257_-12861', -31.282500, -64.302500, NOW()),
    ('VA-900014', '-6257_-12861', -31.282500, -64.302500, NOW()),
    ('VA-900015', '-6257_-12861', -31.282500, -64.302500, NOW()),
    ('VA-900016', '-6257_-12861', -31.282500, -64.302500, NOW()),
    ('VA-900017', '-6261_-12859', -31.302500, -64.292500, NOW()),
    ('VA-900018', '-6261_-12859', -31.302500, -64.292500, NOW()),
    ('VA-900019', '-6261_-12859', -31.302500, -64.292500, NOW()),
    ('VA-900020', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900021', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900022', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900023', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900024', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900025', '-6258_-12862', -31.287500, -64.307500, NOW()),
    ('VA-900026', '-6260_-12858', -31.297500, -64.287500, NOW()),
    ('VA-900027', '-6260_-12858', -31.297500, -64.287500, NOW())
ON CONFLICT (codigo_perro) DO NOTHING;

-- Antirrábicas de esos perros. Las fechas son relativas a hoy (CURRENT_DATE - días), así siempre hay perros
-- al día, por vencer (aplicadas hace 345 o 350 días: vencen en menos de 30) y vencidos (hace más de 365 días).
-- Los perros que no figuran acá no tienen vacunas (IRREGULAR).
-- NOT EXISTS: solo se cargan si la libreta todavía no tiene vacunas, porque data.sql corre en cada arranque
-- y la tabla vacuna no tiene una columna única para usar ON CONFLICT.
INSERT INTO sanidad.vacuna (libreta_id, tipo, fecha_aplicacion, fecha_vencimiento, origen, veterinario_id)
SELECT l.id, 'ANTIRRABICA', CURRENT_DATE - a.dias, (CURRENT_DATE - a.dias + INTERVAL '1 year')::date, a.origen, vet.id
FROM (VALUES
    ('VA-900001', 60, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900002', 150, 'DECLARADA_VECINO', NULL),
    ('VA-900003', 350, 'VERIFICADA_VETERINARIO', 'vet2'),
    ('VA-900004', 420, 'DECLARADA_VECINO', NULL),
    ('VA-900005', 90, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900006', 200, 'VERIFICADA_VETERINARIO', 'vet2'),
    ('VA-900007', 500, 'DECLARADA_VECINO', NULL),
    ('VA-900010', 30, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900011', 120, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900012', 240, 'DECLARADA_VECINO', NULL),
    ('VA-900013', 45, 'VERIFICADA_VETERINARIO', 'vet2'),
    ('VA-900014', 390, 'DECLARADA_VECINO', NULL),
    ('VA-900017', 75, 'VERIFICADA_VETERINARIO', 'vet2'),
    ('VA-900018', 180, 'DECLARADA_VECINO', NULL),
    ('VA-900019', 600, 'DECLARADA_VECINO', NULL),
    ('VA-900020', 20, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900021', 110, 'VERIFICADA_VETERINARIO', 'vet2'),
    ('VA-900022', 270, 'DECLARADA_VECINO', NULL),
    ('VA-900023', 345, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900024', 450, 'DECLARADA_VECINO', NULL),
    ('VA-900026', 100, 'VERIFICADA_VETERINARIO', 'vet1'),
    ('VA-900027', 480, 'DECLARADA_VECINO', NULL)
) AS a(codigo, dias, origen, veterinario)
JOIN sanidad.libreta l ON l.codigo_perro = a.codigo
LEFT JOIN sanidad.veterinario vet ON vet.username = a.veterinario
WHERE NOT EXISTS (SELECT 1 FROM sanidad.vacuna x WHERE x.libreta_id = l.id);
