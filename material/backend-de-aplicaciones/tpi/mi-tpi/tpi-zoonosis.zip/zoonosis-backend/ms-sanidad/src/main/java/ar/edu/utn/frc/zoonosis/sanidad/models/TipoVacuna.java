package ar.edu.utn.frc.zoonosis.sanidad.models;

public enum TipoVacuna {
    ANTIRRABICA,
    OTRA
}
