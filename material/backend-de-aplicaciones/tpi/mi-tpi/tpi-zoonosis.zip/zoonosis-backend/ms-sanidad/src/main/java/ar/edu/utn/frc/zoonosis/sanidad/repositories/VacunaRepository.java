package ar.edu.utn.frc.zoonosis.sanidad.repositories;

import ar.edu.utn.frc.zoonosis.sanidad.models.Libreta;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Vacuna;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Acceso a la tabla vacuna.
 */
public interface VacunaRepository extends JpaRepository<Vacuna, Long> {

    // Las vacunas de una libreta, de la más nueva a la más vieja (RF10)
    List<Vacuna> findByLibretaOrderByFechaAplicacionDesc(Libreta libreta);

    // La vacuna de ese tipo que vence más tarde: con ANTIRRABICA da el estado sanitario (RN09)
    Optional<Vacuna> findFirstByLibretaAndTipoOrderByFechaVencimientoDesc(Libreta libreta, TipoVacuna tipo);
}
