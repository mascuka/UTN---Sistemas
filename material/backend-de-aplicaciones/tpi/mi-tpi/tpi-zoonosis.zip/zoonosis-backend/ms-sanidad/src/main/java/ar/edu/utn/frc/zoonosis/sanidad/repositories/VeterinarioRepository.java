package ar.edu.utn.frc.zoonosis.sanidad.repositories;

import ar.edu.utn.frc.zoonosis.sanidad.models.Veterinario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Acceso a la tabla veterinario.
 */
public interface VeterinarioRepository extends JpaRepository<Veterinario, Long> {

    // El veterinario logueado, por el usuario del token (preferred_username)
    Optional<Veterinario> findByUsername(String username);
}
