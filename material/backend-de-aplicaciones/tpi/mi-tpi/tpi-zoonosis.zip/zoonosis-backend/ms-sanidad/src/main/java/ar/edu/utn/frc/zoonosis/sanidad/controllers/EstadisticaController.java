package ar.edu.utn.frc.zoonosis.sanidad.controllers;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunacionPorZonaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.services.EstadisticaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Mapa de calor público (sin token): vacunación por zona (RF13).
 */
@RestController
@RequestMapping("/api/v1/estadisticas")
public class EstadisticaController {

    private final EstadisticaService estadisticaService;

    public EstadisticaController(EstadisticaService estadisticaService) {
        this.estadisticaService = estadisticaService;
    }

    @GetMapping("/vacunacion-por-zona")
    public ResponseEntity<List<VacunacionPorZonaResponse>> vacunacionPorZona() {
        return ResponseEntity.ok(estadisticaService.vacunacionPorZona());
    }
}
