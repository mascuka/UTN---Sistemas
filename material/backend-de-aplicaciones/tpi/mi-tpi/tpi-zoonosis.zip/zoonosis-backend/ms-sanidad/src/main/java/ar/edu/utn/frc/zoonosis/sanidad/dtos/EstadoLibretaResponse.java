package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;

import java.time.LocalDate;

/**
 * Respuesta de GET /internal/libretas/{codigo}/estado (la usa ms-registro en la ficha y en "mis perros", P3).
 */
public record EstadoLibretaResponse(EstadoSanitario estadoSanitario, LocalDate fechaVencimiento) { }
