package ar.edu.utn.frc.zoonosis.sanidad.models;

// RN10: de dónde salió cada vacuna
public enum OrigenVacuna {
    DECLARADA_VECINO,       // la fecha que puso el vecino en la solicitud
    VERIFICADA_VETERINARIO  // la cargó un veterinario con su matrícula
}
