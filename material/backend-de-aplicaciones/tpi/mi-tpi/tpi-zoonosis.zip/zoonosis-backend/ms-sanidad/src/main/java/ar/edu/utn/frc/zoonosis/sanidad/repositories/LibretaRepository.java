package ar.edu.utn.frc.zoonosis.sanidad.repositories;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica;
import ar.edu.utn.frc.zoonosis.sanidad.models.Libreta;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Acceso a la tabla libreta.
 */
public interface LibretaRepository extends JpaRepository<Libreta, Long> {

    Optional<Libreta> findByCodigoPerro(String codigoPerro);

    // ¿Ya tiene libreta? (apertura idempotente)
    boolean existsByCodigoPerro(String codigoPerro);

    // Cada libreta con el vencimiento de su antirrábica más reciente (MAX), o null si no tiene ninguna.
    // LEFT JOIN: también trae las libretas sin vacunas. Lo usan los vencimientos (RF11) y el mapa (RF13)
    @Query("""
            SELECT new ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica(
                       l.codigoPerro, l.zonaId, l.zonaLatCentro, l.zonaLonCentro, MAX(v.fechaVencimiento))
            FROM Libreta l
            LEFT JOIN Vacuna v ON v.libreta = l AND v.tipo = :antirrabica
            GROUP BY l.codigoPerro, l.zonaId, l.zonaLatCentro, l.zonaLonCentro
            """)
    List<UltimaAntirrabica> buscarUltimaAntirrabicaDeCadaPerro(@Param("antirrabica") TipoVacuna antirrabica);
}
