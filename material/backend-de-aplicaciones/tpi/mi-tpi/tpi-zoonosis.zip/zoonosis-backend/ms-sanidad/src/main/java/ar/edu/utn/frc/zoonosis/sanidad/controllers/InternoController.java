package ar.edu.utn.frc.zoonosis.sanidad.controllers;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.AperturaLibretaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.EstadoLibretaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.LibretaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.services.LibretaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints internos: solo los llama ms-registro dentro de la red de Docker.
 * El gateway no tiene ruta hacia /internal/**, y además piden token (el del usuario, propagado).
 */
@RestController
@RequestMapping("/internal/libretas")
public class InternoController {

    private final LibretaService libretaService;

    public InternoController(LibretaService libretaService) {
        this.libretaService = libretaService;
    }

    // P1 y P4: abrir la libreta de un perro nuevo. 201 si se creó, 200 si ya existía (idempotente)
    @PostMapping
    public ResponseEntity<LibretaResponse> abrir(@Valid @RequestBody AperturaLibretaRequest datos) {
        LibretaService.Resultado resultado = libretaService.abrir(datos);
        HttpStatus estado = resultado.creada() ? HttpStatus.CREATED : HttpStatus.OK;
        return ResponseEntity.status(estado).body(resultado.libreta());
    }

    // P3: estado sanitario para la ficha y "mis perros" de ms-registro. 404 si no existe
    @GetMapping("/{codigo}/estado")
    public ResponseEntity<EstadoLibretaResponse> estado(@PathVariable String codigo) {
        return ResponseEntity.ok(libretaService.estado(codigo));
    }
}
