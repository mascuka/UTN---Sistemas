package ar.edu.utn.frc.zoonosis.sanidad.config;

import ar.edu.utn.frc.zoonosis.commons.security.PropagarTokenInterceptor;
import ar.edu.utn.frc.zoonosis.commons.trazabilidad.PropagarIdPedidoInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * Cliente HTTP para hablar con ms-registro, con su URL y tiempos máximos de espera.
 */
@Configuration
public class RestClientConfig {

    // ms-registro (endpoints internos). Reenvía el token del usuario que hizo el pedido (el veterinario) y el id del pedido
    @Bean
    public RestClient registroRestClient(@Value("${registro.url}") String url) {
        SimpleClientHttpRequestFactory tiempos = new SimpleClientHttpRequestFactory();
        tiempos.setConnectTimeout(3000); // 3 segundos para conectar
        tiempos.setReadTimeout(10000);   // 10 segundos para responder: un servicio recién arrancado tarda más
        return RestClient.builder()
                .baseUrl(url)
                .requestFactory(tiempos)
                .requestInterceptor(new PropagarTokenInterceptor())
                .requestInterceptor(new PropagarIdPedidoInterceptor())
                .build();
    }
}
