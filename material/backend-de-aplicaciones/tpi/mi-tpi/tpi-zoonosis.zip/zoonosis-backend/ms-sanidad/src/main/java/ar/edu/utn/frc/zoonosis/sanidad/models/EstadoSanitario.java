package ar.edu.utn.frc.zoonosis.sanidad.models;

// RN09: se calcula cada vez a partir de las vacunas, no se guarda en la base
public enum EstadoSanitario {
    AL_DIA,    // la antirrábica más reciente vence hoy o después
    IRREGULAR  // vencida, o sin antirrábica
}
