package ar.edu.utn.frc.zoonosis.sanidad.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.RecursoNoEncontradoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.sanidad.clients.RegistroClient;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.AperturaLibretaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.EstadoLibretaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.LibretaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VencimientoResponse;
import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;
import ar.edu.utn.frc.zoonosis.sanidad.models.Libreta;
import ar.edu.utn.frc.zoonosis.sanidad.models.OrigenVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Vacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Veterinario;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.LibretaRepository;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.VacunaRepository;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.VeterinarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

/**
 * Lógica de negocio de las libretas sanitarias:
 * apertura (P1 y P4), libreta (RF10), estado (P3), vacunas (RF09, P2) y vencimientos (RF11).
 * Reglas: RN08, RN09, RN10, RN11, RN12 (con ms-registro) y RN13.
 */
@Service
public class LibretaService {

    private static final Logger log = LoggerFactory.getLogger(LibretaService.class);

    private final LibretaRepository libretaRepository;
    private final VacunaRepository vacunaRepository;
    private final VeterinarioRepository veterinarioRepository;
    private final RegistroClient registroClient;

    public LibretaService(LibretaRepository libretaRepository, VacunaRepository vacunaRepository,
                          VeterinarioRepository veterinarioRepository, RegistroClient registroClient) {
        this.libretaRepository = libretaRepository;
        this.vacunaRepository = vacunaRepository;
        this.veterinarioRepository = veterinarioRepository;
        this.registroClient = registroClient;
    }

    /** Lo que devuelve abrir: la libreta y si se creó recién (201) o ya existía (200). */
    public record Resultado(LibretaResponse libreta, boolean creada) { }

    /**
     * POST /internal/libretas (lo llama ms-registro al dar de alta un perro, P1 y P4).
     * Idempotente: si la libreta ya existe no se crea otra, así ms-registro puede reintentar sin duplicar.
     */
    @Transactional
    public Resultado abrir(AperturaLibretaRequest datos) {
        if (libretaRepository.existsByCodigoPerro(datos.codigoPerro())) {
            log.info("La libreta de {} ya existía: no se crea otra", datos.codigoPerro());
            return new Resultado(obtener(datos.codigoPerro()), false);
        }

        Libreta libreta = new Libreta();
        libreta.setCodigoPerro(datos.codigoPerro());
        libreta.setZonaId(datos.zonaId());
        libreta.setZonaLatCentro(datos.zonaLat());
        libreta.setZonaLonCentro(datos.zonaLon());
        libreta.setFechaApertura(LocalDateTime.now());
        libretaRepository.save(libreta);

        // La antirrábica que declaró el vecino entra como DECLARADA_VECINO, sin veterinario (RN10).
        // Los comunitarios (o si el vecino no la sabía) no traen fecha: la libreta arranca vacía (IRREGULAR)
        if (datos.fechaAntirrabicaDeclarada() != null) {
            Vacuna declarada = new Vacuna();
            declarada.setLibreta(libreta);
            declarada.setTipo(TipoVacuna.ANTIRRABICA);
            declarada.setFechaAplicacion(datos.fechaAntirrabicaDeclarada());
            declarada.setFechaVencimiento(calcularVencimiento(TipoVacuna.ANTIRRABICA, datos.fechaAntirrabicaDeclarada()));
            declarada.setOrigen(OrigenVacuna.DECLARADA_VECINO);
            vacunaRepository.save(declarada);
        }
        log.info("Libreta abierta para {} (zona {}, antirrábica declarada: {})", datos.codigoPerro(), datos.zonaId(),
                datos.fechaAntirrabicaDeclarada() != null);
        return new Resultado(obtener(datos.codigoPerro()), true);
    }

    /** GET /api/v1/libretas/{codigo} (RF10): la libreta con su estado y todas las vacunas. */
    @Transactional(readOnly = true)
    public LibretaResponse obtener(String codigoPerro) {
        Libreta libreta = buscar(codigoPerro);
        LocalDate vencimiento = vencimientoAntirrabica(libreta);
        List<VacunaResponse> vacunas = vacunaRepository.findByLibretaOrderByFechaAplicacionDesc(libreta).stream()
                .map(VacunaResponse::desde)
                .toList();
        return new LibretaResponse(codigoPerro, estadoSegun(vencimiento), vacunas);
    }

    /** GET /internal/libretas/{codigo}/estado (lo llama ms-registro para la ficha y "mis perros", P3). */
    @Transactional(readOnly = true)
    public EstadoLibretaResponse estado(String codigoPerro) {
        LocalDate vencimiento = vencimientoAntirrabica(buscar(codigoPerro));
        return new EstadoLibretaResponse(estadoSegun(vencimiento), vencimiento);
    }

    /**
     * POST /api/v1/libretas/{codigo}/vacunas (RF09, P2): el veterinario registra una vacuna.
     * Sin @Transactional a propósito: la única escritura es el save() del final (que ya es transaccional)
     * y así no se tiene la base ocupada mientras se espera a ms-registro.
     */
    public VacunaResponse registrarVacuna(String codigoPerro, String username, VacunaRequest datos) {
        // La matrícula sale del veterinario logueado, nunca del body
        Veterinario veterinario = veterinarioRepository.findByUsername(username)
                .orElseThrow(() -> new ReglaNegocioException("Tu usuario no figura como veterinario matriculado"));

        // P2: ms-registro confirma el perro y el DNI. Si no responde, sale 503 y no se registra nada
        log.info("Vacuna para {}: verificando el perro en ms-registro", codigoPerro);
        RegistroClient.Verificacion perro = registroClient.verificarPerro(codigoPerro, datos.dniTutor());

        // RN08: solo perros del padrón (aprobados)
        if (!perro.existe()) {
            throw new RecursoNoEncontradoException("El perro " + codigoPerro + " no está en el padrón");
        }
        // RN12: si tiene tutor, el DNI que muestra el tutor tiene que coincidir. Los comunitarios no tienen DNI
        if (!perro.comunitario()) {
            if (datos.dniTutor() == null || datos.dniTutor().isBlank()) {
                throw new ReglaNegocioException("DNI inválido: falta el DNI del tutor");
            }
            if (!perro.dniCoincide()) {
                throw new ReglaNegocioException("DNI inválido: el DNI no coincide con el del tutor del perro");
            }
        }
        // RN11: ni futura ni anterior al nacimiento
        if (datos.fechaAplicacion().isAfter(LocalDate.now())) {
            throw new ReglaNegocioException("Fecha de aplicación inválida: la fecha de aplicación no puede ser futura");
        }
        if (datos.fechaAplicacion().isBefore(perro.fechaNacimiento())) {
            throw new ReglaNegocioException("Fecha de aplicación inválida: la fecha de aplicación no puede ser anterior al nacimiento del perro");
        }

        Vacuna vacuna = new Vacuna();
        vacuna.setLibreta(buscar(codigoPerro));
        vacuna.setTipo(datos.tipo());
        vacuna.setDescripcion(datos.descripcion() == null || datos.descripcion().isBlank() ? null : datos.descripcion().trim());
        vacuna.setFechaAplicacion(datos.fechaAplicacion());
        vacuna.setFechaVencimiento(calcularVencimiento(datos.tipo(), datos.fechaAplicacion()));
        vacuna.setOrigen(OrigenVacuna.VERIFICADA_VETERINARIO); // RN10
        vacuna.setVeterinario(veterinario);
        Vacuna guardada = vacunaRepository.save(vacuna);
        log.info("Vacuna {} registrada para {} por la matrícula {}", guardada.getTipo(), codigoPerro, veterinario.getMatricula());
        return VacunaResponse.desde(guardada);
    }

    /**
     * GET /api/v1/libretas/vencimientos?dias=30 (RF11, RN13): perros con la antirrábica vencida o que vence
     * en los próximos N días. También salen los que nunca tuvieron antirrábica: son IRREGULARES.
     * Primero los que no tienen, después del vencimiento más viejo al más nuevo.
     * Filtros opcionales (null = sin filtro): estado (IRREGULAR = las vencidas, AL_DIA = las que están por vencer)
     * y codigoPerro (un perro).
     */
    @Transactional(readOnly = true)
    public List<VencimientoResponse> vencimientos(int dias, EstadoSanitario estado, String codigoPerro) {
        if (dias < 0) {
            throw new ReglaNegocioException("Días inválidos: la cantidad de días no puede ser negativa");
        }
        LocalDate limite = LocalDate.now().plusDays(dias);
        return libretaRepository.buscarUltimaAntirrabicaDeCadaPerro(TipoVacuna.ANTIRRABICA).stream()
                .filter(fila -> fila.fechaVencimiento() == null || !fila.fechaVencimiento().isAfter(limite))
                .filter(fila -> estado == null || estadoSegun(fila.fechaVencimiento()) == estado)
                .filter(fila -> codigoPerro == null || codigoPerro.isBlank()
                        || fila.codigoPerro().equalsIgnoreCase(codigoPerro.trim()))
                .sorted(Comparator.comparing(UltimaAntirrabica::fechaVencimiento,
                        Comparator.nullsFirst(Comparator.naturalOrder())))
                .map(fila -> new VencimientoResponse(fila.codigoPerro(), fila.fechaVencimiento(),
                        estadoSegun(fila.fechaVencimiento())))
                .toList();
    }

    /** RN09: AL_DIA si la antirrábica más reciente vence hoy o después; si no (o si no tiene), IRREGULAR. */
    public EstadoSanitario estadoSegun(LocalDate vencimientoAntirrabica) {
        if (vencimientoAntirrabica != null && !vencimientoAntirrabica.isBefore(LocalDate.now())) {
            return EstadoSanitario.AL_DIA;
        }
        return EstadoSanitario.IRREGULAR;
    }

    /** RN09: la antirrábica vence al año de aplicada. De las otras vacunas no se calcula vencimiento. */
    private LocalDate calcularVencimiento(TipoVacuna tipo, LocalDate fechaAplicacion) {
        return tipo == TipoVacuna.ANTIRRABICA ? fechaAplicacion.plusYears(1) : null;
    }

    private LocalDate vencimientoAntirrabica(Libreta libreta) {
        return vacunaRepository.findFirstByLibretaAndTipoOrderByFechaVencimientoDesc(libreta, TipoVacuna.ANTIRRABICA)
                .map(Vacuna::getFechaVencimiento)
                .orElse(null);
    }

    private Libreta buscar(String codigoPerro) {
        return libretaRepository.findByCodigoPerro(codigoPerro)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la libreta del perro " + codigoPerro));
    }
}
