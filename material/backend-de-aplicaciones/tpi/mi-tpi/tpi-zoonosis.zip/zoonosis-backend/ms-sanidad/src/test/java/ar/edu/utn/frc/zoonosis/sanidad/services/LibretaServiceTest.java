package ar.edu.utn.frc.zoonosis.sanidad.services;

import ar.edu.utn.frc.zoonosis.commons.exceptions.RecursoNoEncontradoException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ReglaNegocioException;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ServicioNoDisponibleException;
import ar.edu.utn.frc.zoonosis.sanidad.clients.RegistroClient;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.AperturaLibretaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.UltimaAntirrabica;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VencimientoResponse;
import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;
import ar.edu.utn.frc.zoonosis.sanidad.models.Libreta;
import ar.edu.utn.frc.zoonosis.sanidad.models.OrigenVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Vacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Veterinario;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.LibretaRepository;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.VacunaRepository;
import ar.edu.utn.frc.zoonosis.sanidad.repositories.VeterinarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas de las reglas de sanidad: RN08 a RN13, la apertura idempotente de la libreta (P1, P4)
 * y el registro de vacunas con la verificación de ms-registro (P2).
 */
@ExtendWith(MockitoExtension.class)
class LibretaServiceTest {

    private static final LocalDate NACIMIENTO = LocalDate.of(2021, 5, 10);

    @Mock LibretaRepository libretaRepository;
    @Mock VacunaRepository vacunaRepository;
    @Mock VeterinarioRepository veterinarioRepository;
    @Mock RegistroClient registroClient;
    @InjectMocks LibretaService libretaService;

    // ---------- Estado sanitario (RN09) ----------

    @Test
    void conLaAntirrabicaQueVenceHoyTodaviaEstaAlDia_RN09() {
        assertThat(libretaService.estadoSegun(LocalDate.now())).isEqualTo(EstadoSanitario.AL_DIA);
    }

    @Test
    void conLaAntirrabicaVencidaAyerOSinAntirrabicaEsIrregular_RN09() {
        assertThat(libretaService.estadoSegun(LocalDate.now().minusDays(1))).isEqualTo(EstadoSanitario.IRREGULAR);
        assertThat(libretaService.estadoSegun(null)).isEqualTo(EstadoSanitario.IRREGULAR);
    }

    // ---------- Apertura de la libreta (P1 y P4) ----------

    @Test
    void abrirDosVecesLaMismaLibretaNoLaDuplica() {
        Libreta existente = libreta();
        when(libretaRepository.existsByCodigoPerro("VA-000001")).thenReturn(true);
        when(libretaRepository.findByCodigoPerro("VA-000001")).thenReturn(Optional.of(existente));

        LibretaService.Resultado resultado = libretaService.abrir(apertura(null));

        assertThat(resultado.creada()).isFalse();
        verify(libretaRepository, never()).save(any());
    }

    @Test
    void laAntirrabicaDeclaradaQuedaComoDeclaradaYVenceAlAnio_RN09_RN10() {
        LocalDate aplicada = LocalDate.now().minusMonths(2);
        when(libretaRepository.existsByCodigoPerro("VA-000001")).thenReturn(false);
        when(libretaRepository.findByCodigoPerro("VA-000001")).thenReturn(Optional.of(libreta()));

        LibretaService.Resultado resultado = libretaService.abrir(apertura(aplicada));

        ArgumentCaptor<Vacuna> vacuna = ArgumentCaptor.forClass(Vacuna.class);
        verify(vacunaRepository).save(vacuna.capture());
        assertThat(resultado.creada()).isTrue();
        assertThat(vacuna.getValue().getOrigen()).isEqualTo(OrigenVacuna.DECLARADA_VECINO);
        assertThat(vacuna.getValue().getVeterinario()).isNull();
        assertThat(vacuna.getValue().getFechaVencimiento()).isEqualTo(aplicada.plusYears(1));
    }

    @Test
    void unComunitarioArrancaSinVacunas_RN18() {
        when(libretaRepository.existsByCodigoPerro("VA-000001")).thenReturn(false);
        when(libretaRepository.findByCodigoPerro("VA-000001")).thenReturn(Optional.of(libreta()));

        libretaService.abrir(apertura(null));

        verify(vacunaRepository, never()).save(any());
    }

    // ---------- Registrar una vacuna (RF09, P2) ----------

    @Test
    void soloSeVacunanPerrosDelPadron_RN08() {
        veterinarioLogueado();
        when(registroClient.verificarPerro("VA-999999", "30111222"))
                .thenReturn(new RegistroClient.Verificacion(false, false, false, null));

        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-999999", "vet1", vacuna("30111222", LocalDate.now())))
                .isInstanceOf(RecursoNoEncontradoException.class);
    }

    @Test
    void unPerroConTutorNecesitaElDniYTieneQueCoincidir_RN12() {
        veterinarioLogueado();
        when(registroClient.verificarPerro(eq("VA-000001"), any()))
                .thenReturn(new RegistroClient.Verificacion(true, false, false, NACIMIENTO));

        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "vet1", vacuna(null, LocalDate.now())))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("falta el DNI");
        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "vet1", vacuna("11111111", LocalDate.now())))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("no coincide");
        verify(vacunaRepository, never()).save(any());
    }

    @Test
    void unComunitarioSeVacunaSinDniConLaMatriculaDelVeterinario_RN10_RN12() {
        veterinarioLogueado();
        when(registroClient.verificarPerro("VA-000002", null))
                .thenReturn(new RegistroClient.Verificacion(true, true, false, NACIMIENTO));
        when(libretaRepository.findByCodigoPerro("VA-000002")).thenReturn(Optional.of(libreta()));
        when(vacunaRepository.save(any(Vacuna.class))).thenAnswer(inv -> inv.getArgument(0));

        VacunaResponse respuesta = libretaService.registrarVacuna("VA-000002", "vet1", vacuna(null, LocalDate.now()));

        assertThat(respuesta.origen()).isEqualTo(OrigenVacuna.VERIFICADA_VETERINARIO);
        assertThat(respuesta.veterinario().matricula()).isEqualTo("MP-4521");
        assertThat(respuesta.fechaVencimiento()).isEqualTo(LocalDate.now().plusYears(1));
    }

    @Test
    void noSeAceptanVacunasConFechaFuturaNiAnterioresAlNacimiento_RN11() {
        veterinarioLogueado();
        when(registroClient.verificarPerro("VA-000001", "30111222"))
                .thenReturn(new RegistroClient.Verificacion(true, false, true, NACIMIENTO));

        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "vet1", vacuna("30111222", LocalDate.now().plusDays(1))))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("futura");
        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "vet1", vacuna("30111222", NACIMIENTO.minusDays(1))))
                .isInstanceOf(ReglaNegocioException.class).hasMessageContaining("nacimiento");
    }

    @Test
    void siRegistroNoRespondeNoSeRegistraNada_P2() {
        veterinarioLogueado();
        when(registroClient.verificarPerro(any(), any())).thenThrow(new ServicioNoDisponibleException("ms-registro no respondió"));

        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "vet1", vacuna("30111222", LocalDate.now())))
                .isInstanceOf(ServicioNoDisponibleException.class);
        verify(vacunaRepository, never()).save(any());
    }

    @Test
    void unUsuarioQueNoEsVeterinarioMatriculadoNoPuedeVacunar() {
        when(veterinarioRepository.findByUsername("personal1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> libretaService.registrarVacuna("VA-000001", "personal1", vacuna("30111222", LocalDate.now())))
                .isInstanceOf(ReglaNegocioException.class);
        verify(registroClient, never()).verificarPerro(any(), any());
    }

    // ---------- Vencimientos (RF11, RN13) ----------

    @Test
    void vencimientosTraeLosSinAntirrabicaPrimeroYLosQueVencenEnElPlazo_RN13() {
        LocalDate hoy = LocalDate.now();
        when(libretaRepository.buscarUltimaAntirrabicaDeCadaPerro(TipoVacuna.ANTIRRABICA)).thenReturn(List.of(
                fila("VA-1", hoy.plusDays(100)),  // vence lejos: no sale
                fila("VA-2", hoy.plusDays(10)),   // vence en 10 días: sale, todavía AL_DIA
                fila("VA-3", hoy.minusDays(5)),   // vencida: sale, IRREGULAR
                fila("VA-4", null)));             // nunca tuvo: sale primero, IRREGULAR

        List<VencimientoResponse> lista = libretaService.vencimientos(30, null, null);

        assertThat(lista).extracting(VencimientoResponse::codigoPerro).containsExactly("VA-4", "VA-3", "VA-2");
        assertThat(lista).extracting(VencimientoResponse::estadoSanitario)
                .containsExactly(EstadoSanitario.IRREGULAR, EstadoSanitario.IRREGULAR, EstadoSanitario.AL_DIA);
    }

    @Test
    void vencimientosSeFiltranPorEstadoYPorCodigoDePerro_RN13() {
        LocalDate hoy = LocalDate.now();
        when(libretaRepository.buscarUltimaAntirrabicaDeCadaPerro(TipoVacuna.ANTIRRABICA)).thenReturn(List.of(
                fila("VA-2", hoy.plusDays(10)),   // por vencer: AL_DIA
                fila("VA-3", hoy.minusDays(5)),   // vencida: IRREGULAR
                fila("VA-4", null)));             // nunca tuvo: IRREGULAR

        // IRREGULAR = solo las vencidas (y las que nunca tuvieron); AL_DIA = las que están por vencer
        assertThat(libretaService.vencimientos(30, EstadoSanitario.IRREGULAR, null))
                .extracting(VencimientoResponse::codigoPerro).containsExactly("VA-4", "VA-3");
        assertThat(libretaService.vencimientos(30, EstadoSanitario.AL_DIA, null))
                .extracting(VencimientoResponse::codigoPerro).containsExactly("VA-2");
        // Un perro, sin que importen las mayúsculas
        assertThat(libretaService.vencimientos(30, null, " va-3 "))
                .extracting(VencimientoResponse::codigoPerro).containsExactly("VA-3");
    }

    // ---------- Ayudas ----------

    private void veterinarioLogueado() {
        Veterinario vet = new Veterinario();
        vet.setUsername("vet1");
        vet.setNombre("Carlos Ruiz");
        vet.setMatricula("MP-4521");
        when(veterinarioRepository.findByUsername("vet1")).thenReturn(Optional.of(vet));
    }

    private VacunaRequest vacuna(String dni, LocalDate fecha) {
        return new VacunaRequest(dni, TipoVacuna.ANTIRRABICA, fecha, null);
    }

    private AperturaLibretaRequest apertura(LocalDate antirrabica) {
        return new AperturaLibretaRequest("VA-000001", antirrabica, "-6259_-12860",
                new BigDecimal("-31.2925"), new BigDecimal("-64.2975"));
    }

    private Libreta libreta() {
        Libreta libreta = new Libreta();
        libreta.setCodigoPerro("VA-000001");
        return libreta;
    }

    private UltimaAntirrabica fila(String codigo, LocalDate vencimiento) {
        return new UltimaAntirrabica(codigo, "-6259_-12860", new BigDecimal("-31.2925"), new BigDecimal("-64.2975"), vencimiento);
    }
}
