package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import ar.edu.utn.frc.zoonosis.commons.dtos.FormatoFecha;
import ar.edu.utn.frc.zoonosis.sanidad.models.OrigenVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.TipoVacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Vacuna;
import ar.edu.utn.frc.zoonosis.sanidad.models.Veterinario;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

/**
 * Una vacuna de la libreta. fechaVencimiento solo en la antirrábica (vence al año, RN09).
 * Si la cargó un veterinario, sale quién fue (nombre y matrícula); si la declaró el vecino, no.
 */
public record VacunaResponse(
        TipoVacuna tipo,
        String descripcion,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaAplicacion,
        @JsonFormat(pattern = FormatoFecha.FECHA) LocalDate fechaVencimiento,
        OrigenVacuna origen,
        VeterinarioVacuna veterinario
) {

    public record VeterinarioVacuna(String nombre, String matricula) { }

    public static VacunaResponse desde(Vacuna vacuna) {
        Veterinario vet = vacuna.getVeterinario();
        return new VacunaResponse(
                vacuna.getTipo(),
                vacuna.getDescripcion(),
                vacuna.getFechaAplicacion(),
                vacuna.getFechaVencimiento(),
                vacuna.getOrigen(),
                vet != null ? new VeterinarioVacuna(vet.getNombre(), vet.getMatricula()) : null);
    }
}
