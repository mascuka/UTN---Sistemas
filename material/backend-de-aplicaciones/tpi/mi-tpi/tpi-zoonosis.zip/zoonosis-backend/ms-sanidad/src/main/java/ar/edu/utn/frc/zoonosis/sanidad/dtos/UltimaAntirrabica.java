package ar.edu.utn.frc.zoonosis.sanidad.dtos;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila de la consulta LibretaRepository.buscarUltimaAntirrabicaDeCadaPerro (no sale en la API):
 * cada libreta con su zona y el vencimiento de su antirrábica más reciente (null si no tiene ninguna).
 * La usan los vencimientos (RF11) y el mapa de vacunación por zona (RF13).
 */
public record UltimaAntirrabica(
        String codigoPerro,
        String zonaId,
        BigDecimal zonaLat,
        BigDecimal zonaLon,
        LocalDate fechaVencimiento
) { }
