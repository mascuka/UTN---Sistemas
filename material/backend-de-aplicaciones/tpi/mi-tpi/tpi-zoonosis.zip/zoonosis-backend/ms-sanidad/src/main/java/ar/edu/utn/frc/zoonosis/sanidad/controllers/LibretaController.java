package ar.edu.utn.frc.zoonosis.sanidad.controllers;

import ar.edu.utn.frc.zoonosis.sanidad.dtos.LibretaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaRequest;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VacunaResponse;
import ar.edu.utn.frc.zoonosis.sanidad.dtos.VencimientoResponse;
import ar.edu.utn.frc.zoonosis.sanidad.models.EstadoSanitario;
import ar.edu.utn.frc.zoonosis.sanidad.services.LibretaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Endpoints de las libretas sanitarias. Solo maneja HTTP: la lógica está en LibretaService.
 */
@RestController
@RequestMapping("/api/v1/libretas")
public class LibretaController {

    private final LibretaService libretaService;

    public LibretaController(LibretaService libretaService) {
        this.libretaService = libretaService;
    }

    // RF11 (PERSONAL_MUNICIPAL): antirrábicas vencidas o que vencen en los próximos N días (por defecto 30).
    // Filtros opcionales: ?estado=IRREGULAR (solo las vencidas) o AL_DIA (las que están por vencer), ?codigoPerro=
    // Spring prefiere esta ruta fija antes que la de {codigo}
    @GetMapping("/vencimientos")
    public ResponseEntity<List<VencimientoResponse>> vencimientos(@RequestParam(defaultValue = "30") int dias,
                                                                  @RequestParam(required = false) EstadoSanitario estado,
                                                                  @RequestParam(required = false) String codigoPerro) {
        return ResponseEntity.ok(libretaService.vencimientos(dias, estado, codigoPerro));
    }

    // RF10 (PERSONAL_MUNICIPAL o VETERINARIO): la libreta de un perro. 404 si no existe
    @GetMapping("/{codigo}")
    public ResponseEntity<LibretaResponse> obtener(@PathVariable String codigo) {
        return ResponseEntity.ok(libretaService.obtener(codigo));
    }

    // RF09 (VETERINARIO): registrar una vacuna. El veterinario sale del token (preferred_username)
    @PostMapping("/{codigo}/vacunas")
    public ResponseEntity<VacunaResponse> registrarVacuna(@PathVariable String codigo,
                                                          @AuthenticationPrincipal Jwt jwt,
                                                          @Valid @RequestBody VacunaRequest datos) {
        VacunaResponse vacuna = libretaService.registrarVacuna(codigo, jwt.getClaimAsString("preferred_username"), datos);
        return ResponseEntity.status(HttpStatus.CREATED).body(vacuna);
    }
}
