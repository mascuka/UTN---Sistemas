package ar.edu.utn.frc.zoonosis.commons.exceptions;

public class ServicioNoDisponibleException extends ZoonosisException {

    public ServicioNoDisponibleException(String mensaje) {
        super(mensaje, 503);
    }

    public ServicioNoDisponibleException(String mensaje, Throwable causa) {
        super(mensaje, 503, causa);
    }
}
