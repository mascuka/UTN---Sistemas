package ar.edu.utn.frc.zoonosis.commons.handlers;

import ar.edu.utn.frc.zoonosis.commons.dtos.ErrorResponse;
import ar.edu.utn.frc.zoonosis.commons.exceptions.ZoonosisException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Convierte las excepciones en respuestas JSON con el mismo formato (ErrorResponse: status, mensaje y timestamp)
 * en todos los microservicios. Así los controllers no tienen try/catch.
 */
@RestControllerAdvice
public class ManejadorErrores {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErrores.class);

    // Errores del sistema: cada excepción ya trae su código (403, 404, 409, 422, 503)
    @ExceptionHandler(ZoonosisException.class)
    public ResponseEntity<ErrorResponse> manejarZoonosis(ZoonosisException ex) {
        if (ex.getStatus() >= 500) {
            // El detalle va al log; el usuario recibe un mensaje general, sin nombres internos
            log.warn("Dependencia no disponible: {}", ex.getMessage(), ex.getCause());
            return armar(ex.getStatus(), ErrorResponse.MENSAJE_NO_DISPONIBLE, null);
        }
        return armar(ex.getStatus(), ex.getMessage(), null);
    }

    // Datos inválidos según las anotaciones de los DTO (@NotBlank, @Pattern...): 400 con el detalle por campo
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> manejarValidacion(MethodArgumentNotValidException ex) {
        Map<String, String> errores = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(error -> errores.put(error.getField(), error.getDefaultMessage()));
        return armar(400, "Hay datos inválidos", errores);
    }

    // JSON mal escrito, o un valor que no corresponde al campo: 400.
    // Si el problema es un valor (por ejemplo "tipo": "SEXTUPLE" o una fecha 10/05/2021), se dice en qué campo
    // y qué se espera (si es una lista fija, cuáles son los valores posibles): así el que llama sabe qué corregir
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> manejarJsonInvalido(HttpMessageNotReadableException ex) {
        if (ex.getCause() instanceof InvalidFormatException valor && !valor.getPath().isEmpty()) {
            // El camino del campo, por ejemplo "tipo" o "perro.sexo"
            String campo = valor.getPath().stream()
                    .map(JsonMappingException.Reference::getFieldName)
                    .filter(Objects::nonNull)
                    .collect(Collectors.joining("."));
            return armar(400, "Hay datos inválidos", Map.of(campo, explicar(valor)));
        }
        return armar(400, "Pedido inválido: el cuerpo no es un JSON válido", null);
    }

    // Parámetro de la URL con un valor que no corresponde (por ejemplo ?estado=CUALQUIERA o /solicitudes/abc): 400.
    // Igual que con el body, se dice qué se espera
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> manejarParametroInvalido(MethodArgumentTypeMismatchException ex) {
        Class<?> tipo = ex.getRequiredType();
        String motivo;
        if (tipo != null && tipo.isEnum()) {
            motivo = "los valores posibles son " + valoresPosibles(tipo);
        } else if (tipo != null && esNumero(tipo)) {
            motivo = "tiene que ser un número";
        } else {
            motivo = "el valor '" + ex.getValue() + "' no corresponde";
        }
        return armar(400, "Parámetro '" + ex.getName() + "' inválido: " + motivo, null);
    }

    // Un método que esa dirección no tiene (por ejemplo DELETE /api/v1/tutores/1): 405
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorResponse> manejarMetodoInvalido(HttpRequestMethodNotSupportedException ex) {
        return armar(405, "Método inválido: esta dirección no acepta " + ex.getMethod(), null);
    }

    // Una dirección que no existe en el servicio: 404
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ErrorResponse> manejarDireccionInexistente(NoResourceFoundException ex) {
        return armar(404, "Dirección inválida: la dirección pedida no existe", null);
    }

    // Un body que no viene como JSON: 415
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ErrorResponse> manejarFormatoInvalido(HttpMediaTypeNotSupportedException ex) {
        return armar(415, "Formato inválido: el cuerpo del pedido tiene que ser JSON", null);
    }

    // Qué se esperaba en el campo, según su tipo en el DTO. Siempre "Dato inválido: motivo"
    private String explicar(InvalidFormatException valor) {
        Class<?> tipo = valor.getTargetType();
        if (tipo.isEnum()) {
            return "Valor inválido: los valores posibles son " + valoresPosibles(tipo);
        }
        if (tipo == LocalDate.class) {
            return "Fecha inválida: la fecha va como AAAA-MM-DD (por ejemplo, 2021-05-10)";
        }
        if (tipo == boolean.class || tipo == Boolean.class) {
            return "Valor inválido: tiene que ser true o false";
        }
        if (esNumero(tipo)) {
            return "Valor inválido: tiene que ser un número";
        }
        return "Valor inválido: '" + valor.getValue() + "' no corresponde a este campo";
    }

    // Los valores de un enum separados por coma, por ejemplo "AL_DIA, IRREGULAR"
    private String valoresPosibles(Class<?> tipoEnum) {
        return Arrays.stream(tipoEnum.getEnumConstants())
                .map(Object::toString)
                .collect(Collectors.joining(", "));
    }

    private boolean esNumero(Class<?> tipo) {
        return Number.class.isAssignableFrom(tipo) || tipo == int.class || tipo == long.class;
    }

    private ResponseEntity<ErrorResponse> armar(int status, String mensaje, Map<String, String> errores) {
        return ResponseEntity.status(status).body(ErrorResponse.crear(status, mensaje, errores));
    }
}
