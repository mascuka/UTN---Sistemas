package ar.edu.utn.frc.zoonosis.commons.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Documentación OpenAPI (Swagger) de los microservicios, configurada igual en los dos.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI documentacion(@Value("${spring.application.name}") String servicio) {
        return new OpenAPI()
                .info(new Info()
                        .title(servicio)
                        .version("1.0.0")
                        .description("Registro de perros y control antirrábico de Villa Allende"))
                // Servidor relativo: Swagger prueba los endpoints contra la misma dirección desde la que se abrió
                // (el gateway), nunca contra un nombre interno de Docker como http://ms-registro:8081
                .servers(List.of(new Server().url("/")))
                // Botón "Authorize": se pega el token de Keycloak y Swagger lo manda como "Bearer ..."
                .components(new Components().addSecuritySchemes("token",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
                .addSecurityItem(new SecurityRequirement().addList("token"));
    }
}
