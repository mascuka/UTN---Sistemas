package ar.edu.utn.frc.zoonosis.commons.security;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Lee los roles que pone Keycloak en el token (claim "realm_access.roles")
 * y los convierte al formato de Spring Security: VECINO -> ROLE_VECINO.
 * Con eso funcionan las reglas hasRole("VECINO") de la configuración de seguridad.
 */
public class RolesKeycloakConverter implements Converter<Jwt, Collection<GrantedAuthority>> {

    @Override
    public Collection<GrantedAuthority> convert(Jwt jwt) {
        List<GrantedAuthority> autoridades = new ArrayList<>();
        Map<String, Object> realmAccess = jwt.getClaim("realm_access");
        if (realmAccess != null && realmAccess.get("roles") instanceof Collection<?> roles) {
            for (Object rol : roles) {
                autoridades.add(new SimpleGrantedAuthority("ROLE_" + rol));
            }
        }
        return autoridades;
    }
}
