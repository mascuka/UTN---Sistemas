package ar.edu.utn.frc.zoonosis.commons.exceptions;

public class EstadoInvalidoException extends ZoonosisException {

    public EstadoInvalidoException(String mensaje) {
        super(mensaje, 409);
    }
}
