package ar.edu.utn.frc.zoonosis.commons.dtos;

/**
 * Cómo se muestran las fechas en las respuestas: como se leen en Argentina.
 * Por dentro se guardan y se calculan como LocalDate y LocalDateTime; esto cambia solo el texto que ve el usuario.
 * Lo usan las anotaciones @JsonFormat de los DTO de respuesta.
 * Las fechas que se cargan en un pedido se siguen escribiendo como AAAA-MM-DD (por ejemplo, 2021-05-10),
 * y la hora de los errores (ErrorResponse) va en formato estándar: no es un dato para el usuario.
 */
public final class FormatoFecha {

    // Una fecha, por ejemplo "10/05/2021"
    public static final String FECHA = "dd/MM/yyyy";

    // Una fecha con hora, por ejemplo "24/11/2026 a las 21:52 hs" (lo que va entre comillas simples se escribe tal cual)
    public static final String FECHA_Y_HORA = "dd/MM/yyyy 'a las' HH:mm 'hs'";

    private FormatoFecha() {
        // Solo tiene constantes: no se crean objetos de esta clase
    }
}
