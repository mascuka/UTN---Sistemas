package ar.edu.utn.frc.zoonosis.commons.exceptions;

public class ReglaNegocioException extends ZoonosisException {

    public ReglaNegocioException(String mensaje) {
        super(mensaje, 422);
    }
}
