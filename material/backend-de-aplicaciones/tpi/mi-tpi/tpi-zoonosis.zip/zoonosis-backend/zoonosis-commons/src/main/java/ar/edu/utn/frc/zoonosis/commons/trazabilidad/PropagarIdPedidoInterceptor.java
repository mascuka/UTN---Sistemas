package ar.edu.utn.frc.zoonosis.commons.trazabilidad;

import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

/**
 * Se agrega a los RestClient que llaman al otro microservicio (igual que PropagarTokenInterceptor).
 * Le pasa el id del pedido actual en el header X-Request-Id, así los logs de los dos servicios
 * muestran el mismo id para el mismo proceso.
 */
public class PropagarIdPedidoInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        String id = MDC.get(IdPedidoFilter.CLAVE_LOG);
        if (id != null) {
            request.getHeaders().set(IdPedidoFilter.HEADER, id);
        }
        return execution.execute(request, body);
    }
}
