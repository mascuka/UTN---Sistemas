package ar.edu.utn.frc.zoonosis.commons.trazabilidad;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Identificador de cada pedido, para seguir un proceso entre servicios en los logs.
 * Toma el header X-Request-Id que pone el gateway (o el otro microservicio) y lo guarda en el MDC del log:
 * así cada línea de log de este pedido lleva ese id (ver logging.pattern.level en application.yml).
 * Si el pedido no trae id, se inventa uno.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE) // antes que todos, también que la seguridad
public class IdPedidoFilter extends OncePerRequestFilter {

    public static final String HEADER = "X-Request-Id";
    public static final String CLAVE_LOG = "idPedido";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String id = request.getHeader(HEADER);
        if (id == null || id.isBlank()) {
            id = UUID.randomUUID().toString().substring(0, 8);
        }
        MDC.put(CLAVE_LOG, id);
        response.setHeader(HEADER, id); // el cliente también lo ve en la respuesta
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove(CLAVE_LOG); // el hilo se reusa para otro pedido: hay que limpiarlo
        }
    }
}
