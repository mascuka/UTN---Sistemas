package ar.edu.utn.frc.zoonosis.commons.exceptions;

/**
 * 403: el recurso existe, pero no es del usuario que lo pide (por ejemplo, un vecino que pide
 * la solicitud de otro vecino). El rol lo controla Spring Security; esto es el control de dueño (RN04).
 */
public class PermisoDenegadoException extends ZoonosisException {

    public PermisoDenegadoException(String mensaje) {
        super(mensaje, 403);
    }
}
