package ar.edu.utn.frc.zoonosis.commons.security;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.io.IOException;

/**
 * Se agrega a los RestClient que llaman a otro microservicio.
 * Antes de cada llamada copia el token del usuario que hizo el pedido (header Authorization),
 * así el otro servicio también sabe quién es y controla su rol.
 */
public class PropagarTokenInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        // Spring Security guarda acá el usuario del pedido actual (ya validado)
        Authentication usuario = SecurityContextHolder.getContext().getAuthentication();
        if (usuario instanceof JwtAuthenticationToken token) {
            request.getHeaders().setBearerAuth(token.getToken().getTokenValue());
        }
        return execution.execute(request, body);
    }
}
