package ar.edu.utn.frc.zoonosis.commons.dtos;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Map;

/**
 * El formato de todos los errores, en los dos microservicios y en el gateway: status, mensaje y timestamp.
 * "errores" sale solo en un 400 por datos inválidos, con el detalle de cada campo (si es null no sale en el JSON).
 */
public record ErrorResponse(
        int status,
        String mensaje,
        String timestamp,
        Map<String, String> errores
) {

    // Lo que ve el usuario cuando algo de lo que dependemos no responde (503), en los servicios y en el gateway.
    // El detalle (qué servicio o qué API falló) queda solo en el log: el usuario no tiene por qué conocer
    // cómo está armado el sistema por dentro
    public static final String MENSAJE_NO_DISPONIBLE =
            "El servicio no está disponible en este momento. Probá de nuevo en unos minutos.";

    /** Arma el error con la fecha y hora de este momento. */
    public static ErrorResponse crear(int status, String mensaje, Map<String, String> errores) {
        return new ErrorResponse(status, mensaje, fechaHoraActual(), errores);
    }

    // Fecha y hora del error en formato estándar ISO 8601, con la zona horaria: "2026-11-25T10:15:30-03:00".
    // No es para que la lea una persona sino para ubicar el error en los logs. Es la hora del contenedor,
    // la de Argentina (TZ en el docker-compose); se corta en los segundos
    private static String fechaHoraActual() {
        return OffsetDateTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }
}
