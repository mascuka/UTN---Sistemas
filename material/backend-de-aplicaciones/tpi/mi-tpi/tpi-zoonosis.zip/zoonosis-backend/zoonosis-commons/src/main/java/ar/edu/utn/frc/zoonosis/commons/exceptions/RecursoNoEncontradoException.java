package ar.edu.utn.frc.zoonosis.commons.exceptions;

public class RecursoNoEncontradoException extends ZoonosisException {

    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje, 404);
    }
}