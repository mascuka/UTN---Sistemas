package ar.edu.utn.frc.zoonosis.commons.exceptions;

public abstract class ZoonosisException extends RuntimeException {

    private final int status;

    protected ZoonosisException(String mensaje, int status) {
        super(mensaje);
        this.status = status;
    }

    protected ZoonosisException(String mensaje, int status, Throwable causa) {
        super(mensaje, causa);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}