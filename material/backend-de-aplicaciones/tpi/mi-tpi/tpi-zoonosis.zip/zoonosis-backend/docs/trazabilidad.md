# Matriz de trazabilidad

Relaciona lo que pide el enunciado y lo que comprometimos con dónde está implementado y cómo se comprueba.

**Dónde se comprueba:**
- **Postman:** colección `postman/TPI-Zoonosis.postman_collection.json`. Se indica la carpeta y el nombre del pedido; cada pedido tiene sus pruebas.
- **JUnit:** pruebas automáticas en `ms-registro/src/test` y `ms-sanidad/src/test` (ver la sección "Pruebas" del README).

---

## 1. Requisitos obligatorios del enunciado

| Requisito | Implementación | Evidencia |
|---|---|---|
| Microservicios + API Gateway como único punto de entrada, con Security Filter | `api-gateway`: `RutasConfig` (rutas), `SecurityConfig` (token y rol por ruta). Solo el gateway y Keycloak publican puertos (`docker-compose.yml`) | Postman 6: "401: sin token", "403: ..."; llamar a `localhost:8081` o `8082` no responde |
| Al menos 2 microservicios con responsabilidades coherentes | `ms-registro` (personas y padrón) y `ms-sanidad` (salud del perro, sin datos personales) | README, "Arquitectura"; diagrama C2 |
| Al menos 1 proceso con colaboración real | P1 aprobación, P2 vacuna, P3 ficha y "mis perros", P4 comunitarios | Diagramas `docs/procesos/`; Postman 3, 4 y 7; JUnit `*_P1`, `*_P2`, `*_P3`, `*_P4` |
| Qué pasa si el otro servicio no responde | rollback y 503 (P1, P2, P4), `NO_DISPONIBLE` (P3), 503 del gateway | Postman 7 (con `ms-sanidad` apagado); JUnit `siSanidadNoResponde...`, `siRegistroNoResponde...` |
| API pública externa necesaria para una regla | Georef `/calles` (RN03, RN18), `GeorefClient`. Además OpenStreetMap (Nominatim) ubica la calle y el número para la zona del mapa, `OpenStreetMapClient` | Postman 2 "Cargar mis datos de tutor" (calle oficial) y 6 (422 de calle); JUnit `TutorServiceTest`, `PadronServiceTest` |
| Qué pasa si la API externa falla | Georef: vecino `SIN_VERIFICAR`, comunitario 503. OpenStreetMap: no se da de alta el perro, 503 (si no encuentra la dirección, 422, salvo que el personal indique latitud y longitud de Villa Allende) | JUnit `siGeorefNoResponde...`, `siLaDireccionNoSePuedeUbicarYNoHayUbicacionDelPersonalNoSeDaDeAlta`, `siLaDireccionNoSeEncuentraSeUsaLaUbicacionQueIndicoElPersonal`; Postman 8; `GEOREF_URL=...` u `OSM_URL=http://localhost:9 docker compose up -d ms-registro` |
| Keycloak: OIDC, JWT, roles, autorización por rol, integración con el gateway | Realm `zoonosis` (`keycloak/realm-export.json`), `SecurityConfig` en el gateway y en cada servicio, `RolesKeycloakConverter` | Postman 0 (token) y 6 (401 y 403) |
| Trusted zone | red interna `red-zoonosis`; `/internal/**` sin ruta en el gateway; los servicios vuelven a validar el token | Postman 6 "403: los endpoints internos no se exponen" |
| Componente común en `.m2`, usado por al menos 2 microservicios | `zoonosis-commons` (excepciones, `ErrorResponse`, `ManejadorErrores`, roles, interceptores, trazabilidad, OpenAPI), usado por los 3 proyectos | `pom.xml` de cada proyecto; Dockerfiles (`mvn install` del commons) |
| Persistencia relacional sin mezclar modelos | PostgreSQL 16, un schema por servicio, sin FKs entre schemas | `db/init.sql`; `default_schema` en cada `application.yml` |
| API REST: métodos y códigos correctos, JSON, validación, errores | DTOs con Bean Validation, `ManejadorErrores` (400, 404, 405, 409, 415, 422, 503) y `RespuestaError` del gateway (401, 403, 503): el mismo formato (`status`, `mensaje`, `timestamp`) en todos, `ResponseEntity` | Postman 6 (401, 403, 400, 404, 409, 422; la prueba "formato de error") |
| OpenAPI/Swagger que refleje la API | springdoc en cada servicio, Swagger UI en el gateway | http://localhost:8080/swagger-ui.html |
| Docker Compose reproducible | `docker-compose.yml` con 5 contenedores, healthchecks, red interna, Dockerfiles multi-stage | `docker compose up -d --build` desde cero (README) |
| Diagramas C4 (C1 y C2) coherentes con lo implementado | `docs/c4/` | Coinciden con el compose: 5 contenedores, puertos 8080 y 8180 |
| Colección de Postman | `postman/` (66 pedidos, 9 carpetas: por actor, errores, fallas y un extra) | Run collection: todas las pruebas en verde |

---

## 2. Requerimientos funcionales

| RF | Qué | Endpoint | Servicio (clase) | Postman |
|---|---|---|---|---|
| RF01 | Datos de tutor | `POST /api/v1/tutores`, `GET /api/v1/tutores`, `GET` y `PATCH /api/v1/tutores/{id}` | registro (`TutorService`) | 2 "Ver mis datos de tutor", "Cargar mis datos de tutor", "Cambiar mi teléfono (PATCH)" |
| RF02 | Enviar solicitud (la raza, del listado de Zoonosis) | `POST /api/v1/solicitudes` | registro (`SolicitudService.crear`, `RazaService`) | 2 "Enviar solicitud: Toby" y "...Rocco" |
| RF03 | Las solicitudes del vecino | `GET /api/v1/solicitudes` (con el token de un vecino) | registro (`SolicitudService.listarDelVecino`) | 2 y 5 "Mis solicitudes" |
| RF04 | Los perros del vecino | `GET /api/v1/perros` | registro → sanidad (`PerroService.delVecino`) | 5 "Mis perros (estado de la antirrábica)" |
| RF05 | Listar solicitudes con alertas | `GET /api/v1/solicitudes?estado=` y `/{id}` | registro (`SolicitudService.listar`, `obtener`) | 3 "Solicitudes pendientes", "Detalle...", "Solicitudes observadas" |
| RF06 | Aprobar, observar, rechazar | `PATCH /api/v1/solicitudes/{id}` | registro → sanidad (`SolicitudService.resolver`, `PadronService`) | 3 "Aprobar a Toby", "Observar a Rocco" |
| RF07 | Alta de comunitario | `POST /api/v1/perros/comunitarios` (calle y número aproximado) | registro (+ Georef y OpenStreetMap) → sanidad (`PerroService.altaComunitario`) | 3 "Alta de un perro comunitario" |
| RF08 | Ficha del perro | `GET /api/v1/perros/{codigo}` (personal: cualquiera; vecino: los suyos) | registro → sanidad (`PerroService.ficha`) | 3 "Ficha de Toby", "Ficha del comunitario" |
| RF09 | Registrar vacuna | `POST /api/v1/libretas/{codigo}/vacunas` | sanidad → registro (`LibretaService.registrarVacuna`) | 4 "Registrar la antirrábica de Toby", "Vacunar al comunitario" |
| RF10 | Libreta sanitaria | `GET /api/v1/libretas/{codigo}` | sanidad (`LibretaService.obtener`) | 3 "Libreta de Toby", 4 "Ver la libreta..." |
| RF11 | Vencimientos (filtros opcionales por estado y por perro) | `GET /api/v1/libretas/vencimientos?dias=&estado=&codigoPerro=` | sanidad (`LibretaService.vencimientos`) | 3 "Antirrábicas vencidas o por vencer", "Solo las vencidas", "Vencimiento de un perro" |
| RF12 | Mapa: perros por zona | `GET /api/v1/estadisticas/perros-por-zona` | registro (`EstadisticaService`) | 1 "Mapa: perros por zona" |
| RF13 | Mapa: vacunación por zona | `GET /api/v1/estadisticas/vacunacion-por-zona` | sanidad (`EstadisticaService`) | 1 "Mapa: vacunación por zona" |
| RF14 | Padrón para el personal (todo o los perros de un DNI) | `GET /api/v1/perros?dniTutor=` (con el token del personal) | registro (`PerroService.padron`) | 3 "Padrón de perros (todos)", "Perros de una persona (por DNI)" |
| RF15 | El veterinario encuentra los perros de una persona por su DNI (solo datos de los perros) | `GET /api/v1/perros?dniTutor=` (con el token del veterinario) | registro (`PerroService.paraVeterinario`) | 4 "Buscar los perros de Ana por DNI" |

---

## 3. Reglas de negocio

| RN | Dónde está (clase y método) | JUnit | Postman |
|---|---|---|---|
| RN01 entra PENDIENTE | registro `SolicitudService.crear` | `laSolicitudEntraPendienteYSinAlertas_RN01` | 2 "Enviar solicitud: Toby" |
| RN02 solo se resuelve una PENDIENTE | registro `SolicitudService.resolver` | `soloSeResuelveUnaSolicitudPendiente_RN02` | 6 "409: resolver una solicitud ya resuelta" |
| RN03 la calle tiene que ser de Villa Allende (Georef); si no responde, `SIN_VERIFICAR` y alerta para el personal | registro `TutorService.validarCalle`, `GeorefClient`, `SolicitudService.alertas` | `TutorServiceTest` (3 pruebas `_RN03`), `siElDomicilioDelTutorNoSeVerificoSaleLaAlerta_RN03` | 2 "Cargar mis datos de tutor"; 6 "422: calle que no existe en Villa Allende" |
| RN04 cada vecino ve lo suyo | controllers de registro (`jwt.getSubject()`); `TutorService.buscarDelUsuario`, `SolicitudService.obtenerDelVecino`, `PerroService.ficha` (403 si es de otro) | `unVecinoNoPuedeVerNiCambiarLosDatosDeOtro_RN04`, `unVecinoNoPuedeVerLaSolicitudDeOtro_RN04`, `unVecinoSoloVeLaFichaDeSusPerros_RN04` | 6 "RN04: vecino2 no ve las solicitudes de vecino1" y los tres 403 de vecino2 |
| RN05 un perro se manda una sola vez | registro `SolicitudService.validarQueNoEsteRepetido` | `unPerroQueYaEstaEnElPadronNoSeVuelveAMandar_RN05`, `siYaHayUnaSolicitudPendienteParaEsePerroLaNuevaNoSeGuarda_RN05` | 6 "422: mandar dos veces el mismo perro" |
| RN06 posible PPP (alerta calculada) | registro `SolicitudService.alertas` y `esPosiblePpp`, `RazaService.esPeligrosa` | `razaDelListadoMarcaAlertaPpp_RN06`, `masDe25KgMarcaAlertaPppPeroJusto25No_RN06` | 3 "Solicitudes pendientes" (alertas de Rocco); 2 "Mis solicitudes" (el vecino no las ve) |
| RN07 antirrábica vencida → aviso | registro `SolicitudService.crear` | `antirrabicaDeMasDeUnAnioSeAceptaConAviso_RN07`, `...JustoUnAnio..._RN07` | 2 "Enviar solicitud: Rocco" |
| RN08 solo perros del padrón | sanidad `LibretaService.registrarVacuna` + registro `PerroService.verificar` | `soloSeVacunanPerrosDelPadron_RN08`, `laVerificacionDeUnPerroQueNoEstaEnElPadron_RN08` | 6 "404: vacuna a un perro que no está en el padrón" |
| RN09 vence al año / AL_DIA o IRREGULAR | sanidad `LibretaService.calcularVencimiento`, `estadoSegun` | `conLaAntirrabicaQueVenceHoy..._RN09`, `...VencidaAyer..._RN09`, `...VenceAlAnio_RN09_RN10` | 3 "Ficha de Toby" (`AL_DIA`) |
| RN10 origen de la vacuna | sanidad `LibretaService.abrir` y `registrarVacuna` | `laAntirrabicaDeclaradaQuedaComoDeclarada..._RN10`, `unComunitarioSeVacunaSinDni..._RN10_RN12` | 3 "Libreta de Toby"; 4 "Registrar la antirrábica" |
| RN11 fecha válida | sanidad `LibretaService.registrarVacuna` | `noSeAceptanVacunasConFechaFuturaNiAnterioresAlNacimiento_RN11` | 6 "422: vacuna con fecha futura" |
| RN12 DNI que coincide, sin ver datos | registro `PerroService.verificar` y `paraVeterinario` + sanidad `LibretaService.registrarVacuna` | `laVerificacionSoloDiceSiElDniCoincide_RN12`, `unPerroConTutorNecesitaElDni..._RN12`, `...ComunitarioNoPideDni_RN12`, `elVeterinarioVeLosPerrosDeUnDniSoloConDatosDeLosPerros_RF15` | 4 "Buscar los perros de Ana por DNI", "Ver la libreta (sin datos del tutor)"; 6 "422: vacuna con un DNI que no coincide", "422: vacuna sin DNI" |
| RN13 vencimientos | sanidad `LibretaService.vencimientos` | `vencimientosTraeLosSinAntirrabicaPrimero..._RN13`, `vencimientosSeFiltranPorEstadoYPorCodigoDePerro_RN13` | 3 "Antirrábicas vencidas o por vencer", "Solo las vencidas", "Vencimiento de un perro"; 6 "400: filtro de vencimientos con un estado que no existe" |
| RN14 mapa sin zonas de menos de 3 perros | `EstadisticaService` de registro y de sanidad | `cuentaAlDiaEIrregularesPorZonaYOcultaLasZonasConMenosDe3Perros_RN14` | 1 "Mapa: ..." (prueba "solo zonas con 3 perros o más") |
| RN15 sin datos de tutor no hay solicitud | registro `SolicitudService.crear` | `sinDatosDeTutorNoSePuedeEnviarUnaSolicitud_RN15` | 6 "422: solicitud sin datos de tutor" |
| RN16 un DNI, una cuenta | registro `TutorService.validarDniLibre` | `unDniDeOtraCuentaSeRechaza_RN16` | 6 "422: DNI de otra cuenta" |
| RN17 DNI y domicilio fijos con perros | registro `TutorService.modificar` (PATCH) | `conPerrosEnElPadronNoSePuedeCambiarElDomicilio_RN17`, `...SiSePuedeCambiarElTelefono_RN17`, `volverAEscribirLaCalleComoLaEscribioElVecino..._RN17` | 6 "422: cambiar el domicilio teniendo perros en el padrón" |
| RN18 comunitario en una calle de Villa Allende | registro `PerroService.altaComunitario` | `unComunitarioEnUnaCalleQueNoEsDeVillaAllendeSeRechaza_RN18`, `siGeorefNoRespondeElAltaDelComunitarioDa503_RN18` | 6 "422: comunitario fuera de Villa Allende" |
| RN19 la raza tiene que estar en el listado de Zoonosis | registro `RazaService.nombreOficial` (lo usan `SolicitudService.crear` y `PerroService.altaComunitario`) | `RazaServiceTest` (2 pruebas `_RN19`), `unaRazaQueNoEstaEnElListadoNoSeGuarda_RN19`, `laRazaSeGuardaComoFiguraEnElListadoDeZoonosis_RN19`, `unComunitarioConUnaRazaQueNoEstaEnElListadoSeRechaza_RN19` | 2 "...Rocco" (la raza queda "Rottweiler"); 6 "422: raza que no está en el listado" |

---

## 4. Procesos entre microservicios

| Proceso | Caso normal | Caso de falla controlada |
|---|---|---|
| P1 aprobación (registro → sanidad) | Postman 3 "Aprobar a Toby"; JUnit `aprobarDaDeAlta..._P1`, `PadronServiceTest` | Postman 7 "503: aprobarla con ms-sanidad apagado" + "La solicitud sigue PENDIENTE"; JUnit `siSanidadNoRespondeAlAprobar..._P1` |
| P2 vacuna (sanidad → registro) | Postman 4 "Registrar la antirrábica de Toby" | JUnit `siRegistroNoRespondeNoSeRegistraNada_P2`; con `docker compose stop ms-registro` responde 503 |
| P3 ficha y "mis perros" (registro → sanidad) | Postman 3 "Ficha de Toby", 5 "Mis perros" | Postman 7 "Ficha con ms-sanidad apagado: NO_DISPONIBLE"; JUnit `siSanidadNoRespondeLaFichaSaleIgualConNoDisponible_P3` |
| P4 comunitario (registro + Georef + OpenStreetMap → sanidad) | Postman 3 "Alta de un perro comunitario"; JUnit `elComunitarioSeDaDeAlta..._P4` | JUnit `siGeorefNoRespondeElAltaDelComunitarioDa503_RN18`; Georef caído con `GEOREF_URL`, OpenStreetMap caído con `OSM_URL` |

Cada proceso se puede seguir en los logs de los servicios con el id del pedido (README, "Cómo seguir un proceso en los logs").

---

## 5. Cambios respecto de la propuesta inicial

| Cambio | Motivo | Estado |
|---|---|---|
| Mapa de calor público (perros y vacunación por zona) | Sugerencia del profesor al revisar la propuesta (14/10) | Implementado (RF12, RF13, `mapa.html`) |
| Datos del tutor separados de la solicitud (perfil cargado una vez) | El vecino registra perros en distintos momentos sin repetir sus datos | Comentado con el profesor el 15/10; implementado (RF01, RN15 a RN17) |
| Perros comunitarios (sin tutor) | Son los perros con menos control sanitario | Comentado con el profesor el 15/10; implementado (RF07, RN18) |
| Fecha de la última antirrábica opcional en la solicitud | Muchos vecinos no la saben; la registra después un veterinario | Implementado (la libreta arranca sin vacunas) |
| El listado de vencimientos incluye a los perros que nunca tuvieron antirrábica | Son los primeros que hay que vacunar | Implementado (RF11) |
| URLs de recursos comunes en vez de rutas "mías" (`/tutores/mio`); `POST` para crear y `PATCH` para cambiar | Correcciones del profesor en el oral del 12/11 | Implementado (RF01, RF03, RF04, RF06; RN04 con 403) |
| El vecino manda calle y número en vez de latitud y longitud; nombre, apellido y email salen del token | Correcciones del profesor (12/11): el vecino no conoce sus coordenadas | Implementado (OpenStreetMap ubica la dirección; se guarda solo la zona) |
| Un perro repetido se rechaza en vez de marcarse con una alerta; las alertas se calculan y solo salen las que aplican | Correcciones del profesor (12/11) | Implementado (RN05, RN06, RN07) |
| Mensaje general en los 503, sin nombres internos; las respuestas no muestran campos vacíos | Correcciones del profesor (12/11) | Implementado (`ErrorResponse.MENSAJE_NO_DISPONIBLE`) |
| En el C2, los usuarios también apuntan a Keycloak (inicio de sesión y registro) | Corrección del profesor (12/11) | Implementado (`docs/c4`) |
| Si OpenStreetMap no encuentra la dirección, el personal puede indicar latitud y longitud (solo él, y solo en ese caso); Georef confirma que el punto es de Villa Allende | Una calle oficial que OpenStreetMap no tiene (por ejemplo, Vélez Sarsfield) dejaba al perro sin poder entrar al padrón | Implementado (`PadronService.darDeAlta`, campo opcional `ubicacion`) |
| El personal ve el padrón con la misma URL que el vecino usa para sus perros (`GET /api/v1/perros`), y puede buscar los perros de una persona por DNI | Revisión después del oral: con el token del personal la lista salía vacía | Implementado (RF14) |
| El veterinario puede buscar los perros de una persona con el DNI que ella le da, y ve solo datos de los perros | Es lo práctico: casi nadie sabe el código de su perro, y sin el código no se podía vacunar | Implementado (RF15) |
