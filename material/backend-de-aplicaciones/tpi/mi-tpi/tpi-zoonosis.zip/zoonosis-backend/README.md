# Registro de perros y control antirrábico — Villa Allende

Trabajo Práctico Integrador de Backend de Aplicaciones 2026 (UTN FRC, 3K1).

La Dirección de Zoonosis de Villa Allende no tiene un padrón de perros: no sabe cuántos hay, quién es responsable de cada uno, cuáles tienen la antirrábica vencida ni en qué zonas se concentran. Ante una mordedura, no hay dónde consultar si el perro está vacunado.

Este sistema resuelve eso con:
- un **padrón de perros y tutores** validado por Zoonosis;
- una **libreta sanitaria** por perro, con el control de la antirrábica;
- un **mapa de calor público** con los perros y la vacunación por zona.

El vecino se crea su cuenta, carga sus datos una sola vez y registra a cada perro desde su casa.

---

## Índice

1. [Arquitectura](#arquitectura)
2. [Proceso central](#proceso-central-del-registro-a-la-libreta-sanitaria)
3. [Cómo levantarlo](#cómo-levantarlo)
4. [Cómo probarlo](#cómo-probarlo)
5. [Endpoints y permisos](#endpoints-y-permisos)
6. [Reglas de negocio](#reglas-de-negocio)
7. [Colaboración entre microservicios y manejo de fallas](#colaboración-entre-microservicios-y-manejo-de-fallas)
8. [API externa: Georef](#api-externa-georef)
9. [Seguridad](#seguridad)
10. [Componente común](#componente-común-zoonosis-commons)
11. [Persistencia, modelo de datos y datos de prueba](#persistencia-modelo-de-datos-y-datos-de-prueba)
12. [Pruebas](#pruebas)
13. [Decisiones de diseño y alternativas](#decisiones-de-diseño-y-alternativas)
14. [Dificultades y limitaciones conocidas](#dificultades-y-limitaciones-conocidas)
15. [Estructura del repositorio y tecnologías](#estructura-del-repositorio-y-tecnologías)

La relación entre cada requisito y regla, su implementación y su prueba está en **[docs/trazabilidad.md](docs/trazabilidad.md)**.

---

## Arquitectura

Diagramas C4 en `docs/c4/`: [C1 Contexto](docs/c4/C1-Contexto.png) y [C2 Contenedores](docs/c4/C2-Contenedores.png) (fuentes en PlantUML en la misma carpeta).

![C2 Contenedores](docs/c4/C2-Contenedores.png)

| Contenedor | Qué hace | Puerto publicado |
|---|---|---|
| `api-gateway` | Único punto de entrada: enruta a cada microservicio, valida el token y el rol (Security Filter), sirve Swagger y la página del mapa | **8080** |
| `ms-registro` | Tutores, solicitudes, perros (padrón), alertas, validación de la calle con Georef, ubicación del domicilio con OpenStreetMap y perros por zona. **Es el único dueño de los datos personales** | — (interno) |
| `ms-sanidad` | Libretas sanitarias, vacunas, veterinarios, vencimientos y vacunación por zona. Solo conoce el código del perro y su zona | — (interno) |
| `keycloak` | Cuentas (los vecinos se registran solos), roles y emisión de tokens | **8180** |
| `postgres` | Una instancia, **un schema por servicio** (`registro` y `sanidad`), sin claves foráneas entre schemas | — (interno) |

**¿Por qué estos dos microservicios?** Están cortados por **dueño del dato**:
- **registro** guarda a las personas y el padrón;
- **sanidad** guarda la salud de cada perro, sin ningún dato personal.

Entre los dos solo viaja el **código del perro** (y su zona). Así, el servicio que ve el veterinario no tiene DNI, domicilios ni teléfonos.

**Trusted zone:** desde afuera solo se llega al gateway y a Keycloak. Los microservicios y la base están en la red interna de Docker (`red-zoonosis`) y no publican puertos. Igual, cada microservicio **vuelve a validar el token y el rol** (defensa en profundidad). Los endpoints `/internal/**`, que se usan entre servicios, no tienen ruta en el gateway.

---

## Proceso central: del registro a la libreta sanitaria

Es la historia completa que resuelve el backend: un perro sin registrar termina en el padrón oficial, con su libreta y su vacuna verificada, y aparece en el mapa.

1. **Disparador:** el vecino (con su cuenta) carga sus datos una vez. Manda solo lo que sabe: DNI, calle, número y teléfono; su nombre y su email salen de la cuenta. La calle se valida con Georef.
2. **Envía una solicitud** por su perro (la raza, del listado de Zoonosis). Entra `PENDIENTE`, y el personal ve las alertas que apliquen: posible perro peligroso, antirrábica vencida o domicilio sin verificar. Si ese perro ya fue enviado (pendiente o en el padrón), la solicitud no se guarda.
3. **El personal de Zoonosis la revisa** y la aprueba, observa o rechaza.
4. **Al aprobar (P1):**
   - ms-registro ubica el domicilio del tutor (calle y número, con OpenStreetMap) y da de alta el perro en el padrón, con un código y una zona de 500 m;
   - ms-sanidad le abre la libreta con la antirrábica que declaró el vecino.
5. **El veterinario lo vacuna (P2):** si la persona no sabe el código del perro, lo busca con el DNI que ella le da (ve solo datos de los perros). Ingresa ese DNI con la vacuna, ms-registro confirma el perro y el DNI, y la vacuna queda verificada con su matrícula.
6. **Resultado:**
   - el vecino ve a su perro `AL_DIA` (P3);
   - Zoonosis ve la ficha y los vencimientos;
   - el mapa público suma al perro en su zona.

![Proceso principal](docs/procesos/Proceso-Principal.png)

![Estados de una solicitud](docs/procesos/Estados-Solicitud.png)

En Postman, las carpetas 2 a 5 recorren este proceso de punta a punta con datos conocidos.

**Casos de uso** (qué puede hacer cada actor; fuente en `docs/casos-de-uso/casos-de-uso.puml`):

![Casos de uso](docs/casos-de-uso/Casos-de-Uso.png)

---

## Cómo levantarlo

**Requisitos:** Docker Desktop (con Docker Compose) y unos 2 GB de RAM libres. No hace falta tener Java ni Maven: las imágenes se compilan adentro de Docker.

1. Clonar el repositorio. No hay que configurar nada: el `.env` con los valores de prueba ya viene incluido.

2. Levantar todo:

   ```
   docker compose up -d --build
   ```

   - La primera vez compila los tres proyectos Java, así que tarda unos minutos. Keycloak es el que más tarda en arrancar.
   - Los contenedores esperan a que sus dependencias estén sanas (`healthcheck` + `depends_on`).

3. Verificar que los 5 digan `healthy`:

   ```
   docker compose ps
   ```

Para apagar: `docker compose down`. Los datos quedan guardados en el volumen `postgres-data`. Con `docker compose down -v` se borran, y al volver a levantar quedan solo los datos de prueba.

---

## Cómo probarlo

| Qué | Dónde |
|---|---|
| API (todo pasa por el gateway) | http://localhost:8080/api/v1/... |
| Swagger de los dos servicios | http://localhost:8080/swagger-ui.html (arriba a la derecha se elige `ms-registro` o `ms-sanidad`; botón **Authorize** para pegar el token) |
| Mapa de calor (público) | http://localhost:8080/mapa.html |
| Keycloak: registro de un vecino nuevo | http://localhost:8180/realms/zoonosis/account → *Register* |
| Keycloak: consola de administración | http://localhost:8180/admin (usuario y contraseña del `.env`) |

**Usuarios de prueba** (la contraseña es igual al usuario):

| Usuario | Rol | Para qué |
|---|---|---|
| `vecino1`, `vecino2` | VECINO | cargar sus datos, enviar solicitudes, ver sus perros |
| `personal1` | PERSONAL_MUNICIPAL | resolver solicitudes, comunitarios, padrón, fichas, vencimientos |
| `vet1`, `vet2` | VETERINARIO | buscar los perros de una persona por DNI, libretas y vacunas (matrículas MP-4521 y MP-4876) |

Los tokens duran 1 hora. Se piden al realm `zoonosis` con el cliente público `zoonosis-postman`.

### Colección de Postman

En `postman/` están la colección (`TPI-Zoonosis.postman_collection.json`) y el environment (`zoonosis-local.postman_environment.json`).

1. *Import* de los dos archivos y elegir el environment **"Zoonosis local"**.
2. Correr las carpetas en orden (*Run collection*, o de a un pedido), sobre la base limpia (`docker compose down -v` y `up`). **Los tokens se piden solos:** un script de la colección pide el de cada usuario la primera vez y lo reusa mientras sirve. Los identificadores (id de la solicitud, código del perro) se guardan solos para los pedidos siguientes; si están vacíos (por ejemplo, se importó la colección de nuevo o se corre un pedido suelto), el mismo script los busca con los GET de la API.
3. Cada pedido tiene en su descripción el resultado esperado, y pruebas (`Tests`) que lo verifican.

| Carpeta | Qué muestra |
|---|---|
| 0. Keycloak | cómo se pide un token a mano |
| 1. Público | las dos mitades del mapa (sin token) |
| 2. Vecino | alta de sus datos (`POST`) con Georef, cambio del teléfono (`PATCH`), solicitudes (con aviso de vacuna vencida), sus solicitudes y sus perros |
| 3. Personal | solicitudes con alertas, aprobación (abre la libreta en sanidad), observación, ficha, alta de un comunitario, padrón (todo o por DNI), libreta y vencimientos (con los filtros por estado y por perro) |
| 4. Veterinario | los perros de una persona por su DNI (solo datos de los perros), libreta sin datos del tutor, vacuna con el DNI del tutor, vacuna a un comunitario sin DNI |
| 5. Vecino: seguimiento | el resultado de lo anterior visto por el vecino |
| 6. Errores | 401, 403 (por rol y por ser de otro vecino), 400, 404, 409, cada vecino ve solo lo suyo y un 422 por cada regla de negocio (incluido mandar dos veces el mismo perro) |
| 7. Fallas | **se corre sola, con ms-sanidad apagado** (`docker compose stop ms-sanidad`): 503 al aprobar, `NO_DISPONIBLE` en las consultas, 503 del gateway |

Para probar **Georef caído** (en Git Bash):

```
GEOREF_URL=http://localhost:9/georef docker compose up -d ms-registro
```

Con eso, el alta de un comunitario da 503 y un vecino que carga sus datos queda con el domicilio `SIN_VERIFICAR`. Para volver: `docker compose up -d ms-registro` desde una terminal sin esa variable.

Lo mismo con **OpenStreetMap caído** (`OSM_URL=http://localhost:9 docker compose up -d ms-registro`): aprobar una solicitud o dar de alta un comunitario da 503 y no se guarda nada.

---

## Endpoints y permisos

Todos con el prefijo `/api/v1`, a través del gateway. Los permisos se controlan en el gateway **y** en cada microservicio.

Las URLs son recursos comunes: **no hay rutas "mías"**. El usuario sale del token, y cuando el vecino pide algo por id, el microservicio controla que sea suyo (si no, 403). Una misma URL puede servir a dos roles: por ejemplo, `GET /solicitudes` le devuelve al personal todas y al vecino solo las suyas.

| Método y ruta | Público | VECINO | PERSONAL_MUNICIPAL | VETERINARIO | Qué hace |
|---|:-:|:-:|:-:|:-:|---|
| `POST /tutores` | | ✔ | | | Cargar sus datos de tutor, una sola vez → 201 (409 si ya los cargó). Body: `{dni, calle, altura, telefono, consentimiento}` |
| `GET /tutores` | | ✔ | | | Sus datos de tutor (una lista con uno, o vacía si no los cargó) |
| `GET` / `PATCH /tutores/{id}` | | ✔ | | | Ver o cambiar (solo lo que viene en el body) sus datos. 403 si son de otro vecino |
| `POST /solicitudes` | | ✔ | | | Enviar una solicitud → 201 `{id, estado, fechaCreacion, perro, avisos}`: el perro como quedó registrado (la raza, como figura en el listado) |
| `GET /solicitudes?estado=` | | ✔ | ✔ | | Personal: todas las de ese estado (por defecto PENDIENTE), agrupadas en `perro`, `tutor` y `alertas`. Vecino: solo las suyas, con su `perro` (y el `codigoPerro` si se aprobó), sin alertas |
| `GET /solicitudes/{id}` | | ✔ | ✔ | | Detalle. El vecino solo ve las suyas (403) |
| `PATCH /solicitudes/{id}` | | | ✔ | | Aprobar, observar o rechazar (`{estado, mensaje}`): cambia solo el estado |
| `GET /perros?dniTutor=` | | ✔ | ✔ | ✔ | Vecino: sus perros con el estado de la antirrábica. Personal: el padrón completo, o los perros de una persona con `?dniTutor=` (sin estado sanitario: está en la ficha y en vencimientos). Veterinario: con `?dniTutor=`, los perros de la persona que tiene adelante, **solo con datos de los perros** (`codigo, nombre, raza, sexo, fechaNacimiento`), para encontrar el código si no lo sabe |
| `POST /perros/comunitarios` | | | ✔ | | Alta de un perro sin tutor (calle, número aproximado y referencia) → 201 `{codigo}` |
| `GET /perros/{codigo}` | | ✔ | ✔ | | Ficha del perro con su tutor y su estado sanitario. El vecino solo ve sus perros (403) |
| `GET /libretas/{codigo}` | | | ✔ | ✔ | Libreta sanitaria: el estado y todas las vacunas (el vencimiento de la antirrábica está en la vacuna) |
| `POST /libretas/{codigo}/vacunas` | | | | ✔ | Registrar una vacuna (`{dniTutor?, tipo, fechaAplicacion, descripcion?}`) |
| `GET /libretas/vencimientos?dias=30` | | | ✔ | | Antirrábicas vencidas o que vencen en los próximos N días. Filtros opcionales: `estado` (`IRREGULAR` = vencidas, `AL_DIA` = por vencer) y `codigoPerro` |
| `GET /estadisticas/perros-por-zona` | ✔ | ✔ | ✔ | ✔ | Mapa: cantidad de perros por zona |
| `GET /estadisticas/vacunacion-por-zona` | ✔ | ✔ | ✔ | ✔ | Mapa: perros al día e irregulares por zona |
| cualquier otra ruta (incluido `/internal/**`) | | | | | se rechaza (403) |

**Códigos que usamos:**
- 200 / 201: todo bien;
- 400: datos mal formados (con el detalle por campo; si un valor no corresponde, por ejemplo un tipo de vacuna que no existe, dice qué valores acepta);
- 401: sin token, o con el token vencido;
- 403: rol sin permiso, o el recurso es de otro vecino;
- 404: no existe;
- 409: cambio de estado inválido, o algo que ya existe (cargar dos veces los datos de tutor);
- 405: un método que esa dirección no acepta (por ejemplo, `DELETE`);
- **422: se viola una regla de negocio**;
- **503: una dependencia no responde**. El usuario recibe un mensaje general ("El servicio no está disponible en este momento..."): qué servicio o qué API falló queda solo en el log.

Todos los errores tienen el mismo formato JSON, en los dos microservicios y en el gateway (también el 401, el 403 y el 503 que responde el gateway): `status`, `mensaje` y `timestamp`. Solo un 400 por datos inválidos suma `errores`, con el detalle de cada campo. Cada mensaje dice primero qué dato es inválido y después el motivo, sin detalles internos:

```json
{
  "status": 400,
  "mensaje": "Hay datos inválidos",
  "timestamp": "2026-11-25T10:15:30-03:00",
  "errores": { "altura": "Altura inválida: la altura tiene que ser mayor a 0" }
}
```

`timestamp` va en el formato estándar ISO 8601, con la zona horaria: no es un dato para el usuario, sirve para ubicar el error en los logs. Las fechas de los datos sí se muestran como en Argentina (ver más abajo).

Las respuestas no muestran los campos vacíos (`null`): por ejemplo, una solicitud todavía no resuelta no trae el mensaje de Zoonosis, y un perro comunitario no trae tutor. Lo que es sí o no se muestra solo cuando es sí: `comunitario: true` en los comunitarios y, en las alertas de una solicitud, solo la que aplica (`"alertas": { "posiblePpp": true }`).

Los datos de una misma cosa van agrupados: el tutor (`tutor: { dni, nombre, ... }`), el perro que se declaró en una solicitud (`perro: { ... }`) y el veterinario que cargó una vacuna (`veterinario: { nombre, matricula }`). Cada respuesta trae solo lo que hace falta: en una solicitud, del tutor salen el DNI, el nombre y el domicilio; el teléfono y el email están en la ficha del perro.

**Fechas:** en los pedidos se escriben como `AAAA-MM-DD` (por ejemplo, `"fechaNacimiento": "2021-05-10"`). Las respuestas las muestran como se leen en Argentina: `10/05/2021` y, si tienen hora, `24/11/2026 a las 21:52 hs`. Por dentro se guardan y se calculan como fechas de Java (`LocalDate`, `LocalDateTime`); el formato está en un solo lugar, `FormatoFecha` del componente común, y cada DTO de respuesta lo aplica con `@JsonFormat`. Entre los microservicios (endpoints `/internal`) las fechas viajan en el formato estándar (`2021-05-10`), para que el otro servicio las lea sin ambigüedad.

---

## Reglas de negocio

| # | Regla |
|---|---|
| RN01 | Toda solicitud entra PENDIENTE; el perro pasa al padrón solo cuando Zoonosis la aprueba |
| RN02 | Solo se resuelve una solicitud PENDIENTE (si no, 409). Observada y rechazada son finales |
| RN03 | El domicilio tiene que ser de Villa Allende: la calle tiene que existir en Villa Allende (Georef) y se guarda con su nombre oficial. Si Georef no responde, se guarda como `SIN_VERIFICAR` y el personal lo ve como alerta (`domicilioSinVerificar`) en cada solicitud de ese tutor |
| RN04 | Cada vecino ve solo lo suyo: el usuario sale del token. Si pide algo por id que es de otro vecino, 403 |
| RN05 | Un perro se manda una sola vez: si el vecino ya tiene una solicitud pendiente o un perro en el padrón con el mismo nombre (sin mayúsculas ni tildes), la nueva se rechaza (422) y no se guarda |
| RN06 | Alerta de perro potencialmente peligroso (`posiblePpp`): raza marcada como peligrosa en el listado de razas, o más de 25 kg. Solo la ve el personal. Las alertas no se guardan: se calculan al mostrar la solicitud |
| RN07 | Antirrábica declarada de hace más de un año: se acepta, pero se le avisa al vecino |
| RN08 | Solo se vacunan perros que están en el padrón |
| RN09 | La antirrábica vence al año. Con antirrábica vigente el perro está AL_DIA; si no, IRREGULAR |
| RN10 | Cada vacuna guarda su origen: declarada por el vecino o verificada por un veterinario (con matrícula) |
| RN11 | No se aceptan vacunas con fecha futura ni anterior al nacimiento del perro |
| RN12 | El veterinario nunca ve los datos del tutor: ingresa el DNI que le muestra el tutor y el sistema solo dice si coincide. Los comunitarios no necesitan DNI. Si la persona no sabe el código, con su DNI el veterinario ve sus perros, solo con datos de los perros |
| RN13 | El personal lista las antirrábicas vencidas o por vencer |
| RN14 | El mapa solo muestra totales por zona y oculta las zonas con menos de 3 perros |
| RN15 | Para enviar una solicitud hay que tener cargados los datos de tutor |
| RN16 | Un DNI, una cuenta |
| RN17 | Con perros en el padrón, el tutor no puede cambiar su DNI ni su domicilio |
| RN18 | Perro comunitario: lo da de alta el personal, sin tutor, con la calle y un número aproximado de donde vive; la calle tiene que ser de Villa Allende (si Georef no responde, 503) |
| RN19 | La raza tiene que estar en el listado de Zoonosis (tabla `raza`), sin importar mayúsculas ni tildes, y se guarda como figura ahí. Si es una cruza va `Mestizo`; si no se sabe, `No identificada`. Si no está, 422 |

**Dónde está la lógica:**
- las reglas están en los `services` de cada microservicio;
- los `controllers` solo manejan HTTP y los `repositories` solo acceden a la base;
- en [docs/trazabilidad.md](docs/trazabilidad.md) está la clase y el método de cada regla, con sus pruebas.

**Zonas del mapa:**
- son una cuadrícula de 0,005° (unos 500 m): `zonaId = piso(lat / 0,005) + "_" + piso(lon / 0,005)`. Georef no tiene barrios para Villa Allende;
- la zona se calcula en ms-registro al dar de alta el perro, a partir de la calle y el número (OpenStreetMap), y se replica en sanidad al abrir la libreta. Se guarda solo la zona, nunca el punto exacto;
- así cada servicio arma su mitad del mapa sin llamar al otro.

---

## Colaboración entre microservicios y manejo de fallas

**Criterio:**
- si una operación **cambia datos de los dos servicios** y uno no responde, **se cancela todo** (503);
- si es **una consulta**, se responde con lo que hay y se avisa (`NO_DISPONIBLE`).

| Proceso | Quién lo inicia | Qué pasa | Si el otro no responde |
|---|---|---|---|
| **P1. Aprobar una solicitud** | personal | registro ubica el domicilio (OpenStreetMap), da de alta el perro (código y zona) y le pide a sanidad que abra la libreta con la antirrábica declarada | **rollback**: no queda un perro sin libreta, la solicitud sigue PENDIENTE y responde 503. La apertura es idempotente, así que reintentar es seguro |
| **P2. Registrar una vacuna** | veterinario | sanidad le pregunta a registro si el perro está en el padrón y si el DNI coincide | no se registra nada y responde 503 |
| **P3. Ficha y "mis perros"** | personal / vecino | registro arma los datos y le pide a sanidad el estado de la antirrábica | devuelve los datos con `estadoSanitario: NO_DISPONIBLE` |
| **P4. Alta de un comunitario** | personal | registro valida la calle con Georef, la ubica con OpenStreetMap, da de alta el perro y sanidad abre la libreta | rollback y 503 (igual que P1) |

**Diagramas de secuencia:** [P1, aprobación](docs/procesos/P1-Aprobacion.png) y [P2, vacuna](docs/procesos/P2-Vacuna.png). Las fuentes en PlantUML están en `docs/procesos/`.

![P1 Aprobación](docs/procesos/P1-Aprobacion.png)

### Contratos entre servicios

Son endpoints internos: no pasan por el gateway y piden el token del usuario que inició la operación.

| Endpoint | Lo expone → lo llama | Envía | Responde |
|---|---|---|---|
| `POST /internal/libretas` | sanidad → registro (P1, P4). Rol PERSONAL_MUNICIPAL | `{codigoPerro, fechaAntirrabicaDeclarada?, zonaId, zonaLat, zonaLon}` | **201** libreta creada, o **200** si ya existía (idempotente) · 400 datos inválidos |
| `GET /internal/libretas/{codigo}/estado` | sanidad → registro (P3). Rol VECINO o PERSONAL_MUNICIPAL | — | 200 `{estadoSanitario: AL_DIA \| IRREGULAR, fechaVencimiento}` · 404 sin libreta |
| `GET /internal/perros/{codigo}/verificacion?dni=` | registro → sanidad (P2). Rol VETERINARIO | `dni` opcional (los comunitarios no tienen) | 200 `{existe, comunitario, dniCoincide, fechaNacimiento}`. **Nunca devuelve datos del tutor** |

**Cómo se comunican:**
- HTTP con `RestClient`, con un cliente por servicio destino (`SanidadClient` y `RegistroClient`).
- **El token del usuario viaja con el pedido** (`PropagarTokenInterceptor`, del componente común), así que cada servicio controla el rol también en las llamadas internas.
- **Timeouts:** 3 s para conectar; 10 s para responder entre microservicios y 5 s para Georef y OpenStreetMap.
- Cualquier falla de la llamada (no conecta, tarda, responde 4xx o 5xx o algo inesperado) se convierte en `ServicioNoDisponibleException` (503). No hay `catch (Exception e)` que la esconda.
- **El gateway**, si un servicio está apagado, responde **503** con el formato de error común y el mismo mensaje general, para cualquier método.

### Cómo seguir un proceso en los logs

- El gateway le pone a cada pedido un identificador (`X-Request-Id`, que también vuelve en la respuesta).
- Los servicios lo escriben en cada línea de log y se lo pasan entre ellos.
- Para ver, por ejemplo, una aprobación completa en los tres contenedores:

```
docker compose logs api-gateway ms-registro ms-sanidad | grep <id>
```

Se ve el pedido en el gateway, el alta en el padrón en ms-registro, la apertura de la libreta en ms-sanidad y el resultado. Si falla, en el log aparece el motivo (por ejemplo "ms-sanidad no respondió") con el mismo id; al usuario le llega solo el mensaje general. En los logs nunca se escriben datos personales: solo códigos de perro y resultados.

---

## APIs externas: Georef y OpenStreetMap

### Georef

[Georef](https://apis.datos.gob.ar/georef/api) es el Servicio de Normalización de Datos Geográficos del Gobierno nacional. Es gratuito y sin clave.

- **Para qué la usamos (RN03 y RN18):** `/calles` dice si la calle existe en Villa Allende y cuál es su nombre oficial (Villa Allende tiene 582 calles cargadas). El domicilio se guarda con ese nombre. Además, `/ubicacion` dice si un punto cae dentro del municipio: se usa solo cuando el personal indica a mano dónde vive un perro (ver OpenStreetMap).
- **¿Por qué no lo hicimos nosotros?** Las calles oficiales de cada localidad las mantiene el Estado. Una copia propia quedaría desactualizada.
- **Lo que Georef no tiene:** la numeración de las calles de Villa Allende. Valida la calle, pero no sabe dónde queda cada número. Por eso, para ubicar el domicilio, usamos OpenStreetMap.
- **Si no responde, tarda o devuelve algo inesperado:**
  - **para el vecino**, los datos se guardan igual con el domicilio `SIN_VERIFICAR`, y Zoonosis lo ve en sus solicitudes: el vecino no pierde el trámite por una falla externa;
  - **para el alta de un comunitario**, responde 503: lo carga el mismo personal que valida y puede reintentar.

### OpenStreetMap (Nominatim)

[Nominatim](https://nominatim.openstreetmap.org) es el buscador de direcciones de OpenStreetMap. Es gratuito y sin clave (pide identificarse en el `User-Agent` y no más de un pedido por segundo).

- **Para qué la usamos:** para no pedirle coordenadas al vecino. Con la calle y el número, Nominatim devuelve un punto, y de ese punto sale la **zona del mapa** (500 m). Se usa al dar de alta un perro (al aprobar su solicitud, o al cargar un comunitario). Solo se le manda la calle y el número, nunca el nombre ni el DNI, y se guarda solo la zona.
- **Es aproximada:** si OpenStreetMap tiene el número, el punto es la casa; si no, es un punto de esa calle. Para una zona de 500 m alcanza.
- **Si no responde:** no se da de alta el perro y responde 503 (se puede reintentar).
- **Si no encuentra la dirección:** 422 y no se da de alta el perro. Si la dirección es correcta (OpenStreetMap no tiene todas las calles de Villa Allende), el personal puede volver a aprobar, o a cargar el comunitario, indicando la latitud y longitud (campo opcional `ubicacion`, por ejemplo sacada de Google Maps). Georef `/ubicacion` confirma que el punto cae dentro del municipio. Solo lo puede hacer el personal y solo se usa cuando OpenStreetMap no encuentra la dirección: al vecino nunca se le piden coordenadas.

---

## Seguridad

- **Keycloak** (realm `zoonosis`, importado automáticamente desde `keycloak/realm-export.json`):
  - roles `VECINO`, `PERSONAL_MUNICIPAL` y `VETERINARIO`;
  - los vecinos se registran solos y reciben `VECINO` como rol por defecto; las cuentas del personal y de los veterinarios las crea el administrador;
  - el token dura 1 hora.
- **Gateway:** Spring Security reactivo (WebFlux), con las reglas de acceso por ruta y rol de la tabla de [endpoints y permisos](#endpoints-y-permisos). Todo lo que no está en las reglas se rechaza (`denyAll`).
- **Microservicios:** las mismas reglas con Spring Security servlet. Validan el token otra vez.
- **Roles:** se leen del claim `realm_access.roles` y se convierten a `ROLE_...`, con un conversor del componente común.
- **Reglas de dueño (RN04):** el vecino se identifica por el `sub` del token. Cuando pide una solicitud, un perro o sus datos por id, el microservicio controla que sean suyos (`PermisoDenegadoException`, 403).
- **Contraseñas:** están en el `.env`, que se incluye en el repositorio a propósito: son valores de prueba, para que el sistema se levante en cualquier PC con solo clonarlo. En un entorno real ese archivo no se sube y las contraseñas se cambian. El cliente de Keycloak es público y no tiene secreto.
- **Dos direcciones para Keycloak en Docker:**
  - el token se pide desde afuera (`http://localhost:8180`) y trae ese `iss`;
  - los servicios bajan las claves por la red interna (`http://keycloak:8080`);
  - por eso cada servicio tiene `issuer-uri` (para comparar el `iss`) y `jwk-set-uri` (para las claves) por separado.

---

## Componente común (`zoonosis-commons`)

JAR de Maven (`ar.edu.utn.frc.zoonosis:zoonosis-commons:1.0.0`). Adentro de Docker se compila e instala antes que cada servicio.

**Qué tiene (lo que es igual en todos):**

| Clase | Qué hace | Lo usan |
|---|---|---|
| `ZoonosisException` y sus hijas | Excepciones con su código: 403, 404, 409, 422, 503 | registro y sanidad |
| `ErrorResponse` | Formato común de error (`status`, `mensaje`, `timestamp`), y el mensaje general del 503 | registro, sanidad y gateway |
| `FormatoFecha` | Cómo se muestran las fechas en las respuestas (`10/05/2021`, `24/11/2026 a las 21:52 hs`) | registro y sanidad |
| `ManejadorErrores` | `@RestControllerAdvice` que traduce las excepciones y los errores de validación | registro y sanidad |
| `RolesKeycloakConverter` | Lee los roles del token | registro, sanidad y gateway |
| `PropagarTokenInterceptor` | Reenvía el token en las llamadas entre servicios | registro y sanidad |
| `IdPedidoFilter` y `PropagarIdPedidoInterceptor` | Id de cada pedido en los logs y entre servicios | registro y sanidad |
| `OpenApiConfig` | Configuración de Swagger: servidor relativo y botón para el token | registro y sanidad |

**Qué no tiene, a propósito:** entidades, DTOs del dominio ni reglas de negocio. Cada servicio es dueño de lo suyo, y una librería compartida obliga a recompilar todo cuando cambia, así que solo tiene lo estable.

---

## Persistencia, modelo de datos y datos de prueba

Una instancia de PostgreSQL 16 con dos schemas (`registro` y `sanidad`), creados por `db/init.sql`. Cada servicio usa solo el suyo (`hibernate.default_schema`). **No hay claves foráneas entre schemas:** la libreta guarda el código del perro como referencia lógica.

![DER](docs/datos/DER.png)

(Fuente en PlantUML: `docs/datos/der.puml`.)

**Schema `registro`** (ms-registro):

| Entidad | Datos principales | Relaciones |
|---|---|---|
| `Tutor` | `usuarioId` (= `sub` del token, único), `dni` (único), nombre, apellido, calle (nombre oficial de Georef), altura, teléfono, email (de la cuenta), `estadoDomicilio` (VERIFICADO / SIN_VERIFICAR), fecha del consentimiento | — |
| `Perro` | `codigo` (VA-000123, único), nombre, raza, sexo, nacimiento, peso, castrado, fecha de alta, `zonaId` y centro de la zona, referencia de ubicación (solo comunitarios) | N → 1 `Tutor` (**vacío = comunitario**) |
| `Solicitud` | `estado` (PENDIENTE, OBSERVADA, APROBADA, RECHAZADA), mensaje de Zoonosis, fechas, datos declarados del perro, última antirrábica (opcional). Las alertas no se guardan: se calculan al mostrarla | N → 1 `Tutor`; N → 1 `Perro` (al aprobar) |
| `Raza` | nombre (único), `peligrosa` (las razas de la alerta de RN06) | — |

**Schema `sanidad`** (ms-sanidad):

| Entidad | Datos principales | Relaciones |
|---|---|---|
| `Libreta` | `codigoPerro` (único, sin FK), `zonaId` y centro de la zona, fecha de apertura | — |
| `Vacuna` | tipo (ANTIRRABICA / OTRA), descripción, fecha de aplicación, fecha de vencimiento (antirrábica + 1 año), origen (DECLARADA_VECINO / VERIFICADA_VETERINARIO) | N → 1 `Libreta`; N → 1 `Veterinario` (vacío si es declarada) |
| `Veterinario` | `username` (= usuario de Keycloak), nombre, matrícula | — |

El estado sanitario (AL_DIA / IRREGULAR) no se guarda: se calcula a partir de la última antirrábica.

**Datos de prueba**, que se cargan solos al arrancar (`data.sql` de cada servicio, sin duplicar si se reinicia):
- el listado de razas que acepta Zoonosis: 51 de ejemplo, 8 marcadas como potencialmente peligrosas (el real lo define Zoonosis);
- los veterinarios `vet1` y `vet2` con sus matrículas;
- 27 perros de ejemplo (4 comunitarios) en 7 zonas de Villa Allende, con sus libretas y antirrábicas al día, por vencer y vencidas. Una zona tiene solo 2 perros, para mostrar que no aparece en el mapa.

Todos los datos son inventados.

---

## Pruebas

**1. Pruebas automáticas de las reglas de negocio (JUnit 5 + Mockito):** 62 pruebas (48 en ms-registro y 14 en ms-sanidad) en `ms-registro/src/test` y `ms-sanidad/src/test`.
- Prueban cada regla del service, sus casos normales, los límites (por ejemplo, 25 kg justos no es PPP; la antirrábica que vence hoy todavía está al día) y los rechazos.
- También prueban qué pasa cuando el otro servicio, Georef u OpenStreetMap no responden, y que un vecino no pueda ver lo de otro.
- Los repositorios y los clientes HTTP se reemplazan por "mocks", así que no hacen falta la base ni la red.
- El nombre de cada prueba dice qué regla comprueba (por ejemplo `soloSeResuelveUnaSolicitudPendiente_RN02`).

Con Java 21+ y Maven:

```
cd zoonosis-commons && mvn install && cd ..
cd ms-registro && mvn test && cd ..
cd ms-sanidad && mvn test
```

Sin Java instalado, con Docker, desde la raíz del repositorio (Linux o Mac):

```
docker run --rm -v "$PWD":/tpi -w /tpi maven:3.9-eclipse-temurin-21 sh -c "mvn -q -f zoonosis-commons/pom.xml install && mvn -f ms-registro/pom.xml test && mvn -f ms-sanidad/pom.xml test"
```

En Windows (PowerShell):

```
docker run --rm -v "${PWD}:/tpi" -w /tpi maven:3.9-eclipse-temurin-21 sh -c "mvn -q -f zoonosis-commons/pom.xml install && mvn -f ms-registro/pom.xml test && mvn -f ms-sanidad/pom.xml test"
```

Resultado esperado: `Tests run: 41, Failures: 0` (ms-registro) y `Tests run: 13, Failures: 0` (ms-sanidad).

**2. Pruebas funcionales de punta a punta (Postman):** la colección de `postman/` recorre el proceso central, la seguridad, los errores y las fallas, con verificaciones en cada pedido. También se puede correr desde la terminal con Newman:

```
npx newman run postman/TPI-Zoonosis.postman_collection.json -e postman/zoonosis-local.postman_environment.json
```

---

## Decisiones de diseño y alternativas

| Decisión | Alternativa que evaluamos | Por qué elegimos esta |
|---|---|---|
| Dos microservicios cortados por **dueño del dato** (personas / salud del perro) | Uno por actor (vecino, personal, veterinario), o uno por entidad | Por actor o por entidad quedaban CRUDs separados que se llamaban todo el tiempo. Por dueño del dato, sanidad no tiene ningún dato personal y cada uno tiene reglas propias |
| Ante una falla: **cancelar si cambia datos de los dos, degradar si es consulta** | Reintentos automáticos, o una Saga con compensaciones | Es simple, explicable y no deja datos inconsistentes. La Saga resuelve más casos, pero excede un MVP (ver limitaciones) |
| **Apertura idempotente de la libreta** (201 o 200) | Fallar si ya existe | Así reintentar una aprobación es seguro |
| **Zonas en una cuadrícula** de 0,005° | Barrios oficiales | Georef no tiene barrios para Villa Allende; la cuadrícula es pública y no expone domicilios |
| **La zona se replica en sanidad** al abrir la libreta | Que el mapa le pida a registro las zonas | El mapa público no depende de llamadas entre servicios ni de un token |
| **El veterinario verifica con el DNI** (respuesta sí o no) | Mostrarle los datos del tutor | Privacidad: el veterinario no necesita ver datos personales |
| El veterinario **busca los perros de una persona por DNI**, solo con datos de los perros | Que siempre necesite el código del perro | Es lo práctico: casi nadie sabe el código de su perro. Ve el código, el nombre, la raza, el sexo y la fecha de nacimiento, nunca datos de la persona. El DNI se lo da la persona que tiene adelante |
| Georef caído: **`SIN_VERIFICAR`** para el vecino y **503** para el comunitario | El mismo comportamiento en los dos | El vecino no tiene que perder su trámite; el personal puede reintentar en el momento |
| **URLs de recursos comunes** (`/tutores/{id}`, `/solicitudes`) y el usuario del token | Rutas "mías" (`/tutores/mio`) | Es la forma estándar de REST: el recurso es el mismo para todos, y el back controla de quién es |
| **`POST` para crear y `PATCH` para cambiar** | Un `PUT` que crea o actualiza | Cada método hace una sola cosa: crear da 201 una vez; cambiar algo existente (un teléfono, el estado de una solicitud) es parcial |
| El vecino manda **calle y número**; la zona sale de **OpenStreetMap** | Pedirle latitud y longitud | Nadie sabe sus coordenadas. Georef no tiene la numeración de Villa Allende, así que la ubicación sale de otra API pública |
| **Duplicado: se rechaza** (no se guarda) | Guardarlo con una alerta | Una segunda solicitud del mismo perro no aporta nada: quedaba pendiente igual y había que descartarla a mano |
| **Alertas calculadas**, y en la respuesta solo las que aplican (en `true`) | Columnas verdadero/falso guardadas | No se guarda lo que se puede calcular, y la respuesta no se llena de campos en `false` |
| **Listado de razas** en una tabla (con la marca de las peligrosas) | Raza libre, o un enum en el código | Con raza libre entraban razas inventadas o mal escritas y la alerta de RN06 no las reconocía. En una tabla, Zoonosis lo cambia sin tocar el código |
| Hora de los errores en **ISO 8601** y fechas de los datos **como en Argentina** | El mismo formato para todo | La hora del error sirve para buscarlo en los logs; las fechas de los datos las lee una persona |
| **Mensaje general en el 503** | Decir qué servicio falló | El usuario no tiene por qué conocer cómo está armado el sistema; el detalle queda en el log |
| Código del perro con una **secuencia de la base** | Contar los perros + 1 | La secuencia nunca repite un número, aunque dos empleados aprueben al mismo tiempo |
| 503 del gateway con un **filtro global** | Circuit breaker (Resilience4j) con fallback | El filtro resuelve el caso (503 para cualquier método) con una clase, sin otra librería |
| Tokens en Postman con un **script de la colección** | La pestaña OAuth 2.0 de Postman | El script pide los tokens solo, sin clics, y la colección también corre con Newman |

---

## Dificultades y limitaciones conocidas

**Dificultades que resolvimos:**
- **El `iss` del token en Docker:** el token se pide por `localhost:8180`, pero adentro de Docker Keycloak es `keycloak:8080`. Se resolvió separando `issuer-uri` y `jwk-set-uri`, y configurando `KC_HOSTNAME` en Keycloak.
- **El primer pedido a un servicio recién arrancado** tardaba hasta 6 s. Con un timeout de 5 s, la aprobación fallaba aunque sanidad terminaba creando la libreta. Se subió a 10 s el tiempo de espera entre servicios.
- **Keycloak tarda varios minutos en arrancar** en una PC lenta: se le dio más margen al healthcheck para que Docker no lo dé por caído.

**Limitaciones conocidas:**
- **Libreta sin perro:** si sanidad crea la libreta y su respuesta tarda más que el timeout, registro deshace el alta y puede quedar una libreta sin perro. Es el problema de coordinar dos bases sin una transacción distribuida.
  - Lo acotamos con un timeout holgado y la apertura idempotente.
  - Esa libreta no se puede usar: para vacunar, sanidad le pregunta a registro y responde 404.
  - La solución completa sería un patrón Saga u outbox.
- **La ubicación del domicilio es aproximada:** OpenStreetMap no siempre tiene la numeración de Villa Allende y devuelve un punto de la calle. En una avenida larga, el perro puede quedar en la zona de al lado. Si directamente no tiene la calle, el personal indica la latitud y longitud a mano.
- **Dos perros de un mismo tutor no pueden llamarse igual** (RN05): es raro, y evita las solicitudes repetidas.
- **Un veterinario podría probar DNIs** y ver qué perros tiene cada persona (solo datos de los perros, nunca de la persona). Es el costo de no pedirle el código: lo acotamos porque sus cuentas las crea el administrador y cada búsqueda queda en el log con su usuario.
- **Los saltos en los códigos** de perro (por ejemplo VA-000003 después de VA-000001) son esperables: una aprobación deshecha no devuelve su número.
- El sistema no maneja fotos, mordeduras, campañas ni avisos por email: quedaron fuera del alcance del MVP.

---

## Estructura del repositorio y tecnologías

```
zoonosis-commons/        componente común (JAR)
api-gateway/             Spring Cloud Gateway (+ static/mapa.html)
ms-registro/             microservicio de tutores, solicitudes y perros (+ src/test)
ms-sanidad/              microservicio de libretas y vacunas (+ src/test)
keycloak/                realm exportado (se importa al arrancar)
db/init.sql              crea los schemas
postman/                 colección y environment
docs/c4/                 diagramas C1 y C2
docs/casos-de-uso/       diagrama de casos de uso
docs/procesos/           diagramas de secuencia (P1, P2) estados de la solicitud y proceso principal
docs/datos/              DER (modelo de datos)
docs/trazabilidad.md     requisitos y reglas → implementación → pruebas
docker-compose.yml       los 5 contenedores
```

Cada microservicio está organizado en `controllers`, `services`, `repositories`, `models`, `dtos`, `clients` y `config`.

**Tecnologías:**
- Java 21, Spring Boot 3.5, Spring Data JPA, Spring Security (resource server), Bean Validation y springdoc-openapi;
- Spring Cloud Gateway (WebFlux);
- PostgreSQL 16 y Keycloak 26;
- Docker Compose;
- JUnit 5 y Mockito;
- Leaflet, para la página del mapa.
