package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Las pruebas que pide el punto 8 del enunciado: los dos encabezados, los límites del porcentaje, las fórmulas,
 *  los costos, el ancho incorrecto y los descartes, más los números de referencia de los dos CSV. */
class TramoSinPavimentarTest {
    private static final String ORIGINAL = "patente,zona,velocidadPromedio,cargaToneladas,estado";
    private static final String NUEVO = ORIGINAL + ",porcentajeRutaSinPAvimentar";

    @TempDir
    Path carpeta;

    private ResultadoParseo leer(String encabezado, String... filas) throws IOException {
        Path archivo = carpeta.resolve("datos.csv");
        Files.writeString(archivo, encabezado + "\n" + String.join("\n", filas) + "\n", StandardCharsets.UTF_8);
        return new ParserVehiculos().parsear(archivo);
    }

    @Test
    void lasFormulasDelEnunciado() {
        // velocidad 76, carga 11 y 30 %: el índice nuevo es 49 (49.6 truncado); con la fórmula original, 50
        VehiculoRuta nuevo = VehiculoRuta.desdeCampos(new String[] {"trk-1", "NORTE", "76", "11", "EN_RUTA", "30"});
        VehiculoRuta original = VehiculoRuta.desdeCampos(new String[] {"trk-2", "NORTE", "76", "11", "EN_RUTA"});
        assertInstanceOf(VehiculoRutaConTramoSinPavimentar.class, nuevo);
        assertEquals(VehiculoRuta.class, original.getClass());
        assertEquals(49, nuevo.getIndiceDesgaste());
        assertEquals(50, original.getIndiceDesgaste());
        // el costo sigue siendo 2000 * índice / 100 con división entera
        assertEquals(980, nuevo.getCostoDesgasteOperativo());
        assertEquals(1000, original.getCostoDesgasteOperativo());
    }

    @Test
    void elPorcentajeVaDe0A100Inclusive() throws IOException {
        ResultadoParseo r = leer(NUEVO,
                "trk-0,NORTE,40,10,EN_RUTA,0",
                "trk-100,SUR,40,10,DEMORADO,100",
                "trk-menos,CENTRO,40,10,EN_RUTA,-1",
                "trk-mas,CENTRO,40,10,EN_RUTA,101");
        assertEquals(2, r.getFilasProcesadas());
        assertEquals(2, r.getFilasInvalidas());
        assertEquals(0, ((VehiculoRutaConTramoSinPavimentar) r.getVehiculos().get(0)).getPorcentajeRutaSinPAvimentar());
        assertEquals(100, ((VehiculoRutaConTramoSinPavimentar) r.getVehiculos().get(1)).getPorcentajeRutaSinPAvimentar());
        assertThrows(IllegalArgumentException.class,
                () -> VehiculoRuta.desdeCampos(new String[] {"trk", "NORTE", "40", "10", "EN_RUTA", "101"}));
    }

    @Test
    void bajoElEncabezadoNuevoEntranFilasDe5Y6Campos() throws IOException {
        ResultadoParseo r = leer(NUEVO, "trk-5,NORTE,76,11,EN_RUTA", "trk-6,SUR,76,11,EN_RUTA,30");
        assertEquals(2, r.getFilasProcesadas());
        assertEquals(0, r.getFilasInvalidas());
        Flota flota = new Flota(r.getVehiculos());
        assertEquals(1980, flota.getCostoTotalDesgasteOperativo());
        assertEquals(Map.of("NORTE", 1000, "SUR", 980), flota.getCostoPorZona());
    }

    @Test
    void bajoElEncabezadoOriginalSeisCamposEsInvalida() throws IOException {
        ResultadoParseo r = leer(ORIGINAL, "trk-5,NORTE,76,11,EN_RUTA", "trk-6,SUR,76,11,EN_RUTA,30");
        assertEquals(1, r.getFilasProcesadas());
        assertEquals(1, r.getFilasInvalidas());
    }

    @Test
    void anchoIncorrectoEncabezadoRepetidoYFilaVaciaSonInvalidas() throws IOException {
        ResultadoParseo r = leer(NUEVO,
                "trk-4,NORTE,76,11",
                "trk-7,NORTE,76,11,EN_RUTA,30,extra",
                NUEVO,
                "",
                "trk-ok,NORTE,76,11,EN_RUTA,30");
        assertEquals(1, r.getFilasProcesadas());
        assertEquals(4, r.getFilasInvalidas());
        assertEquals(5, r.getFilasLeidas());
    }

    @Test
    void enDepositoSeDescartaSinValidarElPorcentaje() throws IOException {
        // primero el ancho; si es correcto, EN_DEPOSITO se descarta aunque el porcentaje esté fuera de rango
        ResultadoParseo r = leer(NUEVO, "trk-dep,NORTE,500,999,EN_DEPOSITO,500", "trk-dep2,NORTE,40,10,EN_DEPOSITO,4,9");
        assertEquals(1, r.getFilasDescartadas());
        assertEquals(1, r.getFilasInvalidas());
        assertEquals(0, r.getFilasProcesadas());
    }

    @Test
    void unEncabezadoIncorrectoAbortaConIllegalArgumentException() throws IOException {
        Path archivo = carpeta.resolve("malo.csv");
        Files.writeString(archivo, "patente,zona,velocidad,carga,estado,porcentaje\ntrk,NORTE,40,10,EN_RUTA,10\n", StandardCharsets.UTF_8);
        assertThrows(IllegalArgumentException.class, () -> new ParserVehiculos().parsear(archivo));
    }

    @Test
    void losNumerosDeReferenciaDeLosDosCsv() throws IOException {
        ResultadoParseo original = new ParserVehiculos().parsear(Path.of("datos/datos.csv"));
        assertEquals(60, original.getFilasLeidas());
        assertEquals(32, original.getFilasProcesadas());
        assertEquals(20, original.getFilasDescartadas());
        assertEquals(8, original.getFilasInvalidas());
        Flota flotaOriginal = new Flota(original.getVehiculos());
        assertEquals(31840, flotaOriginal.getCostoTotalDesgasteOperativo());
        assertEquals(18, flotaOriginal.contarConIndiceDesgasteMenorA(55));

        ResultadoParseo combinado = new ParserVehiculos().parsear(Path.of("datos/datos-parcial.csv"));
        assertEquals(70, combinado.getFilasLeidas());
        assertEquals(35, combinado.getFilasProcesadas());
        assertEquals(21, combinado.getFilasDescartadas());
        assertEquals(14, combinado.getFilasInvalidas());
        Flota flota = new Flota(combinado.getVehiculos());
        assertEquals(34800, flota.getCostoTotalDesgasteOperativo());
        assertEquals(Map.of("NORTE", 12180, "CENTRO", 13160, "SUR", 9460), flota.getCostoPorZona());
        assertEquals(20, flota.contarConIndiceDesgasteMenorA(55));
        assertTrue(flota.panorama().contains("20"));
    }
}
