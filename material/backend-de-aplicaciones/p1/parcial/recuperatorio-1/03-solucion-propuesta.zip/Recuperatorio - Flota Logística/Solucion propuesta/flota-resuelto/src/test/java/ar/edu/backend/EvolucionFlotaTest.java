package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class EvolucionFlotaTest {
    private static final String ENCABEZADO_ORIGINAL =
            "patente,zona,velocidadPromedio,cargaToneladas,estado";
    private static final String ENCABEZADO_PARCIAL =
            ENCABEZADO_ORIGINAL + ",porcentajeRutaSinPAvimentar";

    @TempDir
    Path directorio;

    private ResultadoParseo leer(String nombre, String encabezado, String filas) throws IOException {
        Path archivo = directorio.resolve(nombre);
        Files.writeString(archivo, encabezado + "\n" + filas, StandardCharsets.UTF_8);
        return new ParserVehiculos().parsear(archivo);
    }

    @Test
    void calculaYAgregaFilasDeAmbosFormatos() throws IOException {
        ResultadoParseo resultado = leer(
                "mixto.csv",
                ENCABEZADO_PARCIAL,
                "trk-original,NORTE,76,11,EN_RUTA\n"
                        + "trk-nuevo,SUR,76,11,EN_RUTA,30\n");

        assertEquals(2, resultado.getFilasProcesadas());
        assertEquals(0, resultado.getFilasInvalidas());

        VehiculoRuta original = resultado.getVehiculos().get(0);
        VehiculoRuta nuevo = resultado.getVehiculos().get(1);
        assertEquals(50, original.getIndiceDesgaste());
        assertEquals(1000, original.getCostoDesgasteOperativo());
        assertEquals(49, nuevo.getIndiceDesgaste());
        assertEquals(980, nuevo.getCostoDesgasteOperativo());
        assertInstanceOf(VehiculoRutaConTramoSinPavimentar.class, nuevo);
        VehiculoRutaConTramoSinPavimentar conPorcentaje =
                (VehiculoRutaConTramoSinPavimentar) nuevo;
        assertEquals(VehiculoRuta.class, conPorcentaje.getClass().getSuperclass());
        assertEquals(30, conPorcentaje.getPorcentajeRutaSinPAvimentar());

        Flota flota = new Flota(resultado.getVehiculos());
        assertEquals(1980, flota.getCostoTotalDesgasteOperativo());
        assertEquals(Map.of("NORTE", 1000, "SUR", 980), flota.getCostoPorZona());
        assertEquals(1000, flota.sumarCostoDesgasteOperativo(
                vehiculo -> vehiculo.getZona().equals("NORTE")));
    }

    @Test
    void conservaElEncabezadoYCalculoDelFormatoAnterior() throws IOException {
        ResultadoParseo resultado = leer(
                "original.csv",
                ENCABEZADO_ORIGINAL,
                "trk-original,NORTE,76,11,EN_RUTA\n");

        assertEquals(1, resultado.getFilasProcesadas());
        assertEquals(0, resultado.getFilasInvalidas());
        assertEquals(50, resultado.getVehiculos().get(0).getIndiceDesgaste());
        assertEquals(1000, resultado.getVehiculos().get(0).getCostoDesgasteOperativo());
    }

    @Test
    void validaLimitesYClasificaFilasDelFormatoNuevo() throws IOException {
        String filas = String.join(
                "\n",
                "trk-porcentaje-min,NORTE,40,10,EN_RUTA,0",
                "trk-porcentaje-max,SUR,40,10,DEMORADO,100",
                "trk-porcentaje-bajo,CENTRO,40,10,EN_RUTA,-1",
                "trk-porcentaje-alto,CENTRO,40,10,EN_RUTA,101",
                "trk-indice-invalido,SUR,128,45,EN_RUTA,100",
                ",,no-entero,,EN_DEPOSITO,101",
                "trk-estado-invalido,NORTE,40,10,PERDIDO,30",
                "trk-ancho-invalido,NORTE,40,EN_RUTA")
                + "\n\n";
        ResultadoParseo resultado = leer("validaciones.csv", ENCABEZADO_PARCIAL, filas);

        assertEquals(9, resultado.getFilasLeidas());
        assertEquals(2, resultado.getFilasProcesadas());
        assertEquals(1, resultado.getFilasDescartadas());
        assertEquals(6, resultado.getFilasInvalidas());
        assertEquals(
                List.of(4, 5, 6, 8, 9, 10),
                resultado.getErrores().stream().map(ErrorParseo::getNumeroLinea).toList());
        assertEquals(25, resultado.getVehiculos().get(0).getIndiceDesgaste());
        assertEquals(40, resultado.getVehiculos().get(1).getIndiceDesgaste());
    }

    @Test
    void clasificaUnEncabezadoRepetidoComoFilaInvalida() throws IOException {
        ResultadoParseo resultado = leer(
                "encabezado-repetido.csv",
                ENCABEZADO_PARCIAL,
                ENCABEZADO_PARCIAL + "\n");

        assertEquals(1, resultado.getFilasLeidas());
        assertEquals(1, resultado.getFilasInvalidas());
        assertEquals(2, resultado.getErrores().get(0).getNumeroLinea());
    }

    @Test
    void elCsvCombinadoConservaLosTotalesEsperados() throws IOException {
        ResultadoParseo resultado = new ParserVehiculos().parsear(
                Path.of("datos", "datos-parcial.csv"));
        Flota flota = new Flota(resultado.getVehiculos());

        assertEquals(70, resultado.getFilasLeidas());
        assertEquals(35, resultado.getFilasProcesadas());
        assertEquals(21, resultado.getFilasDescartadas());
        assertEquals(14, resultado.getFilasInvalidas());
        assertEquals(34800, flota.getCostoTotalDesgasteOperativo());
        assertEquals(
                Map.of("NORTE", 12180, "CENTRO", 13160, "SUR", 9460),
                flota.getCostoPorZona());
        assertEquals(20, flota.contarConIndiceDesgasteMenorA(55));
        org.junit.jupiter.api.Assertions.assertTrue(
                flota.panorama().contains("Vehículos con índice de desgaste menor a 55: 20"));
    }
}
