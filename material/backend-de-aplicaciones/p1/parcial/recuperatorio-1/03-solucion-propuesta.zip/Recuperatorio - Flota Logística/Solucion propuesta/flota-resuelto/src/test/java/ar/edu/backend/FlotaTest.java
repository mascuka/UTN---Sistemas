package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class FlotaTest {
    @Test
    void filtraAgrupaYConservaCopiasDefensivas() {
        VehiculoRuta norte = VehiculoRuta.desdeCampos(
                new String[] {"trk-1", "NORTE", "60", "10", "EN_RUTA"});
        VehiculoRuta sur = VehiculoRuta.desdeCampos(
                new String[] {"trk-2", "SUR", "80", "20", "DEMORADO"});
        List<VehiculoRuta> origen = new ArrayList<>(List.of(norte, sur));
        Flota flota = new Flota(origen);

        origen.clear();

        assertEquals(2, flota.getVehiculos().size());
        assertEquals(800, flota.sumarCostoDesgasteOperativo(
                vehiculo -> vehiculo.getZona().equals("NORTE")));
        assertEquals(1920, flota.getCostoTotalDesgasteOperativo());
        assertEquals(800, flota.getCostoPorZona().get("NORTE"));
        assertEquals(1120, flota.getCostoPorZona().get("SUR"));
        assertThrows(UnsupportedOperationException.class, () -> flota.getVehiculos().clear());
        assertThrows(UnsupportedOperationException.class, () -> flota.getCostoPorZona().clear());
    }
}
