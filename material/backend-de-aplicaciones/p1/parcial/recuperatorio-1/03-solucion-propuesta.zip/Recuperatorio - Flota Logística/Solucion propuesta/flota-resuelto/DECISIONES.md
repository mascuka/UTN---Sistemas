# Decisiones

- Para leer los dos formatos no dupliqué el parser: guardé en «largo» las columnas del encabezado (5 el viejo, 6 el nuevo) y acepto filas de 5 o de largo. El orden lo dejé como estaba: primero el ancho, después descarto EN_DEPOSITO sin validar nada y recién ahí valido.
- porcentajeRutaSinPAvimentar lo puse en VehiculoRutaConTramoSinPavimentar, que hereda directo de VehiculoRuta (le saqué el final) y valida que esté entre 0 y 100. desdeCampos decide por el ancho: con 5 campos arma un VehiculoRuta y con 6 un VehiculoRutaConTramoSinPavimentar, así el parser no hace ningún new.
- Como las filas nuevas usan otra fórmula (0.55, 0.30 y 0.15), le agregué a VehiculoRuta un constructor protected que recibe el índice ya calculado; el público sigue chequeando con la fórmula vieja, así no se rompe el test que ya estaba.
- Al panorama le sumé cuántos tienen índice menor a 55; el main lee datos/datos-parcial.csv si no le pasás nada y no calcula nada, solo delega.
- Sumé TramoSinPavimentarTest con lo que pide el punto 8 (los dos encabezados, los límites 0 y 100, las fórmulas, los costos, los anchos y los descartes). No me quedó nada pendiente.
