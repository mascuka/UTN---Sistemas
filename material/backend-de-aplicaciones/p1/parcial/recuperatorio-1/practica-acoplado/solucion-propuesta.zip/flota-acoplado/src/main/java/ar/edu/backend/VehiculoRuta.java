package ar.edu.backend;

// ANTES: public final class VehiculoRuta {
public class VehiculoRuta {   // MOD
    private static final int ACOPLADO_POR_DEFECTO = 0;   // MOD

    private final String patente;
    private final String zona;
    private final int velocidadPromedio;
    private final int cargaToneladas;
    private final String estado;
    private final int indiceDesgaste;
    private final int acoplado;   // NUEVO

    public VehiculoRuta(
            String patente,
            String zona,
            int velocidadPromedio,
            int cargaToneladas,
            String estado,
            int indiceDesgaste) {
        this(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, ACOPLADO_POR_DEFECTO);   // NUEVO
    }

    public VehiculoRuta(   // NUEVO
            String patente,   // NUEVO
            String zona,   // NUEVO
            int velocidadPromedio,   // NUEVO
            int cargaToneladas,   // NUEVO
            String estado,   // NUEVO
            int indiceDesgaste,   // NUEVO
            int acoplado) {   // NUEVO
        this.patente = validarTexto(patente, "La patente no puede estar vacía");
        this.zona = validarTexto(zona, "La zona no puede estar vacía");
        if (velocidadPromedio <= 0 || velocidadPromedio >= 130) {
            throw new IllegalArgumentException("La velocidad promedio debe ser mayor a 0 y menor a 130");
        }
        if (cargaToneladas > 45) {
            throw new IllegalArgumentException("La carga no puede superar las 45 toneladas");
        }
        if (!"EN_RUTA".equals(estado) && !"DEMORADO".equals(estado)) {
            throw new IllegalArgumentException("Estado de vehículo inválido: " + estado);
        }
        int indiceCalculado = calcularIndiceDesgaste(velocidadPromedio, cargaToneladas);
        if (indiceDesgaste < 1 || indiceDesgaste > 90 || indiceDesgaste != indiceCalculado) {
            throw new IllegalArgumentException("El índice de desgaste debe coincidir con el cálculo y estar entre 1 y 90");
        }
        this.velocidadPromedio = velocidadPromedio;
        this.cargaToneladas = cargaToneladas;
        this.estado = estado;
        this.indiceDesgaste = indiceDesgaste;
        this.acoplado = acoplado;   // NUEVO
    }

    public static VehiculoRuta desdeCampos(String[] campos) {
        // ANTES: if (campos == null || campos.length != 5) {
        // ANTES: throw new IllegalArgumentException("La fila debe tener exactamente cinco columnas");
        if (campos == null || (campos.length != 5 && campos.length != 6)) {   // MOD
            throw new IllegalArgumentException("La fila debe tener cinco o seis columnas");   // MOD
        }

        String patente = limpiar(campos[0]);
        String zona = limpiar(campos[1]);
        int velocidadPromedio = convertirEntero(campos[2], "velocidad promedio");
        int cargaToneladas = convertirEntero(campos[3], "carga en toneladas");
        String estado = limpiar(campos[4]);
        int indiceDesgaste = calcularIndiceDesgaste(velocidadPromedio, cargaToneladas);
        int acoplado = campos.length == 6 ? leerAcoplado(campos[5]) : ACOPLADO_POR_DEFECTO;   // NUEVO

        // ANTES: return new VehiculoRuta(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste);
        if (acoplado > 0) {   // MOD
            return new VehiculoConAcoplado(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, acoplado);   // MOD
        }
        return new VehiculoRuta(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, acoplado);   // MOD
    }

    private static int leerAcoplado(String valor) {   // NUEVO
        String texto = limpiar(valor);   // NUEVO
        int numero = convertirEntero(texto, "acoplado");   // NUEVO
        if (numero < 0 || numero > 20) {   // NUEVO
            throw new IllegalArgumentException("El campo acoplado debe ser mayor o igual a 0 y menor o igual a 20");   // NUEVO
        }
        return numero;   // NUEVO
    }

    private static int calcularIndiceDesgaste(int velocidadPromedio, int cargaToneladas) {
        return (int) (velocidadPromedio * 0.6 + cargaToneladas * 0.4);
    }

    private static int convertirEntero(String valor, String nombreCampo) {
        try {
            return Integer.parseInt(limpiar(valor));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("El campo " + nombreCampo + " debe ser un entero", exception);
        }
    }

    private static String validarTexto(String valor, String mensaje) {
        String texto = limpiar(valor);
        if (texto.isEmpty()) {
            throw new IllegalArgumentException(mensaje);
        }
        return texto;
    }

    private static String limpiar(String valor) {
        if (valor == null) {
            throw new IllegalArgumentException("Los campos no pueden ser nulos");
        }
        return valor.trim();
    }

    public int getCostoDesgasteOperativo() {
        return 2000 * indiceDesgaste / 100;
    }

    public String getPatente() {
        return patente;
    }

    public String getZona() {
        return zona;
    }

    public int getVelocidadPromedio() {
        return velocidadPromedio;
    }

    public int getCargaToneladas() {
        return cargaToneladas;
    }

    public String getEstado() {
        return estado;
    }

    public int getIndiceDesgaste() {
        return indiceDesgaste;
    }

    public int getAcoplado() {   // NUEVO
        return acoplado;   // NUEVO
    }

    /** Para el conteo por tipo: cada subclase dice cómo se llama. */
    public String getTipo() {   // NUEVO
        return "SIN_ACOPLADO";   // NUEVO
    }
}
