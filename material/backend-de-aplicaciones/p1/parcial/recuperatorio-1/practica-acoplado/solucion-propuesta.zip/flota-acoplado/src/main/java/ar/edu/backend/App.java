package ar.edu.backend;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;   // NUEVO

public class App {
    public static void main(String[] args) throws IOException {
        // ANTES: Path archivo = args.length == 0 ? Path.of("datos", "datos.csv") : Path.of(args[0]);
        Path archivo = args.length == 0 ? Path.of("datos", "datos-parcial.csv") : Path.of(args[0]);   // MOD
        ResultadoParseo resultado = new ParserVehiculos().parsear(archivo);
        Flota flota = new Flota(resultado.getVehiculos());
        Map<String, Long> conteo = flota.contarPorTipo();   // NUEVO

        System.out.println(resultado.getResumenErrores());
        System.out.println("Objetos: " + resultado.getVehiculos().size());   // NUEVO
        System.out.println("SIN_ACOPLADO: " + conteo.getOrDefault("SIN_ACOPLADO", 0L)   // NUEVO
                + " | CON_ACOPLADO: " + conteo.getOrDefault("CON_ACOPLADO", 0L));   // NUEVO
        System.out.println(flota.panorama());
    }
}
