package ar.edu.backend;

/** Vehículo con acoplado mayor a 0: costo + 40 USD por cada unidad de acoplado; la velocidad ≤ 90. */
public class VehiculoConAcoplado extends VehiculoRuta {
    public VehiculoConAcoplado(
            String patente,
            String zona,
            int velocidadPromedio,
            int cargaToneladas,
            String estado,
            int indiceDesgaste,
            int acoplado) {
        super(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, acoplado);
        if (velocidadPromedio > 90) {
            throw new IllegalArgumentException("La velocidad no cumple el tope de VehiculoConAcoplado");
        }
    }

    @Override
    public int getCostoDesgasteOperativo() {
        int costo = super.getCostoDesgasteOperativo();
        costo = costo + 40 * getAcoplado();
        return costo;
    }

    @Override
    public String getTipo() {
        return "CON_ACOPLADO";
    }
}
