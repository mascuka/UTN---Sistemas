package ar.edu.backend;

import java.io.IOException;
import java.nio.file.Path;
// import java.util.Map;   // si guardás un conteo en una variable: Map<String, Long> conteo = flota.contarPorEstado();

// ════════════════════════════════════════════════════════════════════════════════════════════
// EL MAIN: «Hacer que el main use por defecto el archivo del parcial y muestre resumen, cantidad de
// objetos, cantidades EN_RUTA/DEMORADO, total y totales por zona. Seguir delegando cálculos.»
// «Seguir delegando» = acá NO hay for, stream ni cuentas: solo se llama a métodos y se imprime.
// ════════════════════════════════════════════════════════════════════════════════════════════

public class App {
    public static void main(String[] args) throws IOException {
        // El archivo del parcial por defecto (copiá datos-parcial.csv a la carpeta datos/):
        //        Path archivo = args.length == 0 ? Path.of("datos", "datos-parcial.csv") : Path.of(args[0]);
        Path archivo = args.length == 0 ? Path.of("datos", "datos.csv") : Path.of(args[0]);
        ResultadoParseo resultado = new ParserVehiculos().parsear(archivo);
        Flota flota = new Flota(resultado.getVehiculos());

        System.out.println(resultado.getResumenErrores());
        // Lo que suelen pedir, en este orden (con los métodos de las plantillas de Flota):
        //        System.out.println("Objetos: " + resultado.getVehiculos().size());
        //        Map<String, Long> conteo = flota.contarPorEstado();
        //        System.out.println("EN_RUTA: " + conteo.getOrDefault("EN_RUTA", 0L) + " | DEMORADO: " + conteo.getOrDefault("DEMORADO", 0L));
        //        System.out.println("Costo de los DEMORADO: " + flota.sumarCostoDesgasteOperativo(v -> "DEMORADO".equals(v.getEstado())));
        //        System.out.println("Mayor costo: " + flota.getMayorCosto().map(VehiculoRuta::getPatente).orElse("-"));
        // getOrDefault(..., 0L): si no hay ninguno imprime 0 («conteos cero»). 0L porque counting() da Long.
        System.out.println(flota.panorama());
    }
}
