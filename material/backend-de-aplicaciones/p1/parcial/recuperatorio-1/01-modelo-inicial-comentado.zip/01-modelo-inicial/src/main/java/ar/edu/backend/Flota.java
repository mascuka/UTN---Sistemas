package ar.edu.backend;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
// ════════════════════════════════════════════════════════════════════════════════════════════
// IMPORTS QUE PUEDEN FALTAR si descomentás algo de abajo (sacales el «// » a los que uses).
// Si te olvidás uno, el error es «cannot find symbol» con el nombre de la clase (TreeMap, Collectors…).
// import java.util.Comparator;          // max / min / sorted: Comparator.comparingInt(...)
// import java.util.Optional;            // devolver «el de mayor…» o «buscar…»: puede no haber ninguno
// import java.util.TreeMap;             // un Map ORDENADO por clave (conteos por estado, por zona…)
// import java.util.stream.Collectors;   // groupingBy, counting, summingInt, averagingInt, toList
// ════════════════════════════════════════════════════════════════════════════════════════════

public final class Flota {
    private final List<VehiculoRuta> vehiculos;

    public Flota(List<VehiculoRuta> vehiculos) {
        if (vehiculos == null) {
            throw new IllegalArgumentException("La lista de vehículos no puede ser nula");
        }
        this.vehiculos = Collections.unmodifiableList(new ArrayList<>(vehiculos));
    }

    // Ya viene hecho: suma el costo de los que cumplen el filtro. REUSALO para «el costo total de los DEMORADO»,
    // «de la zona NORTE», etc. (ver la plantilla 4). El enunciado suele decir «reutilizando el filtro existente».
    public int sumarCostoDesgasteOperativo(Predicate<VehiculoRuta> filtro) {
        if (filtro == null) {
            throw new IllegalArgumentException("El filtro no puede ser nulo");
        }
        return vehiculos.stream()
                .filter(filtro)
                .mapToInt(VehiculoRuta::getCostoDesgasteOperativo)
                .sum();
    }

    public int getCostoTotalDesgasteOperativo() {
        return sumarCostoDesgasteOperativo(vehiculo -> true);
    }

    // Ya viene hecho con un for y merge: es un «agrupar sumando». La versión con Streams está en la plantilla 5.
    public Map<String, Integer> getCostoPorZona() {
        Map<String, Integer> costos = new LinkedHashMap<>();
        for (VehiculoRuta vehiculo : vehiculos) {
            costos.merge(vehiculo.getZona(), vehiculo.getCostoDesgasteOperativo(), Integer::sum);
        }
        return Collections.unmodifiableMap(costos);
    }

    // Ya viene hecho: contar con una condición (filter + count). Devuelve long, no int.
    public long contarConIndiceDesgasteMenorA(int limite) {
        return vehiculos.stream()
                .filter(vehiculo -> vehiculo.getIndiceDesgaste() < limite)
                .count();
    }

    // ════════════════════════════════════════════════════════════════════════════════════════
    // CHULETA DEL COLECTOR: lo que te pueden pedir en Flota. Todo está comentado: descomentá el
    // método que necesites (seleccionalo y Ctrl + /), agregá los imports que dice y llamalo desde el main.
    // El enunciado no te da el nombre del método: «Puede elegir el nombre y representación de esa
    // operación». Los nombres de acá son una sugerencia.
    //
    // Tipos que devuelve cada cosa (el error más común):
    //   counting() → Long (Map<String, Long>, y en el main 0L) · summingInt → Integer · averagingInt → Double
    //   count() → long · sum() de mapToInt → int · average() → OptionalDouble (usá .orElse(0))
    //   max/min → Optional (la flota puede estar vacía) · .toList() → lista que no se puede modificar
    // «Para una colección vacía debe dar un resultado vacío o conteos cero»: groupingBy ya da {} vacío.
    // ════════════════════════════════════════════════════════════════════════════════════════

    // ── 1) CONTEO POR ESTADO (o por zona, o por la columna nueva) ─────────────────────────────
    // Pide: «Incorporar en el colector un conteo por estado, que indique la cantidad de vehículos
    // que se encuentran en cada estado procesado». Devuelve, por ejemplo: {DEMORADO=12, EN_RUTA=20}.
    // Imports: java.util.TreeMap y java.util.stream.Collectors
    //    public Map<String, Long> contarPorEstado() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getEstado, TreeMap::new, Collectors.counting()));
    //    }
    // Por zona: VehiculoRuta::getZona · Por la columna nueva: VehiculoRuta::getTipoCarga (con su getter).
    // Sin TreeMap (sin orden): Collectors.groupingBy(VehiculoRuta::getEstado, Collectors.counting())
    // Main: Map<String, Long> conteo = flota.contarPorEstado();   (import java.util.Map en App)
    // Main: System.out.println("EN_RUTA: " + conteo.getOrDefault("EN_RUTA", 0L) + " | DEMORADO: " + conteo.getOrDefault("DEMORADO", 0L));
    // (getOrDefault con 0L: si no hay ninguno imprime 0, y 0L porque counting() da Long)

    // ── 1b) EL MISMO CONTEO CON UN FOR, con las claves en cero aunque no haya ninguno ──────────
    // Sirve si piden «conteos cero». Imports: java.util.TreeMap
    //    public Map<String, Long> contarPorEstadoConCeros() {
    //        Map<String, Long> conteo = new TreeMap<>();
    //        conteo.put("DEMORADO", 0L);
    //        conteo.put("EN_RUTA", 0L);
    //        for (VehiculoRuta vehiculo : vehiculos) {
    //            conteo.merge(vehiculo.getEstado(), 1L, Long::sum);
    //        }
    //        return conteo;
    //    }

    // ── 1c) CONTEO POR TIPO (común / subclase: GENERAL / REFRIGERADA, SIN_SEGURO / ASEGURADO…) ──
    // Pide: «cantidades NORMAL/PRIORITARIO» cuando cada tipo es una subclase. ¡Sin instanceof!
    // Agregá en VehiculoRuta: public String getTipo() { return "GENERAL"; }  y en la subclase un
    // @Override que devuelva "REFRIGERADA" (ver VehiculoRuta.java). Imports: TreeMap y Collectors
    //    public Map<String, Long> contarPorTipo() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getTipo, TreeMap::new, Collectors.counting()));
    //    }

    // ── 2) CONTAR LOS QUE CUMPLEN ALGO (un solo número) ───────────────────────────────────────
    // Pide: «la cantidad de vehículos DEMORADO», «cuántos superan…». Sin imports nuevos.
    //    public long contarEnEstado(String estado) {
    //        return vehiculos.stream()
    //                .filter(vehiculo -> vehiculo.getEstado().equals(estado))
    //                .count();
    //    }

    // ── 3) CONTAR ENTRE DOS VALORES (inclusive) ──────────────────────────────────────────────
    // Pide: «la cantidad de vehículos cuyo índice de desgaste está entre dos valores, inclusive».
    //    public long contarConIndiceEntre(int minimo, int maximo) {
    //        return vehiculos.stream()
    //                .filter(vehiculo -> vehiculo.getIndiceDesgaste() >= minimo && vehiculo.getIndiceDesgaste() <= maximo)
    //                .count();
    //    }

    // ── 4) COSTO TOTAL DE UN GRUPO, REUSANDO EL FILTRO (Predicate) ───────────────────────────
    // Pide: «el costo total de los vehículos DEMORADO, reutilizando la operación de suma con filtro».
    // Sin imports nuevos: el filtro es una lambda que recibe un vehículo y devuelve true/false.
    //    public int getCostoDemorados() {
    //        return sumarCostoDesgasteOperativo(vehiculo -> "DEMORADO".equals(vehiculo.getEstado()));
    //    }
    // Otros filtros: vehiculo -> vehiculo.getZona().equals("NORTE") · vehiculo -> vehiculo.getIndiceDesgaste() >= 60
    // Main (también vale llamarlo directo): flota.sumarCostoDesgasteOperativo(v -> "DEMORADO".equals(v.getEstado()))

    // ── 5) AGRUPAR SUMANDO (total por zona de otro dato) ─────────────────────────────────────
    // Pide: «el total de carga / de kilómetros por zona». Imports: TreeMap y Collectors
    //    public Map<String, Integer> getCargaPorZona() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getZona, TreeMap::new,
    //                        Collectors.summingInt(VehiculoRuta::getCargaToneladas)));
    //    }
    // Con la columna nueva: Collectors.summingInt(VehiculoRuta::getKilometros)

    // ── 6) PROMEDIO (de todos, o por zona) ───────────────────────────────────────────────────
    // Pide: «la velocidad promedio de los vehículos de cada zona». Imports: TreeMap y Collectors
    //    public double getVelocidadPromedio() {
    //        return vehiculos.stream()
    //                .mapToInt(VehiculoRuta::getVelocidadPromedio)
    //                .average()
    //                .orElse(0);
    //    }
    //    public Map<String, Double> getVelocidadPromedioPorZona() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getZona, TreeMap::new,
    //                        Collectors.averagingInt(VehiculoRuta::getVelocidadPromedio)));
    //    }

    // ── 7) EL MAYOR / EL MENOR (máximo y mínimo) ─────────────────────────────────────────────
    // Pide: «una operación que devuelva el vehículo con mayor costo… para una colección vacía debe
    // dar un resultado vacío». Optional = puede no haber. Imports: Comparator y Optional
    //    public Optional<VehiculoRuta> getMayorCosto() {
    //        return vehiculos.stream()
    //                .max(Comparator.comparingInt(VehiculoRuta::getCostoDesgasteOperativo));
    //    }
    // El menor: .min(...) · Por otro dato: Comparator.comparingInt(VehiculoRuta::getIndiceDesgaste)
    // Main: System.out.println("Mayor costo: " + flota.getMayorCosto().map(VehiculoRuta::getPatente).orElse("-"));

    // ── 8) ORDENAR (devuelve una lista) ──────────────────────────────────────────────────────
    // Pide: «los vehículos ordenados por costo, de mayor a menor». Imports: Comparator
    //    public List<VehiculoRuta> ordenadosPorCosto() {
    //        return vehiculos.stream()
    //                .sorted(Comparator.comparingInt(VehiculoRuta::getCostoDesgasteOperativo).reversed())
    //                .toList();
    //    }
    // De menor a mayor: sin .reversed() · Por texto: Comparator.comparing(VehiculoRuta::getPatente)
    // (.toList() es de Java 16+; con Java más viejo: .collect(Collectors.toList()))

    // ── 9) FILTRAR (los que cumplen algo, en una lista) ──────────────────────────────────────
    // Pide: «los vehículos con costo mayor a un valor», «los de la zona X». Sin imports nuevos.
    //    public List<VehiculoRuta> conCostoMayorA(int umbral) {
    //        return vehiculos.stream()
    //                .filter(vehiculo -> vehiculo.getCostoDesgasteOperativo() > umbral)
    //                .toList();
    //    }

    // ── 10) MAPEAR (transformar cada vehículo en otra cosa: la patente, la zona…) ─────────────
    // Pide: «las patentes de la flota», «las zonas sin repetir». Sin imports nuevos.
    //    public List<String> getPatentes() {
    //        return vehiculos.stream()
    //                .map(VehiculoRuta::getPatente)
    //                .distinct()
    //                .sorted()
    //                .toList();
    //    }
    // map(...) cambia el vehículo por lo que devuelve el getter · distinct() saca repetidos · sorted() ordena

    // ── 11) BUSCAR (por patente: no es única, así que puede haber varios viajes) ──────────────
    // Pide: «buscar los viajes de una patente». Imports: Optional (solo para el segundo)
    //    public List<VehiculoRuta> buscarPorPatente(String patente) {
    //        return vehiculos.stream()
    //                .filter(vehiculo -> vehiculo.getPatente().equals(patente))
    //                .toList();
    //    }
    //    public Optional<VehiculoRuta> primerViajeDe(String patente) {
    //        return vehiculos.stream()
    //                .filter(vehiculo -> vehiculo.getPatente().equals(patente))
    //                .findFirst();
    //    }

    // ── 12) AGRUPAR EN LISTAS (cada zona con sus vehículos) ──────────────────────────────────
    // Pide: «los vehículos de cada zona». Imports: TreeMap y Collectors
    //    public Map<String, List<VehiculoRuta>> agruparPorZona() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getZona, TreeMap::new, Collectors.toList()));
    //    }

    // ── 13) VIAJES POR PATENTE Y PATENTES CON MÁS DE UN VIAJE ────────────────────────────────
    // Pide: «No se exige unicidad de patentes: la cantidad de viajes de cada patente y las patentes
    // que registran más de un viaje». Imports: TreeMap y Collectors
    //    public Map<String, Long> getViajesPorPatente() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getPatente, TreeMap::new, Collectors.counting()));
    //    }
    //    public List<String> getPatentesConMasDeUnViaje() {
    //        return getViajesPorPatente().entrySet().stream()
    //                .filter(entrada -> entrada.getValue() > 1)
    //                .map(Map.Entry::getKey)
    //                .toList();
    //    }

    // ── 14) CONTEO DE DOS NIVELES (por zona y, adentro, por estado) ──────────────────────────
    // Devuelve: {CENTRO={DEMORADO=3, EN_RUTA=8}, NORTE={…}}. Imports: TreeMap y Collectors
    //    public Map<String, Map<String, Long>> contarPorZonaYEstado() {
    //        return vehiculos.stream()
    //                .collect(Collectors.groupingBy(VehiculoRuta::getZona, TreeMap::new,
    //                        Collectors.groupingBy(VehiculoRuta::getEstado, TreeMap::new, Collectors.counting())));
    //    }

    // ── 15) ¿HAY ALGUNO? / ¿TODOS CUMPLEN? / PORCENTAJE ───────────────────────────────────────
    //    public boolean hayDemorados() {
    //        return vehiculos.stream().anyMatch(vehiculo -> "DEMORADO".equals(vehiculo.getEstado()));
    //    }
    //    public double porcentajeDemorados() {
    //        if (vehiculos.isEmpty()) {
    //            return 0;
    //        }
    //        long demorados = vehiculos.stream().filter(v -> "DEMORADO".equals(v.getEstado())).count();
    //        return 100.0 * demorados / vehiculos.size();
    //    }
    // Todos: allMatch(...) · Ninguno: noneMatch(...) · 100.0 (con decimales) para que no sea división entera

    public List<VehiculoRuta> getVehiculos() {
        return vehiculos;
    }

    // Si piden que el panorama MUESTRE ALGO MÁS (por ejemplo «panorama() debe incluir esa cantidad»),
    // agregá otra línea igual a la del for, antes del return:
    //   panorama.append(System.lineSeparator()).append("Índice menor a 55: ").append(contarConIndiceDesgasteMenorA(55));
    public String panorama() {
        StringBuilder panorama = new StringBuilder()
                .append("Costo total por desgaste operativo: ")
                .append(getCostoTotalDesgasteOperativo());
        for (Map.Entry<String, Integer> entrada : getCostoPorZona().entrySet()) {
            panorama.append(System.lineSeparator())
                    .append(entrada.getKey()).append(": ").append(entrada.getValue());
        }
        return panorama.toString();
    }
}
