package ar.edu.backend;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
// import java.util.Set;   // si se descartan varios estados: Set.of("EN_DEPOSITO", "MANTENIMIENTO") (ver C)

public final class ParserVehiculos {
    private static final String ENCABEZADO = "patente,zona,velocidadPromedio,cargaToneladas,estado";
    // ── A) EL ENCABEZADO NUEVO («El nuevo encabezado es patente,…,estado,tipoCarga») ─────────────
    // Copialo EXACTO del enunciado (mayúsculas, sin espacios). Si viene separado por «;», con «;»:
    //    private static final String ENCABEZADO_NUEVO = ENCABEZADO + ",tipoCarga";
    //    private static final String ENCABEZADO_NUEVO = "patente;zona;velocidadPromedio;cargaToneladas;estado;kilometros";
    // ── C) VARIOS ESTADOS QUE SE DESCARTAN (EN_DEPOSITO y MANTENIMIENTO) · import java.util.Set ──
    //    private static final Set<String> DESCARTADOS = Set.of("EN_DEPOSITO", "MANTENIMIENTO");

    public ResultadoParseo parsear(Path archivo) throws IOException {
        List<VehiculoRuta> vehiculos = new ArrayList<>();
        List<ErrorParseo> errores = new ArrayList<>();
        int filasLeidas = 0;
        int filasDescartadas = 0;

        try (BufferedReader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            String encabezado = lector.readLine();
            // ── B) DOS FORMATOS, UN SOLO LOOP («Integrar la lectura de ambas versiones del CSV sin
            // duplicar el proceso de carga»): el encabezado decide el separador y el ancho. Cambiá el if de
            // abajo por esto, y en el while usá «separador» y «columnas» en vez de "," y 5:
            //            String separador;
            //            int columnas;
            //            if (ENCABEZADO.equals(encabezado)) {
            //                separador = ",";
            //                columnas = 5;
            //            } else if (ENCABEZADO_NUEVO.equals(encabezado)) {
            //                separador = ",";
            //                columnas = 6;
            //            } else {
            //                throw new IllegalArgumentException("Encabezado CSV incorrecto");
            //            }
            // Si el nuevo viene con «;»: separador = ";" · con «|»: separador = "\\|" (split usa regex y | es especial)
            if (!ENCABEZADO.equals(encabezado)) {
                throw new IllegalArgumentException("Encabezado CSV incorrecto");
            }

            String linea;
            int numeroLinea = 1;
            while ((linea = lector.readLine()) != null) {
                numeroLinea++;
                filasLeidas++;
                // El -1 conserva los campos vacíos del final («a,b,,,» da 5 campos): no lo saques.
                // Con B:  String[] campos = linea.split(separador, -1);
                //         if (campos.length != columnas) { errores.add(new ErrorParseo(numeroLinea, "La fila debe tener exactamente " + columnas + " columnas")); continue; }
                // «Cada fila debe tener el ancho indicado por su encabezado; no aceptar filas de cinco campos
                // bajo un encabezado de seis, ni a la inversa» → justamente eso hace el if de arriba.
                // Si en cambio dice «bajo el encabezado nuevo se admiten filas de cinco campos y de seis»
                // (Recuperatorio 2): aceptá 5 o 6 con el encabezado nuevo, y desdeCampos decide por el ancho.
                String[] campos = linea.split(",", -1);
                if (campos.length != 5) {
                    errores.add(new ErrorParseo(numeroLinea, "La fila debe tener exactamente cinco columnas"));
                    continue;
                }

                // Primero el ancho, después el descarte, y recién después se valida (lo hace desdeCampos):
                // «verificar ancho y después descartar EN_DEPOSITO sin validar». No cambies ese orden.
                // Con C:  if (DESCARTADOS.contains(estado)) {
                String estado = campos[4].trim();
                if ("EN_DEPOSITO".equals(estado)) {
                    filasDescartadas++;
                    continue;
                }

                // El parser no sabe de subclases: desdeCampos decide qué clase crear (polimorfismo).
                try {
                    vehiculos.add(VehiculoRuta.desdeCampos(campos));
                } catch (IllegalArgumentException exception) {
                    errores.add(new ErrorParseo(numeroLinea, exception.getMessage()));
                }
            }
        }

        return new ResultadoParseo(vehiculos, errores, filasLeidas, filasDescartadas);
    }
}
