package ar.edu.backend;

// import java.util.Set;   // si validás valores fijos con Set.of("GENERAL", "REFRIGERADA") (ver plantilla C)

// ════════════════════════════════════════════════════════════════════════════════════════════
// ¿TE PIDEN UNA SUBCLASE? (un tipo que cuesta o se valida distinto: REFRIGERADA, DEMORADO más caro,
// el formato nuevo con su columna…) → sacale el «final» a la clase:  public class VehiculoRuta {
// Si no, el error es «cannot inherit from final ar.edu.backend.VehiculoRuta».
// La plantilla completa de una subclase está al final de este archivo.
// ════════════════════════════════════════════════════════════════════════════════════════════
public final class VehiculoRuta {
    private final String patente;
    private final String zona;
    private final int velocidadPromedio;
    private final int cargaToneladas;
    private final String estado;
    private final int indiceDesgaste;
    // ── A) COLUMNA NUEVA QUE TIENEN TODOS (por ejemplo kilometros, que suma al costo de todos) ──
    //    private final int kilometros;
    // Y un getter abajo: public int getKilometros() { return kilometros; }

    // Este constructor lo usan los tests: NO le cambies los parámetros. Si agregás la columna nueva acá,
    // hacé que delegue en uno nuevo con el valor del formato viejo (el de las filas de 5 campos):
    //    public VehiculoRuta(String patente, String zona, int velocidadPromedio, int cargaToneladas,
    //            String estado, int indiceDesgaste) {
    //        this(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, 0);
    //    }
    // y el constructor nuevo recibe además «int kilometros», lo valida y lo guarda:
    //        if (kilometros < 0 || kilometros > 5000) {
    //            throw new IllegalArgumentException("Los kilómetros deben estar entre 0 y 5000");
    //        }
    //        this.kilometros = kilometros;
    public VehiculoRuta(
            String patente,
            String zona,
            int velocidadPromedio,
            int cargaToneladas,
            String estado,
            int indiceDesgaste) {
        this.patente = validarTexto(patente, "La patente no puede estar vacía");
        this.zona = validarTexto(zona, "La zona no puede estar vacía");
        if (velocidadPromedio <= 0 || velocidadPromedio >= 130) {
            throw new IllegalArgumentException("La velocidad promedio debe ser mayor a 0 y menor a 130");
        }
        if (cargaToneladas > 45) {
            throw new IllegalArgumentException("La carga no puede superar las 45 toneladas");
        }
        // ESTADO NUEVO VÁLIDO (por ejemplo EN_TALLER): sumalo acá. Con muchos: Set.of("EN_RUTA", "DEMORADO", "EN_TALLER").contains(estado)
        // (Ojo: un estado que se DESCARTA, como MANTENIMIENTO, no va acá: va en ParserVehiculos)
        if (!"EN_RUTA".equals(estado) && !"DEMORADO".equals(estado)) {
            throw new IllegalArgumentException("Estado de vehículo inválido: " + estado);
        }
        // El test VehiculoRutaTest exige que este constructor rechace un índice que no coincide con la
        // fórmula (por ejemplo 41 en vez de 40): no saques esta comprobación.
        int indiceCalculado = calcularIndiceDesgaste(velocidadPromedio, cargaToneladas);
        if (indiceDesgaste < 1 || indiceDesgaste > 90 || indiceDesgaste != indiceCalculado) {
            throw new IllegalArgumentException("El índice de desgaste debe coincidir con el cálculo y estar entre 1 y 90");
        }
        this.velocidadPromedio = velocidadPromedio;
        this.cargaToneladas = cargaToneladas;
        this.estado = estado;
        this.indiceDesgaste = indiceDesgaste;
    }

    // ── B) OTRA FÓRMULA DEL ÍNDICE PARA EL FORMATO NUEVO (como el Recuperatorio 2, «fórmula ponderada») ──
    // La subclase calcula su índice con otra fórmula, pero el constructor de arriba lo compara con la
    // original. Solución: un constructor protegido que recibe el índice ya calculado por la subclase,
    // y el de arriba delega en él con la fórmula original (así el test sigue pasando):
    //    public VehiculoRuta(String patente, String zona, int velocidadPromedio, int cargaToneladas,
    //            String estado, int indiceDesgaste) {
    //        this(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste,
    //                calcularIndiceDesgaste(velocidadPromedio, cargaToneladas));
    //    }
    //    protected VehiculoRuta(String patente, String zona, int velocidadPromedio, int cargaToneladas,
    //            String estado, int indiceDesgaste, int indiceCalculado) {
    //        … las mismas validaciones de arriba, pero sin la línea «int indiceCalculado = …» …
    //    }
    // En la subclase: super(..., indiceDesgaste, calcularIndiceConPendiente(velocidadPromedio, cargaToneladas, pendiente));
    // con  static int calcularIndiceConPendiente(int v, int c, int p) { return (int) (v * 0.50 + c * 0.30 + p * 0.20); }

    public static VehiculoRuta desdeCampos(String[] campos) {
        // ── C) 5 O 6 CAMPOS (la columna nueva viene solo en el formato nuevo) ──────────────────
        // Cambiá esta validación por:
        //        if (campos == null || (campos.length != 5 && campos.length != 6)) {
        //            throw new IllegalArgumentException("La fila debe tener cinco o seis columnas");
        //        }
        if (campos == null || campos.length != 5) {
            throw new IllegalArgumentException("La fila debe tener exactamente cinco columnas");
        }

        String patente = limpiar(campos[0]);
        String zona = limpiar(campos[1]);
        int velocidadPromedio = convertirEntero(campos[2], "velocidad promedio");
        int cargaToneladas = convertirEntero(campos[3], "carga en toneladas");
        String estado = limpiar(campos[4]);
        int indiceDesgaste = calcularIndiceDesgaste(velocidadPromedio, cargaToneladas);
        // Leer el sexto campo (con 5 campos, el valor del formato viejo que diga el enunciado):
        //        int kilometros = campos.length == 6 ? convertirEntero(campos[5], "kilometros") : 0;
        //        String tipoCarga = campos.length == 6 ? limpiar(campos[5]) : "GENERAL";
        // Texto con valores fijos («admite exactamente GENERAL o REFRIGERADA… vacío o desconocido hace inválida la fila»):
        //        if (!"GENERAL".equals(tipoCarga) && !"REFRIGERADA".equals(tipoCarga)) {
        //            throw new IllegalArgumentException("Tipo de carga inválido: " + tipoCarga);
        //        }
        //        (o con import java.util.Set:  if (!Set.of("GENERAL", "REFRIGERADA").contains(tipoCarga)) { … })
        // Entero con rango («mayores iguales a 2000 pero menores a 3800»):
        //        if (facturacion < 2000 || facturacion >= 3800) {
        //            throw new IllegalArgumentException("La facturación debe ser de 2000 a menos de 3800");
        //        }
        //
        // ── D) ACÁ SE DECIDE QUÉ CLASE CREAR (polimorfismo: el parser no sabe de subclases) ─────
        // Por el valor de la columna nueva:
        //        if ("REFRIGERADA".equals(tipoCarga)) {
        //            return new VehiculoRefrigerado(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste);
        //        }
        // Por el estado («un vehículo DEMORADO cuesta un 15 % más»):
        //        if ("DEMORADO".equals(estado)) {
        //            return new VehiculoDemorado(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste);
        //        }
        // Por el ancho de la fila («crear un VehiculoRuta para cinco campos o un VehiculoConX para seis»):
        //        if (campos.length == 6) {
        //            return new VehiculoConFacturacion(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste, facturacion);
        //        }

        return new VehiculoRuta(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste);
    }

    // Si una subclase necesita esta fórmula, cambiá «private» por «protected» (o dejala acá y usala desde desdeCampos).
    private static int calcularIndiceDesgaste(int velocidadPromedio, int cargaToneladas) {
        return (int) (velocidadPromedio * 0.6 + cargaToneladas * 0.4);
    }

    private static int convertirEntero(String valor, String nombreCampo) {
        try {
            return Integer.parseInt(limpiar(valor));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("El campo " + nombreCampo + " debe ser un entero", exception);
        }
    }

    private static String validarTexto(String valor, String mensaje) {
        String texto = limpiar(valor);
        if (texto.isEmpty()) {
            throw new IllegalArgumentException(mensaje);
        }
        return texto;
    }

    private static String limpiar(String valor) {
        if (valor == null) {
            throw new IllegalArgumentException("Los campos no pueden ser nulos");
        }
        return valor.trim();
    }

    // ── E) CAMBIOS EN EL COSTO ────────────────────────────────────────────────────────────────
    // Para TODOS (se cambia acá): «suma 1 USD por cada 10 km» →  return 2000 * indiceDesgaste / 100 + kilometros / 10;
    // Para ALGUNOS (subclase con @Override, ver la plantilla de abajo): «REFRIGERADA cuesta 300 USD adicionales».
    // La COLUMNA REEMPLAZA a los 2000 (como el Parcial 3K1, «que tome el valor ingresado»): un gancho
    // que la subclase redefine, así el cálculo queda en un solo lugar:
    //    public int getCostoDesgasteOperativo() {
    //        return getFacturacionPorFlete() * indiceDesgaste / 100;
    //    }
    //    protected int getFacturacionPorFlete() {
    //        return 2000;
    //    }
    // y en VehiculoConFacturacion:  @Override protected int getFacturacionPorFlete() { return facturacion; }
    // Siempre en enteros y en ese orden: 2000 * indice / 100 (si dividís primero, perdés decimales).
    // Porcentajes en enteros: 15 % más → costo * 115 / 100 · 10 % menos → costo * 90 / 100
    public int getCostoDesgasteOperativo() {
        return 2000 * indiceDesgaste / 100;
    }

    // ── F) EL TIPO, PARA CONTAR POR TIPO SIN instanceof (ver Flota, plantilla 1c) ──────────────
    //    public String getTipo() {
    //        return "GENERAL";
    //    }
    // y en la subclase:  @Override public String getTipo() { return "REFRIGERADA"; }

    public String getPatente() {
        return patente;
    }

    public String getZona() {
        return zona;
    }

    public int getVelocidadPromedio() {
        return velocidadPromedio;
    }

    public int getCargaToneladas() {
        return cargaToneladas;
    }

    public String getEstado() {
        return estado;
    }

    public int getIndiceDesgaste() {
        return indiceDesgaste;
    }
}

// ════════════════════════════════════════════════════════════════════════════════════════════
// PLANTILLA DE SUBCLASE: creá un archivo nuevo (por ejemplo VehiculoRefrigerado.java) con esto.
// Pide: «REFRIGERADA respeta las validaciones anteriores, admite como máximo 30 toneladas inclusive
// y cuesta 300 USD adicionales sobre el costo normal». Acordate de sacarle el «final» a VehiculoRuta.
//
// package ar.edu.backend;
//
// public class VehiculoRefrigerado extends VehiculoRuta {
//     public VehiculoRefrigerado(String patente, String zona, int velocidadPromedio, int cargaToneladas,
//             String estado, int indiceDesgaste) {
//         super(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste);  // 1.º las validaciones de siempre
//         if (cargaToneladas > 30) {                                                         // 2.º sus topes propios
//             throw new IllegalArgumentException("Una carga refrigerada no puede superar las 30 toneladas");
//         }
//     }
//
//     @Override
//     public int getCostoDesgasteOperativo() {
//         return super.getCostoDesgasteOperativo() + 300;      // 15 % más: super.getCostoDesgasteOperativo() * 115 / 100
//     }
//
//     @Override
//     public String getTipo() {                                // solo si contás por tipo (plantilla F)
//         return "REFRIGERADA";
//     }
// }
//
// Con una columna propia (formato nuevo, «VehiculoConFacturacion»): agregá el atributo, recibilo en el
// constructor, validalo después de super(...), con su getter, y el @Override del gancho de la plantilla E.
// ════════════════════════════════════════════════════════════════════════════════════════════
