# Chuleta del recuperatorio · Flota Logística

Las plantillas están **comentadas dentro de cada clase**: seleccioná las líneas y `Ctrl + /` para descomentarlas.
El proyecto compila y pasa los tests tal cual está. Todo lo comentado se probó descomentándolo.

## Si el enunciado dice… → qué tocar

| Frase del enunciado | Dónde | Plantilla |
|---|---|---|
| «El nuevo encabezado es …,tipoCarga» | `ParserVehiculos` | A: `ENCABEZADO_NUEVO` |
| «Integrar la lectura de ambas versiones del CSV sin duplicar el proceso de carga» | `ParserVehiculos` | B: separador y columnas según el encabezado |
| «no aceptar filas de cinco campos bajo un encabezado de seis, ni a la inversa» | `ParserVehiculos` | B: `campos.length != columnas` |
| «se admiten filas de cinco campos y de seis» (bajo el encabezado nuevo) | `ParserVehiculos` + `desdeCampos` | B (5 o 6) + D (por el ancho) |
| «descartar MANTENIMIENTO sin validar» | `ParserVehiculos` | C: `Set.of(...)` |
| «Conservar también el formato original: todos sus … son X» | `VehiculoRuta.desdeCampos` | C: `campos.length == 6 ? … : X` |
| «admite exactamente GENERAL o REFRIGERADA» | `VehiculoRuta.desdeCampos` | C: valores fijos |
| «valores mayores iguales a 2000 pero menores a 3800» | `VehiculoRuta` (o la subclase) | C: rango (`< 2000 \|\| >= 3800`) |
| «REFRIGERADA … cuesta 300 USD adicionales / como máximo 30 t» | subclase nueva | plantilla de subclase (al final de `VehiculoRuta`) |
| «un DEMORADO cuesta un 15 % más» | subclase nueva + `desdeCampos` | D (por estado) + `super…() * 115 / 100` |
| «que tome el valor ingresado» (la columna reemplaza a los 2000) | `VehiculoRuta` + subclase | E: gancho `getFacturacionPorFlete()` |
| «el costo de todos suma 1 USD cada 10 km» | `VehiculoRuta.getCostoDesgasteOperativo` | E: para todos |
| «fórmula ponderada para el formato nuevo» | `VehiculoRuta` + subclase | B de `VehiculoRuta`: constructor `protected` |
| «Incorporar en el colector un conteo por estado» | `Flota` | 1 (o 1b con ceros) |
| «cantidades NORMAL/PRIORITARIO» (cada tipo es una subclase) | `Flota` + `VehiculoRuta` | 1c + F (`getTipo()`, sin `instanceof`) |
| «el costo total de los DEMORADO, reutilizando el filtro» | `Flota` | 4 (`sumarCostoDesgasteOperativo`) |
| «total de … por zona» | `Flota` | 5 (`summingInt`) |
| «el promedio de …» | `Flota` | 6 |
| «el vehículo con mayor costo» | `Flota` | 7 (`Optional`) |
| «ordenados por …» | `Flota` | 8 |
| «los que superan …» | `Flota` | 9 |
| «las patentes …» (transformar) | `Flota` | 10 (`map`) |
| «buscar por patente» | `Flota` | 11 |
| «los vehículos de cada zona» | `Flota` | 12 |
| «patentes con más de un viaje» | `Flota` | 13 |
| «el main use por defecto el archivo del parcial y muestre …» | `App` | `datos-parcial.csv` + las líneas comentadas |
| «Seguir delegando cálculos» | `App` | sin `for`, `stream` ni cuentas en el main |

## Imports que pueden faltar

| Si usás… | Import |
|---|---|
| `TreeMap::new` (mapa ordenado) | `java.util.TreeMap` |
| `Collectors.groupingBy`, `counting`, `summingInt`, `averagingInt`, `toList` | `java.util.stream.Collectors` |
| `Comparator.comparingInt` (max, min, sorted) | `java.util.Comparator` |
| `Optional<VehiculoRuta>` | `java.util.Optional` |
| `Set.of(...)` | `java.util.Set` |
| `Map<String, Long>` en el main | `java.util.Map` |

## Tipos (el error más común)

- `counting()` → `Long`: `Map<String, Long>` y en el main `getOrDefault("EN_RUTA", 0L)`.
- `summingInt` → `Integer` · `averagingInt` → `Double` · `count()` → `long`.
- `average()` → `OptionalDouble`: `.orElse(0)` · `max` / `min` → `Optional`: `.map(...).orElse("-")`.
- Con la flota vacía: `groupingBy` da `{}` («resultado vacío»), `max` da `Optional.empty()`.

## Orden para no romper nada

1. Parser (dos encabezados) → 2. `VehiculoRuta` (columna, validaciones) → 3. subclase si cambia el cálculo para algunos → 4. `Flota` → 5. `App` → 6. `mvn test` y correr el main con `datos/datos-parcial.csv`.

- El constructor de 6 parámetros de `VehiculoRuta` lo usan los tests: no le cambies la firma (delegá con `this(...)`).
- Para heredar, sacale el `final` a `VehiculoRuta`.
- Precedencia: ancho → descarte → validaciones.
- Costos en enteros: `2000 * indice / 100` en ese orden; porcentajes como `* 115 / 100`.
