package ar.edu.backend;

/** Vehículo del formato nuevo (fila de seis campos, con pendientePromedio). */
public class VehiculoConPendiente extends VehiculoRuta {
    private final int pendientePromedio;

    public VehiculoConPendiente(
            String patente,
            String zona,
            int velocidadPromedio,
            int cargaToneladas,
            String estado,
            int indiceDesgaste,
            int pendientePromedio) {
        super(patente, zona, velocidadPromedio, cargaToneladas, estado, indiceDesgaste,
                calcularIndiceDesgaste(velocidadPromedio, cargaToneladas, pendientePromedio));
        if (pendientePromedio < 0 || pendientePromedio > 30) {
            throw new IllegalArgumentException("El campo pendientePromedio debe ser mayor o igual a 0 y menor o igual a 30");
        }
        this.pendientePromedio = pendientePromedio;
    }

    /** El índice de las filas nuevas: la fórmula ponderada, truncada a entero. */
    static int calcularIndiceDesgaste(int velocidadPromedio, int cargaToneladas, int pendientePromedio) {
        return (int) (velocidadPromedio * 0.50 + cargaToneladas * 0.30 + pendientePromedio * 0.20);
    }

    public int getPendientePromedio() {
        return pendientePromedio;
    }
}
