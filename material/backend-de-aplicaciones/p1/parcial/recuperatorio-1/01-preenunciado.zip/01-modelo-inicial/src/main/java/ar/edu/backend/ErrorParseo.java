package ar.edu.backend;

public final class ErrorParseo {
    private final int numeroLinea;
    private final String motivo;

    public ErrorParseo(int numeroLinea, String motivo) {
        if (numeroLinea < 1) {
            throw new IllegalArgumentException("El número de línea debe ser positivo");
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new IllegalArgumentException("El motivo no puede estar vacío");
        }
        this.numeroLinea = numeroLinea;
        this.motivo = motivo;
    }

    public int getNumeroLinea() {
        return numeroLinea;
    }

    public String getMotivo() {
        return motivo;
    }
}
