package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class VehiculoRutaTest {
    @Test
    void convierteCamposYCalculaIndiceYCosto() {
        VehiculoRuta vehiculo = VehiculoRuta.desdeCampos(
                new String[] {" trk-0012 ", " NORTE ", "76", "11", "EN_RUTA"});

        assertEquals("trk-0012", vehiculo.getPatente());
        assertEquals("NORTE", vehiculo.getZona());
        assertEquals(50, vehiculo.getIndiceDesgaste());
        assertEquals(1000, vehiculo.getCostoDesgasteOperativo());
    }

    @Test
    void rechazaFilasFueraDeLasInvariantes() {
        assertThrows(IllegalArgumentException.class, () -> VehiculoRuta.desdeCampos(
                new String[] {"trk-1", "NORTE", "0", "10", "EN_RUTA"}));
        assertThrows(IllegalArgumentException.class, () -> VehiculoRuta.desdeCampos(
                new String[] {"trk-1", "NORTE", "60", "46", "EN_RUTA"}));
        assertThrows(IllegalArgumentException.class, () -> VehiculoRuta.desdeCampos(
                new String[] {"trk-1", "NORTE", "60", "10", "PERDIDO"}));
        assertThrows(IllegalArgumentException.class, () -> new VehiculoRuta(
                "trk-1", "NORTE", 60, 10, "EN_RUTA", 41));
    }
}
