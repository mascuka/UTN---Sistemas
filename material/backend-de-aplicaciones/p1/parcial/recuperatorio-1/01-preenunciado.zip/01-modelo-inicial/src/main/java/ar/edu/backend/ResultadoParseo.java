package ar.edu.backend;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ResultadoParseo {
    private final List<VehiculoRuta> vehiculos;
    private final List<ErrorParseo> errores;
    private final int filasLeidas;
    private final int filasDescartadas;

    public ResultadoParseo(
            List<VehiculoRuta> vehiculos,
            List<ErrorParseo> errores,
            int filasLeidas,
            int filasDescartadas) {
        if (vehiculos == null || errores == null) {
            throw new IllegalArgumentException("Las listas no pueden ser nulas");
        }
        if (filasLeidas < 0 || filasDescartadas < 0 || filasDescartadas > filasLeidas
                || vehiculos.size() + errores.size() + filasDescartadas != filasLeidas) {
            throw new IllegalArgumentException("Los contadores no coinciden con las filas del resultado");
        }
        this.vehiculos = Collections.unmodifiableList(new ArrayList<>(vehiculos));
        this.errores = Collections.unmodifiableList(new ArrayList<>(errores));
        this.filasLeidas = filasLeidas;
        this.filasDescartadas = filasDescartadas;
    }

    public int getFilasLeidas() {
        return filasLeidas;
    }

    public int getFilasProcesadas() {
        return vehiculos.size();
    }

    public int getFilasDescartadas() {
        return filasDescartadas;
    }

    public int getFilasInvalidas() {
        return errores.size();
    }

    public List<VehiculoRuta> getVehiculos() {
        return vehiculos;
    }

    public List<ErrorParseo> getErrores() {
        return errores;
    }

    public String getResumenErrores() {
        StringBuilder resumen = new StringBuilder()
                .append("Filas leídas: ").append(filasLeidas).append(System.lineSeparator())
                .append("Procesadas: ").append(getFilasProcesadas()).append(System.lineSeparator())
                .append("Descartadas: ").append(filasDescartadas).append(System.lineSeparator())
                .append("Inválidas: ").append(getFilasInvalidas()).append(System.lineSeparator())
                .append("Vehículos con índice de desgaste menor a 55: ")
                .append(new Flota(vehiculos).contarConIndiceDesgasteMenorA(55));

        for (ErrorParseo error : errores) {
            resumen.append(System.lineSeparator())
                    .append("Línea ").append(error.getNumeroLinea()).append(": ").append(error.getMotivo());
        }
        return resumen.toString();
    }
}
