package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ParserVehiculosTest {
    @Test
    void procesaLosAgregadosDelArchivoDelEnunciado() throws IOException {
        ResultadoParseo resultado = new ParserVehiculos().parsear(Path.of("datos", "datos.csv"));
        Flota flota = new Flota(resultado.getVehiculos());

        assertEquals(60, resultado.getFilasLeidas());
        assertEquals(32, resultado.getFilasProcesadas());
        assertEquals(20, resultado.getFilasDescartadas());
        assertEquals(8, resultado.getFilasInvalidas());
        assertEquals(31840, flota.getCostoTotalDesgasteOperativo());
        assertEquals(11200, flota.getCostoPorZona().get("NORTE"));
        assertEquals(12440, flota.getCostoPorZona().get("CENTRO"));
        assertEquals(8200, flota.getCostoPorZona().get("SUR"));
        assertEquals(18, flota.contarConIndiceDesgasteMenorA(55));
    }

    @Test
    void registraLineasFisicasYDescartaDepositoAntesDeConvertir(@TempDir Path directorio)
            throws IOException {
        Path archivo = directorio.resolve("datos.csv");
        Files.writeString(
                archivo,
                "patente,zona,velocidadPromedio,cargaToneladas,estado\n"
                        + "\n"
                        + " , ,no-numero,,EN_DEPOSITO\n"
                        + "trk-1,NORTE,60,10,EN_RUTA\n"
                        + "trk-2,NORTE,60,10,PERDIDO\n",
                StandardCharsets.UTF_8);

        ResultadoParseo resultado = new ParserVehiculos().parsear(archivo);

        assertEquals(4, resultado.getFilasLeidas());
        assertEquals(1, resultado.getFilasProcesadas());
        assertEquals(1, resultado.getFilasDescartadas());
        assertEquals(2, resultado.getFilasInvalidas());
        assertEquals(2, resultado.getErrores().get(0).getNumeroLinea());
        assertEquals(5, resultado.getErrores().get(1).getNumeroLinea());
    }

    @Test
    void abortaConEncabezadoIncorrectoYPropagaErroresDeLectura(@TempDir Path directorio)
            throws IOException {
        Path archivo = directorio.resolve("mal.csv");
        Files.writeString(archivo, "otro,encabezado\n", StandardCharsets.UTF_8);

        assertThrows(IllegalArgumentException.class, () -> new ParserVehiculos().parsear(archivo));
        assertThrows(
                IOException.class,
                () -> new ParserVehiculos().parsear(directorio.resolve("inexistente.csv")));
    }
}
