# Decisiones

- Herencia simple: `ServidorConIngresos extends Servidor` guarda el sexto campo y redefine `ingresoPorHora()`; `costoRiesgoOperativo()` quedó en `Servidor` y usa ese método, así que `total()`, los filtros y los totales por región toman la regla nueva sin cambios.
- `Servidor.desdeCampos` acepta 5 o 6 campos y decide qué objeto crear; el parser detecta el formato por el encabezado y exige ese mismo ancho en cada fila (una sola carga para los dos formatos).
- `Servidor` ahora guarda el estado para poder contar por estado en `Cloud.conteoPorEstado()` (TreeMap, vacío si no hay servidores). El constructor de 3 parámetros se mantiene por compatibilidad.
- El main usa `datos/datos-parcial.csv` por defecto. Nada pendiente: pasan los tests viejos y los nuevos.
