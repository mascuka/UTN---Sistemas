package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

public class EvolucionTest {
    @TempDir
    Path dir;

    private ResultadoParseo leer(String filas) throws IOException {
        Path p = dir.resolve("nuevo.csv");
        Files.writeString(p, "id,region,porcentajeCPU,usoMemoria,estado,ingresos\n" + filas);
        return new ParserServidores().leer(p);
    }

    @Test
    void nuevasTarifasYColector() throws IOException {
        var r = leer(
                "srv-0054,SA-EAST-1,59,59,ALERTA,  1110\nsrv-0027,SA-EAST-1,98,17934,CRITICO,   1679\nsrv-0123,US-WEST-2,56,47,ALERTA,   1253\n");
        assertEquals(2, r.getProcesadas());
        assertEquals(1, r.getInvalidas());
        assertEquals(654, r.getServidores().get(0).costoRiesgoOperativo());
        Cloud c = new Cloud(r.getServidores());
        assertEquals(1318, c.total());
        assertEquals(Map.of("US-WEST-2", 664, "SA-EAST-1", 654), c.totalesPorRegion());
        assertEquals(2, c.filtrar(s -> s.getIndiceCarga() < 80).size());
    }

    @Test
    void formatoAnteriorSigueVigente() throws IOException {
        Path p = dir.resolve("viejo.csv");
        Files.writeString(p,
                "id,region,porcentajeCPU,usoMemoria,estado\nsrv-0054,SA-EAST-1,59,59,ALERTA\nsrv-0027,SA-EAST-1,98,17934,CRITICO\n");
        var r = new ParserServidores().leer(p);
        assertEquals(1, r.getProcesadas());
        assertEquals(590, r.getServidores().get(0).costoRiesgoOperativo());
    }

}
