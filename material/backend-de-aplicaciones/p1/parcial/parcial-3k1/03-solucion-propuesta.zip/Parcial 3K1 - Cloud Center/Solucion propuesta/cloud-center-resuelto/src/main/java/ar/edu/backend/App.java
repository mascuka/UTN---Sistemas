package ar.edu.backend;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

/**
 * Lee el CSV (por defecto el del parcial) y muestra el resumen. Los cálculos los
 * hacen ResultadoParseo y Cloud: el main solo muestra.
 */
public class App {
    public static void main(String[] args) throws IOException {
        Path archivo = Path.of(args.length == 0 ? "datos/datos-parcial.csv" : args[0]);
        ResultadoParseo resultado = new ParserServidores().leer(archivo);
        Cloud colector = new Cloud(resultado.getServidores());

        System.out.println(resultado.informe());
        resultado.getDescartes().forEach(System.out::println);
        resultado.getErrores().forEach(System.out::println);

        Map<String, Long> porEstado = colector.conteoPorEstado();
        System.out.println("ALERTA: %d | CRITICO: %d".formatted(
                porEstado.getOrDefault("ALERTA", 0L), porEstado.getOrDefault("CRITICO", 0L)));
        System.out.println(colector.panorama());
    }
}
