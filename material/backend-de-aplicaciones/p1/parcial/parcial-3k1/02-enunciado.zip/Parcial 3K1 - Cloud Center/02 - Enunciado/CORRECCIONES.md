# Correcciones a lo que entregó la cátedra

El test nuevo (`EvolucionTest`) está bien: compila contra el proyecto inicial y pasa con una solución correcta. Lo que se corrigió:

- **La carpeta del test.** Venía como `test-nuevos/EvolucionTest.java`, suelto, y la consigna dice "copiar `tests-nuevos/ar` a `src/test/java/ar`". Ahora está en `tests-nuevos/ar/edu/backend/EvolucionTest.java` (el mismo archivo, sin cambios), así la instrucción se puede seguir tal cual.
- **El nombre del CSV.** Venía como `datos_parcial.csv` y la consigna dice `datos-parcial.csv`. Ahora se llama `datos-parcial.csv`.
- **El ejemplo de la consigna.** Decía que un índice de carga de 65 con un ingreso de 1300 USD da 877 USD, pero la cuenta da 1300 × 65 / 100 = **845**. Corregido en el PDF.

Sin corregir, porque no cambian lo que hay que hacer:

- "todos servidores en este punto tiene un costo de 1000": es un **ingreso** de 1000 (el `INGRESO_PROMEDIO` del preenunciado).
- "totales por zona": en este dominio son los totales por **región**.
- "El conteo por modalidad ... se revisa": acá es el conteo por **estado**.
