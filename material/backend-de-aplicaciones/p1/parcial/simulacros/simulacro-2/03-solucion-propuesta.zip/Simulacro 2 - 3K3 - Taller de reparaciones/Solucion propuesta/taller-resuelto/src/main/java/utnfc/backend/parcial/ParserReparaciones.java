package utnfc.backend.parcial;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ParserReparaciones {
    private static final String CABECERA_INICIAL = "id,cliente,dispositivo,marca,prioridad,horas,estado,costoBase";
    private static final String CABECERA_EVOLUCIONADA = CABECERA_INICIAL + ",garantia,repuestos,modalidad";

    public ResultadoParseo leer(Path ruta) throws IOException {
        List<Reparacion> reparaciones = new ArrayList<>();
        List<String> errores = new ArrayList<>();
        int leidas = 0;
        int descartadas = 0;
        try (BufferedReader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            String cabecera = lector.readLine();
            if (!CABECERA_INICIAL.equals(cabecera) && !CABECERA_EVOLUCIONADA.equals(cabecera)) {
                throw new IllegalArgumentException("encabezado incorrecto");
            }
            int ancho = cabecera.split(",").length;   // 8 u 11
            String linea;
            while ((linea = lector.readLine()) != null) {
                leidas++;
                try {
                    String[] campos = Arrays.stream(linea.split(",", -1))
                            .map(String::strip)
                            .collect(Collectors.toList())
                            .toArray(new String[0]);
                    if (campos.length != ancho) {
                        throw new IllegalArgumentException("columnas incorrectas");
                    }
                    if (campos[6].equals("CANCELADA")) {
                        descartadas++;
                        continue;
                    }
                    if (!campos[6].equals("ABIERTA") && !campos[6].equals("LISTA") && !campos[6].equals("ENTREGADA")) {
                        throw new IllegalArgumentException("estado desconocido");
                    }
                    reparaciones.add(Reparacion.desdeCampos(campos));
                } catch (IllegalArgumentException error) {
                    errores.add("Linea " + (leidas + 1) + ": " + error.getMessage());
                }
            }
        }
        return new ResultadoParseo(reparaciones, leidas, descartadas, errores);
    }
}
