package utnfc.backend.parcial;

public class Reparacion {
    private final String id;
    private final String cliente;
    private final String dispositivo;
    private final String marca;
    private final String estado;
    private final int prioridad;
    private final int horas;
    private final double costoBase;
    private final boolean garantia;
    private final double repuestos;

    public Reparacion(String id, String cliente, String dispositivo, String marca,
            int prioridad, int horas, String estado, double costoBase) {
        this(id, cliente, dispositivo, marca, prioridad, horas, estado, costoBase, false, 0);
    }

    public Reparacion(String id, String cliente, String dispositivo, String marca,
            int prioridad, int horas, String estado, double costoBase, boolean garantia, double repuestos) {
        if (id == null || id.isBlank() || cliente == null || cliente.isBlank()
                || prioridad < 1 || prioridad > 3 || horas <= 0 || costoBase < 0) {
            throw new IllegalArgumentException("datos invalidos");
        }
        if (repuestos < 0) {
            throw new IllegalArgumentException("repuestos negativos");
        }
        this.id = id.strip();
        this.cliente = cliente.strip();
        this.dispositivo = dispositivo.strip();
        this.marca = marca.strip();
        this.prioridad = prioridad;
        this.horas = horas;
        this.estado = estado.strip();
        this.costoBase = costoBase;
        this.garantia = garantia;
        this.repuestos = repuestos;
    }

    public static Reparacion desdeCampos(String[] campos) {
        if (campos.length != 8 && campos.length != 11) {
            throw new IllegalArgumentException("columnas incorrectas");
        }
        if (campos.length == 8) {
            return new Reparacion(campos[0], campos[1], campos[2], campos[3],
                    Integer.parseInt(campos[4]), Integer.parseInt(campos[5]), campos[6],
                    Double.parseDouble(campos[7]));
        }
        boolean garantia = switch (campos[8]) {
            case "SI" -> true;
            case "NO" -> false;
            default -> throw new IllegalArgumentException("garantia invalida: " + campos[8]);
        };
        int prioridad = Integer.parseInt(campos[4]);
        int horas = Integer.parseInt(campos[5]);
        double costoBase = Double.parseDouble(campos[7]);
        double repuestos = Double.parseDouble(campos[9]);
        return switch (campos[10]) {
            case "NORMAL" -> new Reparacion(campos[0], campos[1], campos[2], campos[3],
                    prioridad, horas, campos[6], costoBase, garantia, repuestos);
            case "EXPRESS" -> new ReparacionExpress(campos[0], campos[1], campos[2], campos[3],
                    prioridad, horas, campos[6], costoBase, garantia, repuestos);
            default -> throw new IllegalArgumentException("modalidad invalida: " + campos[10]);
        };
    }

    public double importe() {
        double manoDeObra = horas * 850;
        double total = costoBase + manoDeObra + prioridad * 300 + repuestos;
        if (garantia) {
            total -= manoDeObra * 0.20;
        }
        return total;
    }

    public String getId() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public String getDispositivo() {
        return dispositivo;
    }

    public String getMarca() {
        return marca;
    }

    public String getEstado() {
        return estado;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public int getHoras() {
        return horas;
    }

    public double getCostoBase() {
        return costoBase;
    }

    public boolean isGarantia() {
        return garantia;
    }

    public double getRepuestos() {
        return repuestos;
    }

    public String getModalidad() {
        return "NORMAL";
    }
}
