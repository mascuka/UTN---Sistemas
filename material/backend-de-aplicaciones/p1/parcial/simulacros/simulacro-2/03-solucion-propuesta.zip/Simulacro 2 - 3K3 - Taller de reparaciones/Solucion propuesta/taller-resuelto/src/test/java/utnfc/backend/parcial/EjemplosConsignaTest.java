package utnfc.backend.parcial;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/** Tests propios: el ejemplo de la consigna (con garantía y EXPRESS) y los valores inválidos */
class EjemplosConsignaTest {
    private static Reparacion reparacion(String garantia, String repuestos, String modalidad) {
        return Reparacion.desdeCampos(new String[] {
                "R1", "Ana", "celular", "Nexo", "2", "3", "LISTA", "1000", garantia, repuestos, modalidad });
    }

    @Test
    void elEjemploDeLaConsigna() {
        // costo base 1000 + mano de obra 3 * 850 + prioridad 2 * 300 + repuestos 200
        assertEquals(4350, reparacion("NO", "200", "NORMAL").importe(), 0.001);
        // con garantía: 20 % menos de la mano de obra (510)
        assertEquals(3840, reparacion("SI", "200", "NORMAL").importe(), 0.001);
        // EXPRESS: 25 % más sobre el importe común, una sola vez
        assertEquals(4800, reparacion("SI", "200", "EXPRESS").importe(), 0.001);
        assertEquals("EXPRESS", reparacion("SI", "200", "EXPRESS").getModalidad());
    }

    @Test
    void valoresInvalidos() {
        assertThrows(IllegalArgumentException.class, () -> reparacion("TAL VEZ", "200", "NORMAL"));
        assertThrows(IllegalArgumentException.class, () -> reparacion("", "200", "NORMAL"));
        assertThrows(IllegalArgumentException.class, () -> reparacion("SI", "-1", "NORMAL"));
        assertThrows(IllegalArgumentException.class, () -> reparacion("SI", "200", "URGENTE"));
        assertThrows(IllegalArgumentException.class, () -> reparacion("SI", "abc", "NORMAL"));
    }
}
