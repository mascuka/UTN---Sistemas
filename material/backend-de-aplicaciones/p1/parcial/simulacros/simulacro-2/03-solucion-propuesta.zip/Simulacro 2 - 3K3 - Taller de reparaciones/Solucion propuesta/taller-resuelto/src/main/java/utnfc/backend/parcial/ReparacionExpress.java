package utnfc.backend.parcial;

/** Reparación EXPRESS: el importe común de Reparacion más un recargo del 25 %, una sola vez. */
public class ReparacionExpress extends Reparacion {
    private static final double RECARGO = 1.25;

    public ReparacionExpress(String id, String cliente, String dispositivo, String marca,
            int prioridad, int horas, String estado, double costoBase, boolean garantia, double repuestos) {
        super(id, cliente, dispositivo, marca, prioridad, horas, estado, costoBase, garantia, repuestos);
    }

    @Override
    public double importe() {
        return super.importe() * RECARGO;
    }

    @Override
    public String getModalidad() {
        return "EXPRESS";
    }
}
