# Correcciones a lo que entregó la cátedra

Este parcial se dio como Simulacro 1 en 3K1 y se tomó como parcial en 3K8. Lo que se corrigió:

- **El test nuevo no compilaba.** `EvolucionTest` no tenía `package` ni los imports de JUnit, y usaba `ResultadoParseo`, que en este proyecto se llama `ResultadoProceso`. Se agregaron y se cambió el nombre.
- **Un caso del test contradecía la consigna.** `limitesYClasificacion` usaba el tipo de cliente "P" (solo valen REGULAR y PREMIUM, y los ejemplos de la consigna hablan de clientes PREMIUM) y esperaba 2 procesadas y 2 inválidas. Con las reglas de la consigna, de esas filas solo CL1 es válida: CL2 tiene un estado desconocido (`PRE_AROBADO`), CL3 es EN_MORA con 15000 de ingresos y el RECHAZADO es NORMAL. Ahora usa PREMIUM y espera 1 procesada y 3 inválidas.
- **Carpetas y nombres.** La carpeta venía como `test_nuevos` y el CSV como `datos_parcial.csv`, y la consigna dice `tests-nuevos` y `datos-parcial.csv`. Se renombraron.
- **La consigna** (el `.md` y el PDF). Decía copiar los tests a `src/test/java/ar/edu/backend`, pero así quedan en `ar/edu/backend/ar/edu/backend`: van en `src/test/java/ar`. El comando decía `ar.edu.backend.fintech.App`, pero el paquete es `ar.edu.backend`. Pedía mostrar "total y totales por zona", que vino copiado del parcial de envíos: en este dominio se muestra el informe de la cartera. Y "el conteo por modalidad" es el conteo por nivel de morosidad.

Con el test corregido, el proyecto inicial compila y falla en 2 tests, y una solución correcta pasa los 14 de la cátedra.

En el preenunciado se corrigieron el `enunciado.md` del proyecto y el PDF:

- Los comandos decían `ar.edu.backend.fintech.Main`: es `ar.edu.backend.App`.
- El recorrido dice leer `CentralCreditos`: la clase es `CarteraCreditos`.
