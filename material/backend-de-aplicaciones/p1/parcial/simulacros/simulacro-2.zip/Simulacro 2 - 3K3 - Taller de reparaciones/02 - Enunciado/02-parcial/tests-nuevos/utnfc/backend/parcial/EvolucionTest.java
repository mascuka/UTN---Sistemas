package utnfc.backend.parcial;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/*
 * Corregido (ver CORRECCIONES.md). El original:
 * - armaba filas de 10 campos, y el formato nuevo tiene 11: faltaba la modalidad (se agregó "NORMAL");
 * - usaba reparacion.tieneGarantia(), que no existe en el proyecto inicial (la consigna pide que los tests
 *   compilen contra el inicial "sin depender de una API exclusiva de la solución docente"): ahora la garantía
 *   se comprueba por el importe, con y sin garantía.
 * Los valores esperados son los mismos.
 */
class EvolucionTest {
    @Test
    void agregaGarantiaYRepuestos() {
        var conGarantia = Reparacion.desdeCampos(new String[] {
                "P", "A", "celular", "Nexo", "1", "5", "ENTREGADA", "0", "SI", "100", "NORMAL"
        });
        var sinGarantia = Reparacion.desdeCampos(new String[] {
                "P", "A", "celular", "Nexo", "1", "5", "ENTREGADA", "0", "NO", "100", "NORMAL"
        });

        // 5 h * 850 + prioridad 1 * 300 + 100 de repuestos = 4650; con garantía, 20 % menos de la mano de obra (850)
        assertEquals(4650, sinGarantia.importe());
        assertEquals(3800, conGarantia.importe());
    }

    @Test
    void reconoceEntregada() {
        var reparacion = Reparacion.desdeCampos(new String[] {
                "P", "A", "celular", "Nexo", "1", "1", "ENTREGADA", "0", "NO", "0", "NORMAL"
        });

        assertEquals("ENTREGADA", reparacion.getEstado());
    }
}
