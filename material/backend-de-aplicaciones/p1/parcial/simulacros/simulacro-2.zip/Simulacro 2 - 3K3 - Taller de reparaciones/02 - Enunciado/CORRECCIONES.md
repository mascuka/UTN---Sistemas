# Correcciones a lo que entregó la cátedra

- **El test nuevo no compilaba contra el proyecto inicial.** Usaba `reparacion.tieneGarantia()`, que no existe en el preenunciado, y la consigna pide que los tests nuevos "compilen contra el proyecto inicial ... sin depender de una API exclusiva de la solución docente". Ahora la garantía se comprueba por el importe: el mismo trabajo cuesta 4650 sin garantía y 3800 con garantía.
- **Las filas del test tenían 10 campos.** El formato nuevo tiene 11: faltaba la modalidad, y se agregó `NORMAL`. Los valores esperados (3800 y ENTREGADA) son los mismos.

Con el test corregido, el proyecto inicial compila y falla (no acepta 11 columnas), y una solución correcta pasa los 5 tests.
