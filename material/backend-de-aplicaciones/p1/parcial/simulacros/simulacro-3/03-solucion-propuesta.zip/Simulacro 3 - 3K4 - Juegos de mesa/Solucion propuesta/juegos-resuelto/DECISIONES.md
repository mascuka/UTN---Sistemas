# Decisiones

- Herencia: `JuegoCooperativo extends JuegoMesa` guarda la dificultad y redefine `getPuntuacionAjustada()` como `super.getPuntuacionAjustada() + dificultad / 2.0`. `getTipo()` es polimórfico ("Normal" o "Cooperativo").
- `JuegoMesa.desdeCampos` acepta 9 o 10 campos: si la 10ª columna trae un valor, valida la dificultad (un entero de 1 a 10) y crea un `JuegoCooperativo`. El parser detecta el formato por el encabezado y exige ese ancho en cada fila.
- `ServicioJuegos` suma `calcularSumaPuntuacionAjustada()` y `contarJuegosPorTipo()`, con los nombres que usa el test nuevo (en este simulacro el test sí exige esas firmas), y el panorama muestra el total de puntos y los conteos por tipo. El main usa `datos/datos-parcial.csv`.
- Con el CSV del parcial: 140 leídas, 100 procesadas, 16 descartadas y 24 inválidas; 55 normales y 45 cooperativos; 1887,50 puntos en total. Pasan los tests viejos y los 6 nuevos.
