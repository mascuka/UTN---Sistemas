package ar.edu.backend.envios;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        Path archivo = Path.of(args.length == 0 ? "datos/datos-parcial.csv" : args[0]);
        ResultadoParseo resultado = new ParserEnvios().leer(archivo);
        CentralEnvios central = new CentralEnvios(resultado.getEnvios());
        System.out.println(resultado.resumen());
        resultado.getDescartes().forEach(System.out::println);
        resultado.getErrores().forEach(System.out::println);
        Map<String, Long> porModalidad = central.conteoPorModalidad();
        System.out.println("Objetos: " + resultado.getEnvios().size());
        System.out.println("NORMAL: " + porModalidad.getOrDefault("NORMAL", 0L)
                + " | PRIORITARIO: " + porModalidad.getOrDefault("PRIORITARIO", 0L));
        System.out.println(central.panorama());
    }
}
