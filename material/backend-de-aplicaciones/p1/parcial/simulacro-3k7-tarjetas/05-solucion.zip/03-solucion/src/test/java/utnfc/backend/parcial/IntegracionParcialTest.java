package utnfc.backend.parcial;
import org.junit.jupiter.api.Test;
import java.nio.file.Path;
import java.io.IOException;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
class IntegracionParcialTest {
    @Test void datosCompletos() throws IOException {
        var r=new ParserLiquidaciones().leer(Path.of("src/resources/datos-parcial.csv"));
        assertEquals(140,r.getLeidas()); assertEquals(100,r.getProcesadas());
        assertEquals(16,r.getDescartadas()); assertEquals(24,r.getInvalidas());
        var l=new LiquidadorTarjetas(r.getConsumos());
        assertEquals(1408456,l.getTotalLiquidacion()); assertEquals(14084,l.getPromedioComision());
        assertEquals(Map.of("SIN_SEGURO",55L,"ASEGURADO",45L),l.cantidadesPorModalidad());
        assertEquals(Map.of("Alimentos",475104,"Combustible",436562,"Servicios",496790),l.totalesPorRubro());
        assertEquals(29,l.filtrar(c -> c.getCentavos() <= 100000).size());
        assertEquals(r.getLeidas(),r.getProcesadas()+r.getDescartadas()+r.getInvalidas());
        assertEquals(2000,l.filtrar(c -> c.getId().equals("P001")).get(0).comision());
        assertEquals(2600,l.filtrar(c -> c.getId().equals("P002")).get(0).comision());
        assertEquals(500000,l.filtrar(c -> c.getId().equals("P003")).get(0).getCentavos());
        assertEquals(10600,l.filtrar(c -> c.getId().equals("P003")).get(0).comision());
        assertEquals(3000000,l.filtrar(c -> c.getId().equals("P006")).get(0).getCentavos());
        assertTrue(l.filtrar(c -> c.getId().equals("P117")).isEmpty());
        assertTrue(r.getErrores().containsKey(118));
        assertEquals("ANULADO", r.getDescartes().get(102));
        assertEquals("ANULADO", r.getDescartes().get(103));
        assertTrue(r.getErrores().containsKey(134));
        assertTrue(new LiquidadorTarjetas(java.util.List.of()).cantidadesPorModalidad().isEmpty());
    }
}
