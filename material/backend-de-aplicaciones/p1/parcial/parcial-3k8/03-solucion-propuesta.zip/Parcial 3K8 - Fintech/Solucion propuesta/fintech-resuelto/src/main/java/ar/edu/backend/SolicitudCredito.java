package ar.edu.backend;

public class SolicitudCredito {

    private final String idCliente;
    private final String tipoCliente;
    private final double scoreFinanciero;
    private final String estado;
    private final String nivelMorosidad;

    private final static double TASA_BASE = 40;

    public SolicitudCredito(String idClient, String tipoCliente, double scoreFinanciero, String estado) {
        this(idClient, tipoCliente, scoreFinanciero, estado, "NORMAL");
    }

    public SolicitudCredito(String idClient, String tipoCliente, double scoreFinanciero, String estado,
            String nivelMorosidad) {

        if (idClient == null || idClient.isBlank() || tipoCliente == null || tipoCliente.isBlank())
            throw new IllegalArgumentException("El Id del Cliente como su Categorizacion (tipo) son requeridos");

        this.idCliente = idClient;
        this.tipoCliente = tipoCliente;
        this.scoreFinanciero = scoreFinanciero;
        this.estado = estado;
        this.nivelMorosidad = nivelMorosidad;
    }

    public static SolicitudCredito desdeCampos(String[] tokens) {
        if (tokens.length != 5 && tokens.length != 6)
            throw new IllegalArgumentException("Se esperan 5 o 6 columnas a procesar");

        double ingresos = Double.parseDouble(tokens[2]);
        double deudas = Double.parseDouble(tokens[3]);
        // El formato viejo no trae la columna: todos son NORMAL
        String nivelMorosidad = tokens.length == 6 ? tokens[5].strip() : "NORMAL";
        if (tokens.length == 6)
            validarMorosidad(tokens[4], nivelMorosidad);

        if (nivelMorosidad.equals("EN_MORA")) {
            if (ingresos <= 25000 || deudas < 0 || deudas > ingresos * 0.12)
                throw new IllegalArgumentException("EN_MORA: ingresos de mas de 25000 y deudas de hasta el 12%");
        } else {
            if (ingresos < 1000 || ingresos > 15000)
                throw new IllegalArgumentException("Los ingresos mensuales no son aptos para solicitar el credito");

            if (deudas < 0 || deudas >= ingresos)
                throw new IllegalArgumentException("La deudas registradas no permiten solicitar el credito");
        }

        double scoreFinanciero = (1 - (deudas / ingresos)) * 100;
        return new SolicitudCredito(tokens[0], tokens[1], scoreFinanciero, tokens[4], nivelMorosidad);
    }

    /** Qué nivel de morosidad admite cada estado (solo en el formato de 6 columnas) */
    private static void validarMorosidad(String estado, String nivel) {
        switch (estado) {
            case "RECHAZADO" -> {
                if (!nivel.equals("EN_MORA"))
                    throw new IllegalArgumentException("RECHAZADO solo admite EN_MORA: " + nivel);
            }
            case "APROBADO", "PRE_APROBADO" -> {
                if (!nivel.equals("NORMAL") && !nivel.equals("EN_MORA"))
                    throw new IllegalArgumentException("nivel de morosidad invalido: " + nivel);
            }
            default -> throw new IllegalArgumentException("estado de solicitud desconocido: " + estado);
        }
    }

    public String getIdCliente() {
        return idCliente;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public double getScoreFinanciero() {
        return scoreFinanciero;
    }

    public String getEstado() {
        return estado;
    }

    public String getNivelMorosidad() {
        return nivelMorosidad;
    }

    public double getTasaInteresAnual() {
        return SolicitudCredito.TASA_BASE + (100 - this.scoreFinanciero) * 0.8;
    }

}
