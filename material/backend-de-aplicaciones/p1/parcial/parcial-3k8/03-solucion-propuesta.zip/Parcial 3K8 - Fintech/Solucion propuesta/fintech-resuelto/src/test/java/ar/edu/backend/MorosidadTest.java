package ar.edu.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Tests propios: los casos validos de EN_MORA y el conteo, que los tests de la catedra no prueban */
public class MorosidadTest {
    @TempDir
    Path dir;

    private static String[] fila(String ingresos, String deudas, String estado, String nivel) {
        return new String[] { "CL", "PREMIUM", ingresos, deudas, estado, nivel };
    }

    @Test
    void enMoraConIngresosAltosYDeudaBaja() {
        var s = SolicitudCredito.desdeCampos(fila("30000", "3600", "APROBADO", "EN_MORA"));
        assertEquals("EN_MORA", s.getNivelMorosidad());
        assertEquals(88.0, Math.round(s.getScoreFinanciero() * 100.0) / 100.0);
        // RECHAZADO solo admite EN_MORA, y con EN_MORA valen sus reglas
        assertEquals("RECHAZADO", SolicitudCredito.desdeCampos(fila("26000", "0", "RECHAZADO", "EN_MORA")).getEstado());
    }

    @Test
    void enMoraFueraDeLasReglas() {
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("25000", "0", "APROBADO", "EN_MORA")));
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("30000", "3601", "APROBADO", "EN_MORA")));
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("15000", "3000", "APROBADO", "EN_MORA")));
    }

    @Test
    void combinacionesDeEstadoYNivel() {
        assertEquals("NORMAL", SolicitudCredito.desdeCampos(fila("15000", "3000", "PRE_APROBADO", "NORMAL")).getNivelMorosidad());
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("15000", "3000", "RECHAZADO", "NORMAL")));
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("15000", "3000", "APROBADO", "")));
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("15000", "3000", "APROBADO", "MOROSO")));
        assertThrows(IllegalArgumentException.class, () -> SolicitudCredito.desdeCampos(fila("15000", "3000", "PENDIENTE", "NORMAL")));
        // El constructor viejo sigue andando: NORMAL por defecto
        assertEquals("NORMAL", new SolicitudCredito("A", "REGULAR", 50, "APROBADO").getNivelMorosidad());
    }

    @Test
    void conteoPorMorosidad() throws IOException {
        Path p = dir.resolve("nuevo.csv");
        Files.writeString(p, "idCliente,tipoCliente,ingresosMensuales,totalDeudasActuales,estadoSolicitud,nivelMorosidad\n"
                + "A,PREMIUM,15000,3000,APROBADO,NORMAL\nB,REGULAR,30000,1000,RECHAZADO,EN_MORA\nC,REGULAR,9000,100,PRE_APROBADO, NORMAL \n");
        var r = new ParserSolicitudes().procesar(p);
        assertEquals(3, r.getProcesadas());
        assertEquals(Map.of("EN_MORA", 1L, "NORMAL", 2L), new CarteraCreditos(r.getCreditos()).conteoPorMorosidad());
        assertTrue(new CarteraCreditos(List.of()).conteoPorMorosidad().isEmpty());
    }
}
