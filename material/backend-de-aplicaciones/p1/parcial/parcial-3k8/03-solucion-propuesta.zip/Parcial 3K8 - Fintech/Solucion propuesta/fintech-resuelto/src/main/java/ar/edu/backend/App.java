package ar.edu.backend;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public class App {
    public static void main(String[] args) throws IOException {
        Path archivo = Path.of(args.length == 0 ? "datos/datos-parcial.csv" : args[0]);
        ResultadoProceso resultado = new ParserSolicitudes().procesar(archivo);
        CarteraCreditos cartera = new CarteraCreditos(resultado.getCreditos());

        System.out.println(resultado.informe());
        resultado.getDescartes().forEach(System.out::println);
        resultado.getErrores().forEach(System.out::println);

        Map<String, Long> porMorosidad = cartera.conteoPorMorosidad();
        System.out.println("Objetos: " + resultado.getCreditos().size());
        System.out.println("NORMAL: " + porMorosidad.getOrDefault("NORMAL", 0L)
                + " | EN_MORA: " + porMorosidad.getOrDefault("EN_MORA", 0L));
        System.out.println(cartera.informe());
    }
}
