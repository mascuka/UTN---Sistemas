package utnfc.backend.parcial;

public class Reparacion {
    private final String id;
    private final String cliente;
    private final String dispositivo;
    private final String marca;
    private final String estado;
    private final int prioridad;
    private final int horas;
    private final double costoBase;

    public Reparacion(String id, String cliente, String dispositivo, String marca,
            int prioridad, int horas, String estado, double costoBase) {
        if (id == null || id.isBlank() || cliente == null || cliente.isBlank()
                || prioridad < 1 || prioridad > 3 || horas <= 0 || costoBase < 0) {
            throw new IllegalArgumentException("datos invalidos");
        }
        this.id = id.strip();
        this.cliente = cliente.strip();
        this.dispositivo = dispositivo.strip();
        this.marca = marca.strip();
        this.prioridad = prioridad;
        this.horas = horas;
        this.estado = estado.strip();
        this.costoBase = costoBase;
    }

    public static Reparacion desdeCampos(String[] campos) {
        if (campos.length != 8) {
            throw new IllegalArgumentException("columnas incorrectas");
        }
        return new Reparacion(campos[0], campos[1], campos[2], campos[3],
                Integer.parseInt(campos[4]), Integer.parseInt(campos[5]), campos[6],
                Double.parseDouble(campos[7]));
    }

    public double importe() {
        return costoBase + horas * 850 + prioridad * 300;
    }

    public String getId() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public String getDispositivo() {
        return dispositivo;
    }

    public String getMarca() {
        return marca;
    }

    public String getEstado() {
        return estado;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public int getHoras() {
        return horas;
    }

    public double getCostoBase() {
        return costoBase;
    }
}
